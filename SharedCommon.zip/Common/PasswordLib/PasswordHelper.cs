﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;

namespace PasswordLib
{
    public class PasswordHelper
    {
        private const int ITERATIONS = 60000;
        public static bool VerifyPassword(string inputPassword, string passwordInDB, string saltInDB)
        {
            byte[] pwInDbByteArr = DeserializeFromString(passwordInDB);
            byte[] saltInDbByteArr = DeserializeFromString(saltInDB);

            Rfc2898DeriveBytes pbkdf2 = new Rfc2898DeriveBytes(inputPassword, saltInDbByteArr, ITERATIONS);
            byte[] inputPasswordHash = pbkdf2.GetBytes(128);

            int diff = pwInDbByteArr.Length ^ inputPasswordHash.Length;
            for (int i = 0; i < pwInDbByteArr.Length && i < inputPasswordHash.Length; i++)
                diff |= pwInDbByteArr[i] ^ inputPasswordHash[i];

            return diff == 0;
        }

        public static void CreatePasswordHash(string password, out string passwordHash, out string salt)
        {
            // Generate a salt
            RNGCryptoServiceProvider provider = new RNGCryptoServiceProvider();
            byte[] saltByteArr = new byte[128];
            provider.GetBytes(saltByteArr);
            salt = SerializeToString(saltByteArr);
            // Generate the hash
            Rfc2898DeriveBytes pbkdf2 = new Rfc2898DeriveBytes(password, saltByteArr, ITERATIONS);
            passwordHash = SerializeToString(pbkdf2.GetBytes(128));
        }

        private static byte[] DeserializeFromString(string settings)
        {
            byte[] b = Convert.FromBase64String(settings);
            using (var stream = new MemoryStream(b))
            {
                var formatter = new BinaryFormatter();
                stream.Seek(0, SeekOrigin.Begin);
                return (byte[])formatter.Deserialize(stream);
            }
        }

        private static string SerializeToString(byte[] settings)
        {
            using (var stream = new MemoryStream())
            {
                var formatter = new BinaryFormatter();
                formatter.Serialize(stream, settings);
                stream.Flush();
                stream.Position = 0;
                return Convert.ToBase64String(stream.ToArray());
            }
        }
    }
}
