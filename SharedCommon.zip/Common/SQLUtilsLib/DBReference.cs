﻿namespace SQLUtilsLib
{
    using System.IO;
    using System.Text;

    public static class DBReference
    {
        public static string ConnStr_SSISDB { get; set; }
        public static string ConnStr_DV { get; set; }
        public static string ConnStr_LND { get; set; }
        public static string ConnStr_STG { get; set; }
        public static string ConnStr_EXP { get; set; }
        public static string ConnStr_GES_LND { get; set; }
        public static string ConnStr_GES_STG { get; set; }
        public static string ConnStr_GES_DV { get; set; }
        public static string ConnStr_BVReportDB { get; set; }
        public static string ConnStr_CDRDW { get; set; }

        public static void InitiateDBReference(string connStr_LND, string connStr_SSISDB =null, string connStr_DV = null, string connStr_STG = null
            ,string connStr_EXP = null, string connStr_GES_LND = null, string connStr_GES_STG = null, string connStr_GES_DV = null
            ,string connStr_BVReportDB = null, string connStr_CDRDW = null)
        {
            if(!string.IsNullOrEmpty(connStr_LND))
                ConnStr_LND = RemoveProviderFromConnStr(connStr_LND);
            if (!string.IsNullOrEmpty(connStr_SSISDB))
                ConnStr_SSISDB = RemoveProviderFromConnStr(connStr_SSISDB);
            if (!string.IsNullOrEmpty(connStr_DV))
                ConnStr_DV = RemoveProviderFromConnStr(connStr_DV);
            if (!string.IsNullOrEmpty(connStr_STG))
                ConnStr_STG = RemoveProviderFromConnStr(connStr_STG);
            if (!string.IsNullOrEmpty(connStr_EXP))
                ConnStr_EXP = RemoveProviderFromConnStr(connStr_EXP);
            if (!string.IsNullOrEmpty(connStr_GES_LND))
                ConnStr_GES_LND = RemoveProviderFromConnStr(connStr_GES_LND);
            if (!string.IsNullOrEmpty(connStr_GES_STG))
                ConnStr_GES_STG = RemoveProviderFromConnStr(connStr_GES_STG);
            if (!string.IsNullOrEmpty(connStr_GES_DV))
                ConnStr_GES_DV = RemoveProviderFromConnStr(connStr_GES_DV);
            if (!string.IsNullOrEmpty(connStr_BVReportDB))
                ConnStr_BVReportDB = RemoveProviderFromConnStr(connStr_BVReportDB);
            if (!string.IsNullOrEmpty(connStr_CDRDW))
                ConnStr_CDRDW = RemoveProviderFromConnStr(connStr_CDRDW);
        }

        public static string RemoveProviderFromConnStr(string connStr)
        {
            var dsb = new System.Data.Common.DbConnectionStringBuilder();
            dsb.ConnectionString = connStr;
            dsb.Remove("Provider");
            return dsb.ConnectionString;
        }
    }

    public static class BinaryReaderUtilities
    {
        public static object ReadValue(BinaryReader binaryReader, int length, string type)
        {
            object data = null;
            switch (type)
            {
                case "Byte":
                    byte[] byte_arr = binaryReader.ReadBytes(length);

                    data = Encoding.ASCII.GetString(byte_arr);//.Replace("\0","");
                    break;
                case "Int32":
                    data = binaryReader.ReadInt32();
                    break;
                case "Double64":
                    data = binaryReader.ReadDouble();
                    break;
            }

            return data;
        }

        public static object ReadValue(BinaryReader binaryReader, int startOffset, int length, string type)
        {
            object data = null;
            binaryReader.BaseStream.Seek(startOffset, SeekOrigin.Begin);
            switch (type)
            {
                case "Byte":
                    byte[] byte_arr = binaryReader.ReadBytes(length);

                    data = Encoding.ASCII.GetString(byte_arr);//.Replace("\0","");
                    break;
                case "Int32":
                    data = binaryReader.ReadInt32();
                    break;
                case "Double64":
                    data = binaryReader.ReadDouble();
                    break;
            }

            return data;
        }
    }
}
