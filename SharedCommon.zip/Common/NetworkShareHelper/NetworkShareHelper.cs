﻿using System;
using System.ComponentModel;
using System.Net;

namespace NetworkShareHelper
{
    public static class NetworkShareHelper
    {
        public static bool CheckConnection(string root, string username, string password)
        {
            bool result = false;
            try
            {
                using (new NetworkConnection(root, new NetworkCredential(username, password)))
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                var w32ex = ex as Win32Exception;
                if (w32ex == null)
                {
                    w32ex = ex.InnerException as Win32Exception;
                }
                if (w32ex != null)
                {
                    int code = w32ex.NativeErrorCode;
                    // that error 1219 means the network path is already connected and we can already access it
                    if (code == 1219)
                    {
                        result = true;
                    }
                }
            }
            return result;
        }
    }
}
