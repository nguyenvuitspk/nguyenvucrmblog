﻿using DataReaderUtilsLib;
using SQLUtilsLib;

namespace NetworkShareHelper
{
    public class SharedGNetworkAccess
    {
        public string RootFolder { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public SharedGNetworkAccess()
        {
            RootFolder = string.Empty;
            Username = string.Empty;
            Password = string.Empty;
        }

        /// <summary>
        /// Init network credential base on connection name
        /// </summary>
        public SharedGNetworkAccess(string connectionName)
        {
            var serverConfig = DataReaderUtilities.GetRowValue(DBReference.ConnStr_DV,
                                    string.Format(@"SELECT	[CONN_VALUE]
		                                                    ,[USER_NAME]
		                                                    ,[USER_SECRET]
                                                    FROM [dbo].[SAT_LOCATION_AUTHS]
                                                    WHERE [CONN_NAME] = '{0}'", connectionName));

            RootFolder = serverConfig["CONN_VALUE"].ToString();
            Username = serverConfig["USER_NAME"].ToString();
            Password = serverConfig["USER_SECRET"].ToString();
        }
    }
}
