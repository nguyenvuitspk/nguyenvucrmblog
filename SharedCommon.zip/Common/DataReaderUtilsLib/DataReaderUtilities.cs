﻿namespace DataReaderUtilsLib
{
    using System.Data;
    using System.Data.SqlClient;

    public class DataReaderUtilities
    {
        public static DataSet GetData(string connnectionString, string sqlQuery)
        {
            var dsb = new System.Data.Common.DbConnectionStringBuilder();

            dsb.ConnectionString = connnectionString;
            dsb.Remove("Provider");

            var ds = new DataSet();
            using (var conn = new SqlConnection(dsb.ConnectionString))
            {
                ds = GetData(conn, sqlQuery);
            }

            return ds;
        }

        public static DataSet GetData(SqlConnection sqlConnection, string sqlQuery)
        {
            var ds = new DataSet();

            var adapter = new SqlDataAdapter(sqlQuery, sqlConnection);
            adapter.SelectCommand.CommandTimeout = 0;
            adapter.Fill(ds);

            return ds;
        }

        public static object GetScalaValue(string connnectionString, string sqlQuery)
        {
            var dsb = new System.Data.Common.DbConnectionStringBuilder();

            dsb.ConnectionString = connnectionString;
            dsb.Remove("Provider");

            object value;
            using (var conn = new SqlConnection(dsb.ConnectionString))
            {
                value = GetScalaValue(conn, sqlQuery);
            }

            return value;
        }

        public static object GetScalaValue(SqlConnection sqlConnection, string sqlQuery)
        {
            var ds = new DataSet();

            var adapter = new SqlDataAdapter(sqlQuery, sqlConnection);
            adapter.SelectCommand.CommandTimeout = 0;
            adapter.Fill(ds);
            
            if (!(ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0))
            {
                var value = ds.Tables[0].Rows[0][0];
                return value;
            }

            return null;
        }

        public static DataRow GetRowValue(string connnectionString, string sqlQuery)
        {
            var dsb = new System.Data.Common.DbConnectionStringBuilder();

            dsb.ConnectionString = connnectionString;
            dsb.Remove("Provider");

            DataRow dr;
            using (var conn = new SqlConnection(dsb.ConnectionString))
            {
                dr = GetRowValue(conn, sqlQuery);
            }

            return dr;
        }

        public static DataRow GetRowValue(SqlConnection sqlConnection, string sqlQuery)
        {
            var ds = new DataSet();
            
            var adapter = new SqlDataAdapter(sqlQuery, sqlConnection);
            adapter.SelectCommand.CommandTimeout = 0;
            adapter.Fill(ds);

            if (!(ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0))
            {
                return ds.Tables[0].Rows[0];
            }

            return null;
        }

        public static string[] FixSingleQuote(string[] columnList)
        {
            for (var i = 0; i < columnList.Length; i++)
            {
                if (columnList[i] != null)
                {
                    columnList[i] = columnList[i].Replace("'", "''");
                }
                
            }
            return columnList;
        }
    }
}
