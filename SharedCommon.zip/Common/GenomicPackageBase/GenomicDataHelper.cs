﻿using DataReaderUtilsLib;
using SQLUtilsLib;
using System;

namespace GenomicPackageBase
{
    public class GenomicDataHelper
    {
        /// <summary>
        /// Compute DGV with C = anpha * A * B + beta.C
        /// </summary>
        /// <param name="A"></param>
        /// <param name="rowA"></param>
        /// <param name="colA"></param>
        /// <param name="transA"></param>
        /// <param name="B"></param>
        /// <param name="colB"></param>
        /// <param name="transB"></param>
        /// <param name="C"></param>
        /// <param name="colC"></param>
        /// <param name="anpha"></param>
        /// <param name="beta"></param>
        /// <param name="is64bitProccess"></param>
        /// <returns></returns>
        public static void MultiplyMatrix(double[] A, int rowA, int colA, int transA,
                                             double[] B, int colB, int transB,
                                             double[] C, int colC, double anpha, double beta, bool is64bitProccess)
        {
            int m = rowA;
            int n = colB;
            int k = colA;

            if (transA == MKLib.CBLAS.TRANSPOSE.Trans)
            {
                m = colA;
                k = rowA;
            }

            if (transB == MKLib.CBLAS.TRANSPOSE.Trans)
            {
                n = colB;
                k = colA;
            }

            if (is64bitProccess)
                MKLib.CBLAS.dgemm64(MKLib.CBLAS.ORDER.RowMajor, transA, transB, m, n, k, anpha, A, colA, B, colB, beta, C, colC);
            else
                MKLib.CBLAS.dgemm32(MKLib.CBLAS.ORDER.RowMajor, transA, transB, m, n, k, anpha, A, colA, B, colB, beta, C, colC);
        }

        public static Int64 GetWPID(long PID)
        {
            string sqlCommand = string.Format(@"SELECT [WPID]
                                                FROM [dbo].[vOperations]
                                                WHERE [PID] = '{0}'", PID);
            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, sqlCommand);
            return value == null ? -1 : (Int64)value;
        }
    }
}
