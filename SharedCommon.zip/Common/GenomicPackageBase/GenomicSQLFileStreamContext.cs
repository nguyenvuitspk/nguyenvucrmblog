﻿using SQLUtilsLib;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenomicPackageBase
{
    public class GenomicSQLFileStreamContext : IDisposable
    {
        private SqlCommand sqlCommand;
        private byte[] context;
        private SqlConnection sqlConnection;
        private SqlTransaction transaction;

        public GenomicSQLFileStreamContext()
        {
            // Random text tranformation with max size = 12
            string nameTransRandom = Path.GetRandomFileName().Replace(".", "").PadRight(12, 'a');

            // Connect sql file stream
            ConnectSQLFileStream(nameTransRandom);
        }

        /// <summary>
        /// should using constructor with pid
        /// </summary>
        /// <param name="PID"></param>
        public GenomicSQLFileStreamContext(string PID)
        {
            ConnectSQLFileStream(PID);
        }

        private void ConnectSQLFileStream(string nameTransactionFS)
        {
            SqlConnectionStringBuilder dvTrustConnectionString = new SqlConnectionStringBuilder(DBReference.ConnStr_DV);
            dvTrustConnectionString.DataSource = ".";
            dvTrustConnectionString.IntegratedSecurity = true;
            sqlConnection = new SqlConnection(dvTrustConnectionString.ConnectionString);
            sqlConnection.Open();
            transaction = sqlConnection.BeginTransaction("tranFS" + nameTransactionFS);
            sqlCommand = new SqlCommand();
            sqlCommand.Connection = sqlConnection;
            sqlCommand.Transaction = transaction;

            // get context
            sqlCommand.CommandText = "SELECT GET_FILESTREAM_TRANSACTION_CONTEXT()";
            Object obj = sqlCommand.ExecuteScalar();
            context = (byte[])obj;
        }

        public byte[] GetContext()
        {
            return context;
        }

        public void Dispose()
        {
            sqlCommand.Transaction.Commit();
            sqlCommand.Dispose();
            sqlConnection.Close();
            sqlConnection.Dispose();

            GC.SuppressFinalize(this);
        }


    }
}
