﻿namespace GenomicPackageBase
{
    public class GenomicConstants
    {
        public const string GEN_MSG_ERR_WF_NOT_INIT = @"Package was not initiated correctly";
        
        // Path file dll
        public const string MKL_DLL_32_BIT_FILE_PATH = @"C:\Program Files\Microsoft SQL Server\130\DTS\Binn\mkl.dll";
        public const string MKL_DLL_64_BIT_FILE_PATH = @"C:\Program Files\Microsoft SQL Server\130\DTS\Binn\mkl.dll";
    }
}
