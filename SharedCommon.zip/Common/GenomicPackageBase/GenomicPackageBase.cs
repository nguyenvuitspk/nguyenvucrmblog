﻿using DataReaderUtilsLib;
using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Tasks.ScriptTask;
using SQLUtilsLib;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using WorkflowOperation;

namespace GenomicPackageBase
{
    /// 
    /// GenomicPackageBase
    /// Define base processes applied for all genomic transformation packages in both CDR and GES
    /// All main() function of genomic packages must be as below
    /*  public void Main()
        {
            // TODO: Add your code here
            try
            {
                GetInputParameters();
                ValidateInputs();
                Process();
                ValidateOutputs();
                WriteOutputs();
            }
            catch (Exception ex)
            {
                  string _parameters = "";
                  parameters += "; ANIMAL_DATASET_ID = " + datasetId;
                  base.LogException(ex, parameters);
            }
        }
    */
    public abstract class GenomicPackageBase : VSTARTScriptObjectModelBase
    {
        protected string connStrSSISDB = string.Empty,
                            connStrDV = string.Empty;

        protected Int64 PID = -1;
        protected string wPID = string.Empty;
        protected int DV_RUN_ID = -1;

        protected abstract List<WorkflowOperation.Parameter> outputParameters { get; set; }

        /// <summary>
        /// The package will call this as default and implement to get more specific paramters in its GetInputParameters
        /// </summary>
        public virtual void GetInputParameters()
        {
            Variables vars = null;

            vars = null;
            Dts.VariableDispenser.LockOneForRead("$Project::ConnStr_SSISDB", ref vars);
            connStrSSISDB = vars[0].Value.ToString();
            vars.Unlock();

            vars = null;
            Dts.VariableDispenser.LockOneForRead("User::PID", ref vars);
            PID = Convert.ToInt64(vars[0].Value);
            vars.Unlock();

            connStrDV = WorkflowOperation.WorkflowOperation.GetConfigurationValue(connStrSSISDB, "ConnStr_DV");
            DBReference.InitiateDBReference(null, connStrSSISDB, connStrDV);

            var wPIDInfo = GenomicDataHelper.GetWPID(PID);
            
            if (wPIDInfo == -1)
            {
               throw new Exception(GenomicConstants.GEN_MSG_ERR_WF_NOT_INIT);
            }

            wPID = wPIDInfo.ToString();
        }

        /// <summary>
        /// The package will call this as default and implement more specific validation in its ValidatInputs
        /// </summary>
        public virtual void ValidateInputs()
        {
            ///
        }

        /// <summary>
        /// The package will implement it for package specific validation
        /// </summary>
        public virtual void ValidateOutputs()
        {
            // TODO: Do nothing now. 
        }

        /// <summary>
        /// The package will call to write output for next transformation.
        /// </summary>
        public virtual void WriteOutputs()
        {
            Datasets output_DS = new Datasets();

            output_DS.Items = outputParameters;
            WorkflowOperation.WorkflowOperation.WriteOutputDS(PID, output_DS);

            Dts.TaskResult = (int)ScriptResults.Success;
        }

        /// <summary>
        /// Get the environment parameters before calling this function to log the exception in package
        /// </summary>
        public virtual void LogException(Exception ex, string packageParameters = "")
        {
            Variables vars = null;
            Dts.VariableDispenser.LockOneForRead("System::TaskName", ref vars);
            string TaskName = vars[0].Value.ToString();
            vars.Unlock();

            string parameters = string.Empty; 
            parameters += "; SSISDB = " + connStrSSISDB; 
            parameters += "; PID = " + PID.ToString(); 
            parameters += "; wPID = " + DV_RUN_ID.ToString(); 
            parameters += packageParameters; 
            
            DataReaderUtilities.GetData(connStrSSISDB, string.Format(@"exec [dbo].[spLogMessageForTransformationOperations]
                                                                                @PID ={0},
                                                                                @MessageSource = '{1}',
                                                                                @Message = '{2}'"
                                                                            , PID
                                                                            , TaskName
                                                                            , "Error: " + ex.Message.Replace("'", "''") + parameters));

            Dts.Events.FireError(1, TaskName, ex.ToString(), "", 0);
            Dts.TaskResult = (int)ScriptResults.Failure;
        }

        /// <summary>
        /// The package will override this method to do business
        /// </summary>
        public abstract void Process();

        #region ScriptResults declaration
        /// <summary>
        /// This enum provides a convenient shorthand within the scope of this class for setting the
        /// result of the script.
        /// </summary>
        protected enum ScriptResults
        {
            Success = Microsoft.SqlServer.Dts.Runtime.DTSExecResult.Success,
            Failure = Microsoft.SqlServer.Dts.Runtime.DTSExecResult.Failure
        };
        #endregion
    }
}

