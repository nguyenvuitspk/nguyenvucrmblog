﻿using DataReaderUtilsLib;
using SQLUtilsLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenomicPackageBase
{
    public class GenomicDNAHelper
    {
        /// <summary>
        /// Get standard raw DNA length = max(marker ID)
        /// Used by: Import Genotype, Import Imputed DNA
        /// </summary>
        public static int GetRawDNALength()
        {
            string sqlCommnad = string.Format(@"SELECT MAX(BK_MARKER_ID) FROM [dbo].[HUB_GMARKERS]");
            return int.Parse(DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV, sqlCommnad).ToString());
        }

        /// <summary>
        /// Convert Alleles data into full length binary DNA which contains data at covered marker of best chip. 
        /// For SNPs out of scope of best chip, take 0000 (Unknown value) as default value.
        /// </summary>
        /// <param name="alleles">At one position have a pair of allele</param>
        /// <param name="chipMarkers">Marker list of a best chip</param>
        /// <param name="rawDNALength">Raw DNA length in current system, call GetRawDNALength to get</param>
        public static byte[] BuildRawDNA(Dictionary<int, string> alleles, Dictionary<int, string> chipMarkers, int rawDNALength)
        {
            return new byte[rawDNALength];
        }

        /// <summary>
        /// Convert Raw DNA (byte[]) to Alleles[] following a chip
        /// </summary>
        /// <param name="DNA">Raw DNA</param>
        /// <param name="chipMarkers">Marker list of a specification</param>
        /// <returns></returns>
        public static Dictionary<int, string> ConvertRawDNAToAlleles(byte[] DNA, Dictionary<int, string> chipMarkers)
        {
            return new Dictionary<int, string>();
        }

        /// <summary>
        /// Build pair allele from DNA base on marker List input and alleleList input
        /// </summary>
        /// <param name="DNA"></param>
        /// <param name="markerList">list marker position</param>
        /// <param name="allelesList">Contain information allele (2 character such as 'AT', 'GG') 
        ///                          of the corresponding marker in marker List input (same index in both list)
        ///                          Ex: At markerList[i] have information the corresponding alleleList[i]</param>
        /// <returns>List pair allele have sample order index of markers in markerList</returns>
        public static List<string> BuildPairAlleleFromDNA(byte[] DNA, List<int> markerList, List<string> allelesList)
        {
            byte[] tranformedValueRef = new byte[] { 0, 1, 2, 3 };
            List<string> pairAlleleListOutput = new List<string>();
            int bytePosition;
            int andBits;
            int shift;
            int lengthMarker = markerList.Count;
            int lengthDNA = DNA.Length;

            for (int i = 0; i < lengthMarker; i++)
            {
                bytePosition = (markerList[i] - 1) / 2;
                shift = markerList[i] % 2 == 1 ? 4 : 0;
                andBits = markerList[i] % 2 == 1 ? 0xF0 : 0x0F;

                if (bytePosition < lengthDNA)
                {
                    if ((DNA[bytePosition] & andBits) == 0)
                        pairAlleleListOutput.Add("--");
                    else
                    {
                        switch (tranformedValueRef[(DNA[bytePosition] >> shift) & 3])
                        {
                            case 0:
                                pairAlleleListOutput.Add(allelesList[i][0].ToString() + allelesList[i][0].ToString());
                                break;
                            case 1:
                                pairAlleleListOutput.Add(allelesList[i]);
                                break;
                            case 2:
                                pairAlleleListOutput.Add(allelesList[i][1].ToString() + allelesList[i][0].ToString());
                                break;
                            case 3:
                                pairAlleleListOutput.Add(allelesList[i][1].ToString() + allelesList[i][1].ToString());
                                break;
                        }
                    }
                }
                else
                {
                    pairAlleleListOutput.Add("--");
                }
            }

            return pairAlleleListOutput;
        }

        /// <summary>
        /// Get DNA (byte[]) of animal from DNA PathName
        /// </summary>
        /// <param name="sqlFileStreamContext">SQL FileStream transaction context</param>
        /// <param name="DNAFilePath">DNA file path</param>
        /// <returns></returns>
        public static byte[] GetDNA(byte[] sqlFileStreamContext, string DNAFilePath)
        {
            byte[] dnaBytes = null;

            using (SqlFileStream sqlFileStream = new SqlFileStream(DNAFilePath, sqlFileStreamContext, FileAccess.Read))
            {
                dnaBytes = new byte[sqlFileStream.Length];
                sqlFileStream.Seek(0L, SeekOrigin.Begin);
                sqlFileStream.Read(dnaBytes, 0, dnaBytes.Length);
                sqlFileStream.Close();
            }

            return dnaBytes;
        }

        /// <summary>
        /// Get full DNA that contain all values of markers in system by:
        /// + Contain bit '0000' for marker not belong to markersList
        /// + Contain bit value correspond to inputtedDNA if its marker is in markersList
        /// </summary>
        /// <param name="rawDNA">Raw DNA</param>
        /// <param name="markersList">Marker list of a mask</param>
        /// <param name="rawDNAByteLength">Raw DNA byte length at current system</param>
        /// <returns></returns>
        public static byte[] ExtractRawDNAByMask(byte[] rawDNA, List<int> markersList, int rawDNAByteLength)
        {
            // Init extracted Dna
            byte[] extractedDna = new byte[rawDNAByteLength];
            int bytePosition;
            int andBits; // Store value to keeps 4 bit left or 4 bit right for any 1 byte value

            // Update dna for extracted Dna base on markerlist
            foreach (int markerPosition in markersList)
            {
                bytePosition = (markerPosition - 1) / 2;
                andBits = (markerPosition % 2 == 1) ? 0xF0 : 0x0F;
                extractedDna[bytePosition] = (byte)((rawDNA[bytePosition] & andBits) | extractedDna[bytePosition]);
            }

            return extractedDna;
        }

        /// <summary>
        /// Extract imputed DNA values which its markers are in markerList
        /// </summary>
        /// <param name="imputedDNA"></param>
        /// <param name="markersList">Sort by sequence before calling this</param>
        /// <returns></returns>
        public static byte[] ExtractImputedDNAByMask(byte[] imputedDNA, List<int> markersList)
        {
            byte[] extractedDna = new byte[(markersList.Count - 1) / 2 + 1];  // Init number of byte extractedDna is (markersList.Count - 1) / 2 + 1 byte
            int markerCounter = 0;
            int andBits; // Store value to keeps 4 bit left or 4 bit right for any 1 byte value
            int shiftLeft;
            int shiftRight;

            foreach (int markerPosition in markersList)
            {
                andBits = (markerPosition % 2 == 1) ? 0xF0 : 0x0F;
                shiftRight = (markerCounter % 2 == 1 && andBits == 0xF0) ? 4 : 0;
                shiftLeft = (markerCounter % 2 == 0 && andBits == 0x0F) ? 4 : 0;
                extractedDna[markerCounter / 2] = (byte)(extractedDna[markerCounter / 2] | (((imputedDNA[(markerPosition - 1) / 2] & andBits) >> shiftRight) << shiftLeft));
                markerCounter++;
            }

            return extractedDna;
        }

        /// <summary>
        /// Get full DNA that contain all values of markers in system by:
        /// + Contain bit '0000' for marker not belong to markersList
        /// + Contain bit value correspond to imputedDNA if its marker is in markersList
        /// </summary>
        /// <param name="importedDNA"></param>
        /// <param name="markersList">Sort by sequence before calling this</param>
        /// <param name="rawDNAByteLength"></param>
        /// <returns></returns>
        public static byte[] ImportImputedDNA(byte[] importedDNA, List<int> markersList, int rawDNAByteLength)
        {
            byte[] dnaBytes = new byte[rawDNAByteLength];
            int markerCount = 0;
            int bytePosition;
            int andBits; // Store value to keeps 4 bit left or 4 bit right for any 1 byte value
            int shiftLeft;
            int shiftRight;

            foreach (int markerPosition in markersList)
            {
                bytePosition = (markerPosition - 1) / 2;
                andBits = (markerCount % 2 == 0) ? 0xF0 : 0x0F;
                shiftRight = (markerPosition % 2 == 0 && andBits == 0xF0) ? 4 : 0;
                shiftLeft = (markerPosition % 2 == 1 && andBits == 0x0F) ? 4 : 0;

                dnaBytes[bytePosition] = (byte)(dnaBytes[bytePosition] | (((importedDNA[markerCount / 2] & andBits) >> shiftRight) << shiftLeft));

                markerCount++;
            }

            return dnaBytes;
        }

        /// <summary>
        /// Computed dna checkstring of markerList and storage value in int array
        /// </summary>
        /// <param name="dnaBytes"></param>
        /// <param name="markerList"></param>
        /// <returns></returns>
        public static byte[] ComputeDnaCheckString(byte[] dnaBytes, List<int> markerList)
        {
            byte[] tranformedValueRef = new byte[] { 0, 1, 1, 2 };
            byte[] dnaCheckstring = new byte[markerList.Count];
            int bytePosition;
            int andBits;
            int shift;
            int lengthDna = dnaBytes.Length;

            for (int i = 0; i < markerList.Count; i++)
            {
                bytePosition = (markerList[i] - 1) / 2;
                shift = markerList[i] % 2 == 1 ? 4 : 0;
                andBits = markerList[i] % 2 == 1 ? 0xF0 : 0x0F;

                if (bytePosition < lengthDna)
                {
                    if ((dnaBytes[bytePosition] & andBits) == 0)
                        dnaCheckstring[i] = 5;
                    else
                        dnaCheckstring[i] = tranformedValueRef[(dnaBytes[bytePosition] >> shift) & 3];
                }
                else
                {
                    dnaCheckstring[i] = 5;
                }
            }

            return dnaCheckstring;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dnaBytes"></param>
        /// <param name="markerList"></param>
        /// <returns></returns>
        public static int CountNoOfObsMarkerByPanel(byte[] dnaBytes, List<int> markerList)
        {
            int bytePosition;
            int andBits;
            int noOfObsMarker = 0;

            foreach (int markerPosition in markerList)
            {
                bytePosition = (markerPosition - 1) / 2;
                andBits = markerPosition % 2 == 1 ? 0xF0 : 0x0F;

                if ((dnaBytes[bytePosition] & andBits) != 0)
                    noOfObsMarker++;
            }

            return noOfObsMarker;
        }

        /// <summary>
        /// Implement build dna for samples in dnaRepoTable base on MARKER_ID, ALLELE_1, ALLELE_2 and TOP_TOP_ALLELE 
        /// </summary>
        /// <param name="dnaRepoTable">
        ///     + Contain columns SAMPLE_ID, LOADED_DATE, MARKER_ID, ALLELE_1, ALLELE_2, TOP_TOP_ALLELE (not null).
        ///     + Must be order By SAMPLE_ID
        /// </param>
        /// <param name="dnaLength"></param>
        /// <returns></returns>
        public static DataTable BuildDNA(DataTable dnaRepoTable, int dnaLength)
        {
            // Prepare common variable
            string sampleId = null;
            string sampleLoadDate = string.Empty;
            string chipCode = string.Empty;
            byte[] dnaBytes = null;
            int markerPosition = 0;
            int bytePosition = 0;
            int markerValue = 0;
            int shift = 0;
            int dnaRepoCount = dnaRepoTable.Rows.Count;

            // Init dataTable storage dna
            DataTable dnaTable = new DataTable();
            dnaTable.Columns.Add("SAMPLE_ID", typeof(string));
            dnaTable.Columns.Add("LOADED_DATE", typeof(string));
            dnaTable.Columns.Add("DNA", typeof(byte[]));

            int count = 1;
            // Implement build dna
            foreach (DataRow dnaRepoRow in dnaRepoTable.Rows)
            {
                if (string.IsNullOrEmpty(sampleId) || !sampleId.Equals(dnaRepoRow["SAMPLE_ID"].ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    // Add new row sample dna
                    if (!string.IsNullOrEmpty(sampleId))
                        dnaTable.Rows.Add(sampleId, sampleLoadDate, dnaBytes);

                    // Reset variable value
                    sampleId = dnaRepoRow["SAMPLE_ID"].ToString();
                    sampleLoadDate = dnaRepoRow["LOADED_DATE"].ToString();
                    chipCode = dnaRepoRow["GCHIP_CODE"].ToString();
                    dnaBytes = new byte[dnaLength];
                }

                // Computed marker value
                if (string.IsNullOrEmpty(dnaRepoRow["ALLELE_1"].ToString()))
                    markerValue = 0;
                else if (dnaRepoRow["ALLELE_1"].ToString().Equals(dnaRepoRow["TOP_TOP_ALLELE"].ToString()[0].ToString(), StringComparison.OrdinalIgnoreCase)
                            && dnaRepoRow["ALLELE_1"].ToString().Equals(dnaRepoRow["ALLELE_2"].ToString(), StringComparison.OrdinalIgnoreCase))   // AA
                    markerValue = 4;
                else if (dnaRepoRow["ALLELE_1"].ToString().Equals(dnaRepoRow["TOP_TOP_ALLELE"].ToString()[0].ToString(), StringComparison.OrdinalIgnoreCase)
                            && dnaRepoRow["ALLELE_2"].ToString().Equals(dnaRepoRow["TOP_TOP_ALLELE"].ToString()[1].ToString(), StringComparison.OrdinalIgnoreCase))  // AB
                    markerValue = 5;
                else if (dnaRepoRow["ALLELE_1"].ToString().Equals(dnaRepoRow["TOP_TOP_ALLELE"].ToString()[1].ToString(), StringComparison.OrdinalIgnoreCase)
                            && dnaRepoRow["ALLELE_2"].ToString().Equals(dnaRepoRow["TOP_TOP_ALLELE"].ToString()[0].ToString(), StringComparison.OrdinalIgnoreCase))  // BA
                    markerValue = 6;
                else if (dnaRepoRow["ALLELE_1"].ToString().Equals(dnaRepoRow["TOP_TOP_ALLELE"].ToString()[1].ToString(), StringComparison.OrdinalIgnoreCase)
                            && dnaRepoRow["ALLELE_1"].ToString().Equals(dnaRepoRow["ALLELE_2"].ToString(), StringComparison.OrdinalIgnoreCase))  // BB
                    markerValue = 7;

                // Assign marker value to dna bytes
                markerPosition = int.Parse(dnaRepoRow["MARKER_ID"].ToString());
                bytePosition = (markerPosition - 1) / 2;
                shift = markerPosition % 2 == 1 ? 4 : 0;
                dnaBytes[bytePosition] = (byte)((markerValue << shift) | dnaBytes[bytePosition]);

                if (sampleId.Equals(dnaRepoRow["SAMPLE_ID"].ToString()) && dnaRepoCount == count)
                {
                    dnaTable.Rows.Add(sampleId, sampleLoadDate, dnaBytes);
                }
                count++;
            }

            return dnaTable;
        }
    }
}
