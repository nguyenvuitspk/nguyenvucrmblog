﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace GenomicPackageBase
{
    public class MKLib
    {
        public sealed class CBLAS
        {
            private CBLAS() { }

            public sealed class ORDER
            {
                private ORDER() { }
                public static int RowMajor = 101;
                public static int ColMajor = 102;
            }

            public sealed class TRANSPOSE
            {
                private TRANSPOSE() { }
                public static int NoTrans = 111;
                public static int Trans = 112;
                public static int ConjTrans = 113;
            }

            /** CBLAS cblas_dgemm wrapper */
            public static void dgemm32(int Order, int TransA, int TransB,
                int M, int N, int K, double alpha, double[] A, int lda,
                double[] B, int ldb, double beta, double[] C, int ldc)
            {
                CBLASNative32.cblas_dgemm(Order, TransA, TransB, M, N, K,
                    alpha, A, lda, B, ldb, beta, C, ldc);
            }

            public static void dgemm64(int Order, int TransA, int TransB,
                int M, int N, int K, double alpha, double[] A, int lda,
                double[] B, int ldb, double beta, double[] C, int ldc)
            {
                CBLASNative64.cblas_dgemm(Order, TransA, TransB, M, N, K,
                    alpha, A, lda, B, ldb, beta, C, ldc);
            }
        }

        /// <summary>
        /// Using in Enviroment 32 bit
        /// </summary>
        [SuppressUnmanagedCodeSecurity]
        internal sealed class CBLASNative32
        {
            private CBLASNative32() { }

            /** CBLAS native cblas_dgemm declaration */
            [DllImport(GenomicConstants.MKL_DLL_32_BIT_FILE_PATH, CallingConvention = CallingConvention.Cdecl,
                 ExactSpelling = true, SetLastError = false)]
            internal static extern void cblas_dgemm(
                int Order, int TransA, int TransB, int M, int N, int K,
                double alpha, [In] double[] A, int lda, [In] double[] B, int ldb,
                double beta, [In, Out] double[] C, int ldc);
        }

        /// <summary>
        /// Using in Enviroment 64 bit
        /// </summary>
        [SuppressUnmanagedCodeSecurity]
        internal sealed class CBLASNative64
        {
            private CBLASNative64() { }

            /** CBLAS native cblas_dgemm declaration */
            [DllImport(GenomicConstants.MKL_DLL_64_BIT_FILE_PATH, CallingConvention = CallingConvention.Cdecl,
                 ExactSpelling = true, SetLastError = false)]
            internal static extern void cblas_dgemm(
                int Order, int TransA, int TransB, int M, int N, int K,
                double alpha, [In] double[] A, int lda, [In] double[] B, int ldb,
                double beta, [In, Out] double[] C, int ldc);
        }
    }
}
