﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QAReportLib
{
    public abstract class BVQAReports : IDisposable
    {
        public string SourceBVRunID { get; set; }

        public string CompareBVRunID { get; set; }

        public string QAReportConnectionString { get; set; }

        public string OutputDirectory { get; set; }

        public List<Tuple<string, string>> SummarysAndChartsReportfilters { get; set; } // Item1: Column Name, Item2: Value of Item1

        public List<Tuple<string, string>> DifferentReportfilters { get; set; } // Item1: Column Name, Item2: Value of Item1

        public SqlConnection SqlConnection { get; set; }

        public BVQAReports(string _QAReportConnectionString, string _SourceBVRunID, string _CompareBVRunID, string _OutputDirectory)
        {
            SourceBVRunID = _SourceBVRunID;
            CompareBVRunID = _CompareBVRunID;
            QAReportConnectionString = _QAReportConnectionString;
            OutputDirectory = _OutputDirectory;
            OpenSqlConnection();
            InitReportFilters();
        }

        public BVQAReports(string _QAReportConnectionString, string _OutputDirectory)
        {
            QAReportConnectionString = _QAReportConnectionString;
            OutputDirectory = _OutputDirectory;
            OpenSqlConnection();
            InitReportFilters();
        }

        public abstract void InitReportFilters();

        public abstract void Export();

        protected void ChangeTupleValue(List<Tuple<string, string>> lTuple, string item1, string newItem2)
        {
            int index = lTuple.FindIndex(_ => _.Item1 == item1);
            lTuple[index] = Tuple.Create(item1, newItem2);
        }

        public void OpenSqlConnection()
        {
            SqlConnection = new SqlConnection(QAReportConnectionString);
            SqlConnection.Open();
        }

        public void CloseSqlConnection()
        {
            SqlConnection.Close();
        }

        public void Dispose()
        {
            CloseSqlConnection();
        }
    }
}
