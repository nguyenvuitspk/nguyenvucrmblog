﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace QAReportLib
{
    public class QAReportDataHelper
    {
        public static List<string> GetTraitCodesForPdfReport(SqlConnection sqlConnection, List<Tuple<string, string>> filters, CompareType? compareType = null)
        {
            string sqlCommand = "SELECT DISTINCT TRAIT_CODE FROM #compare WHERE " + (compareType.HasValue ? "TYPE = '" + compareType.ToString() + "'" : "(TYPE = 'BV' OR TYPE = 'REL')");

            // Add condition fileter data
            foreach (var filter in filters)
            {
                sqlCommand += " AND " + filter.Item1 + " = '" + filter.Item2 + "'";
            }

            return DataReaderUtilsLib.DataReaderUtilities.GetData(sqlConnection, sqlCommand).Tables[0].AsEnumerable().Select(r => r.Field<string>("TRAIT_CODE")).ToList();
        }

        public static DataTable GetExtremeBVAnimalDataReport(SqlConnection sqlConnection, CompareType cmpType, List<Tuple<string, string>> filters)
        {
            string globalTable = string.Empty;

            switch (cmpType)
            {
                case CompareType.BV:
                case CompareType.RAW_SOLUTION:
                    globalTable = "#bv";
                    break;
                case CompareType.REL:
                    globalTable = "#rel";
                    break;
                case CompareType.DTD:
                    globalTable = "#dtd";
                    break;
            }

            // Create condition filter data
            string filterRankDiffValues = filters.Count() > 0 ? string.Join(" AND ", filters.Select(_ => _.Item1 + " = '" + _.Item2 + "'").ToList()) : "";
            string traitCodeDefaults = GetTraitCodeBVsDefault();

            string sqlCommand = string.Format(@"DECLARE @TRAIT_DEFAULT VARCHAR(MAX) = '" + GetTraitCodeBVsDefault() + @"'
                                                  ,@selectTopTenAnimalPerTraitPerBreed VARCHAR(MAX) = ''

                                                  ;WITH cteBreed
                                                  AS
                                                        (
                                                   SELECT DISTINCT BREED_PUTATIVE
                                                   FROM {0}
                                                  )

                                                  SELECT @selectTopTenAnimalPerTraitPerBreed += ' UNION ALL
                                                              select *
                                                              from (
                                                              SELECT TOP 10 ANIMAL_NATIONAL_ID
                                                                   ,BREED_PUTATIVE
                                                                   ,''' + lTrait.TRAIT_CODE + ''' as trait_code
                                                                   ,ROW_NUMBER() OVER (ORDER BY ABS(SRC_' + TRAIT_CODE + ' - CMP_' + TRAIT_CODE + ') DESC) as RANK_DIFF
                                                              FROM {0}
                                                              WHERE BREED_PUTATIVE = ''' + BREED_PUTATIVE + ''' {1}
                                                              ORDER BY ABS(SRC_' + TRAIT_CODE + ' - CMP_' + TRAIT_CODE + ') DESC) as d '
                                                  FROM cteBreed
                                                  CROSS APPLY (SELECT [value] AS TRAIT_CODE FROM dbo.fnSplitString(@TRAIT_DEFAULT, ',')) lTrait
                                                  
                                                  IF @selectTopTenAnimalPerTraitPerBreed <> ''
                                                  BEGIN
                                                      SET @selectTopTenAnimalPerTraitPerBreed = SUBSTRING(@selectTopTenAnimalPerTraitPerBreed, 11, LEN(@selectTopTenAnimalPerTraitPerBreed)) + ' order by BREED_PUTATIVE,trait_code, RANK_DIFF'
                                                      EXEC (@selectTopTenAnimalPerTraitPerBreed)
                                                  END
                                                  ELSE
                                                  BEGIN
                                                       SELECT '' AS ANIMAL_NATIONAL_ID ,'' AS BREED_PUTATIVE , '' AS trait_code , '' AS RANK_DIFF WHERE 1 = 0   -- Get empty data
                                                  END
                                                  ", globalTable, filterRankDiffValues);

            return DataReaderUtilsLib.DataReaderUtilities.GetData(sqlConnection, sqlCommand).Tables[0];
        }

        public static DataTable GetDifferentFrequencyDataReport(SqlConnection sqlConnection, CompareType cmpType, List<Tuple<string, string>> filters)
        {
            // Create condition filter data
            string filterDiffFreqValues = filters.Count() > 0 ? " AND " + string.Join(" AND ", filters.Select(_ => _.Item1 + " = '" + _.Item2 + "'").ToList()) : "";

            string sqlCommand = string.Format(@"SELECT DIFF
	                                                   ,FREQ
                                                FROM #diff_freq
                                                WHERE TYPE = '{0}'{1}", cmpType.ToString(), filterDiffFreqValues);

            return DataReaderUtilsLib.DataReaderUtilities.GetData(sqlConnection, sqlCommand).Tables[0];

        }

        public static DataTable GetSummaryCompareDataReport(SqlConnection sqlConnection, CompareType cmpType, List<Tuple<string, string>> filters)
        {
            string filterSummaryCompareValues = filters.Count() > 0 ? " AND " + string.Join(" AND ", filters.Select(_ => _.Item1 + " = '" + _.Item2 + "'").ToList()) : "";
            string sqlCommand = string.Format(@"DECLARE @TRAIT VARCHAR(MAX) = 'BPI,HWI,TWI,ASI,MILK,FAT,PROT,SCC,FERT,EASE,RESSUR,SURV,SURVDI,INDEX,LIKE,MSPEED,TEMP,WGEN,OTYPE,ANGUL,BODYD,BODYL,BONE,CENTL,CHESTW,FOOTA,FOREA,FRONTH,LOIN,MAMM,MUZW,PINSET,PINW,REARAH,REARAW,RLEG,RSET,RUMPL,STAT,TEATL,TEATPF,TEATPR,TGEN,UDDEP,UDTEX,FEEDEF,LWT,RFI_C,RFI_H';

                                                SELECT TRAIT_CODE
                                                        ,IIF(NO_ANIMAL IS NULL, '-', CAST(NO_ANIMAL AS VARCHAR(128))) AS NO_ANIMAL
                                                        ,IIF(DIFF_MEAN IS NULL, '-', CAST(DIFF_MEAN AS VARCHAR(128))) AS DIFF_MEAN
                                                        ,IIF(DIFF_STD_DEV IS NULL, '-', CAST(DIFF_STD_DEV AS VARCHAR(128))) AS DIFF_STD_DEV
                                                        ,IIF(DIFF_MIN IS NULL, '-', CAST(DIFF_MIN AS VARCHAR(128))) AS DIFF_MIN
                                                        ,IIF(DIFF_MAX IS NULL, '-', CAST(DIFF_MAX AS VARCHAR(128))) AS DIFF_MAX
                                                        ,IIF(COR_SRC_COMP IS NULL, '-', CAST(COR_SRC_COMP AS VARCHAR(128))) AS COR_SRC_COMP
                                                        ,IIF(COR_COMP_DIFF IS NULL, '-', CAST(COR_COMP_DIFF AS VARCHAR(128))) AS COR_COMP_DIFF
                                                        ,IIF(COR_SRC_DIFF IS NULL, '-', CAST(COR_SRC_DIFF AS VARCHAR(128))) AS COR_SRC_DIFF
                                                        ,IIF(STD_DEV_SCALE IS NULL, '-', CAST(STD_DEV_SCALE AS VARCHAR(128))) AS STD_DEV_SCALE
                                                        ,IIF(REG_A IS NULL, '-', CAST(REG_A AS VARCHAR(128))) AS REG_A
                                                        ,IIF(REG_B IS NULL, '-', CAST(REG_B AS VARCHAR(128))) AS REG_B
                                                        ,IIF(SRC_MEAN IS NULL, '-', CAST(SRC_MEAN AS VARCHAR(128))) AS SRC_MEAN
                                                        ,IIF(SRC_STD_DEV IS NULL, '-', CAST(SRC_STD_DEV AS VARCHAR(128))) AS SRC_STD_DEV
                                                        ,IIF(SRC_MIN IS NULL, '-', CAST(SRC_MIN AS VARCHAR(128))) AS SRC_MIN
                                                        ,IIF(SRC_MAX IS NULL, '-', CAST(SRC_MAX AS VARCHAR(128))) AS SRC_MAX
                                                        ,IIF(COMP_MEAN IS NULL, '-', CAST(COMP_MEAN AS VARCHAR(128))) AS COMP_MEAN
                                                        ,IIF(COMP_STD_DEV IS NULL, '-', CAST(COMP_STD_DEV AS VARCHAR(128))) AS COMP_STD_DEV
                                                        ,IIF(COMP_MIN IS NULL, '-', CAST(COMP_MIN AS VARCHAR(128))) AS COMP_MIN
                                                        ,IIF(COMP_MAX IS NULL, '-', CAST(COMP_MAX AS VARCHAR(128))) AS COMP_MAX
						                        FROM #compare
												JOIN (SELECT col1 AS BK_TRAIT_CODE, ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS RN FROM dbo.fn_Split_String(@TRAIT, ',')) AS trait ON trait.BK_TRAIT_CODE = #compare.TRAIT_CODE
                                                WHERE [TYPE] = '{0}'{1}
												ORDER BY trait.RN", cmpType.ToString(), filterSummaryCompareValues);

            var ds = DataReaderUtilsLib.DataReaderUtilities.GetData(sqlConnection, sqlCommand);

            return ds != null && ds.Tables.Count > 0 ? ds.Tables[0] : null;
        }

        public static DataRow GetLinearFuncData(SqlConnection sqlConnection, string traitCode, CompareType cmpType, List<Tuple<string, string>> filters)
        {
            string filterLinearFuncData = filters.Count() > 0 ? " AND " + string.Join(" AND ", filters.Select(_ => _.Item1 + " = '" + _.Item2 + "'").ToList()) : "";
            string sqlLinearCommand = string.Format(@"SELECT COR_SRC_COMP
		                                                        ,REG_A
		                                                        ,REG_B
                                                                ,COMP_MIN
		                                                        ,COMP_MAX
                                                                ,DIFF_STD_DEV
                                                        FROM #compare
                                                        WHERE TRAIT_CODE = '{0}' AND TYPE = '{1}'{2}", traitCode, cmpType.ToString(), filterLinearFuncData);

            return DataReaderUtilsLib.DataReaderUtilities.GetRowValue(sqlConnection, sqlLinearCommand);
        }

        public static void ExecBVCompare(SqlConnection sqlConnection, string sqlQuery)
        {
            using (SqlCommand cmd = new SqlCommand(sqlQuery, sqlConnection))
            {
                cmd.CommandTimeout = 0;
                cmd.ExecuteNonQuery();
            }
        }

        public static List<string> GetBreedCodes(SqlConnection sqlConnection, CompareType? cmpType = null)
        {
            string globalTable = "";
            if (cmpType.HasValue)
            {
                switch (cmpType.Value)
                {
                    case CompareType.BV:
                    case CompareType.RAW_SOLUTION:
                        globalTable = "#bv";
                        break;
                    case CompareType.REL:
                        globalTable = "#rel";
                        break;
                    case CompareType.DTD:
                        globalTable = "#dtd";
                        break;
                }
            }
            else globalTable = "#compare";

            string sqlCommand = @"SELECT DISTINCT BREED_PUTATIVE FROM " + globalTable;
            return DataReaderUtilsLib.DataReaderUtilities.GetData(sqlConnection, sqlCommand).Tables[0].AsEnumerable().Select(r => r.Field<string>("BREED_PUTATIVE")).ToList();
        }

        public static List<string> GetTraitGroupCodes(SqlConnection sqlConnection)
        {
            string sqlCommand = "SELECT DISTINCT TRAIT_GROUP_CODE FROM #compare";
            return DataReaderUtilsLib.DataReaderUtilities.GetData(sqlConnection, sqlCommand).Tables[0].AsEnumerable().Select(r => r.Field<string>("TRAIT_GROUP_CODE")).ToList();
        }

        public static List<string> GetSexs(SqlConnection sqlConnection)
        {
            string sqlCommand = "SELECT DISTINCT SEX FROM #compare";
            return DataReaderUtilsLib.DataReaderUtilities.GetData(sqlConnection, sqlCommand).Tables[0].AsEnumerable().Select(r => r.Field<string>("SEX")).ToList();
        }

        public static List<string> GetOwnerCodes(SqlConnection sqlConnection)
        {
            string sqlCommand = "SELECT DISTINCT OWNER_CODE FROM #compare";
            return DataReaderUtilsLib.DataReaderUtilities.GetData(sqlConnection, sqlCommand).Tables[0].AsEnumerable().Select(r => r.Field<string>("OWNER_CODE")).ToList();
        }

        public static string GetRunNameInGesRpt(SqlConnection sqlConnection, string runId)
        {
            string sqlCommand = string.Format("SELECT RUN_NAME FROM BVReportDB.dbo.RUNS WHERE RUN_ID = '{0}'", runId);
            return DataReaderUtilsLib.DataReaderUtilities.GetScalaValue(sqlConnection, sqlCommand).ToString();
        }

        public static string GetRunNameInGesNP(SqlConnection sqlConnection, string runId)
        {
            string sqlCommand = string.Format("SELECT BK_RUN_NAME FROM dbo.HUB_RUNS (NOLOCK) WHERE PK_RUN_ID = '{0}'", runId);
            return DataReaderUtilsLib.DataReaderUtilities.GetScalaValue(sqlConnection, sqlCommand).ToString();
        }

        public static string GetReleaseNameInGesRpt(SqlConnection sqlConnection, string runId)
        {
            string sqlCommand = string.Format(@"SELECT releases.RELEASE_NAME
                                                FROM BVReportDB.dbo.RUNS runs
                                                JOIN BVReportDB.dbo.RELEASES releases ON releases.RELEASE_ID = runs.RELEASE_ID
                                                WHERE runs.RUN_ID = '{0}'", runId);
            return DataReaderUtilsLib.DataReaderUtilities.GetScalaValue(sqlConnection, sqlCommand).ToString();
        }

        public static string GetReleaseNameInGesNP(SqlConnection sqlConnection, string runId)
        {
            string sqlCommand = string.Format(@"SELECT hReleases.BK_RELEASE_NAME
                                                FROM dbo.LNK_RUN_RELEASES (NOLOCK) lRReleases
                                                JOIN dbo.HUB_RELEASES (NOLOCK) hReleases ON hReleases.PK_RELEASE_ID = lRReleases.PK_RELEASE_ID
                                                WHERE lRReleases.PK_RUN_ID = '{0}'", runId);
            return DataReaderUtilsLib.DataReaderUtilities.GetScalaValue(sqlConnection, sqlCommand).ToString();
        }

        public static string GetQueryGetScatterPlotData(SqlConnection sqlConnection, string traitCode, CompareType cmpType, List<Tuple<string, string>> filters)
        {
            string globalTable = string.Empty;

            switch (cmpType)
            {
                case CompareType.BV:
                case CompareType.RAW_SOLUTION:
                    globalTable = "#bv";
                    break;
                case CompareType.REL:
                    globalTable = "#rel";
                    break;
                case CompareType.DTD:
                    globalTable = "#dtd";
                    break;
            }

            string filterScatterPlotData = filters.Count() > 0 ? " AND " + string.Join(" AND ", filters.Select(_ => _.Item1 + " = '" + _.Item2 + "'").ToList()) : "";

            return string.Format(@"SELECT SRC_" + traitCode + @" AS BV_SOURCE
                                          ,CMP_" + traitCode + @" AS BV_COMPARE
                                   FROM {0}
                                   WHERE  SRC_" + traitCode + " IS NOT NULL AND CMP_" + traitCode + " IS NOT NULL {1}", globalTable, filterScatterPlotData); ;
        }

        public static object GetXmlValue(SqlConnection sqlConnection, string parameterName)
        {
            string sqlCommand = string.Format("SELECT [PARAM_VALUE] FROM #xml WHERE PARAM_NAME = '{0}'", parameterName);
            return DataReaderUtilsLib.DataReaderUtilities.GetScalaValue(sqlConnection, sqlCommand);
        }

        public static string GetQuerySummaryTraitCompareCdrUI()
        {
            return @"SELECT ANIMAL_NATIONAL_ID AS [National ID]
					   ,BPI
					   ,DIFF_BV AS [Diff. BV]
					   ,DIFF_NO_HERD AS [Diff. Herds]
					   ,DIFF_NO_DTRS AS [Diff. Dtrs]
					   ,DIFF_NO_RIP AS [Diff. RIP]
					   ,COMPARE_REL AS [Comp. Rel1]
					   ,SOURCE_REL AS [Curr. Rel2]
				    FROM #traitCompare";
        }

        public static string GetTraitCodeBVsDefault()
        {
            return "BPI,HWI,TWI,ASI,MILK,FAT,PROT,SCC,FERT,EASE,RESSUR,SURV,SURVDI,INDEX,LIKE,MSPEED,TEMP,WGEN,OTYPE,ANGUL,BODYD,BODYL,BONE,CENTL,CHESTW,FOOTA,FOREA,FRONTH,LOIN,MAMM,MUZW,PINSET,PINW,REARAH,REARAW,RLEG,RSET,RUMPL,STAT,TEATL,TEATPF,TEATPR,TGEN,UDDEP,UDTEX,FEEDEF,LWT,RFI_C,RFI_H";
        }

        public static DataTable GetSummaryTraitCompareCdrUI(SqlConnection sqlConnection, string xml, string sortFilter, bool isSortDesc, bool isSearch = false)
        {
            string sqlCommand = string.Format(GetQueryInitTempTablesForQACompares() + @" EXEC wsp_ui_flexible_trait_compare_qa_report '{0}', {1}, '{2}', {3}", xml, isSearch ? 1 : 0, sortFilter, isSortDesc ? 1 : 0);
            return DataReaderUtilsLib.DataReaderUtilities.GetData(sqlConnection, sqlCommand).Tables[0];
        }

        public static DataTable GetInformationTraitCompareCdrUI(SqlConnection sqlConnection, string animalId, string srcRunId, string cmpRunId, string traitCode)
        {
            string sqlCommand = string.Format(GetQueryInitTempTablesForQACompares() + @" EXEC usp_ui_get_animal_information_trait_compare_qa_report '{0}', '{1}', '{2}', '{3}'", animalId, srcRunId, cmpRunId, traitCode);
            var data = DataReaderUtilsLib.DataReaderUtilities.GetData(sqlConnection, sqlCommand).Tables[0];
            sqlConnection.Close();
            return data;
        }

        public static DataTable GetCompareBVsAnimalTraitCompareCdrUI(SqlConnection sqlConnection, string animalId, string srcRunId, string cmpRunId)
        {
            string sqlCommand = string.Format(GetQueryInitTempTablesForQACompares() + @" EXEC usp_ui_get_trait_values_of_animal_trait_compare_qa_report '{0}', '{1}', '{2}'", animalId, srcRunId, cmpRunId);
            var data = DataReaderUtilsLib.DataReaderUtilities.GetData(sqlConnection, sqlCommand).Tables[0];
            sqlConnection.Close();
            return data;
        }

        /// <summary>
        /// Init temp table includes #compare, #diff_freq, #bv, #rel, #dtd
        /// </summary>
        /// <returns></returns>
        public static string GetQueryInitTempTablesForQACompares()
        {
            string createTableBV = @"CREATE TABLE {table_name} 
                                    (
                                      ANIMAL_NATIONAL_ID VARCHAR(16) NULL,
                                      [SEX] CHAR(1) NULL,
		                              [BREED_PUTATIVE] CHAR(1) NULL,
		                              [OWNER_CODE] VARCHAR(16) NULL,
		                              [TRAIT] VARCHAR(16) NULL,
		                              [TRAIT_GROUP_CODE] VARCHAR(16) NULL";

            foreach (string trait in GetTraitCodeBVsDefault().Split(','))
            {
                createTableBV += ",SRC_" + trait + " FLOAT NULL,CMP_" + trait + " FLOAT NULL";
            }

            createTableBV += ")";

            return @"IF OBJECT_ID('tempdb..#compare') IS NOT NULL
		                    DROP TABLE #compare

	                    CREATE TABLE #compare
	                    (
		                    [TYPE] varchar(16) NULL,
		                    [TRAIT_CODE] varchar(16) NULL,
                            [TRAIT_GROUP_CODE] VARCHAR(16) NULL,
                            [OWNER_CODE] VARCHAR(16) NULL,
		                    [BREED_PUTATIVE] VARCHAR(1) NULL,
                            [NASIS_ACTIVE] CHAR(1) NULL,
                            [SEX] CHAR(1) NULL,
		                    [NO_ANIMAL] float NULL,
		                    [DIFF_MEAN] float NULL,
		                    [DIFF_STD_DEV] float NULL,
		                    [DIFF_MIN] float NULL,
		                    [DIFF_MAX] float NULL,
		                    [COR_SRC_COMP] float NULL,
		                    [COR_COMP_DIFF] float NULL,
		                    [COR_SRC_DIFF] float NULL,
		                    [STD_DEV_SCALE] float NULL,
		                    [REG_A] float NULL,
		                    [REG_B] float NULL,
		                    [SRC_MEAN] float NULL,
		                    [SRC_STD_DEV] float NULL,
		                    [SRC_MIN] float NULL,
		                    [SRC_MAX] float NULL,
		                    [COMP_MEAN] float NULL,
		                    [COMP_STD_DEV] float NULL,
		                    [COMP_MIN] float NULL,
		                    [COMP_MAX] float NULL,
		                    [R2] float NULL
	                    )

	                    IF OBJECT_ID('tempdb..#diff_freq') IS NOT NULL
		                    DROP TABLE #diff_freq

	                    CREATE TABLE #diff_freq
	                    (
		                    [TYPE] varchar(16) NULL,
                            [SEX] CHAR(1) NULL,
		                    [TRAIT_CODE] varchar(16) NULL,
                            [TRAIT_GROUP_CODE] VARCHAR(16) NULL,
                            [OWNER_CODE] VARCHAR(16) NULL,
		                    [BREED_PUTATIVE] VARCHAR(1) NULL,
                            [NASIS_ACTIVE] CHAR(1) NULL,
		                    [DIFF] FLOAT NULL,
		                    [FREQ] FLOAT NULL
	                    )

                        
	                    IF OBJECT_ID('tempdb..#mapping_bv_col_names') IS NOT NULL
		                    DROP TABLE #mapping_bv_col_names

                        CREATE TABLE #mapping_bv_col_names
	                    (
		                    TRAIT_GROUP_CODE VARCHAR(128) NULL,
                            TRAIT_CODE VARCHAR(128) NULL,
		                    COW_COL_NAME_BV VARCHAR(128) NULL,
		                    BULL_COL_NAME_BV VARCHAR(128) NULL,
		                    COW_COL_NAME_REL VARCHAR(128) NULL,
		                    BULL_COL_NAME_REL VARCHAR(128) NULL,
		                    COW_COL_NAME_DTD VARCHAR(128) NULL,
		                    BULL_COL_NAME_DTD VARCHAR(128) NULL,
		                    COW_COL_NAME_RAW_BV VARCHAR(128) NULL,
		                    BULL_COL_NAME_RAW_BV VARCHAR(128) NULL
	                    )

	                    IF OBJECT_ID('tempdb..#bv') IS NOT NULL
		                    DROP TABLE #bv

	                    " + createTableBV.Replace("{table_name}", "#bv") + @"

	                    IF OBJECT_ID('tempdb..#rel') IS NOT NULL
		                    DROP TABLE #rel

	                     " + createTableBV.Replace("{table_name}", "#rel") + @"

	                    IF OBJECT_ID('tempdb..#dtd') IS NOT NULL
		                    DROP TABLE #dtd
	                    " + createTableBV.Replace("{table_name}", "#dtd") + @"

                        DROP TABLE IF EXISTS #xml
                        CREATE TABLE #xml
	                    (
		                    [PARAM_NAME] VARCHAR(128) NULL,
		                    [PARAM_VALUE] VARCHAR(1024) NULL
	                    )

				        DROP TABLE IF EXISTS #traitCompare
				        CREATE TABLE #traitCompare
				        (
					        ANIMAL_NATIONAL_ID VARCHAR(128) NULL,
					        BPI DECIMAL(18, 3) NULL,
					        DIFF_BV DECIMAL(18, 3) NULL,
					        DIFF_NO_HERD DECIMAL(18, 3) NULL,			
					        DIFF_NO_DTRS DECIMAL(18, 3) NULL,
					        DIFF_NO_RIP DECIMAL(18, 3) NULL,
					        SOURCE_REL DECIMAL(18, 3) NULL,
					        COMPARE_REL DECIMAL(18, 3) NULL
				        )

                        EXEC [dbo].[usp_common_get_column_name_bvs_of_trait_codes_qa_report] '" + GetTraitCodeBVsDefault() + "'";
        }
    }
}
