﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using OxyPlot;
using OxyPlot.Axes;
using OxyPlot.Series;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QAReportLib
{
    public class QAReportPDFLib
    {
        /// <summary>
        /// Export Scatter plot and histogram chart of breeding values and reliability for one page pdf 
        /// base on breed and trait
        /// </summary>
        public static void ExportChartsToPagePDF(SqlConnection sqlConnection, ColumnText colTextPdf, Rectangle[] layoutColumns, string curRunName, string cmpRunName, string trait, List<Tuple<string, string>> filters)
        {
            // Init model
            OxyPlot.PlotModel bvScatterPlotModel = new OxyPlot.PlotModel();
            OxyPlot.PlotModel bvHistogramModel = new OxyPlot.PlotModel { };
            OxyPlot.PlotModel relScatterPlotModel = new OxyPlot.PlotModel();
            OxyPlot.PlotModel relHistogramModel = new OxyPlot.PlotModel();

            // Get breed Code
            string breedCode = "";
            if (filters.FirstOrDefault(_ => _.Item1 == "BREED_PUTATIVE") != null)
                breedCode = filters.FirstOrDefault(_ => _.Item1 == "BREED_PUTATIVE").Item2;
            else
            {
                var breedCodes = QAReportDataHelper.GetBreedCodes(sqlConnection);
                breedCode = breedCodes.Count() == 1 ? breedCodes[0] : null;
            }

            // Get plot data
            AddDataToPlotModelsForPDF(sqlConnection, bvScatterPlotModel, bvHistogramModel, curRunName, cmpRunName, breedCode, trait, CompareType.BV, filters);
            AddDataToPlotModelsForPDF(sqlConnection, relScatterPlotModel, relHistogramModel, curRunName, cmpRunName, breedCode, trait, CompareType.REL, filters);

            // Export chart
            ExportChartToPagePDF(bvScatterPlotModel, colTextPdf, layoutColumns[0]);
            ExportChartToPagePDF(relScatterPlotModel, colTextPdf, layoutColumns[1]);
            ExportChartToPagePDF(bvHistogramModel, colTextPdf, layoutColumns[2]);
            ExportChartToPagePDF(relHistogramModel, colTextPdf, layoutColumns[3]);
        }

        public static void ExportChartsToPagePDF(SqlConnection sqlConnection, ColumnText colTextPdf, Rectangle[] layoutColumns, string curRunName, string cmpRunName, string trait, List<Tuple<string, string>> filters, CompareType cmpType)
        {
            // Init model
            OxyPlot.PlotModel bvScatterPlotModel = new OxyPlot.PlotModel();
            OxyPlot.PlotModel bvHistogramModel = new OxyPlot.PlotModel { };

            // Get breed Code
            string breedCode = "";
            if (filters.FirstOrDefault(_ => _.Item1 == "BREED_PUTATIVE") != null)
                breedCode = filters.FirstOrDefault(_ => _.Item1 == "BREED_PUTATIVE").Item2;
            else
            {
                var breedCodes = QAReportDataHelper.GetBreedCodes(sqlConnection, cmpType);
                breedCode = breedCodes.Count() == 1 ? breedCodes[0] : null;
            }

            // Get plot data
            AddDataToPlotModelsForPDF(sqlConnection, bvScatterPlotModel, bvHistogramModel, curRunName, cmpRunName, breedCode, trait, cmpType, filters);

            // Export chart
            ExportChartToPagePDF(bvScatterPlotModel, colTextPdf, layoutColumns[0]);
            ExportChartToPagePDF(bvHistogramModel, colTextPdf, layoutColumns[1]);
        }

        private static void ExportChartToPagePDF(OxyPlot.PlotModel model, ColumnText colTextPdf, Rectangle colLayout)
        {
            // Set layout
            colTextPdf.SetSimpleColumn(colLayout);

            // Get image from plot model
            var stream = new MemoryStream();
            var pngExporter = new OxyPlot.WindowsForms.PngExporter { Width = QAReportConstant.QA_REPORT_IMG_WIDTH, Height = QAReportConstant.QA_REPORT_IMG_HEIGHT, Background = OxyColors.White };
            pngExporter.Export(model, stream);
            stream.Seek(0, SeekOrigin.Begin);
            var img = iTextSharp.text.Image.GetInstance(stream);
            img.ScalePercent((iTextSharp.text.PageSize.A4.Height / 2 - 80) / QAReportConstant.QA_REPORT_IMG_WIDTH * 100, (iTextSharp.text.PageSize.A4.Width / 2 - 30) / QAReportConstant.QA_REPORT_IMG_HEIGHT * 100);

            // Add image to page
            colTextPdf.AddElement(img);
            colTextPdf.Go();
            colTextPdf.Go();

            // Clear memory
            stream.Dispose();
            pngExporter = null;
        }

        /// <summary>
        /// Export Scatter Plot And Histogram charts to pdf file for breeding values or reliability values base on sql query
        /// </summary>
        private static void AddDataToPlotModelsForPDF(SqlConnection conn, OxyPlot.PlotModel scatterPlotModel, OxyPlot.PlotModel histogramModel, string curRunName, string cmpRunName
                                                        , string breedCode, string traitCode, CompareType cmpType, List<Tuple<string, string>> filters)
        {
            var scatterSeries = new ScatterSeries { MarkerType = OxyPlot.MarkerType.Circle, BinSize = QAReportConstant.QA_REPORT_SCATTER_POINT_SIZE, MarkerFill = QAReportConstant.QA_REPORT_SCATTER_POINT_COLOR };
            var historgramSeries = new RectangleBarSeries { FillColor = OxyPlot.OxyColors.White, StrokeColor = OxyPlot.OxyColors.Black };
            int animalCount = 0;

            // Add scatter series point
            string sqlScatterPlotCommand = QAReportDataHelper.GetQueryGetScatterPlotData(conn, traitCode, cmpType, filters);
            Dictionary<int, int> histogramData = new Dictionary<int, int>();

            using (var cmd = new SqlCommand(sqlScatterPlotCommand, conn))
            {
                cmd.CommandTimeout = 0;

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        if (!(DBNull.Value.Equals(reader["BV_COMPARE"]) || DBNull.Value.Equals(reader["BV_SOURCE"])))
                        {
                            double bvCompare = double.Parse(reader["BV_COMPARE"].ToString());
                            double bvSource = double.Parse(reader["BV_SOURCE"].ToString());

                            scatterSeries.Points.Add(new ScatterPoint(bvCompare, bvSource));

                            // Add to histogram data
                            int diff = (int)(bvSource - bvCompare);

                            if (diff >= -60 && diff <= 60)
                            {
                                if (histogramData.ContainsKey(diff))
                                    histogramData[diff]++;
                                else histogramData.Add(diff, 1);
                            }

                            // Set animal count
                            animalCount++;
                        }
                    }
                }
            }

            // Add function linear plot
            DataRow linearFuncDataRow = QAReportDataHelper.GetLinearFuncData(conn, traitCode, cmpType, filters);
            string scatterPlotTitle = string.Empty;
            string histogramTitle = string.Empty;
            double regA = 0, regB = 0, corr = 0, stdDiff = 0;

            if (linearFuncDataRow != null)
            {
                regA = !linearFuncDataRow["REG_A"].Equals(DBNull.Value) ? double.Parse(linearFuncDataRow["REG_A"].ToString()) : 0;
                regB = !linearFuncDataRow["REG_B"].Equals(DBNull.Value) ? double.Parse(linearFuncDataRow["REG_B"].ToString()) : 0;
                corr = !linearFuncDataRow["COR_SRC_COMP"].Equals(DBNull.Value) ? double.Parse(linearFuncDataRow["COR_SRC_COMP"].ToString()) : 0;
                stdDiff = !linearFuncDataRow["DIFF_STD_DEV"].Equals(DBNull.Value) ? double.Parse(linearFuncDataRow["DIFF_STD_DEV"].ToString()) : 0;
                Func<double, double> linearFunc = (x) => regA * x + regB;
                Func<double, double> linearXYFunc = (x) => x;

                if (!linearFuncDataRow["COMP_MIN"].Equals(DBNull.Value) && !linearFuncDataRow["COMP_MAX"].Equals(DBNull.Value))
                {
                    scatterPlotModel.Series.Add(new FunctionSeries(linearFunc, double.Parse(linearFuncDataRow["COMP_MIN"].ToString()), double.Parse(linearFuncDataRow["COMP_MAX"].ToString()), 0.01));

                    // Linear x = y
                    scatterPlotModel.Series.Add(new FunctionSeries(linearXYFunc, double.Parse(linearFuncDataRow["COMP_MIN"].ToString()), double.Parse(linearFuncDataRow["COMP_MAX"].ToString()), 0.01));
                }
            }

            // Add rectangle bar series
            foreach (var diff in histogramData.Keys.ToList())
            {
                historgramSeries.Items.Add(new RectangleBarItem(diff, 0, diff + 1, histogramData[diff]));
            }

            // Set title plot
            scatterPlotTitle = string.Format("{0}{1} There are {2} animals\n(r = {3}, slope = {4}, int = {5})\n ", breedCode != null ? breedCode + " - " : "", traitCode, animalCount, Math.Round(corr, 4, MidpointRounding.AwayFromZero), Math.Round(regA, 4, MidpointRounding.AwayFromZero), Math.Round(regB, 4, MidpointRounding.AwayFromZero));
            histogramTitle = string.Format("{0} Differences, STD.DEV = {1}", (cmpType == CompareType.BV || cmpType == CompareType.RAW_SOLUTION) ? "Breeding Value" : (cmpType == CompareType.REL ? "Reliability" : "DTD"), Math.Round(stdDiff, 4, MidpointRounding.AwayFromZero));

            SetupScatterPlotModel(scatterPlotModel, scatterPlotTitle, cmpRunName, curRunName);
            SetupHistogramModel(histogramModel, histogramTitle, cmpRunName, curRunName, cmpType.Equals(CompareType.BV) ? true : false);

            // Add to model
            scatterPlotModel.Series.Add(scatterSeries);
            histogramModel.Series.Add(historgramSeries);

            // Clear memory
            linearFuncDataRow = null;
            histogramData.Clear();
            histogramData = null;
        }

        private static void SetupScatterPlotModel(OxyPlot.PlotModel model, string title, string cmpRunName, string curRunName)
        {
            model.Title = title;
            model.Axes.Add(new LinearAxis { Position = AxisPosition.Bottom, Title = string.Format("COMPARE RUN ({0})", cmpRunName) });
            model.Axes.Add(new LinearAxis { Position = AxisPosition.Left, Title = string.Format("CURRENT RUN ({0})", curRunName) });
            model.TitlePadding = -10;
        }

        private static void SetupHistogramModel(OxyPlot.PlotModel model, string title, string cmpRunName, string curRunName, bool isBVChart)
        {
            string nameAxis = isBVChart ? "BV" : "REL";
            model.Title = title;    
            model.Axes.Add(new LinearAxis { Position = AxisPosition.Bottom, Title = string.Format("{0} CURRENT RUN {1} - {0} COMPARE RUN {2}", nameAxis, curRunName, cmpRunName), Minimum = QAReportConstant.QA_REPORT_HISTOGRAM_CHART_X_AXIS_MIN_VALUE, Maximum = QAReportConstant.QA_REPORT_HISTOGRAM_CHART_X_AXIS_MAX_VALUE});
            model.Axes.Add(new LinearAxis { Position = AxisPosition.Left, Title = "Frequency" });
        }

        public static Rectangle[] GetQAReportPdfLayoutDefault()
        {
            float widthA4 = iTextSharp.text.PageSize.A4.Height;
            float heightA4 = iTextSharp.text.PageSize.A4.Width;

            Rectangle[] layoutColumns = {
                new Rectangle(10,  heightA4 / 2 + 10, widthA4/2 - 10,  heightA4 - 10) ,  // Position for bv scatter plot
                new Rectangle(widthA4 / 2 + 10, heightA4 / 2 + 10, widthA4 - 10, heightA4 - 10), // Position for rel scatter plot
                new Rectangle(10, 10, widthA4 / 2 - 10, heightA4 / 2 - 10) ,  // Position for bv histogram
                new Rectangle(widthA4/2 + 10, 10, widthA4 - 10, heightA4/2 - 10),  // Position for rel histogram
            };

            return layoutColumns;
        }

        public static Rectangle[] GetQAReportPdfLayoutForCdrUI()
        {
            float widthA4 = iTextSharp.text.PageSize.A4.Height;
            float heightA4 = iTextSharp.text.PageSize.A4.Width;

            Rectangle[] layoutColumns = {
                new Rectangle(240, heightA4 / 2 + 10, widthA4,  heightA4 - 10) ,  // Position for bv scatter plot             
                new Rectangle(240, 10, widthA4, heightA4 / 2 - 10)  // Position for bv histogram
            };

            return layoutColumns;
        }

        public static ColumnText SetupPagePdf(Document document, string pdfExportFileName)
        {
            document.SetPageSize(iTextSharp.text.PageSize.A4.Rotate());
            PdfWriter pdfWriter = PdfWriter.GetInstance(document, new FileStream(pdfExportFileName, FileMode.Create));
            document.Open();

            PdfContentByte canvas = pdfWriter.DirectContent;
            return new ColumnText(canvas);
        }
    }
}
