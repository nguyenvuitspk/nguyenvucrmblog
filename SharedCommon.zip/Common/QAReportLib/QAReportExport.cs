﻿using DocumentFormat.OpenXml.Spreadsheet;
using iTextSharp.text;
using iTextSharp.text.pdf;
using NetworkShareHelper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NetworkShareHelper;

namespace QAReportLib
{
    public class QAReportExport
    {
        public static void ExportExcelReport(SqlConnection sqlConnection, string excelFilePath, string query, string sheetName, string[][] headerReport = null, bool autoSaveFile = false)
        {
            QAReportExcelLib qaReportExcel = new QAReportExcelLib(excelFilePath, autoSaveFile);
            Worksheet workSheet = qaReportExcel.AddWorkSheet(sheetName);
            qaReportExcel.AppendSheetDataReport(workSheet, headerReport);
            qaReportExcel.AppendSheetDataReport(sqlConnection, workSheet, query, true);
            qaReportExcel.Save(workSheet);
            qaReportExcel.Dispose();
        }

        public static void ExportExcelReport(string excelFilePath, DataTable dataTable, string sheetName, string[][] headerReport = null, bool autoSaveFile = false)
        {
            QAReportExcelLib qaReportExcel = new QAReportExcelLib(excelFilePath, autoSaveFile);
            Worksheet workSheet = qaReportExcel.AddWorkSheet(sheetName);
            qaReportExcel.AppendSheetDataReport(workSheet, headerReport);
            qaReportExcel.AppendSheetDataReport(workSheet, dataTable, true);
            qaReportExcel.Save(workSheet);
            qaReportExcel.Dispose();
        }

        public static string ExportSummaryCompareToExcelFile(string outputFolder, SqlConnection sqlConnection, string srcReleaseName, string cmpReleaseName, CompareType cmpType, List<Tuple<string, string>> filters ,bool autoSaveFile = false)
        {
            DateTime reportTime = DateTime.Now;
            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string excelFilePath = string.Format(@"{0}\{1}\summary_{2}{3}.xlsx"
                                                    , outputFolder
                                                    , reportGenerateDirectory
                                                    , cmpType.ToString()
                                                    , filters.Count() > 0 ? "_" + string.Join("_", filters.Select(_ => _.Item2).ToArray()) : "");
            string fileName = reportGenerateDirectory + "\\" + excelFilePath.Substring(excelFilePath.LastIndexOf("\\") + 1);
            SharedGNetworkAccess web_directory_bin = new SharedGNetworkAccess("WEB_DIRECTORY_BIN");
            using (new NetworkConnection(web_directory_bin.RootFolder, new System.Net.NetworkCredential(web_directory_bin.Username, web_directory_bin.Password)))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(excelFilePath));
                QAReportExcelLib qaReportExcel = new QAReportExcelLib(excelFilePath, sqlConnection, autoSaveFile);
                Worksheet workSheet = qaReportExcel.AddWorkSheet(QAReportConstant.QA_REPORT_SUMMARY_COMPARE_WORK_SHEET_NAME);
                qaReportExcel.AppendSumaryCompareReportHeader(workSheet, srcReleaseName, cmpReleaseName);
                qaReportExcel.AppendSheetDataSumaryCompareReport(workSheet, cmpType, filters);
                qaReportExcel.Save(workSheet);
                qaReportExcel.Dispose();
                return fileName;
            }
        }

        public static string ExportPdfReport(string outputFolder, SqlConnection sqlConnection, string srcRunName, string cmpRunName, List<Tuple<string, string>> filters, CompareType? cmpType = null)
        {
            DateTime reportTime = DateTime.Now;
            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string pdfExportFilePath = string.Format(@"{0}\{1}\breed{2}{3}.pdf"
                , outputFolder
                , reportGenerateDirectory
                , cmpType.HasValue? "_" + cmpType.ToString() : ""
                , filters.Count() > 0 ? "_" + string.Join("_", filters.Select(_ => _.Item2).ToArray()) : "");
            string fileName = reportGenerateDirectory + "\\" + pdfExportFilePath.Substring(pdfExportFilePath.LastIndexOf("\\") + 1);
            Directory.CreateDirectory(Path.GetDirectoryName(pdfExportFilePath));
            List<string> traits = QAReportDataHelper.GetTraitCodesForPdfReport(sqlConnection, filters, cmpType);

            if (traits.Count() > 0)
            {
                Document document = new Document();
                ColumnText colTextPdf = QAReportPDFLib.SetupPagePdf(document, pdfExportFilePath);
                Rectangle[] layoutColumns = cmpType.HasValue? QAReportPDFLib.GetQAReportPdfLayoutForCdrUI() : QAReportPDFLib.GetQAReportPdfLayoutDefault();

                foreach (string trait in traits)
                {
                    if(cmpType.HasValue)
                        QAReportPDFLib.ExportChartsToPagePDF(sqlConnection, colTextPdf, layoutColumns, srcRunName, cmpRunName, trait, filters, cmpType.Value);
                    else
                        QAReportPDFLib.ExportChartsToPagePDF(sqlConnection, colTextPdf, layoutColumns, srcRunName, cmpRunName, trait, filters);

                    document.NewPage();
                }

                document.Close();
            }
            return fileName;
        }

        public static string ExportExtremeBVAnimals(string outputFolder, CompareType cmpType, SqlConnection sqlConnection, List<Tuple<string, string>> filters)
        {
            DateTime reportTime = DateTime.Now;
            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string filePath = string.Format(@"{0}\{1}\extreme_{2}_animals{3}.txt"
                                            , outputFolder
                                            , reportGenerateDirectory
                                            , cmpType.ToString().ToLower()
                                            , filters.Count() > 0 ? "_" + string.Join("_", filters.Select(_ => _.Item2).ToArray()) : "");
            string fileName = reportGenerateDirectory + "\\" + filePath.Substring(filePath.LastIndexOf("\\") + 1);
            Directory.CreateDirectory(Path.GetDirectoryName(filePath));
            string curBreed = "";
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("List of animals with relatively extreme breeding value differences");

            // Get data
            DataTable table = QAReportDataHelper.GetExtremeBVAnimalDataReport(sqlConnection, cmpType, filters);

            if (table != null)
            {
                foreach (DataRow row in table.Rows)
                {
                    if (!row["BREED_PUTATIVE"].ToString().Equals(curBreed))
                    {
                        sb.AppendLine();
                        curBreed = row["BREED_PUTATIVE"].ToString();
                        sb.AppendLine(curBreed);
                    }

                    sb.Append(row["ANIMAL_NATIONAL_ID"].ToString()).Append(" ");
                }
            }

            File.Delete(filePath);
            File.WriteAllText(filePath, sb.ToString());
            return fileName;
        }
    }
}
