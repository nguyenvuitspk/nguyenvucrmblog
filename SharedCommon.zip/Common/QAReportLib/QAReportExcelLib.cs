﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QAReportLib
{
    public class QAReportExcelLib : IDisposable
    {
        private SpreadsheetDocument spreedSheetDocument;
        private SqlConnection sqlConnection;
        private int curRowIdx;

        #region Constructor
        public QAReportExcelLib()
        {
            this.curRowIdx = 1;
        }

        public QAReportExcelLib(string excelFilePath, SqlConnection sqlConnection, bool autoSaveFile = false)
        {
            InitExcelDocument(excelFilePath, autoSaveFile);
            this.sqlConnection = sqlConnection;
            this.curRowIdx = 1;
        }

        public QAReportExcelLib(string excelFilePath, bool autoSaveFile = false)
        {
            InitExcelDocument(excelFilePath, autoSaveFile);
            this.curRowIdx = 1;
        }
        #endregion

        /// <summary>
        /// Init WorkbookPart, WorksheetPart and SheetData for document
        /// </summary>
        private void InitExcelDocument(string excelFilePath, bool autoSaveFile)
        {
            spreedSheetDocument = SpreadsheetDocument.Create(excelFilePath, SpreadsheetDocumentType.Workbook, autoSaveFile);
            spreedSheetDocument.AddWorkbookPart();
            spreedSheetDocument.WorkbookPart.Workbook = new Workbook();
            spreedSheetDocument.WorkbookPart.Workbook.Sheets = new Sheets();

        }

        #region Method for summary compare report
        public void AppendSumaryCompareReportHeader(Worksheet workSheet, string pbvReleaseName, string abvReleaseName)
        {
            // Get header list
            Tuple<string, string[]>[] sumaryCompareHeaders = GetSummaryCompareReportHeader(pbvReleaseName, abvReleaseName);

            // Init rows and mergeCells
            Row headerRow = new Row();
            Row subHeaderRow = new Row();

            int headerRowIdx = this.curRowIdx;
            int subHeaderRowIdx = this.curRowIdx + 1;
            int colIdx = 0;

            // Append header data to row and after then merge cells
            foreach (var header in sumaryCompareHeaders)
            {
                // Append text to row
                AppendTextToRow(headerRow, new string[] { header.Item1 }, headerRowIdx, colIdx);
                AppendTextToRow(subHeaderRow, header.Item2, subHeaderRowIdx, colIdx);

                // Create Merge cell column header
                if (header.Item2.Count() > 0)
                    MergeTwoCells(workSheet, GetColumnName(headerRowIdx, colIdx), GetColumnName(headerRowIdx, colIdx + header.Item2.Count() - 1));
                else
                    MergeTwoCells(workSheet, GetColumnName(headerRowIdx, colIdx), GetColumnName(subHeaderRowIdx, colIdx));

                colIdx += 1 + (header.Item2.Count() - 1 >= 0 ? header.Item2.Count() - 1 : 0);
            }

            // Append row to sheetdata
            SheetData sheetData = workSheet.Elements<SheetData>().First();
            sheetData.AppendChild(headerRow);
            sheetData.AppendChild(subHeaderRow);

            // Update index Row
            this.curRowIdx += 2;
        }
            
        /// <summary>
        /// Append data to sheet data report
        /// </summary>
        public void AppendSheetDataSumaryCompareReport(Worksheet workSheet, CompareType cmpType, List<Tuple<string, string>> filters)
        {
            SheetData sheetData = workSheet.Elements<SheetData>().First();
            var summaryCompareData = QAReportDataHelper.GetSummaryCompareDataReport(sqlConnection, cmpType, filters);

            foreach(DataRow row in summaryCompareData.Rows)
            {
                AppendToLastRowSheetData(sheetData, row.ItemArray);
                curRowIdx++;
            }

            // Clear memory
            summaryCompareData.Clear();
            summaryCompareData = null;
        }

        public Tuple<string, string[]>[] GetSummaryCompareReportHeader(string pbvReleaseName, string abvReleaseName)
        {
            return new Tuple<string, string[]>[]
              {
                new Tuple<string, string[]>("Trait", new string[0]),
                new Tuple<string, string[]>("No", new string[0]),
                new Tuple<string, string[]>("Different", new string[4] { "Mean", "St d", "Min", "Max"}),
                new Tuple<string, string[]>("Correlation", new string[3] { "1 x 2", "2 x Dif", "1 x Dif"}),
                new Tuple<string, string[]>("SD1/SD2", new string[0]),
                new Tuple<string, string[]>("Regression", new string[2] { "a", "b"}),
                new Tuple<string, string[]>(pbvReleaseName, new string[4] { "Mean", "St d", "Min", "Max" }),
                new Tuple<string, string[]>(abvReleaseName, new string[4] { "Mean", "St d", "Min", "Max" }),
              };
        }
        #endregion

        #region Medthod for forward prediction
        public void AppendFWPredictionReportHeader(Worksheet workSheet, bool isBull = false)
        {
            // Get header list 
            var sumaryCompareHeaders = isBull ? GetFWPredictionBullReportHeader()
                : GetFWPredictionCowReportHeader();

            // Init rows and mergeCells 
            Row headerRow = new Row();
            Row subHeaderRow = new Row();

            int headerRowIdx = this.curRowIdx;
            int subHeaderRowIdx = this.curRowIdx + 1;
            int colIdx = 0;

            // Append header data to row and after then merge cells 
            foreach (var header in sumaryCompareHeaders)
            {
                // Append text to row 
                AppendTextToRow(headerRow, new string[] { header.Item1 }, headerRowIdx, colIdx);
                AppendTextToRow(subHeaderRow, header.Item2, subHeaderRowIdx, colIdx);

                // Create Merge cell column header 
                if (header.Item2.Count() > 0)
                    MergeTwoCells(workSheet, GetColumnName(headerRowIdx, colIdx), GetColumnName(headerRowIdx, colIdx + header.Item2.Count() - 1));
                else
                    MergeTwoCells(workSheet, GetColumnName(headerRowIdx, colIdx), GetColumnName(subHeaderRowIdx, colIdx));

                colIdx += 1 + (header.Item2.Count() - 1 >= 0 ? header.Item2.Count() - 1 : 0);
            }

            // Append row to sheetdata 
            SheetData sheetData = workSheet.Elements<SheetData>().First();
            sheetData.AppendChild(headerRow);
            sheetData.AppendChild(subHeaderRow);

            // Update index Row 
            this.curRowIdx += 2;
        }

        public Tuple<string, string[]>[] GetFWPredictionBullReportHeader()
        {
            return new Tuple<string, string[]>[]
            {
                new Tuple<string, string[]>("NATIONAL_ID", new string[0]),
                new Tuple<string, string[]>("SIRE_NATIONAL_ID", new string[0]),
                new Tuple<string, string[]>("DAM_NATIONAL_ID", new string[0]),
                new Tuple<string, string[]>("BIRTH_DATE", new string[0]),
                new Tuple<string, string[]>("BV_B", new string[0]),
                new Tuple<string, string[]>("REL_B", new string[0]),
                new Tuple<string, string[]>("NO_OFFSPRING", new string[0]),
                new Tuple<string, string[]>("BV_A", new string[0]),
                new Tuple<string, string[]>("REL_A", new string[0]),
            };
        }

        public Tuple<string, string[]>[] GetFWPredictionCowReportHeader()
        {
            return new Tuple<string, string[]>[]
            {
                new Tuple<string, string[]>("NATIONAL_ID", new string[0]),
                new Tuple<string, string[]>("SIRE_NATIONAL_ID", new string[0]),
                new Tuple<string, string[]>("DAM_NATIONAL_ID", new string[0]),
                new Tuple<string, string[]>("BIRTH_DATE", new string[0]),
                new Tuple<string, string[]>("BV_B", new string[0]),
                new Tuple<string, string[]>("REL_B", new string[0]),
                new Tuple<string, string[]>("NoLacts", new string[0]),
                new Tuple<string, string[]>("NO_OBS", new string[0]),
                new Tuple<string, string[]>("BV_A", new string[0]),
                new Tuple<string, string[]>("REL_A", new string[0])
            };
        }

        public void AppendSheetForwardPredictionReport(Worksheet workSheet, List<Tuple<string, string>> filters, DataTable summaryCompareData, bool isBull)
        {
            SheetData sheetData = workSheet.Elements<SheetData>().First();

            foreach (DataRow row in summaryCompareData.Rows)
            {
                AppendToLastRowSheetData(sheetData, row.ItemArray);
                curRowIdx++;
            }

            // Clear memory
            summaryCompareData.Clear();
        }
        #endregion

        #region Method for Trait compare report
        #endregion

        #region Method for Excel
        public Worksheet AddWorkSheet(string workSheetName)
        {
            WorksheetPart workSheetPart = spreedSheetDocument.WorkbookPart.AddNewPart<WorksheetPart>();
            workSheetPart.Worksheet = new Worksheet(new SheetData());

            spreedSheetDocument.WorkbookPart.Workbook.Sheets.AppendChild(new Sheet()
            {
                Id = spreedSheetDocument.WorkbookPart.GetIdOfPart(workSheetPart),
                SheetId = 1,
                Name = workSheetName
            });

            return workSheetPart.Worksheet;
        }

        public Worksheet GetWorksheet(string worksheetName)
        {
            IEnumerable<Sheet> sheets = spreedSheetDocument.WorkbookPart.Workbook.Descendants<Sheet>().Where(s => s.Name == worksheetName);
            WorksheetPart worksheetPart = (WorksheetPart)spreedSheetDocument.WorkbookPart.GetPartById(sheets.First().Id);
            if (sheets.Count() == 0)
                return null;
            else
                return worksheetPart.Worksheet;
        }

        /// <summary>
        /// Append values to last row of sheetdata
        /// </summary>
        private void AppendToLastRowSheetData(SheetData sheetData, object[] values)
        {
            Row row = new Row();
            int idxCol = 0;

            foreach (object value in values)
            {
                Cell cell = new Cell();
                cell.CellReference = GetColumnName(curRowIdx, idxCol++);
                cell.CellValue = new CellValue(value == null || value.ToString().Equals("")? "-" : value.ToString());

                // Set type cell value
                if (value is int || value is float || value is double)
                    cell.DataType = CellValues.Number;
                else // String
                    cell.DataType = CellValues.String;

                // Append to row
                row.AppendChild(cell);

            }

            sheetData.AppendChild(row);
        }

        private void AppendTextToRow(Row row, string[] values, int idxRow, int idxCol)
        {
            foreach (string value in values)
            {
                Cell cell = new Cell();
                cell.DataType = CellValues.String;
                cell.CellReference = GetColumnName(idxRow, idxCol++);
                cell.CellValue = new CellValue(value);

                row.AppendChild(cell);
            }
        }

        public void AppendSheetDataReport(Worksheet workSheet, DataTable tableData, bool isAddHeader = false)
        {
            SheetData sheetData = workSheet.Elements<SheetData>().First();

            if (isAddHeader)
            {
                AppendToLastRowSheetData(sheetData, tableData.Columns.Cast<DataColumn>().Select(_ => _.ColumnName).ToArray());
                curRowIdx++;
            }

            foreach (DataRow row in tableData.Rows)
            {
                AppendToLastRowSheetData(sheetData, row.ItemArray);
                curRowIdx++;
            }

            // Clear memory
            tableData.Clear();
            tableData = null;
        }

        /// <summary>
        /// Using for append big data
        /// </summary>
        /// <param name="workSheet"></param>
        /// <param name="sqlCommand"></param>
        public void AppendSheetDataReport(SqlConnection sqlConnection, Worksheet workSheet, string sqlCommand, bool isAddHeader = false)
        {
            SheetData sheetData = workSheet.Elements<SheetData>().First();

            using (var cmd = new SqlCommand(sqlCommand, sqlConnection))
            {
                cmd.CommandTimeout = 0;

                using (var reader = cmd.ExecuteReader())
                {
                    if (isAddHeader)
                    {
                        AppendToLastRowSheetData(sheetData, Enumerable.Range(0, reader.FieldCount).Select(_ => reader.GetName(_)).ToArray());
                        curRowIdx++;
                    }

                    object[] values = new object[reader.FieldCount];

                    while (reader.Read())
                    {
                        reader.GetValues(values);
                        AppendToLastRowSheetData(sheetData, values);
                        curRowIdx++;
                    }
                }
            }
        }

        /// <summary>
        /// Append data to reports
        /// </summary>
        /// <param name="sqlConnection"></param>
        /// <param name="workSheet"></param>
        /// <param name="data">data[i] are data for row in excel file</param>
        /// <param name="isAddHeader"></param>
        public void AppendSheetDataReport(Worksheet workSheet, string[][] data)
        {
            if (data == null) return;

            SheetData sheetData = workSheet.Elements<SheetData>().First();

            foreach(var row in data)
            {
                AppendToLastRowSheetData(sheetData, row);
                curRowIdx++;
            }
        }

        public void MergeTwoCells(Worksheet worksheet, string cell1Name, string cell2Name)
        {
            // Open the document for editing.

            if (worksheet == null || string.IsNullOrEmpty(cell1Name) || string.IsNullOrEmpty(cell2Name))
            {
                return;
            }

            MergeCells mergeCells;
            if (worksheet.Elements<MergeCells>().Count() > 0)
            {
                mergeCells = worksheet.Elements<MergeCells>().First();
            }
            else
            {
                mergeCells = new MergeCells();

                // Insert a MergeCells object into the specified position.
                if (worksheet.Elements<CustomSheetView>().Count() > 0)
                {
                    worksheet.InsertAfter(mergeCells, worksheet.Elements<CustomSheetView>().First());
                }
                else if (worksheet.Elements<DataConsolidate>().Count() > 0)
                {
                    worksheet.InsertAfter(mergeCells, worksheet.Elements<DataConsolidate>().First());
                }
                else if (worksheet.Elements<SortState>().Count() > 0)
                {
                    worksheet.InsertAfter(mergeCells, worksheet.Elements<SortState>().First());
                }
                else if (worksheet.Elements<AutoFilter>().Count() > 0)
                {
                    worksheet.InsertAfter(mergeCells, worksheet.Elements<AutoFilter>().First());
                }
                else if (worksheet.Elements<Scenarios>().Count() > 0)
                {
                    worksheet.InsertAfter(mergeCells, worksheet.Elements<Scenarios>().First());
                }
                else if (worksheet.Elements<ProtectedRanges>().Count() > 0)
                {
                    worksheet.InsertAfter(mergeCells, worksheet.Elements<ProtectedRanges>().First());
                }
                else if (worksheet.Elements<SheetProtection>().Count() > 0)
                {
                    worksheet.InsertAfter(mergeCells, worksheet.Elements<SheetProtection>().First());
                }
                else if (worksheet.Elements<SheetCalculationProperties>().Count() > 0)
                {
                    worksheet.InsertAfter(mergeCells, worksheet.Elements<SheetCalculationProperties>().First());
                }
                else
                {
                    worksheet.InsertAfter(mergeCells, worksheet.Elements<SheetData>().First());
                }
            }

            // Create the merged cell and append it to the MergeCells collection.
            MergeCell mergeCell = new MergeCell() { Reference = new StringValue(cell1Name + ":" + cell2Name) };
            mergeCells.Append(mergeCell);

            worksheet.Save();
            
        }

        private static string GetColumnName(int indexRow, int indexColumn)
        {
            string columnName = "";
            char achar;
            int mod;

            // Get Column name
            while (true)
            {
                mod = (indexColumn % 26) + 65;
                indexColumn = (int)(indexColumn / 26);
                achar = (char)mod;
                columnName = achar + columnName;
                if (indexColumn > 0) indexColumn--;
                else if (indexColumn == 0) break;
            }

            return columnName + indexRow;
        }

        /// <summary>
        /// Save worksheet
        /// </summary>
        public void Save(Worksheet workSheet)
        {
            workSheet.Save();
            spreedSheetDocument.WorkbookPart.Workbook.Save();
            
        }

        public void Dispose()
        {
            spreedSheetDocument.Dispose();
            spreedSheetDocument = null;
            sqlConnection = null;
        }
        #endregion
    }
}
