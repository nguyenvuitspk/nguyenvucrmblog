﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QAReportLib
{
    public class QAReportConstant
    {
        public static string QA_REPORT_SUMMARY_COMPARE_WORK_SHEET_NAME = "Summary Compare Report";
        public static string QA_REPORT_SUMMARY_TRAIT_COMPARE_WORK_SHEET_NAME = "Summary Trait Compare Report";
        public static string QA_REPORT_INFORMATION_ANIMAL_TRAIT_COMPARE_WORK_SHEET_NAME = "Information Animal Trait Compare Report";
        public static string QA_REPORT_BVS_TRAIT_COMPARE_WORK_SHEET_NAME = "BVs Trait Compare Report";

        // Plot model
        public static int QA_REPORT_SCATTER_POINT_SIZE = 2;
        public static OxyPlot.OxyColor QA_REPORT_SCATTER_POINT_COLOR = OxyPlot.OxyColors.Black;

        // Image
        public static int QA_REPORT_IMG_WIDTH = 600;
        public static int QA_REPORT_IMG_HEIGHT = 400;

        public static int QA_REPORT_HISTOGRAM_CHART_X_AXIS_MIN_VALUE = -60;
        public static int QA_REPORT_HISTOGRAM_CHART_X_AXIS_MAX_VALUE = 60;

        public const string EB_ZONE_CONN_NAME = "ETL_DIRECTORY_BIN";

        public const string GES_QA_REPORT_OUTPUT_DIRECTORY = @"{0}\Gesnp";  // {RootFolder}\Gesnp
    }

    public enum CompareType
    {
        BV,
        REL,
        DTD,
        RAW_SOLUTION,
        BV1DTD2
    }

    public enum TraitCompareExportType
    {

    }
}
