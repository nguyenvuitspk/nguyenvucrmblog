﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSVFileParserLib
{
   public class CSVFileParser
    {
        public static string[] ParseNext(StreamReader frf, int colNo, char delimiter)
        {
            var line = frf.ReadLine();
            if (line != null)
            {
                return ParseCSVRecordLine(line, colNo, delimiter);
            }
            else
            {
                return null;
            }
        }

        public static string[] ParseCSVRecordLine(string line, int colNo, char delimiter)
        {
            string[] result = new string[colNo];

            var a = line.Split(delimiter);
            for (var i = 0; i < colNo; i++)
            {
                if (i < a.Length)
                {
                    result[i] = a[i].Trim();
                }
            }
            return result;
        }
    }
}
