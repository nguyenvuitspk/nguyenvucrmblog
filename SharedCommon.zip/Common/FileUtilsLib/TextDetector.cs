﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileUtilsLib
{
    public static class TextDetector
    {
        public const long MAX_SAMPLE = 8192L;
        public const float MAX_TOLERANCE = 0.9f;

        private static int[] histogram (byte[] data)
        {
            int len = data.Length;
            int[] h=new int[256];
            for (int i = 0; i < 256; i++) h[i] = 0;
            for (int i = 0; i < len; i++) h[data[i]]++  ;
            return h;
        }

        private static bool detectText(int[] hist, int total)
        {
            int countNormal = 0;
            for (int i = 0; i < 256; i++)
            {
                char ch = (char)i;
                if (Char.IsLetterOrDigit(ch)
                    ||
                    Char.IsWhiteSpace(ch)
                    ||
                    Char.IsPunctuation(ch)
                    )
                    countNormal += hist[i];
            }
            return (((float)countNormal / (float)total) > MAX_TOLERANCE);
        }
        public static bool isTextFile(string fileName)
        {
            FileStream fs=null;
            BinaryReader br=null;
            byte[] data;
            if (!File.Exists(fileName)) throw new FileNotFoundException("File "+ fileName + " does not exist");
            try
            {
                fs = File.Open(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                br = new BinaryReader(fs);
                long len = br.BaseStream.Length;
                if (len > MAX_SAMPLE) len = MAX_SAMPLE;
                data = br.ReadBytes((int)len);
                br.Close();
                fs.Close();
            } catch (Exception e) { throw e; }
            finally
            {
                if (br != null) { br.Close(); br.Dispose(); }
                if (fs != null) { fs.Close(); fs.Dispose(); }
            }
            return detectText(histogram(data),data.Length);
        }

    }
}
