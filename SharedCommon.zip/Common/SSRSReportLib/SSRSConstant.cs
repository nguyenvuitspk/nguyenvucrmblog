﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSRSReportLib
{
    public class SSRSConstant
    {
        public const string REPORT_SERVER_CONN_NAME = "REPORT_SERVER_PATH";
        public const string WEB_DIRECTORY_BIN = "WEB_DIRECTORY_BIN";
    }
    
    public enum ReportFileType
    {
        PDF,
        CSV,
        HTML5,
        IMAGE,
        MHTML,
        EXCEL,
        WORD,
        PPTX,
        ATOM,
        RGDI,
        EXCELOPENXML,
        DIF,
        TXT

    }    
}
