using DataReaderUtilsLib;
using NetworkShareHelper;
using SQLUtilsLib;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using ReportingServices = SSRSReportLib.ReportExecution2005;

namespace SSRSReportLib
{
    public class SSRSReport
    {
        #region Properties
        /// <summary>
        /// ssrs-project-name/report-id. E.g. export-heifer/report_shipment. 
        /// Then full path will be http://ssrsreport.adhis.com.au/reports/export-heifer/report_shipment
        /// </summary>
        public string ProjectName { get; set; }

        public string ReportID { get; set; }

        public List<ReportParameter> ReportParameters { get; set; }

        protected string ReportServiceUsername { get; set; }

        protected string ReportServicePassword { get; set; }

        protected string ReportServiceURL { get; set; }

        #endregion

        #region Constructors
        public SSRSReport()
        {
            ReportServiceUsername = "np";
            ReportServicePassword = "np123";
            ReportServiceURL = "http://localhost/ReportServer";
        }

        public SSRSReport(string _ReportServiceURL, string _ReportServiceUsername, string _ReportServicePassword)
        {
            ReportServiceURL = _ReportServiceURL;
            ReportServiceUsername = _ReportServiceUsername;
            ReportServicePassword = _ReportServicePassword;
        }
        #endregion

        #region Methods
        public string GetReport(string destRptFilePath, ReportFileType rptFileType)
        {
            var rptSvc = new ReportingServices.ReportExecutionService();
            rptSvc.Timeout = 30 * 60 * 1000;
            rptSvc.Credentials = new NetworkCredential(ReportServiceUsername, ReportServicePassword);
            rptSvc.Url = ReportServiceURL + Path.DirectorySeparatorChar + "ReportExecution2005.asmx";

            rptSvc.ExecutionHeaderValue = new ReportingServices.ExecutionHeader();

            string rptPath = "/" + ProjectName + "/" + ReportID;
            string rptSvcHistoryId = null;
            rptSvc.LoadReport(rptPath, rptSvcHistoryId);

            // Pass parameters to SSRS
            var execInfo = rptSvc.GetExecutionInfo();
            //if(execInfo.ParametersRequired && (ReportParameters != null))
            if((ReportParameters != null) && (ReportParameters.Count > 0))
            {
                rptSvc.SetExecutionParameters(ReportParameters.Select(rp => new ReportingServices.ParameterValue()
                {
                    Name = rp.ParamName,
                    Value = rp.ParamValue
                }).ToArray(), "en_us");
            }

            // Get Result bytes
            string devInfo = @"<DeviceInfo><Toolbar>False</Toolbar></DeviceInfo>";
            string extension = "";
            string mimetype = "";
            string encoding = "";
            ReportingServices.Warning[] warnings = null;
            string[] streamid = null;
            rptSvc.Timeout = System.Threading.Timeout.Infinite;
            var rptResultBuffer = rptSvc.Render(rptFileType.ToString(), devInfo, out extension, out mimetype, out encoding, out warnings, out streamid);

            // Try to create Directory of destination Report File
            var networkAccess = new SharedGNetworkAccess("WEB_DIRECTORY_BIN");

            using (new NetworkConnection(networkAccess.RootFolder, new NetworkCredential(networkAccess.Username, networkAccess.Password)))
            {
                if (!Directory.Exists(Path.GetDirectoryName(destRptFilePath)))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(destRptFilePath));
                }
            }
            // Save result to destination Report File
            File.WriteAllBytes(destRptFilePath, rptResultBuffer);

            return destRptFilePath;
        }

        public string GetReportWithoutCredential(string destRptFilePath, ReportFileType rptFileType)
        {
            var rptSvc = new ReportingServices.ReportExecutionService();
            rptSvc.Timeout = 30 * 60 * 1000;
            rptSvc.Credentials = new NetworkCredential(ReportServiceUsername, ReportServicePassword);
            rptSvc.Url = ReportServiceURL + Path.DirectorySeparatorChar + "ReportExecution2005.asmx";

            rptSvc.ExecutionHeaderValue = new ReportingServices.ExecutionHeader();

            string rptPath = "/" + ProjectName + "/" + ReportID;
            string rptSvcHistoryId = null;
            rptSvc.LoadReport(rptPath, rptSvcHistoryId);

            // Pass parameters to SSRS
            var execInfo = rptSvc.GetExecutionInfo();
            //if(execInfo.ParametersRequired && (ReportParameters != null))
            if ((ReportParameters != null) && (ReportParameters.Count > 0))
            {
                rptSvc.SetExecutionParameters(ReportParameters.Select(rp => new ReportingServices.ParameterValue()
                {
                    Name = rp.ParamName,
                    Value = rp.ParamValue
                }).ToArray(), "en_us");
            }

            // Get Result bytes
            string devInfo = @"<DeviceInfo><Toolbar>False</Toolbar></DeviceInfo>";
            string extension = "";
            string mimetype = "";
            string encoding = "";
            ReportingServices.Warning[] warnings = null;
            string[] streamid = null;
            rptSvc.Timeout = System.Threading.Timeout.Infinite;
            var rptResultBuffer = rptSvc.Render(rptFileType.ToString(), devInfo, out extension, out mimetype, out encoding, out warnings, out streamid);

            if (!Directory.Exists(Path.GetDirectoryName(destRptFilePath)))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(destRptFilePath));
            }
            // Save result to destination Report File
            File.WriteAllBytes(destRptFilePath, rptResultBuffer);

            return destRptFilePath;
        }

        /// <summary>
        /// Get extension file base on fileType input
        /// </summary>
        /// <param name="fileType"></param>
        /// <returns></returns>
        public string GetExtensionReportFile(ReportFileType fileType)
        {
            switch (fileType)
            {
                case ReportFileType.PDF:
                    return ".pdf";
                case ReportFileType.CSV:
                    return ".csv";
                case ReportFileType.WORD:
                    return ".docx";
                case ReportFileType.EXCEL:
                    return ".xlsx";
                case ReportFileType.PPTX:
                    return ".pptx";
                case ReportFileType.IMAGE:
                    return ".png";
                case ReportFileType.HTML5:
                    return ".html";
                case ReportFileType.ATOM:
                    return ".atomsvc";
            }

            return string.Empty;
        }

        public string GetFFReport(string destRptFilePath, ReportFileType rptFileType, string subRpt)
        {
            var rptSvc = new ReportingServices.ReportExecutionService();
            rptSvc.Timeout = -1;
            rptSvc.Credentials = new NetworkCredential(ReportServiceUsername, ReportServicePassword);
            rptSvc.Url = ReportServiceURL + Path.DirectorySeparatorChar + "ReportExecution2005.asmx";

            rptSvc.ExecutionHeaderValue = new ReportingServices.ExecutionHeader();

            string rptPath = "/" + ProjectName + "/" + subRpt;
            string rptSvcHistoryId = null;
            rptSvc.LoadReport(rptPath, rptSvcHistoryId);

            // Pass parameters to SSRS
            var execInfo = rptSvc.GetExecutionInfo();
            //if(execInfo.ParametersRequired && (ReportParameters != null))
            if ((ReportParameters != null) && (ReportParameters.Count > 0))
            {
                rptSvc.SetExecutionParameters(ReportParameters.Select(rp => new ReportingServices.ParameterValue()
                {
                    Name = rp.ParamName,
                    Value = rp.ParamValue
                }).ToArray(), "en_us");
            }

            // Get Result bytes
            string devInfo = @"<DeviceInfo><Toolbar>False</Toolbar></DeviceInfo>";
            string extension = "";
            string mimetype = "";
            string encoding = "";
            ReportingServices.Warning[] warnings = null;
            string[] streamid = null;
            var rptResultBuffer = rptSvc.Render(rptFileType.ToString(), devInfo, out extension, out mimetype, out encoding, out warnings, out streamid);

            var networkAccess = new SharedGNetworkAccess("WEB_DIRECTORY_BIN");
            // Try to create Directory of destination Report File
            using (new NetworkConnection(networkAccess.RootFolder, new NetworkCredential(networkAccess.Username, networkAccess.Password)))
            {
                if (!Directory.Exists(Path.GetDirectoryName(destRptFilePath)))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(destRptFilePath));
                }
            }
            // Save result to destination Report File
            File.WriteAllBytes(destRptFilePath, rptResultBuffer);

            return destRptFilePath;
        }
        #endregion
    }

    public class ReportParameter
    {
        public string ParamName { get; set; }

        public string ParamValue { get; set; }
    }
}
