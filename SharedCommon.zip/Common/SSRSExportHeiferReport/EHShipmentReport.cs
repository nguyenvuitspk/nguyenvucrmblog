﻿using SSRSReportLib;
using System;
using System.Collections.Generic;

namespace SSRSExportHeiferReport
{
    public class EHShipmentReport: SSRSExportHeiferReport
    {
        public EHShipmentReport()
            : base()
        {
            ReportID = "Export_Ready_Status_Report";
        }

        public string GetReport(ReportFileType fileType,string reportfilepath, string Herd_ID, string Farmname, string ShipmentDate)
        {
            ReportParameters = new List<ReportParameter>() {
                  new ReportParameter {
                        ParamName = "National_Herd_ID",
                        ParamValue = Herd_ID
                  },
                   new ReportParameter {
                        ParamName = "Farm_Name",
                        ParamValue = Farmname
                  },
                    new ReportParameter {
                        ParamName = "Expected_Shipment_Date",
                        ParamValue = ShipmentDate
                  }
                  //  ,
                  //new ReportParameter {
                  //      ParamName = "OFFSET",
                  //      ParamValue = offset.ToString()
                  //}
            };

            return base.GetReport(reportfilepath,fileType);
        }
    }
}
