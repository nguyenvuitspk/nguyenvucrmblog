﻿using SSRSReportLib;

namespace SSRSExportHeiferReport
{
    public class SSRSExportHeiferReport : SSRSReport
    {        
        public SSRSExportHeiferReport()
            : base()
        {
            ProjectName = "EH_Project";
        }
        
    }
}
