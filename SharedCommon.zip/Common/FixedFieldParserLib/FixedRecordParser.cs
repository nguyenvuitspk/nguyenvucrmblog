﻿namespace FixedFieldParserLib
{
    using System;
    using System.IO;

    public class FixedRecordParser
    {
        /// <summary>
        /// Open Fixed Record File
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        public static StreamReader OpenFixedRecordFile(string filename)
        {
            try
            {
                StreamReader frf = new StreamReader(filename);
                return frf;
            }
            catch
            {
                // return NULL if there is a problem
                return null;
            }

        }

        /// <summary> Parse Next line
        /// </summary>
        /// <param name="frf"></param>
        /// <param name="columnsLength">3,1,7,35,35,35,35,....</param>
        /// <returns>Trimmed Strings of the fields, null when file is finished</returns>
        public static string[] ParseNext(StreamReader frf, int[] columnsLength)
        {
            var line = frf.ReadLine();
            if (line != null)
            {
                return ParseFixedRecordLine(line, columnsLength);
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// close the file
        /// </summary>
        /// <param name="frf"></param>
        public static void CloseFixedRecordFile(StreamReader frf)
        {
            frf.Close();
        }

        /// <summary>Parse Fixed Record Line
        /// </summary>
        /// <param name="line">current line of the file</param>
        /// <param name="columnsLength">3,1,7,35,35,35,35,....</param>
        /// <returns>Trimmed Strings of the fields</returns>
        public static string[] ParseFixedRecordLine(string line, int[] columnsLength)
        {
            string[] result = new string[columnsLength.Length];
            int startOffset = 0;
            for (var i = 0; i < columnsLength.Length; i++)
            {
                if (line.Length >= startOffset + columnsLength[i])
                {
                    result[i] = line.Substring(startOffset, columnsLength[i]).Trim();
                }
                else if (startOffset <= line.Length)
                {
                    result[i] = line.Substring(startOffset, line.Length - startOffset).Trim();
                }

                startOffset = startOffset + columnsLength[i];
            }

            return result;
        }
    }
}
