﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.IO;
using System.Text;
using System.Threading;

namespace RunWF
{
    class Program
    {
        /* USAGE OF RETURNED ERRORLEVEL
         * -w : existed in cmd line >> app wait for WF to complete then return WF 's STATUS ( 0 == SUCCESS || -1 == FAILED) 
         * -w : not existed in cmd line >> app START WF ONLY then return STARTING 's STATUS ( 0 == SUCCESS || -1 == FAILED) 
         * -isgetcsv = true : get CSV template then return ( 2 == SUCCESS || -2 == FAILED)
         * IF APP RETURN 24 : APPLICATION FAILED
         */

        #region Declare variables
        static string cnDV = "";
        static string cnSSISDB = "";
        static string isGetCSV = "false";
        static string wfName = "";
        static string csvPath = "";
        static string userName = "";
        static string isGetSTT = "false";
        static string wfID = "";
        static bool isWaitExist = false;
        static bool isParamExist = false;
        static int rs = 24;
        #endregion
        #region UTILITIES
        private static string GetValFromArg(string[] inputArr, string compareVal)
        {
            for (int i = 0; i < inputArr.Length; i++)
            {
                if (inputArr[i].Equals(compareVal))
                {
                    return inputArr[i + 1];
                }
            }
            return "";
        }

        private static bool IsExistInArg(string[] inputArr, string compareVal)
        {
            foreach (var item in inputArr)
            {
                if (item == compareVal)
                {
                    return true;
                }
            }
            return false;
        }

        private static void WriteLogFile(string filePath, string logType, string logMsg)
        {
            string path = filePath + logType + "Log_" + DateTime.Now.ToString("ddMMyyyy") + ".txt";
            File.AppendAllText(path, logMsg + Environment.NewLine + Environment.NewLine);
        }

        private static string FindWfIdByWfName(string wfName, string cnDV)
        {
            try
            {
                string query = string.Format(@"select distinct PK_WORKFLOW_ID from WORKFLOW_DETAIL 
                                    where BK_WORKFLOW_NAME = '{0}'", wfName);
                return DataReaderUtilsLib.DataReaderUtilities.GetScalaValue(cnDV, query).ToString();
            }
            catch (Exception ex)
            {
                WriteLogFile(AppDomain.CurrentDomain.BaseDirectory, "Error", ex.ToString());
                return "";
            }
        }

        private static WorkflowOperation.Workflow PreparePIO4WF(WorkflowOperation.Workflow workflow, string type, string name, string value)
        {
            try
            {
                if (workflow == null)
                {
                    WriteLogFile(AppDomain.CurrentDomain.BaseDirectory, "Error", "Recheck Workflow ID...");
                    rs = -1;
                    return new WorkflowOperation.Workflow();
                }
                for (var i = 0; i < workflow.Transformations.Count; i++)
                {
                    var tr = workflow.Transformations[i];
                    if (workflow.Transformations.Count <= i) continue;
                    var trPost = workflow.Transformations[i];
                    #region Assign value for Input_Datasets
                    if (type.Equals("Input_Datasets") && tr.Input_Datasets.Items != null)
                    {
                        for (var iDS = 0; iDS < tr.Input_Datasets.Items.Count; iDS++)
                        {
                            if (trPost.Input_Datasets.Items[iDS].Name == name)
                            {
                                trPost.Input_Datasets.Items[iDS].Value = value; //Add value for input_datasets into transformation
                                break;
                            }
                        }
                        break;
                    }
                    #endregion
                    #region Assign value for Parameters
                    if (type.Equals("Parameters") && tr.Parameters != null)
                    {
                        for (var p = 0; p < tr.Parameters.Count; p++)
                        {
                            if (tr.Parameters[p].Name == name)
                            {
                                tr.Parameters[p].Value = value; //Add value for parameters into transformation
                                break;
                            }
                        }
                        break;
                    }
                    #endregion
                    #region Assign value for Output_Datasets
                    if (type.Equals("Output_Datasets") && tr.Output_Datasets.Items != null)
                    {
                        for (var oDS = 0; oDS < tr.Output_Datasets.Items.Count; oDS++)
                        {
                            if (trPost.Output_Datasets.Items[oDS].Name == name)
                            {
                                trPost.Output_Datasets.Items[oDS].Value = value; //Add value for output_datasets into transformation
                                break;
                            }
                        }
                        break;
                    }
                    #endregion
                }
                return workflow;
            }
            catch (Exception ex)
            {
                WriteLogFile(AppDomain.CurrentDomain.BaseDirectory, "Error", ex.ToString());
                rs = -1;
                return new WorkflowOperation.Workflow();
            }
        }

        private static string HandleSameFileName(string fullPath)
        {
            int count = 1;

            string fileNameOnly = Path.GetFileNameWithoutExtension(fullPath);
            string extension = Path.GetExtension(fullPath);
            string path = Path.GetDirectoryName(fullPath);
            string newFullPath = fullPath;
            if (!Directory.Exists(path))  // if it doesn't exist, create
                Directory.CreateDirectory(path);

            while (File.Exists(newFullPath))
            {
                string tempFileName = string.Format("{0}({1})", fileNameOnly, count++);
                newFullPath = Path.Combine(path, tempFileName + extension);
            }
            return newFullPath;
        }
        private static int ProvideCSVFile(string workflowID)
        {
            try
            {
                var workflow = WorkflowOperation.WorkflowOperation.GetSystemWorkflow(workflowID);
                if (workflow == null)
                {
                    WriteLogFile(AppDomain.CurrentDomain.BaseDirectory, "Error", "Recheck Workflow ID...");
                    return -2;
                }
                for (var i = 0; i < workflow.Transformations.Count; i++)
                {
                    var csv = new StringBuilder();
                    var pkgPath = workflow.Transformations[i].ETLPkgName;
                    var firstLine = string.Format("{0},{1}", "PackagePath", pkgPath);
                    csv.AppendLine(firstLine);
                    var tr = workflow.Transformations[i];
                    if (workflow.Transformations.Count <= i) continue;
                    var trPost = workflow.Transformations[i];
                    #region Create CSV Template base on Input_Datasets Parameters Output_Datasets
                    if (tr.Input_Datasets.Items != null)
                    {
                        for (var j = 0; j < tr.Input_Datasets.Items.Count; j++)
                        {
                            var cntInputDS = tr.Input_Datasets.Items[j].Name;
                            if (!cntInputDS.Equals("Animal_Base"))
                            {
                                var newLine = string.Format("{0},{1},{2}", "Input_Datasets", cntInputDS, "");
                                csv.AppendLine(newLine);
                            }
                        }
                    }

                    if (tr.Parameters != null)
                    {
                        for (var k = 0; k < tr.Parameters.Count; k++)
                        {
                            var cntInputPR = tr.Parameters[k].Name;
                            var newLine = string.Format("{0},{1},{2}", "Parameters", cntInputPR, "");
                            csv.AppendLine(newLine);
                        }
                    }

                    if (tr.Output_Datasets.Items != null)
                    {
                        for (var j = 0; j < tr.Output_Datasets.Items.Count; j++)
                        {
                            var cntOutputDS = tr.Output_Datasets.Items[j].Name;
                            var newLine = string.Format("{0},{1},{2}", "Output_Datasets", cntOutputDS, "");
                            csv.AppendLine(newLine);
                        }
                    }

                    #endregion
                    File.WriteAllText(HandleSameFileName(AppDomain.CurrentDomain.BaseDirectory + @"\CSV_Files\" + Path.GetFileNameWithoutExtension(pkgPath) + ".csv"), csv.ToString());
                    WriteLogFile(AppDomain.CurrentDomain.BaseDirectory, "Run", "CSV Template: " + Path.GetFileNameWithoutExtension(pkgPath) + " created successfully!");
                }
                return 2;
            }
            catch (Exception ex)
            {
                WriteLogFile(AppDomain.CurrentDomain.BaseDirectory, "Error", ex.ToString());
                return -2;
            }
        }

        private static void RunWFWithCSVFile(string workflowID, string userName, string csvPath)
        {
            try
            {
                var workflow = WorkflowOperation.WorkflowOperation.GetSystemWorkflow(workflowID);
                if (workflow == null)
                {
                    WriteLogFile(AppDomain.CurrentDomain.BaseDirectory, "Error", "Recheck Workflow ID...");
                    rs = -1;
                    return;
                }
                for (var i = 0; i < workflow.Transformations.Count; i++)
                {
                    var tr = workflow.Transformations[i];
                    if (workflow.Transformations.Count <= i) continue;
                    var trPost = workflow.Transformations[i];
                    #region Read CSV and assign value for Input_Datasets
                    if (tr.Input_Datasets.Items != null)
                    {
                        for (var iDS = 0; iDS < tr.Input_Datasets.Items.Count; iDS++)
                        {
                            using (TextFieldParser parser = new TextFieldParser(csvPath))
                            {
                                parser.TextFieldType = FieldType.Delimited;
                                parser.SetDelimiters(",");
                                while (!parser.EndOfData)
                                {
                                    string[] fields = parser.ReadFields(); //Processing row
                                    if (fields[0] == "Input_Datasets")
                                    {
                                        if (trPost.Input_Datasets.Items[iDS].Name == fields[1])
                                        {
                                            trPost.Input_Datasets.Items[iDS].Value = fields[2]; //Add value from CSV File
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    #endregion
                    #region Read CSV and assign value for Parameters
                    if (tr.Parameters != null)
                    {
                        for (var p = 0; p < tr.Parameters.Count; p++)
                        {
                            using (TextFieldParser parser = new TextFieldParser(csvPath))
                            {
                                parser.TextFieldType = FieldType.Delimited;
                                parser.SetDelimiters(",");
                                while (!parser.EndOfData)
                                {
                                    string[] fields = parser.ReadFields(); //Processing row
                                    for (int c = 0; c < fields.Length; c++)
                                    {
                                        if (fields[0] == "Parameters")
                                        {
                                            if (tr.Parameters[p].Name == fields[1])
                                            {
                                                tr.Parameters[p].Value = fields[2]; //Add value from CSV File
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    #endregion
                    #region Read CSV and assign value for Output_Datasets
                    if (tr.Output_Datasets.Items != null)
                    {
                        for (var oDS = 0; oDS < tr.Output_Datasets.Items.Count; oDS++)
                        {
                            using (TextFieldParser parser = new TextFieldParser(csvPath))
                            {
                                parser.TextFieldType = FieldType.Delimited;
                                parser.SetDelimiters(",");
                                while (!parser.EndOfData)
                                {
                                    string[] fields = parser.ReadFields(); //Processing row
                                    for (int c = 0; c < fields.Length; c++)
                                    {
                                        if (fields[0] == "Output_Datasets")
                                        {
                                            if (trPost.Output_Datasets.Items[oDS].Name == fields[1])
                                            {
                                                trPost.Output_Datasets.Items[oDS].Value = fields[2]; //Add value from CSV File
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    #endregion
                }
                var WPID = WorkflowOperation.WorkflowOperation.CreateUserWorkflowOperation(workflow, userName);
                rs = 0;
            }
            catch (Exception ex)
            {
                WriteLogFile(AppDomain.CurrentDomain.BaseDirectory, "Error", ex.ToString());
                rs = -1;
            }
        }

        private static void RunWFWithoutCSVFile(string workflowID, string userName, string[] inputArr)
        {
            try
            {
                var workflow = WorkflowOperation.WorkflowOperation.GetSystemWorkflow(workflowID);
                string getParamRaw = "";
                if (workflow == null)
                {
                    WriteLogFile(AppDomain.CurrentDomain.BaseDirectory, "Error", "Recheck Workflow ID...");
                    rs = -1;
                    return;
                }

                for (int i = 0; i < inputArr.Length; i++)
                {
                    if (inputArr[i].Equals("-P"))
                    {
                        getParamRaw = inputArr[i + 1];
                        string[] substring = getParamRaw.Split(';');
                        workflow = PreparePIO4WF(workflow, substring[0], substring[1], substring[2]);
                    }
                }

                var WPID = WorkflowOperation.WorkflowOperation.CreateUserWorkflowOperation(workflow, userName);
                rs = 0;
            }
            catch (Exception ex)
            {
                WriteLogFile(AppDomain.CurrentDomain.BaseDirectory, "Error", ex.ToString());
                rs = -1;
            }
        }

        private static void RunWFWithBothCsvCmdParam(string workflowID, string userName, string[] inputArr)
        {
            try
            {
                var workflow = WorkflowOperation.WorkflowOperation.GetSystemWorkflow(workflowID);
                string getParamRaw = "";
                if (workflow == null)
                {
                    WriteLogFile(AppDomain.CurrentDomain.BaseDirectory, "Error", "Recheck Workflow ID...");
                    rs = -1;
                    return;
                }

                #region Get all parameters from args THEN add to workflow 's information
                using (TextFieldParser parser = new TextFieldParser(csvPath))
                {
                    parser.TextFieldType = FieldType.Delimited;
                    parser.SetDelimiters(",");
                    while (!parser.EndOfData)
                    {
                        string[] fields = parser.ReadFields(); //Processing row
                        if (fields[0] != "PackagePath")
                        {
                            workflow = PreparePIO4WF(workflow, fields[0], fields[1], fields[2]);//Add value from CSV File
                        }
                    }
                }
                #endregion

                #region Get all parameters from args THEN add to workflow 's information
                for (int i = 0; i < inputArr.Length; i++)
                {
                    if (inputArr[i].Equals("-P"))
                    {
                        getParamRaw = inputArr[i + 1];
                        string[] substring = getParamRaw.Split(';');
                        workflow = PreparePIO4WF(workflow, substring[0], substring[1], substring[2]);
                    }
                }
                #endregion
                var WPID = WorkflowOperation.WorkflowOperation.CreateUserWorkflowOperation(workflow, userName);
                rs = 0;
            }
            catch (Exception ex)
            {
                WriteLogFile(AppDomain.CurrentDomain.BaseDirectory, "Error", ex.ToString());
                rs = -1;
            }
        }

        private static string GetSttWf(string workflowID, string cnSSISDB)
        {
            try
            {
                string query = string.Format(@"DECLARE @MAX_WPID INT SELECT @MAX_WPID = MAX(WPID) FROM SSISDB.dbo.WorkflowOperations WHERE WORKFLOW_ID = '{0}' SELECT STATUS FROM SSISDB.dbo.WorkflowOperations WHERE WORKFLOW_ID = '{0}' AND WPID= @MAX_WPID", workflowID);
                return DataReaderUtilsLib.DataReaderUtilities.GetScalaValue(cnSSISDB, query).ToString();
            }
            catch (Exception ex)
            {
                WriteLogFile(AppDomain.CurrentDomain.BaseDirectory, "Error", ex.ToString());
                return "";
            }
        }
        private static void wait4WfRs(string workflowID, string cnSSISDB, string wfName)
        {
            try
            {
                string stt = "";
                do
                {
                    stt = GetSttWf(workflowID, cnSSISDB);
                    Thread.Sleep(2000);
                } while (stt != "SUCCESS" && stt != "FAILED");
                WriteLogFile(AppDomain.CurrentDomain.BaseDirectory, "Run", "WORKFLOW " + wfName + " Run: " + stt + " at " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                if (stt == "SUCCESS")
                {
                    rs = 0;
                    return;
                }
                if (stt == "FAILED")
                {
                    rs = -1;
                    return;
                }
            }
            catch (Exception ex)
            {
                WriteLogFile(AppDomain.CurrentDomain.BaseDirectory, "Error", ex.ToString());
                rs = -1;
            }
        }

        private static string DetectRunningType(string[] args)
        {
            try
            {
                #region Read & Add values from ARGS
                cnDV = GetValFromArg(args, "-cndv");
                cnSSISDB = GetValFromArg(args, "-cnssisdb");
                wfName = GetValFromArg(args, "-wfname");
                isGetCSV = GetValFromArg(args, "-isgetcsv");
                csvPath = GetValFromArg(args, "-csvpath");
                userName = GetValFromArg(args, "-username");
                isGetSTT = GetValFromArg(args, "-isgetstt");
                #endregion

                SQLUtilsLib.DBReference.InitiateDBReference(null, cnSSISDB, cnDV);
                // Check 3 indeed values 
                if (String.IsNullOrEmpty(cnDV) || String.IsNullOrEmpty(cnSSISDB) || String.IsNullOrEmpty(wfName))
                {
                    WriteLogFile(AppDomain.CurrentDomain.BaseDirectory, "Error", "Please recheck inputs!");
                    return "failed";
                }
                wfID = FindWfIdByWfName(wfName, cnDV);
                // Check User purpose
                if (isGetCSV.Equals("true"))
                {
                    return "CSV";
                }

                isWaitExist = IsExistInArg(args, "-w");
                isParamExist = IsExistInArg(args, "-P");
                if (isParamExist && String.IsNullOrEmpty(csvPath))
                {
                    return "RunWithoutCSV";
                }
                if (!isParamExist && !String.IsNullOrEmpty(csvPath))
                {
                    return "RunWithCSV";
                }
                if (isParamExist && !String.IsNullOrEmpty(csvPath))
                {
                    return "RunWithBoth";
                }
                return "failed";
            }
            catch (Exception ex)
            {
                WriteLogFile(AppDomain.CurrentDomain.BaseDirectory, "Error", ex.ToString());
                rs = -1;
                return "failed";
            }
        }

        private static void RunWithType(string[] args)
        {
            string getType = DetectRunningType(args);
            if (String.IsNullOrEmpty(wfID))
            {
                rs = -1;
                return;
            }

            if (getType == "failed")
            {
                rs = -1;
                return;
            }
            if (getType == "CSV")
            {
                rs = ProvideCSVFile(wfID);
                return;
            }
            if (getType.Contains("RunWithCSV"))
            {
                if (isWaitExist)
                {
                    RunWFWithCSVFile(wfID, userName, csvPath);
                    wait4WfRs(wfID, cnSSISDB, wfName);
                    return;
                }
                else
                {
                    RunWFWithCSVFile(wfID, userName, csvPath);
                    return;
                }
            }
            if (getType.Contains("RunWithoutCSV"))
            {
                if (isWaitExist)
                {
                    RunWFWithoutCSVFile(wfID, userName, args);
                    wait4WfRs(wfID, cnSSISDB, wfName);
                    return;
                }
                else
                {
                    RunWFWithoutCSVFile(wfID, userName, args);
                    return;
                }
            }
            if (getType.Contains("RunWithBoth"))
            {
                if (isWaitExist)
                {
                    RunWFWithBothCsvCmdParam(wfID, userName, args);
                    wait4WfRs(wfID, cnSSISDB, wfName);
                    return;
                }
                else
                {
                    RunWFWithBothCsvCmdParam(wfID, userName, args);
                    return;
                }
            }
        }
        #endregion

        static int Main(string[] args)
        {
            #region 4TEST ONLY
            //cnDV = "Data Source=.;Initial Catalog=GESNP;Provider=SQLNCLI11.1;Integrated Security=SSPI;Connection Timeout=900;"; /*vtr test*/
            //cnSSISDB = "Data Source=.;Initial Catalog=SSISDB;Provider=SQLNCLI11.1;Integrated Security=SSPI;Connection Timeout=900;"; /*vtr test*/
            //wfName = "WF-GEN-ME-CREATE-GREF-SET-STD";/*vtr test*/
            //csvPath = @"C:\Users\NP\Desktop\consoleTest\GEN_Me_Create_GRef_Set_Std.csv";/*vtr test*/
            //userName = "vtr yuen";/*vtr test*/
            //isGetCSV = "false";/*vtr test*/
            //isGetSTT = "true"; /*vtr test*/
            //string[] arrtest = new string[] {
            //    "-cndv", "Data Source=.;Initial Catalog=GESNP;Provider=SQLNCLI11.1;Integrated Security=SSPI;Connection Timeout=900;"
            //    ,"-cnssisdb", "Data Source=.;Initial Catalog=SSISDB;Provider=SQLNCLI11.1;Integrated Security=SSPI;Connection Timeout=900;"
            //    ,"-wfname" ,"WF-GEN-ME-CREATE-GREF-SET-STD"
            //    ,"-csvpath", @"C:\Users\NP\Desktop\consoleTest\GEN_Me_Create_GRef_Set_Std.csv"
            //    ,"-username", "lenhu"
            //    ,"-isgetcsv", "false"
            //    ,"-isgetstt", "false"
            //    ,"-P", "Input_Datasets;ANIMAL_PEDIGREE_CALVING_EASE_DATASET_ID;F8AE609E-DDBB-4559-BFE3-8C07C6BF1794"
            //    ,"-P" , "Input_Datasets;ANIMAL_PEDIGREE_CONFORMATION_DATASET_ID;192537BE-C413-4A87-A8EB-DC610DF19D30"
            //    ,"-P" , "Input_Datasets;ANIMAL_PEDIGREE_FERTILITY_DATASET_ID;87887116-E275-401B-8438-FF23EB47E22F"
            //    ,"-P" , "Input_Datasets;ANIMAL_PEDIGREE_SCC_DATASET_ID;FE8F37B1-6194-4D17-AB8E-D7D3A350AEC6"
            //    ,"-P" , "Input_Datasets;ANIMAL_PEDIGREE_SURVIVAL_DATASET_ID;1D0795CB-2A2D-451C-8E73-E1DC8B9E1ED9"
            //    ,"-P" , "Input_Datasets;ANIMAL_PEDIGREE_WORKABILITY_DATASET_ID;44E649D8-2C2F-42DE-A9FE-4BCF417071FF"
            //    ,"-P" , "Input_Datasets;ANIMAL_PEDIGREE_YIELD_DATASET_ID;8CB41912-336E-4611-90C9-93666C5445F4"
            //    ,"-P" , "Input_Datasets;LAMBDA_DATASET_ID;3E49363A-7AE0-42C8-B470-A6A956105006"
            //    ,"-P" , "Parameters;TRAIT_LIST;1D396BB2-2860-4F8A-A979-07B2A7BCDD79,C07BAFE6-AE59-43B1-A4C9-151B50367140,D95FE4F8-F817-4A73-9E9A-15274F7C83AA,AE5AECEB-4B52-48F7-93D6-1E287AF733D9,C2788D2D-821A-4B53-93AE-2313B16EC6BB,B7601A04-417D-47E9-9A28-2A2B73B603E8,C0FEA5AE-1D4E-4530-9E81-37232FDB0403,3A582256-3BAB-4B46-908C-3B4982EFC277,B36ADBE3-84C1-4F6B-9E85-420D0B658D18,9C29E582-6E4D-4E0C-B7E7-44DF17F1CF75,1F6610F5-8C71-4D3C-8D2C-45FA09D47D50,0E60032B-EF1A-4E51-8821-5E2E3DB3CAB4,3A339B19-FDC1-4A16-919C-680EE1010CCF,45D0F433-73CA-4AB0-8042-6CA95E2D9800,0546C3D4-66B6-428A-94F4-729BAB229C8E,ACDB7CC9-D111-4C62-AFBB-77605AD53893,F7E35C1E-82AD-4CFE-8071-79583E8224F3,7A463759-FFCF-4D9B-A2C5-9D5ADBF70CE5,5BFAE7DD-10DD-4465-A22D-AB297CD64FDE,56AC07F6-7679-4F10-A911-B5970B883320,514272E3-2E52-4E94-8FF0-B6F39EEB3AFF,5B7C4F4E-0D2B-47D9-9E5B-BC3E9F1DDD3B,C385D623-9244-4CC3-AC93-C0C1A80FD315,04DB1101-3C57-4B69-8687-C81BB1079D6B,C86454FD-931D-4C99-85D7-C934C0F10466,CE226930-4BD4-424F-A057-DA4E202C43FA,3C174499-E56A-4BA9-83E1-DD0124C1EFB2,23FCF965-AAF7-4146-A2D9-DE5271A22559,5F6C43AC-B912-4281-9677-EC485A4ADE5F,D563DCC1-52D5-45D3-A440-F3825FB8F11E,9E9ABFA6-769A-4A73-9403-F5935D39EF71,F5469DD3-1D84-4F74-AD2C-FB4F2AA667F7,863A6F61-48EE-4E2B-A6D9-FCCDBBEC0968"
            //    ,"-P" , "Output_Datasets;MARKER_EFFECT_DATASET_ID;5DD88636-9C9B-4283-A249-BA1FA11F748B"
            //    ,"-w"
            //}; /*vtr test*/
            //args = arrtest; /*vtr test*/
            #endregion

            RunWithType(args);
            return rs;
        }
    }
}
