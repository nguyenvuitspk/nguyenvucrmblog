﻿namespace CommonETLLibs
{
    public class Constant
    {
        public const string SqlDateTimeFortmat = "yyyy-MM-dd HH:mm:ss.fff";
    }

    public static class RunStatus
    {
        public const string NEW = "NEW";
        public const string RUNNING = "RUNNING";
        public const string COMPLETED = "COMPLETED";
        public const string FAILED = "FAILED";
    }

    public static class TransformationOperationStatus
    {
        public const string CREATED = "CREATED";
        public const string RUNNING = "RUNNING";
        public const string CANCELED = "CANCELED";
        public const string FAILED = "FAILED";
        public const string PENDING = "PENDING";
        public const string ENDED_UNEXPECTEDLY = "ENDED UNEXPECTEDLY";
        public const string SUCCESS = "SUCCESS";
        public const string STOPPING = "STOPPING";
        public const string COMPLETED = "COMPLETED";
    }

    public static class WorkflowOperationStatus
    {
        public const string RUNNING = "RUNNING";
        public const string FAILED = "FAILED";
        public const string CANCELLED = "CANCELLED";
        public const string SUCCESS = "SUCCESS";
        public const string CREATED = "CREATED";
    }

    public static class ProcessDIFFileStatus
    {
        public const string COMPLETE = "COMPLETE";
        public const string FAILED = "FAILED";
        public const string REJECT = "REJECT";
    }

}
