﻿namespace CommonETLLibs
{
    using System;

    public class UserDefinedException
    {
    }

    public class FileCannotFoundException : Exception
    {

        public FileCannotFoundException(string fileName)
            : base("Cannot find the file: " + fileName + "!")
        {
        }
    }

    public class TransformationFailure : Exception
    {
        public TransformationFailure(string transformation)
            : base("The workflow has been failed at: " + transformation)
        {
        }
    }

}
