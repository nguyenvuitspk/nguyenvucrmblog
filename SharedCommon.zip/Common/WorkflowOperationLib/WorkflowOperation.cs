﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Management = Microsoft.SqlServer.Management.IntegrationServices;
using CommonETLLibs;
using DataReaderUtilsLib;
using SQLUtilsLib;
using System.Xml.Linq;

namespace WorkflowOperation
{
    public class WorkflowOperation
    {
        #region parse XML 
        public static Workflow ParseXml2Workflow(string xml)
        {
            Workflow result;
            XmlSerializer serializer = new XmlSerializer(typeof(Workflow));
            using (StringReader reader = new StringReader(xml))
            {
                result = (Workflow)serializer.Deserialize(reader);
            }
            return result;
        }

        public static string ParseWorkflow2XML(Workflow obj)
        {
            StringWriter sw = new StringWriter();
            XmlSerializer s = new XmlSerializer(obj.GetType());
            s.Serialize(sw, obj);
            return sw.ToString();
        }

        public static Datasets ParseXml2DS(string xml)
        {
            Datasets result = new Datasets();
            if (xml != null && xml != "")
            {
                XmlSerializer serializer = new XmlSerializer(typeof(Datasets));
                using (TextReader reader = new StringReader(xml))
                {
                    result = (Datasets)serializer.Deserialize(reader);
                }
            }
            return result;
        }

        public static string ParseDSToXML(Datasets dataset)
        {
            StringWriter sw = new StringWriter();
            XmlSerializer s = new XmlSerializer(dataset.GetType());
            s.Serialize(sw, dataset);
            return sw.ToString();
        }

        #endregion

        public static string CreateWorkflowOperation(string workflowId, string ConsumerID, string workflowDetail = "", string callerName = "")
        {
            return CreateWorkflowOperation(workflowId, ConsumerID, workflowDetail, callerName, DBReference.ConnStr_SSISDB);
        }

        public static string CreateWorkflowOperation(string workflowId, string ConsumerID, string workflowDetail, string callerName, string connectionString = null)
        {
            string userNotificationId = Convert.ToString(DataReaderUtilities.GetScalaValue(connectionString, string.Format(@"exec dbo.spCreateWorkflowOperation @workflowId ='{0}', @ConsumerID ='{1}', @workflowDetail ='{2}', @callerName ='{3}'   ", workflowId, ConsumerID, workflowDetail, callerName)));
            return userNotificationId;
        }

        public static DataSet GetScheduledWorkflowToRun()
        {
            var ds = DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, string.Format("exec dbo.spGetScheduledWorkflowToRun"));
            return ds;

        }

        public static Workflow GetSystemWorkflowByName(string workflowName)
        {
            var workflowId = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV, string.Format("select PK_WORKFLOW_ID FROM HUB_WORKFLOWS WHERE BK_WORKFLOW_NAME = '{0}'", workflowName));
            if (workflowId != null)
            {
                return GetSystemWorkflow(workflowId.ToString());
            }
            return null;
        }

        public static Workflow GetSystemWorkflow(string workflowId)
        {
            return GetSystemWorkflow(workflowId, DBReference.ConnStr_DV);
        }

        public static Workflow GetSystemWorkflow(string workflowId, string connectionString)
        {
            Workflow wf = new Workflow();
            var sqlquery = @"select distinct 
                                    PK_WORKFLOW_ID,
                                    BK_WORKFLOW_NAME,
                                    [PK_TRANSFORMATION_ID],
                                    [BK_TRANSFORMATION_NAME],
                                    [BK_TRANSFORMATION_ETLPKG_NAME],
                                    [STEP_ORDER]
                                    from [dbo].[WORKFLOW_DETAIL]
                                    where PK_WORKFLOW_ID = '{0}'
                                    order by [STEP_ORDER]";
            var ds = DataReaderUtilities.GetData(connectionString, string.Format(sqlquery, workflowId));
            if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0) return null;

            wf.Id = ds.Tables[0].Rows[0]["PK_WORKFLOW_ID"].ToString(); ;
            wf.Name = ds.Tables[0].Rows[0]["BK_WORKFLOW_NAME"].ToString();
            wf.Transformations = ds.Tables[0].AsEnumerable().Select(dataRow => new Transformation { Id = dataRow.Field<string>("PK_TRANSFORMATION_ID"), Name = dataRow.Field<string>("BK_TRANSFORMATION_NAME"), ETLPkgName = dataRow.Field<string>("BK_TRANSFORMATION_ETLPKG_NAME"), Step = dataRow.Field<int>("STEP_ORDER") }).ToList();

            for (int i = 0; i < wf.Transformations.Count; i++)
            {
                wf.Transformations[i].Input_Datasets = new Datasets();
                wf.Transformations[i].Output_Datasets = new Datasets();
                wf.Transformations[i].Parameters = new List<Parameter>();

                sqlquery = @" select distinct 
                                     [INPUT_NAME], 
                                     [InputConnName]
                                     from [dbo].[WORKFLOW_DETAIL]
                                     where PK_WORKFLOW_ID ='{0}'
                                     and PK_TRANSFORMATION_ID ='{1}' 
                                     and INPUT_NAME is not null";
                ds = DataReaderUtilities.GetData(connectionString, string.Format(sqlquery, workflowId, wf.Transformations[i].Id));

                if (!(ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0))
                {
                    wf.Transformations[i].Input_Datasets.Items = ds.Tables[0].AsEnumerable().Select(dataRow => new Parameter() { Name = dataRow.Field<string>("Input_name"), Value = dataRow.Field<string>("InputConnName") }).ToList();
                }

                sqlquery = @" select distinct 
                                     [OUTPUT_NAME],
                                     [OutputConnName]
                                     from [dbo].[WORKFLOW_DETAIL]
                                     where PK_WORKFLOW_ID ='{0}'
                                     and PK_TRANSFORMATION_ID ='{1}' 
                                     and OUTPUT_NAME is not null";

                ds = DataReaderUtilities.GetData(connectionString, string.Format(sqlquery, workflowId, wf.Transformations[i].Id));

                if (!(ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0))
                {
                    wf.Transformations[i].Output_Datasets.Items = ds.Tables[0].AsEnumerable().Select(dataRow => new Parameter() { Name = dataRow.Field<string>("Output_name"), Value = dataRow.Field<string>("OutputConnName") }).ToList();
                }


                sqlquery = @" select distinct [PARAM_NAME], [PARAM_VALUE]
                                     from [dbo].[WORKFLOW_DETAIL]
                                     where PK_WORKFLOW_ID ='{0}'
                                     and PK_TRANSFORMATION_ID ='{1}' 
                                     and [PARAM_NAME] is not null ";
                ds = DataReaderUtilities.GetData(connectionString, string.Format(sqlquery, workflowId, wf.Transformations[i].Id));

                if (!(ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0))
                {
                    wf.Transformations[i].Parameters = ds.Tables[0].AsEnumerable().Select(dataRow => new Parameter() { Name = dataRow.Field<string>("PARAM_NAME"), Value = dataRow.Field<string>("PARAM_VALUE")}).ToList();
                }


            }

            return wf;
        }
        
        public static void UpdateWorkflowStatus(string workflowId, string status, string WPID, string ConsumerID)
        {
            string sqlquery = string.Format("exec [dbo].[spUpdateWorkflowStatus] @WORKFLOW_ID='{0}', @Status='{1}', @WPID ='{2}', @ConsumerID ='{3}'", workflowId, status, WPID, ConsumerID);
            DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, sqlquery);
        }

        public static void WriteOutputDS(Int64 PID, Datasets ds)
        {
            string sqlquery = string.Format("exec spWriteOutputDS @Output_DS='{0}', @PID= {1}", ParseDSToXML(ds), PID);
            DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, sqlquery);
        }

        public static string GetEventDrivenWorkflowIdByType(string difType)
        {
            string workflowId = string.Empty;
            string sql = string.Format("select WORKFLOW_ID from [dbo].[Event-DrivenWorkflow] where [Type]='{0}'", difType);
            var obj = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, sql);
            workflowId = obj != null ? obj.ToString() : null;
            return workflowId;
        }

        public static string GetWorkflowTypeFromScheduleWorkflow(string WorkflowID)
        {
            string workflowType = string.Empty;
            string sql = string.Format(@"select [Type] from [dbo].[ScheduledWorkflow]
                                        where WORKFLOW_ID = '{0}'", WorkflowID);
            var obj = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, sql);
            workflowType = obj != null ? obj.ToString() : null;
            return workflowType;
        }

        public static string GetWorkflowTypeFromEventDriven(string WorkflowID)
        {
            string workflowType = string.Empty;
            string sql = string.Format(@"select [Type] from [dbo].[Event-DrivenWorkflow]
                                        where WORKFLOW_ID = '{0}'", WorkflowID);
            var obj = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, sql);
            workflowType = obj != null ? obj.ToString() : null;

            return workflowType;
        }

        public static string GetConfigurationValue(string connStr_SSISDB, string ConfigurationName)
        {
            string value = string.Empty;
            string sql = string.Format(@"select top 1 [ConfiguredValue] from [dbo].[SSISConfiguration] where [ConfigurationName] ='{0}'", ConfigurationName);
            var obj = DataReaderUtilities.GetScalaValue(connStr_SSISDB, sql);
            value = obj != null ? obj.ToString() : null;
            return value;
        }

        public static string GetConstantsValue(string connStr_SSISDB, string ConstantsName)
        {
            string value = string.Empty;
            string sql = string.Format(@"select top 1 [Value] from [dbo].[Constants] where [Name] ='{0}'", ConstantsName);
            var obj = DataReaderUtilities.GetScalaValue(connStr_SSISDB, sql);
            value = obj != null ? obj.ToString() : null;
            return value;
        }

        public static List<string> GetEventDriventHelpers()
        {
            List<string> SSISHelperList = new List<string>();
            string sql = string.Format(@"select distinct SSISHelper from [dbo].[Event-DrivenWorkflow]");
            var ds = DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, sql);

            if (!(ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0))
            {
                SSISHelperList = ds.Tables[0].AsEnumerable().Select(dataRow => dataRow.Field<string>("SSISHelper")).ToList();
            }
            return SSISHelperList;
        }

        public static DataSet GetWorkflowOperationsToRun(string consumerId, string WPIDsExclude)
        {
            if (string.IsNullOrEmpty(WPIDsExclude))
            {
                WPIDsExclude = "-1";
            }
            var ds = DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, string.Format("exec dbo.spGetWorkflowOperationsToRun @ConsumerId ='{0}', @WPIDsExclude ='{1}'", consumerId, WPIDsExclude));
            return ds;

        }

        public static string GetWorkflowOperationStatus(string WPID)
        {
            string status = string.Empty;
            string sql = string.Format(@"select [status] from [dbo].[WorkflowOperations]
                                         where WPID = {0}", WPID);
            var obj = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, sql);

            status = obj != null ? obj.ToString() : null;
            return status;
        }

        public static string GetDSNameByDSId(string DS_Id)
        {
            string value = string.Empty;
            string sql = string.Format(@"
                                        select NAME_DATASET from [dbo].[SAT_DATASET_DETAILS]
                                        WHERE PK_DATASET_ID ='{0}'
                                        and MD_LOADEND_TS is null", DS_Id);
            var obj = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV, sql);
            value = obj != null ? obj.ToString() : null;
            return value;
        }

        public static string CreateUserWorkflowOperation(string workflowId, List<Transformation> listTransformation, string callerName)
        {
            return CreateUserWorkflowOperation(workflowId, listTransformation, callerName, DBReference.ConnStr_DV, DBReference.ConnStr_SSISDB);
        }

        public static string CreateUserWorkflowOperation(string workflowId, List<Transformation> listTransformation, string callerName, string clientConnectionString, string ssisConnectionString)
        {
            try
            {
                var workflow = GetSystemWorkflow(workflowId, clientConnectionString);
                foreach (var T in workflow.Transformations)
                {
                    var inputT = listTransformation.FirstOrDefault(f => f.Id == T.Id);
                    if (inputT != null)
                    {
                        T.Parameters = inputT.Parameters;
                        T.Input_Datasets = inputT.Input_Datasets;
                        T.Output_Datasets = inputT.Output_Datasets;
                    }
                }

                var workflowDetail = ParseWorkflow2XML(workflow);

                string WPID = CreateWorkflowOperation(workflowId, "OD", workflowDetail, callerName, ssisConnectionString);
                return WPID;
            }
            catch
            {
                return null;
            }

        }

        public static string CreateUserWorkflowOperation(Workflow workflow, string callerName)
        {
            return CreateUserWorkflowOperation(workflow, callerName, DBReference.ConnStr_SSISDB);
        }

        public static string CreateUserWorkflowOperation(Workflow workflow, string callerName, string connectionString)
        {
            try
            {
                var workflowDetail = ParseWorkflow2XML(workflow);
                string WPID = CreateWorkflowOperation(workflow.Id, "OD", workflowDetail, callerName, connectionString);
                return WPID;
            }
            catch
            {
                return null;
            }

        }

        public static bool TerminateUserWorkflowOperation(string WPID, string stop_by_name)
        {
            try
            {
                int result = 0;
                result = Convert.ToInt16(DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, string.Format(@"exec dbo.spTerminateWorkflowOperation @WPID ={0},
                                                                                          @STOP_BY_NAME = '{1}'", WPID, stop_by_name)));
                return result == 0 ? false : true;
            }
            catch
            {
                return false;
            }

        }

        public static bool DeleteUserNotificationById(long id)
        {
            try
            {
                DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, string.Format(@"delete from [dbo].[UserNotifications] where id = {0}", id));
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool DeleteUserNotificationByWPID(long WPID)
        {
            try
            {
                DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, string.Format(@"delete from [dbo].[UserNotifications] where WPID = {0}", WPID));
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool DeleteUserNotificationByPID(long PID)
        {
            try
            {
                DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, string.Format(@"delete from [dbo].[UserNotifications] where PID = {0}", PID));

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool ArchiveUserNotificationByWPID(List<string> WPIDList)
        {
            try
            {
                string WPIDs = string.Join(",", WPIDList.Select(x => x.ToString()).ToArray());
                DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, string.Format(@"update [dbo].[UserNotifications] set [ARCHIVED] =1 where [WPID] in({0})", WPIDs));

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool ArchiveUserNotificationByID(List<string> IdList)
        {
            try
            {
                string Ids = string.Join(",", IdList.Select(x => x.ToString()).ToArray());
                DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, string.Format(@"update [dbo].[UserNotifications] set [ARCHIVED] =1 where [ID] in({0})", Ids));

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool UnArchiveUserNotificationByWPID(List<string> WPIDList)
        {
            try
            {
                string WPIDs = string.Join(",", WPIDList.Select(x => x.ToString()).ToArray());
                DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, string.Format(@"update [dbo].[UserNotifications] set [ARCHIVED] =0 where [WPID] in({0})", WPIDs));

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool UnArchiveUserNotificationByID(List<string> IdList)
        {
            try
            {
                string Ids = string.Join(",", IdList.Select(x => x.ToString()).ToArray());
                DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, string.Format(@"update [dbo].[UserNotifications] set [ARCHIVED] =0 where [ID] in({0})", Ids));

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool MarkAsReadUserNotificationByWPID(List<string> WPIDList)
        {
            try
            {
                string WPIDs = string.Join(",", WPIDList.Select(x => x.ToString()).ToArray());
                DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, string.Format(@"update [dbo].[UserNotifications] set [MARK_AS_READ] =1 where [WPID] in({0})", WPIDs));

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool MarkAsReadUserNotificationByID(List<string> IdList)
        {
            try
            {
                string Ids = string.Join(",", IdList.Select(x => x.ToString()).ToArray());
                DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, string.Format(@"update [dbo].[UserNotifications] set [MARK_AS_READ] =1 where [Id] in({0})", Ids));

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static void MarkSkipRemainTransformations(string currentPID)
        {
            string sqlCommand = string.Format(@"exec [dbo].[spLogMessageForTransformationOperations]
                                                @PID ={0},
                                                @MessageSource = '{1}',
                                                @Message = '{2}'", currentPID, "STOP_WITH_SUCCESS", "Skip remain transformations of workflow!");

            DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, sqlCommand);
        }
        
        public static long ExecutePackageFromSSISDBbySP(string ETLPkgName, List<Parameter> Parameters)
        {
            var packageInfo = ETLPkgName.Split('\\');
            var sqlConnection = new SqlConnection(DBReference.ConnStr_SSISDB);
            
            Parameters = Parameters ?? new List<Parameter>();
            var paraXml = new XElement("Parameters", Parameters.Select(x => new XElement("Parameter",
                                           new XAttribute("Name", x.Name),
                                           new XAttribute("Value", x.Value))));


            long executionOperationId = Convert.ToInt64(DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB,
                                                                                        string.Format(@"exec dbo.spInitSSISPackage @FOLDER_NAME ='{0}', @PROJECT_NAME ='{1}', @PACKAGE_NAME ='{2}'",
                                                                                                        packageInfo[0], packageInfo[1], packageInfo[2])));

            DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, string.Format(@"exec dbo.spRunSSISPackage @EXECUTION_ID = {0}, @PARAMETERS = '{1}'", executionOperationId, paraXml));

            return executionOperationId;

        }

        public static void WaitAllExecutionComplete(List<long> ExecutionList)
        {
            var sqlConnection = new SqlConnection(DBReference.ConnStr_SSISDB);

            Management.IntegrationServices integrationServices = new Management.IntegrationServices(sqlConnection);
            var catalogSSISDB = integrationServices.Catalogs["SSISDB"];

            foreach(var executionId in ExecutionList)
            {
                Management.ExecutionOperation executionOperation = catalogSSISDB.Executions[executionId];

                executionOperation.Refresh();
                while (!executionOperation.Completed)
                {
                    //Check every 3 secs to see if the packages have completed.
                    Thread.Sleep(3000);
                    executionOperation.Refresh();
                }
            }

            integrationServices.Connection.Disconnect();
        }

        public static bool ExecuteListChildThread(List<SSISChildThread> listChildThread, int MaxThread)
        {
            int numberThreadNotCompleted = listChildThread.Count;
            Object syncRunPackageObject = new object();
            Boolean isForcedStop = false;
            Boolean isSuccess = true;
            Semaphore semaphoreQueue = new Semaphore(MaxThread, MaxThread);

            foreach (SSISChildThread childThread in listChildThread)
            {
                new Thread(() =>   //create thread to excute SSIS package
                {
                    //waiting until received signal to do work
                    semaphoreQueue.WaitOne();  

                    //check current child thread can be execute?
                    if (isForcedStop)
                    {
                        lock (syncRunPackageObject)
                        {
                            numberThreadNotCompleted--;
                        }

                        semaphoreQueue.Release();
                        return;
                    }

                    childThread.Execute();

                    if (!childThread.IsSuccess)
                    {
                        //force all waiting child threads not executing
                        isForcedStop = true;
                        isSuccess = false;
                    }

                    lock (syncRunPackageObject)
                    {
                        numberThreadNotCompleted--;
                    }
                    semaphoreQueue.Release();
                }).Start();
            }

            //wait until all child threads are complete
            while (numberThreadNotCompleted > 0)  
            {
                Thread.Sleep(3000);
            }

            return isSuccess;
        }
        
        public static Management.Operation.ServerOperationStatus GetSSISExecutionStatus(long executionId)
        {
            var result = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, string.Format("SELECT status FROM catalog.executions (NOLOCK) WHERE execution_id = {0}", executionId));
            Management.Operation.ServerOperationStatus status = (Management.Operation.ServerOperationStatus)result;
            return status;
        }

        public static bool IsSSISExecutionCompleted(long executionId)
        {
            Management.Operation.ServerOperationStatus status = GetSSISExecutionStatus(executionId);
            bool isCompleted = false;
            if (status == Management.Operation.ServerOperationStatus.Canceled ||
                status == Management.Operation.ServerOperationStatus.Failed ||
                status == Management.Operation.ServerOperationStatus.UnexpectTerminated ||
                status == Management.Operation.ServerOperationStatus.Success ||
                status == Management.Operation.ServerOperationStatus.Completion)
                isCompleted = true;
            return isCompleted;
        }

        public static bool IsSkipRemainTransformation(string WPID)
        {
            string sqlCommand = string.Format(@"SELECT IIF(COUNT(1) > 0, 1, 0) AS IS_SKIP_TRANSFROMATION
                                                FROM dbo.vOperations
                                                WHERE WPID = {0} AND Transformation_Message_Source = 'STOP_WITH_SUCCESS' + CHAR(10)", WPID);

            return DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, sqlCommand).ToString().Equals("1") ? true : false;
        }
    }
    
    public class WorkflowThread
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string WPID { get; set; }
        public string ConsumerID { get; set; }
        public List<Transformation> Transformations { get; set; }
        public ManualResetEvent DoneEvent { get; set; }
        public string Status { get; set; }

        public WorkflowThread()
        { }

        public WorkflowThread(string Id, string Name)
        {
            this.Id = Id;
            this.Name = Name;
        }

        public void Start(Object threadContext)
        {
            try
            {
                WorkflowOperation.UpdateWorkflowStatus(this.Id, WorkflowOperationStatus.RUNNING, WPID, ConsumerID);

                for (var i = 0; i < Transformations.Count; i++)
                {
                    if (WorkflowOperation.IsSkipRemainTransformation(WPID))
                        break;

                    Status = WorkflowOperation.GetWorkflowOperationStatus(WPID);
                    if (Status == WorkflowOperationStatus.CANCELLED)
                    {
                        break;
                    }

                    Transformation Ti = Transformations[i];
                    if (i > 0)
                    {
                        for (var j = 0; j < Ti.Input_Datasets.Items.Count; j++)
                        {
                            var previousTransformationOuput = Transformations[i - 1].Output_Datasets.Items.FirstOrDefault(x => x.Name == Ti.Input_Datasets.Items[j].Name);
                            if (previousTransformationOuput != null)
                            {
                                Ti.Input_Datasets.Items[j].Value = previousTransformationOuput.Value;
                            }
                        }
                    }

                    Ti.Execute(WPID);
                    Transformations[i] = Ti;
                    if (!(Ti.Status == TransformationOperationStatus.SUCCESS || Ti.Status == TransformationOperationStatus.CANCELED))
                    {
                        Status = WorkflowOperationStatus.FAILED;
                        string tran_msg = string.Empty;
                        if (!string.IsNullOrEmpty(Ti.PID))
                            tran_msg = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, string.Format("SELECT MESSAGE FROM dbo.TransformationOperations WHERE PID = '{0}'", Ti.PID)).ToString();
                        DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, string.Format("exec spLogMessageForWorkflowOperations @WPID={0}, @Message='Workflow has been failed at step: {1}, {2}'", WPID, Ti.Step.ToString(), tran_msg.Replace("'", "''")));
                        break;
                    }
                }

                if (!(Status == WorkflowOperationStatus.FAILED || Status == WorkflowOperationStatus.CANCELLED))
                {
                    Status = WorkflowOperationStatus.SUCCESS;
                }

                WorkflowOperation.UpdateWorkflowStatus(this.Id, Status, WPID, ConsumerID);
            }

            catch (Exception ex)
            {
                WorkflowOperation.UpdateWorkflowStatus(this.Id, WorkflowOperationStatus.FAILED, WPID, ConsumerID);
                DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, string.Format("exec spLogMessageForWorkflowOperations @WPID={0}, @Message='{1}'", WPID, "Exception thrown: " + ex.Message.Replace("'", "''")));
            }

            finally
            {
                this.DoneEvent.Set();
            }
        }        
    }

    public class Transformation
    {
        [XmlAttribute("Id")]
        public string Id { get; set; }
        [XmlAttribute("Name")]
        public string Name { get; set; }
        [XmlElement("ETLPkgName")]
        public string ETLPkgName { get; set; }
        [XmlElement("Input_Dataset")]
        public Datasets Input_Datasets { get; set; }
        [XmlElement("Output_Dataset")]
        public Datasets Output_Datasets { get; set; }
        [XmlElement("Step")]
        public int Step { get; set; }
        [XmlElement("Parameter")]
        public List<Parameter> Parameters { get; set; }
        public string Status { get; set; }
        public string PID { get; set; }

        public Transformation()
        { }

        public Transformation(string Id, string Name, int Step, string ETLPkgName, List<Parameter> Parameters, Datasets Input_Datasets, Datasets Output_Datasets)
        {
            this.Id = Id;
            this.Name = Name;
            this.ETLPkgName = ETLPkgName;
            this.Step = Step;
            this.Parameters = Parameters;
            this.Input_Datasets = Input_Datasets;
            this.Output_Datasets = Output_Datasets;
        }

        public void Execute(string WPID)
        {

            //ExecutePackageFromSSISDB(WPID);

            ExecutePackageFromSSISDBbySP(WPID);

        }

        public Datasets ExecutePackageFromSSISDB(string WPID)
        {
            try
            {
                var packageInfo = ETLPkgName.Split('\\');
                var sqlConnection = new SqlConnection(DBReference.ConnStr_SSISDB);
                Management.IntegrationServices integrationServices = new Management.IntegrationServices(sqlConnection);
                System.Collections.ObjectModel.Collection<Management.PackageInfo.ExecutionValueParameterSet> executionValueParameterSet = new System.Collections.ObjectModel.Collection<Management.PackageInfo.ExecutionValueParameterSet>();

                //Add Parameter
                if (Parameters != null && Parameters.Count > 0)
                {
                    foreach (var p in Parameters)
                    {
                        executionValueParameterSet.Add(new Management.PackageInfo.ExecutionValueParameterSet
                        { ParameterName = p.Name, ParameterValue = p.Value, ObjectType = 30 });
                    }
                }

                //Add Input
                if (Input_Datasets != null && Input_Datasets.Items.Count > 0)
                {
                    foreach (var p in Input_Datasets.Items)
                    {
                        executionValueParameterSet.Add(new Management.PackageInfo.ExecutionValueParameterSet
                        { ParameterName = p.Name, ParameterValue = p.Value, ObjectType = 30 });
                    }
                }

                //Add Output
                if (Output_Datasets != null && Output_Datasets.Items != null)
                {
                    if (Output_Datasets.Items.Count > 0)
                    {
                        foreach (var p in Output_Datasets.Items)
                        {
                            executionValueParameterSet.Add(new Management.PackageInfo.ExecutionValueParameterSet
                            { ParameterName = p.Name, ParameterValue = p.Value, ObjectType = 30 });
                        }
                    }
                }

                var catalogSSISDB = integrationServices.Catalogs["SSISDB"];
                Management.PackageInfo myPackage = catalogSSISDB.Folders[packageInfo[0]].Projects[packageInfo[1]].Packages[packageInfo[2]];
                //myPackage.
                long executionIdentifier = myPackage.Execute(false, null, executionValueParameterSet);
                DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, string.Format(@"exec dbo.spCreateTransformationOperations  @PID={0}, @WPID={1}, @TRANSFORM_ID='{2}', @TRANSFORM_NAME='{3}',@INPUT_DATASET='{4}'", executionIdentifier, WPID, Id, Name, WorkflowOperation.ParseDSToXML(Input_Datasets)));
                
                while (!WorkflowOperation.IsSSISExecutionCompleted(executionIdentifier))
                {
                    //Check every 3 secs to see if the packages have completed.
                    Thread.Sleep(3000);
                }

                this.Status = WorkflowOperation.GetSSISExecutionStatus(executionIdentifier).ToString().ToUpper();

                Datasets Output_Dataset = new Datasets();
                var ds = DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, string.Format(@"select OUTPUT_DATASET from [SSISDB].[dbo].[TransformationOperations] where PID ='{0}'", executionIdentifier));
                if (ds != null && ds.Tables.Count > 0)
                {
                    Output_Dataset = WorkflowOperation.ParseXml2DS(ds.Tables[0].Rows[0]["OUTPUT_DATASET"].ToString());
                }

                integrationServices.Connection.Disconnect();
                return Output_Dataset;
            }
            catch (Exception ex)
            {
                throw new Exception("Error occur at ExecutePackageFromSSISDB, message: " + ex.Message);
            }
        }
        
        public void ExecutePackageFromSSISDBbySP(string WPID)
        {
            try
            {
                var packageInfo = ETLPkgName.Split('\\');
                var sqlConnection = new SqlConnection(DBReference.ConnStr_SSISDB);
                
                Parameters = Parameters ?? new List<Parameter>();
                Input_Datasets.Items = Input_Datasets.Items ?? new List<Parameter>();
                Output_Datasets.Items = Output_Datasets.Items ?? new List<Parameter>();

                List<Parameter> allParameters = new List<Parameter>();
                allParameters.AddRange(Parameters);
                allParameters.AddRange(Input_Datasets.Items);
                allParameters.AddRange(Output_Datasets.Items);

                var paraXml = new XElement("Parameters", allParameters.Select(x => new XElement("Parameter",
                                               new XAttribute("Name", x.Name),
                                               new XAttribute("Value", x.Value))));


                long executionOperationId = Convert.ToInt64(DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB,
                                                                                            string.Format(@"exec dbo.spInitSSISPackage @FOLDER_NAME ='{0}', @PROJECT_NAME ='{1}', @PACKAGE_NAME ='{2}'",
                                                                                                            packageInfo[0], packageInfo[1], packageInfo[2])));
                this.PID = executionOperationId.ToString();
                DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, 
                                            string.Format(@"exec dbo.spCreateTransformationOperations @PID={0}, @WPID={1}, @TRANSFORM_ID='{2}', @TRANSFORM_NAME='{3}',@INPUT_DATASET='{4}'", 
                                                            executionOperationId, WPID, Id, Name, WorkflowOperation.ParseDSToXML(Input_Datasets)));

                DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, string.Format(@"exec dbo.spRunSSISPackage @EXECUTION_ID = {0}, @PARAMETERS = '{1}'", executionOperationId, paraXml));

                while (!WorkflowOperation.IsSSISExecutionCompleted(executionOperationId))
                {
                    //Check every 3 secs to see if the packages have completed.
                    Thread.Sleep(3000);
                }

                this.Status = WorkflowOperation.GetSSISExecutionStatus(executionOperationId).ToString().ToUpper();

                var ds = DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, string.Format(@"select OUTPUT_DATASET from [SSISDB].[dbo].[TransformationOperations] where PID ='{0}' and  coalesce(OUTPUT_DATASET,'')<>''", executionOperationId));

                if (!(ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0))
                {
                    Output_Datasets = WorkflowOperation.ParseXml2DS(ds.Tables[0].Rows[0]["OUTPUT_DATASET"].ToString());
                }

                //return Output_Datasets;
            }
            catch (Exception ex)
            {
                throw new Exception("Error occur at ExecutePackageFromSSISDB, message: " + ex.Message);
            }
        }

    }

    public class Parameter
    {
        [XmlAttribute("Name")]
        public string Name { get; set; }
        [XmlAttribute("Value")]
        public string Value { get; set; }

        public Parameter()
        {
        }

        public Parameter(string Name, string Value)
        {
            this.Name = Name;
            this.Value = Value;
        }
    }

    public class Datasets
    {
        [XmlElement("Item")]
        public List<Parameter> Items { get; set; }

        public Datasets() { }
    }

    public class SSISHelperPackage
    {
        public string ETLPkgName { get; set; }
        public List<Parameter> Parameters { get; set; }

        public SSISHelperPackage()
        { }

        public void Start()
        {
            // ExecutePackageFromSSISDB(ETLPkgName, Parameters);
            ExecutePackageFromSSISDBbySP(ETLPkgName, Parameters);
        }

        public static void ExecutePackageFromSSISDB(string ETLPkgName, List<Parameter> Parameters)
        {
            var packageInfo = ETLPkgName.Split('\\');
            var sqlConnection = new SqlConnection(DBReference.ConnStr_SSISDB);

            System.Collections.ObjectModel.Collection<Management.PackageInfo.ExecutionValueParameterSet> executionValueParameterSet = new System.Collections.ObjectModel.Collection<Microsoft.SqlServer.Management.IntegrationServices.PackageInfo.ExecutionValueParameterSet>();
            //Add Parameter
            if (Parameters != null && Parameters.Count > 0)
            {
                foreach (var p in Parameters)
                {
                    executionValueParameterSet.Add(new Management.PackageInfo.ExecutionValueParameterSet
                    { ParameterName = p.Name, ParameterValue = p.Value, ObjectType = 30 });
                }
            }

            Management.IntegrationServices integrationServices = new Management.IntegrationServices(sqlConnection);

            var catalogSSISDB = integrationServices.Catalogs["SSISDB"];
            Management.PackageInfo myPackage = catalogSSISDB.Folders[packageInfo[0]].Projects[packageInfo[1]].Packages[packageInfo[2]];

            long executionIdentifier = myPackage.Execute(false, null, executionValueParameterSet);

            //DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, string.Format(@"exec dbo.spCreateTransformationOperations  @PID={0}, @WPID={1}, @TRANSFORM_ID='{2}', @TRANSFORM_NAME='{3}',@INPUT_DATASET='{4}'", executionOperation.Id, WPID, Id, Name, WorkflowOperation.ParseDSToXML(Input_Datasets)));
            
            while (!WorkflowOperation.IsSSISExecutionCompleted(executionIdentifier))
            {
                //Check every 3 secs to see if the packages have completed.
                Thread.Sleep(3000);
            }

            integrationServices.Connection.Disconnect();
            // return executionOperation;
        }

        public static void ExecutePackageFromSSISDBbySP(string ETLPkgName, List<Parameter> Parameters)
        {
            var packageInfo = ETLPkgName.Split('\\');
            var sqlConnection = new SqlConnection(DBReference.ConnStr_SSISDB);
            
            Parameters = Parameters ?? new List<Parameter>();
            var paraXml = new XElement("Parameters", Parameters.Select(x => new XElement("Parameter",
                                           new XAttribute("Name", x.Name),
                                           new XAttribute("Value", x.Value))));

            long executionOperationId = Convert.ToInt64(DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, 
                                                                                        string.Format(@"exec dbo.spInitSSISPackage @FOLDER_NAME ='{0}', @PROJECT_NAME ='{1}', @PACKAGE_NAME ='{2}'", 
                                                                                                        packageInfo[0], packageInfo[1], packageInfo[2])));

            DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, string.Format(@"exec dbo.spRunSSISPackage @EXECUTION_ID = {0}, @PARAMETERS = '{1}'", executionOperationId, paraXml));
            
            while (!WorkflowOperation.IsSSISExecutionCompleted(executionOperationId))
            {
                //Check every 3 secs to see if the packages have completed.
                Thread.Sleep(3000);
            }

        }
    }

    [XmlRoot("Workflow")]
    public class Workflow
    {
        [XmlAttribute("Id")]
        public string Id { get; set; }
        [XmlAttribute("Name")]
        public string Name { get; set; }
        [XmlAttribute("WPID")]
        public string WPID { get; set; }
        [XmlAttribute("ConsumerID")]
        public string ConsumerID { get; set; }
        [XmlElement("Transformation")]
        public List<Transformation> Transformations { get; set; }

        public string Status { get; set; }

        public Workflow()
        { }

    }

    public class SSISChildThread
    {
        #region Variable

        public string ETLPkgName { get; set; }
        public List<Parameter> Parameters { get; set; }
        public Boolean IsSuccess { get; set; }

        #endregion

        #region Initial Constructors

        public SSISChildThread() { }

        public SSISChildThread(String ETLPkgName, List<Parameter> Parameters)
        {
            this.ETLPkgName = ETLPkgName;
            this.Parameters = Parameters;
        }

        #endregion

        /// <summary>
        /// Run thread package
        /// </summary>
        public void Execute()
        {
            var packageInfo = ETLPkgName.Split('\\');
            var sqlConnection = new SqlConnection(DBReference.ConnStr_SSISDB);

            Parameters = Parameters ?? new List<Parameter>();
            var paraXml = new XElement("Parameters", Parameters.Select(x => new XElement("Parameter",
                                           new XAttribute("Name", x.Name),
                                           new XAttribute("Value", x.Value))));
                                           
            long executionOperationId = Convert.ToInt64(DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, 
                                                                                        string.Format(@"exec dbo.spInitSSISPackage @FOLDER_NAME ='{0}', @PROJECT_NAME ='{1}', @PACKAGE_NAME ='{2}'", 
                                                                                                        packageInfo[0], packageInfo[1], packageInfo[2])));

            DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, string.Format(@"exec dbo.spRunSSISPackage @EXECUTION_ID = {0}, @PARAMETERS = '{1}'", executionOperationId, paraXml));
            
            while (!WorkflowOperation.IsSSISExecutionCompleted(executionOperationId))
            {
                //Check every 3 secs to see if the packages have completed.
                Thread.Sleep(3000);
            }

            //get result execute this package
            var status = WorkflowOperation.GetSSISExecutionStatus(executionOperationId);
            if (status == Management.Operation.ServerOperationStatus.Failed
                || status == Management.Operation.ServerOperationStatus.Canceled)
                IsSuccess = false;
            else
                IsSuccess = true;
        }
    }
}
