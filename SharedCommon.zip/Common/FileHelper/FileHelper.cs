﻿using System;
using System.IO;
using System.Text;
using System.Threading;

namespace FileHelper
{
    public class FileUtilities
    {
        private static object lockObj = new object();
        private static object SyncLogFile = new object();

        public static void WriteFile(string filePath, byte[] data, bool isAppend = true, int offset = 0)
        {
            bool isError = true;
            int errCount = 0;
            while (isError == true && errCount < 10)
            {
                try
                {
                    lock (lockObj)
                    {
                        using (FileStream fs = new FileStream(filePath, isAppend ? FileMode.Append : FileMode.Create))
                        {
                            fs.Write(data, offset, data.Length);
                        }
                    }
                    isError = false;
                }
                catch (Exception ex)
                {
                    errCount++;
                    string logFile = @"R:\UAT_Log\" + string.Format(@"error.log");

                    lock (SyncLogFile)
                    {
                        if (!Directory.Exists(Path.GetDirectoryName(logFile)))
                        {
                            Directory.CreateDirectory(Path.GetDirectoryName(logFile));
                        }

                        using (StreamWriter sw = new StreamWriter(logFile, true))
                        {
                            sw.WriteLine(DateTime.Now.ToString() + ": Error: " + ex.Message + "filePath: " + filePath);
                        }
                    }

                    if (errCount >= 10)
                        throw new Exception(@"Error writing file. Please check error message logged at R:\UAT_Log\error.log");
                }
                // Sleep for 5s
                Thread.Sleep(5000);
            }

            
        }

        public static void WriteTextFile(string filePath, string content, bool isAppend = true)
        {
            byte[] data = Encoding.ASCII.GetBytes(content);
            WriteFile(filePath, data, isAppend);
        }

        public static void CreateDirectoryAndDeleteFileIfExist(string filePath, bool isAppend = false)
        {
            lock (lockObj)
            {
                // Check exist Directory
                if (!Directory.Exists(Path.GetDirectoryName(filePath)))
                    Directory.CreateDirectory(Path.GetDirectoryName(filePath));

                // Delete file if exists
                if (!isAppend && File.Exists(filePath))
                    File.Delete(filePath);
            }
        }

        public static void CreateDirectory(string dirPath)
        {
            lock (lockObj)
            {
                // Check exist Directory
                if (!Directory.Exists(Path.GetDirectoryName(dirPath)))
                    Directory.CreateDirectory(Path.GetDirectoryName(dirPath));
            }
        }
    }
}
