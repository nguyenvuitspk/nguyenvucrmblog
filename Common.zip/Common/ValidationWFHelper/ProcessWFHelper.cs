using ActivityHelper;
using ActivityHelper.Common;
using DataReaderUtilsLib;
using OfficeOpenXml;
using SQLUtilsLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Serialization;
using ValidationWFHelper.Common;
using ValidationWFHelper.DIFItem;
using WorkflowOperation;

namespace ValidationWFHelper
{
    public class ProcessWFHelper
    {
        #region Constants
        private const int ACTIVITY_LOG_MESSAGE_MAX_LENGTH = 8000;
        #endregion

        #region Connection String for logging
        public static string ConnStr_DV
        {
            get
            {
                return DBReference.ConnStr_DV;
            }
        }

        public static string ConnStr_EXP
        {
            get
            {
                return DBReference.ConnStr_EXP;
            }
        }

        public static string ConnStr_GES_DV
        {
            get
            {
                return DBReference.ConnStr_GES_DV;
            }
        }

        public static string ConnStr_GES_LND
        {
            get
            {
                return DBReference.ConnStr_GES_LND;
            }
        }

        public static string ConnStr_GES_STG
        {
            get
            {
                return DBReference.ConnStr_GES_STG;
            }
        }

        public static string ConnStr_LND
        {
            get
            {
                return DBReference.ConnStr_LND;
            }
        }

        public static string ConnStr_SSISDB
        {
            get
            {
                return DBReference.ConnStr_SSISDB;
            }
        }

        public static string ConnStr_STG
        {
            get
            {
                return DBReference.ConnStr_STG;
            }
        }
        #endregion

        #region Properties
        private static ProcessWFHelper _instance;

        public static string EtlSourceDirectoryServer;
        public static string EtlSourceDirectoryFolder;
        public static string EtlSourceDirectoryDomain;
        public static string EtlSourceDirectoryCredential;
        public static string EtlSourceDirectorySecret;
        public static string MissingDataSupplierMessage = "Data Supplier is empty. Failed to create animal";
        public static string InvalidDataSupplierMessage = "Data Supplier {0} cannot be found in database. Failed to create animal";
        #endregion

        #region Constructor
        public ProcessWFHelper(string ConnStr_SSISDB, string locationAuthName = "ETL_WEB_DIRECTORY_BIN")
        {
            var ConnStr_LND = WorkflowOperation.WorkflowOperation.GetConfigurationValue(ConnStr_SSISDB, "ConnStr_LND");
            var ConnStr_DV = WorkflowOperation.WorkflowOperation.GetConfigurationValue(ConnStr_SSISDB, "ConnStr_DV");
            DBReference.InitiateDBReference(ConnStr_LND, ConnStr_SSISDB, ConnStr_DV);

            var authEtlSource = GetLocationAuthByName(locationAuthName);
            if((authEtlSource != null) && (authEtlSource.Length == 3))
            {
                var authLocations = authEtlSource[0].Split(@"\".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                if((authLocations != null) && (authLocations.Length > 1))
                {
                    EtlSourceDirectoryServer = string.Format(@"\\{0}", authLocations[0]);
                    EtlSourceDirectoryFolder = authLocations[1];
                }

                var authCredentials = authEtlSource[1].Split(@"\".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                if ((authCredentials != null) && (authCredentials.Length > 1))
                {
                    EtlSourceDirectoryDomain = authCredentials[0];
                    EtlSourceDirectoryCredential = authCredentials[1];
                }

                EtlSourceDirectorySecret = authEtlSource[2];
            }
        }
        #endregion

        #region Instance
        public static ProcessWFHelper Instance(string ConnStr_SSISDB)
        {
            // Just refresh singleton
            _instance = new ProcessWFHelper(ConnStr_SSISDB);

            return _instance;
        }
        #endregion

        #region Common methods
        public static string[] GetLocationAuthByName(string locAuthName)
        {
            string[] locAuth = null;
            if(string.IsNullOrWhiteSpace(locAuthName))
            {
                locAuth = new string[] { @"\\localhost\shared", @"NPBASE\np", @"np123" };
            }
            else
            {
                try
                {
                    var ds = DataReaderUtilities.GetData(DBReference.ConnStr_DV,
                        string.Format(@"SELECT [CONN_VALUE], [USER_NAME], [USER_SECRET] FROM [CDR].[dbo].[SAT_LOCATION_AUTHS] WHERE CONN_NAME = '{0}'", locAuthName));
                    if ((ds != null) && (ds.Tables.Count > 0) 
                        && (ds.Tables[0].Rows.Count > 0) && (ds.Tables[0].Rows[0] != null))
                    {
                        var dr = ds.Tables[0].Rows[0];
                        var location = dr["CONN_VALUE"]?.ToString();
                        var credential = dr["USER_NAME"]?.ToString();
                        var secret = dr["USER_SECRET"]?.ToString();

                        locAuth = new string[] { location, credential, secret };
                    }
                    else
                    {
                        locAuth = new string[] { string.Empty, string.Empty, string.Empty };
                    }
                }
                catch (Exception ex)
                {
                    var location = string.Format("\\\\{0}\\{1}", "localhost", locAuthName);
                    locAuth = new string[] { location, @"NPBASE\np", @"np123" };
                }
            }

            return locAuth;
        }

        public static bool CheckExistsPartyCode(string partyCode)
        {
            if (!string.IsNullOrWhiteSpace(partyCode))
            {
                var ds = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                        string.Format(@"SELECT TOP 1 1 FROM [CDR].[dbo].[HUB_PARTIES] WHERE [BK_PARTY_CODE] = '{0}'", 
                            partyCode.Replace("'", "''")));

                if(ds != null)
                {
                    return true;
                }
            }

            return false;
        }

        public static string GetPartyIDByDataSupplierName(string dataSupplierName)
        {
            string partyCode = string.Empty;
            if (!string.IsNullOrWhiteSpace(dataSupplierName))
            {
                var ds = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                        string.Format(@"SELECT TOP 1 Parties.PARTY_CODE
                                        FROM CDRSTG.dbo.PARTIES Parties
                                        WHERE Parties.NAME = '{0}'",
                            dataSupplierName.Replace("'", "''")));

                if (ds != null)
                {
                    partyCode = ds.ToString();
                }
            }

            return partyCode;
        }

        public static string GetDIFLocationFolder(string dataSupplierName, string type)
        {
            var dataSupplierPartyCode = GetPartyCode(dataSupplierName);
            
            string folderByDay = String.Format("{0:yyyyMMdd}", DateTime.Now);
            string file_folder = EtlSourceDirectoryServer + @"\" + EtlSourceDirectoryFolder + @"\" + folderByDay + string.Format(@"\{0}\{1}\", dataSupplierPartyCode, type);

            return file_folder;
        }

        public static string GetPartyNameBySessionId(int sessionId)
        {
            string partyName = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                        string.Format(@"SELECT TOP 1 IIF(hParties.BK_PARTY_CODE <> 'datagene', COALESCE(sParties.NAME, ''), 'adhis')
                                        FROM report.SESSION_LOGS sLogs
                                        JOIN dbo.HUB_PARTIES (NOLOCK) hParties ON hParties.BK_PARTY_CODE = sLogs.PARTY_CODE
								                                        AND sLogs.SESSION_ID = {0}
                                        JOIN dbo.SAT_PARTIES (NOLOCK) sParties ON sParties.PK_PARTY_ID = hParties.PK_PARTY_ID
                                                                        AND sParties.MD_LOADEND_TS IS NULL",
                            sessionId)).ToString();
            return partyName;
        }

        private static string GetPartyCode(string dataSupplierName)
        {
            var dataSupplierPartyCode = "";

            if (!string.IsNullOrWhiteSpace(dataSupplierName))
                dataSupplierPartyCode = GetPartyIDByDataSupplierName(dataSupplierName);

            return dataSupplierPartyCode;
        }

        public static string GetWorkflowStatus(string WPID)
        {
            string status = WorkflowOperation.WorkflowOperation.GetWorkflowOperationStatus(WPID);

            return status;
        }

        public static void UpdateRelatedWPIDToActivityLog(int activityLogId, string WPID)
        {
            // Update related WPID to activity log
            DataReaderUtilities.GetData(DBReference.ConnStr_DV,
                string.Format(@"EXEC [dbo].[usp_common_update_related_WPID_activity_log] @PID ={0}, @RELATED_WPID ={1}", activityLogId, WPID));
        }

        public static string GetUsernameByActivityLog(int activityLogId)
        {
            // Update related WPID to activity log
            return DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV, string.Format(@" SELECT sLog.USER_NAME
                                                                                              FROM report.ACTIVITY_LOGS aLog
                                                                                              INNER JOIN report.SESSION_LOGS sLog ON sLog.SESSION_ID = aLog.SESSION_ID
                                                                                              WHERE aLog.PID = '{0}'", activityLogId)).ToString();
        }

        public static string ExecuteCreateWorkflow(Workflow workflow, int activityLogID)
        {            
            var WPID = CreateWorkflowAsync(workflow, GetUsernameByActivityLog(activityLogID));
            UpdateRelatedWPIDToActivityLog(activityLogID, WPID);

            return WPID;
        }

        public static string CreateWorkflowAsync(Workflow workflow, string userName = "")
        {
            string workflow_XML = WorkflowOperation.WorkflowOperation.ParseWorkflow2XML(workflow);
            workflow_XML = workflow_XML.Replace("\"'\"", "\"\"");
            string WPID = WorkflowOperation.WorkflowOperation.CreateWorkflowOperation(workflowId: workflow.Id, ConsumerID: workflow.ConsumerID, workflowDetail: workflow_XML, callerName: userName);

            return WPID;
        }


        public static Workflow GetWorkflow(string workflowName, string fullPathFile)
        {
            var folderByDay = string.Empty;
            var folderDPC = string.Empty;
            var folderByType = string.Empty;
            var fileName = string.Empty;

            var pathLevels = fullPathFile.Split(@"\".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            if (pathLevels.Length >= 6)
            {
                folderByDay = pathLevels[2];
                folderDPC = pathLevels[3];
                folderByType = pathLevels[4];
                fileName = pathLevels[5];
            }            

            var workflow = WorkflowOperation.WorkflowOperation.GetSystemWorkflowByName(workflowName);
            workflow.Transformations[0].Input_Datasets.Items.FirstOrDefault(c => c.Name == "SourceDirectory").Value
                = string.Format(@"{0}\{1}", EtlSourceDirectoryServer, EtlSourceDirectoryFolder);
            workflow.Transformations[0].Parameters.FirstOrDefault(c => c.Name == "ListOfFiles").Value =
                string.Format(@"{0}\{1}\{2}\{3}", folderByDay, folderDPC, folderByType, fileName);
            workflow.Transformations[0].Parameters.FirstOrDefault(c => c.Name == "CompleteDirectory").Value =
                string.Format(@"{0}\{1}\COMPLETE", EtlSourceDirectoryServer, EtlSourceDirectoryFolder);
            workflow.Transformations[0].Parameters.FirstOrDefault(c => c.Name == "FailedDirectory").Value =
                string.Format(@"{0}\{1}\FAILED", EtlSourceDirectoryServer, EtlSourceDirectoryFolder);
            workflow.Transformations[0].Parameters.FirstOrDefault(c => c.Name == "RejectDirectory").Value =
                string.Format(@"{0}\{1}\REJECT", EtlSourceDirectoryServer, EtlSourceDirectoryFolder);
            workflow.ConsumerID = WFConstant.ConsumerID;

            return workflow;
        }

        public static string ToActivityLogMessage(Exception ex)
        {
            var messageBuilder = new StringBuilder();
            if (ex != null)
            {
                messageBuilder.Append(ex.Message);
                messageBuilder.AppendLine(ex.StackTrace);
            }

            messageBuilder.AppendFormat("ConnStr_EXP: ", DBReference.ConnStr_EXP);
            messageBuilder.AppendFormat("ConnStr_LND: ", DBReference.ConnStr_LND);
            messageBuilder.AppendFormat("ConnStr_STG: ", DBReference.ConnStr_STG);
            messageBuilder.AppendFormat("ConnStr_DV: ", DBReference.ConnStr_DV);
            messageBuilder.AppendFormat("ConnStr_SSISDB: ", DBReference.ConnStr_SSISDB);
            messageBuilder.AppendFormat("ConnStr_GES_LND: ", DBReference.ConnStr_GES_LND);
            messageBuilder.AppendFormat("ConnStr_GES_STG: ", DBReference.ConnStr_GES_STG);
            messageBuilder.AppendFormat("ConnStr_GES_DV: ", DBReference.ConnStr_GES_DV);

            var message = messageBuilder.ToString();
            if (message.Length > ACTIVITY_LOG_MESSAGE_MAX_LENGTH)
            {
                message = message.Substring(0, ACTIVITY_LOG_MESSAGE_MAX_LENGTH);
            }

            return message;
        }
        #endregion

        #region Methods to use
        public static DataTable GetMissedDataFromXML(string query)
        {
            DataSet ds = DataReaderUtilities.GetData(DBReference.ConnStr_LND, query);

            if (ds != null && ds.Tables.Count > 0)
            {
                var dt = ds.Tables[0];

                return dt;
            }

            return null;
        }

        public static DataTable GetMissedCowDataFromCSV(string filePath)
        {
            DataTable dtCows = null;

            var dsData = DataReaderUtilities.GetData(DBReference.ConnStr_LND,
                string.Format(@"EXEC usp_common_parse_missing_field_import_cow_csv @file_name ='{0}'", filePath));
            if ((dsData != null) && (dsData.Tables.Count > 0))
            {
                dtCows = dsData.Tables[0];
            }
            
            return dtCows;
        }

        public static DataTable GetMissedBullDataFromCSV(string filePath)
        {
            DataTable dtBulls = null;

            DataSet dsData = DataReaderUtilities.GetData(DBReference.ConnStr_LND,
                string.Format(@"EXEC usp_common_parse_missing_field_import_bull_csv @file_name ='{0}'", filePath));
            if ((dsData != null) && (dsData.Tables.Count > 0))
            {
                dtBulls = dsData.Tables[0];
            }

            return dtBulls;
        }

        public static int ProcessCow(string xml, int sessionId)
        {
            var taskCode = ActivityTaskCodeConstant.PROCESS_CREATE_COW_FROM_UI;
            var activityLogId = ActivityLogHelper.CreateActivityLog(sessionId, taskCode);

            try
            {
                var dataSupplierCode = string.Empty;
                using (var reader = new StringReader(xml))
                {
                    var serializer = new XmlSerializer(typeof(Animal));
                    var parsedBull = serializer.Deserialize(reader) as Animal;
                    dataSupplierCode = parsedBull?.DPC;
                }

                if (string.IsNullOrEmpty(dataSupplierCode))
                {
                    ActivityLogHelper.SetActivityLogStatus(activityLogId, ActivityStatusConstant.FAILED,
                                                            ToActivityLogMessage(new Exception(MissingDataSupplierMessage)));
                }
                else if (!CheckExistsPartyCode(dataSupplierCode))
                {
                    ActivityLogHelper.SetActivityLogStatus(activityLogId, ActivityStatusConstant.FAILED,
                                ToActivityLogMessage(new Exception(string.Format(InvalidDataSupplierMessage, dataSupplierCode))));
                }
                else
                {

                    var file_folder = string.Format(@"{0}\{1}\{2}\{3}\{4}\", EtlSourceDirectoryServer, EtlSourceDirectoryFolder,
                    String.Format("{0:yyyyMMdd}", DateTime.Now), dataSupplierCode, "COW_EXTENT_CSV");
                    if (!Directory.Exists(file_folder)) // Check exist of folder
                    {
                        DirectoryHelper.TryCreateDirectory(file_folder, string.Format(@"{0}\{1}", EtlSourceDirectoryServer, EtlSourceDirectoryFolder), EtlSourceDirectoryDomain, EtlSourceDirectoryCredential, EtlSourceDirectorySecret);
                    }

                    // Write csv file
                    var dt = GetMissedDataFromXML(string.Format(@"EXEC usp_common_parse_missing_field_DIF102 @COW_XML ='{0}'", xml.Replace("'", "''")));

                    var timestamp = DateTime.UtcNow.Ticks;
                    string file_name = timestamp + ".csv";
                    var fullPathFile = file_folder + file_name;
                    CSVHelper.WriteDataTable(dt, fullPathFile);

                    // Execute workflow
                    string workflowName = WFConstant.CowWorkflowName;
                    Workflow workflow = GetWorkflow(workflowName, fullPathFile);

                    ExecuteCreateWorkflow(workflow, activityLogId);
                }
            }
            catch (Exception ex)
            {
                ActivityLogHelper.SetActivityLogStatus(activityLogId, ActivityStatusConstant.FAILED, ToActivityLogMessage(ex));
            }

            return activityLogId;
        }

        public static int ProcessBull(string xml, int sessionId)
        {
            var taskCode = ActivityTaskCodeConstant.PROCESS_CREATE_BULL_FROM_UI;
            var activityLogId = ActivityLogHelper.CreateActivityLog(sessionId, taskCode);

            try
            {
                var dataSupplierCode = string.Empty;
                using (var reader = new StringReader(xml))
                {
                    var serializer = new XmlSerializer(typeof(Animal));
                    var parsedBull = serializer.Deserialize(reader) as Animal;
                    dataSupplierCode = string.IsNullOrEmpty(parsedBull?.DATA_SUPPLIER) ? parsedBull?.BULL_OWNER_CODE : parsedBull?.DATA_SUPPLIER;
                }

                if (string.IsNullOrEmpty(dataSupplierCode))
                {
                    ActivityLogHelper.SetActivityLogStatus(activityLogId, ActivityStatusConstant.FAILED,
                                                            ToActivityLogMessage(new Exception(MissingDataSupplierMessage)));
                }
                else if (!CheckExistsPartyCode(dataSupplierCode))
                {
                    ActivityLogHelper.SetActivityLogStatus(activityLogId, ActivityStatusConstant.FAILED,
                                ToActivityLogMessage(new Exception(string.Format(InvalidDataSupplierMessage, dataSupplierCode))));
                }
                else
                {
                    var file_folder = string.Format(@"{0}\{1}\{2}\{3}\{4}\", EtlSourceDirectoryServer, EtlSourceDirectoryFolder,
                        String.Format("{0:yyyyMMdd}", DateTime.Now), dataSupplierCode, "BULL_EXTENT_CSV");
                    if (!Directory.Exists(file_folder)) // Check exist of folder
                    {
                        DirectoryHelper.TryCreateDirectory(file_folder, string.Format(@"{0}\{1}", EtlSourceDirectoryServer, EtlSourceDirectoryFolder), EtlSourceDirectoryDomain, EtlSourceDirectoryCredential, EtlSourceDirectorySecret);
                    }

                    // Write csv file
                    var dt = GetMissedDataFromXML(string.Format(@"EXEC usp_common_parse_missing_field_DIF105 @BULL_XML ='{0}'", xml.Replace("'", "''")));

                    var timestamp = DateTime.UtcNow.Ticks;
                    string file_name = timestamp + ".csv";
                    var fullPathFile = file_folder + file_name;
                    CSVHelper.WriteDataTable(dt, fullPathFile);

                    // Execute workflow
                    string workflowName = WFConstant.BullWorkflowName;
                    Workflow workflow = GetWorkflow(workflowName, fullPathFile);

                    ExecuteCreateWorkflow(workflow, activityLogId);
                }
            }
            catch (Exception ex)
            {
                ActivityLogHelper.SetActivityLogStatus(activityLogId, ActivityStatusConstant.FAILED, ToActivityLogMessage(ex));
            }

            return activityLogId;
        }

        public static int ProcessDeleteAnimal(string listAnimal, int sessionId)
        {
            var taskCode = ActivityTaskCodeConstant.PROCESS_DELETE_BULL;
            var activityLogId = ActivityLogHelper.CreateActivityLog(sessionId, taskCode);

            try
            {               

                var WPID = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                        string.Format(@"EXEC wsp_addui_delete_animals @list_national_id ='{0}'", listAnimal));
                if (WPID != null) 
                {
                    //Update Workflow
                    UpdateRelatedWPIDToActivityLog(activityLogId, WPID.ToString());
                }

            }
            catch (Exception ex)
            {
                ActivityLogHelper.SetActivityLogStatus(activityLogId, ActivityStatusConstant.FAILED, ex.Message);
            }

            return activityLogId;
        }

        public static int ProcessNasisBull(string xml, int sessionId)
        {
            var taskCode = ActivityTaskCodeConstant.PROCESS_CREATE_NASIS_BULL_FROM_UI;
            var activityLogId = ActivityLogHelper.CreateActivityLog(sessionId, taskCode);

            try
            {
                var dataSupplierCode = string.Empty;
                using (var reader = new StringReader(xml))
                {
                    var serializer = new XmlSerializer(typeof(Animal));
                    var parsedBull = serializer.Deserialize(reader) as Animal;
                    dataSupplierCode = string.IsNullOrEmpty(parsedBull?.DATA_SUPPLIER) ? parsedBull?.BULL_OWNER_CODE : parsedBull?.DATA_SUPPLIER;
                }

                if (string.IsNullOrEmpty(dataSupplierCode))
                {
                    ActivityLogHelper.SetActivityLogStatus(activityLogId, ActivityStatusConstant.FAILED,
                                                            ToActivityLogMessage(new Exception(MissingDataSupplierMessage)));
                }
                else if (!CheckExistsPartyCode(dataSupplierCode))
                {
                    ActivityLogHelper.SetActivityLogStatus(activityLogId, ActivityStatusConstant.FAILED,
                                ToActivityLogMessage(new Exception(string.Format(InvalidDataSupplierMessage, dataSupplierCode))));
                }
                else
                {
                    var file_folder = string.Format(@"{0}\{1}\{2}\{3}\{4}\", EtlSourceDirectoryServer, EtlSourceDirectoryFolder,
                    String.Format("{0:yyyyMMdd}", DateTime.Now), dataSupplierCode, "NASISBULL_EX_CSV");
                    if (!Directory.Exists(file_folder)) // Check exist of folder
                    {
                        DirectoryHelper.TryCreateDirectory(file_folder, string.Format(@"{0}\{1}", EtlSourceDirectoryServer, EtlSourceDirectoryFolder), EtlSourceDirectoryDomain, EtlSourceDirectoryCredential, EtlSourceDirectorySecret);
                    }

                    // Write csv file
                    var dt = GetMissedDataFromXML(string.Format(@"EXEC usp_common_parse_missing_field_DIF105_nasis @BULL_XML ='{0}'", xml.Replace("'", "''")));

                    var timestamp = DateTime.UtcNow.Ticks;
                    string file_name = timestamp + ".csv";
                    var fullPathFile = file_folder + file_name;
                    CSVHelper.WriteDataTable(dt, fullPathFile);

                    // Execute workflow
                    string workflowName = WFConstant.BullWorkflowName;
                    Workflow workflow = GetWorkflow(workflowName, fullPathFile);

                    ExecuteCreateWorkflow(workflow, activityLogId);
                }
            }
            catch (Exception ex)
            {
                ActivityLogHelper.SetActivityLogStatus(activityLogId, ActivityStatusConstant.FAILED, ToActivityLogMessage(ex));
            }

            return activityLogId;
        }

        public static int ProcessImportCowFile(string filePath, int sessionId, string dataSupplierName = null, string type = "")
        {
            var taskCode = ActivityTaskCodeConstant.PROCESS_IMPORT_COW;
            var activityLogId = ActivityLogHelper.CreateActivityLog(sessionId, taskCode);

            try
            {
                var impFullPathFile = string.Empty;

                var impExtension = Path.GetExtension(filePath);
                if (".csv".Equals(impExtension))
                {
                    var dataSupplierPartyCode = GetPartyCode(dataSupplierName);

                    if (string.IsNullOrEmpty(dataSupplierPartyCode))
                    {
                        ActivityLogHelper.SetActivityLogStatus(activityLogId, ActivityStatusConstant.FAILED,
                                                                ToActivityLogMessage(new Exception(MissingDataSupplierMessage)));
                    }
                    else if (!CheckExistsPartyCode(dataSupplierPartyCode))
                    {
                        ActivityLogHelper.SetActivityLogStatus(activityLogId, ActivityStatusConstant.FAILED,
                                    ToActivityLogMessage(new Exception(string.Format(InvalidDataSupplierMessage, dataSupplierPartyCode))));
                    }
                    else
                    {
                        var folCreatedDate = String.Format("{0:yyyyMMdd}", DateTime.Now);
                        var impFolderPath = string.Format(@"{0}\{1}\{2}\{3}\{4}\", EtlSourceDirectoryServer,
                                                EtlSourceDirectoryFolder, folCreatedDate, dataSupplierPartyCode, "COW_EXTENT_CSV");
                        if (!Directory.Exists(impFolderPath)) // Check exist of folder
                        {
                            DirectoryHelper.TryCreateDirectory(impFolderPath, string.Format(@"{0}\{1}", EtlSourceDirectoryServer,
                                                                EtlSourceDirectoryFolder), EtlSourceDirectoryDomain,
                                                                EtlSourceDirectoryCredential, EtlSourceDirectorySecret);
                        }

                        impFullPathFile = string.Format("{0}{1}.csv", impFolderPath, DateTime.UtcNow.Ticks.ToString());

                        var dtCsvData = GetMissedCowDataFromCSV(filePath);

                        CSVHelper.WriteDataTable(dtCsvData, impFullPathFile);
                    }
                }
                else if (".xlsx".Equals(impExtension))
                {
                    impFullPathFile = ConvertExcelToCSV(filePath, "COW_EXTENT_XLSX", new List<int>() { 2}, dataSupplierName);
                }
                else
                {
                    impFullPathFile = filePath;
                }

                // Execute workflow
                var workflow = GetWorkflow(type.Equals("DIF115") ? WFConstant.CowWorkflowName115 : WFConstant.CowWorkflowName, impFullPathFile);
                
                ExecuteCreateWorkflow(workflow, activityLogId);
            }
            catch (Exception ex)
            {
                ActivityLogHelper.SetActivityLogStatus(activityLogId, ActivityStatusConstant.FAILED, ToActivityLogMessage(ex));
            }

            return activityLogId;
        }

        public static int ProcessImportBullFile(string filePath, int sessionId, string dataSupplierName, string type)
        {
            var taskCode = type.Equals("DIF105_NASIS") ? ActivityTaskCodeConstant.PROCESS_IMPORT_NASIS_BULL :
                                                  ActivityTaskCodeConstant.PROCESS_IMPORT_BULL;
           
            var activityLogId = ActivityLogHelper.CreateActivityLog(sessionId, taskCode);
            
            try
            {
                var impFullPathFile = string.Empty;

                var impExtension = Path.GetExtension(filePath);
                if (".csv".Equals(impExtension))
                {
                    var dataSupplierPartyCode = GetPartyCode(dataSupplierName);

                    var folCreatedDate = String.Format("{0:yyyyMMdd}", DateTime.Now);
                    var impFolderPath = string.Format(@"{0}\{1}\{2}\{3}\{4}\", EtlSourceDirectoryServer, EtlSourceDirectoryFolder, folCreatedDate, dataSupplierPartyCode, "BULL_EXTENT_CSV");
                    if (!Directory.Exists(impFolderPath)) // Check exist of folder
                    {
                        DirectoryHelper.TryCreateDirectory(impFolderPath, string.Format(@"{0}\{1}", EtlSourceDirectoryServer, EtlSourceDirectoryFolder), EtlSourceDirectoryDomain, EtlSourceDirectoryCredential, EtlSourceDirectorySecret);
                    }

                    impFullPathFile = string.Format("{0}{1}.csv", impFolderPath, DateTime.UtcNow.Ticks.ToString());

                    var dtCsvData = GetMissedBullDataFromCSV(filePath);

                    CSVHelper.WriteDataTable(dtCsvData, impFullPathFile);
                }
                else if (".xlsx".Equals(impExtension))
                {
                    impFullPathFile = ConvertExcelToCSV(filePath, "BULL_EXTENT_XLSX", new List<int>() { 3 }, dataSupplierName);
                }
                else
                {
                    impFullPathFile = filePath;
                }
                
                // Execute workflow
                var workflow = GetWorkflow(WFConstant.BullWorkflowName, impFullPathFile);

                ExecuteCreateWorkflow(workflow, activityLogId);
            }
            catch (Exception ex)
            {
                ActivityLogHelper.SetActivityLogStatus(activityLogId, ActivityStatusConstant.FAILED, ToActivityLogMessage(ex));
            }

            return activityLogId;
        }

        public static string ConvertExcelToCSV(string filePath, string folderName, List<int> columnDateFormats, string dataSupplierName = null)
        {
            var dataSupplierPartyCode = GetPartyCode(dataSupplierName);

            DataTable dtCsvData = new DataTable();
            var folCreatedDate = String.Format("{0:yyyyMMdd}", DateTime.Now);
            var impFolderPath = string.Format(@"{0}\{1}\{2}\{3}\{4}\", EtlSourceDirectoryServer, EtlSourceDirectoryFolder, 
                                                folCreatedDate, dataSupplierPartyCode, folderName);
            if (!Directory.Exists(impFolderPath)) // Check exist of folder
            {
                DirectoryHelper.TryCreateDirectory(impFolderPath, string.Format(@"{0}\{1}", EtlSourceDirectoryServer, EtlSourceDirectoryFolder),
                                                EtlSourceDirectoryDomain, EtlSourceDirectoryCredential, EtlSourceDirectorySecret);
            }

            var impFullPathFile = string.Format("{0}{1}.csv", impFolderPath, DateTime.UtcNow.Ticks.ToString());

            using (ExcelPackage xlPackage = new ExcelPackage(new FileInfo(filePath)))
            {
                var myWorksheet = xlPackage.Workbook.Worksheets.First(); //select sheet here
                var totalRows = myWorksheet.Dimension.End.Row;
                var totalColumns = myWorksheet.Dimension.End.Column;

                var headerCol = myWorksheet.Cells[5, 1, 5, totalColumns]
                                           .Select(c => new DataColumn(c.Value == null ? string.Empty : c.Value.ToString()))
                                           .ToArray();

                dtCsvData.Columns.AddRange(headerCol);
                dtCsvData.Rows.Add(headerCol);

                for (int rowNum = 6; rowNum <= totalRows; rowNum++) //select starting row here
                {
                    var row = myWorksheet.Cells[rowNum, 1, rowNum, totalColumns].Select((c, index) =>
                    {
                        string value = "";

                        if (c.Value != null)
                        {
                            if (columnDateFormats.Contains(index + 1))
                            {
                                if(c.Value is double)
                                {
                                    value = string.Format("{0:dd/MM/yyyy}", DateTime.FromOADate(Double.Parse(c.Value.ToString())));
                                }
                                else
                                {
                                    value = DateTime.Parse(c.Value.ToString()).ToString("dd/MM/yyyy");
                                }                                    
                            }
                            else value = c.Value.ToString();
                        }

                        return value;
                    }).ToArray();

                    if (row.Where(_ => !_.Equals("")).Count() > 0)
                        dtCsvData.Rows.Add(row);
                    else break;
                }

            }

            CSVHelper.WriteDataTable(dtCsvData, impFullPathFile);
            return impFullPathFile;
        }

        public static int ProcessImportItb200File(string filePath, int sessionId)
        {
            var taskCode = ActivityTaskCodeConstant.PROCESS_IMPORT_ITB200;
            var activityLogId = ActivityLogHelper.CreateActivityLog(sessionId, taskCode);

            string srcDirectory = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV, @"SELECT CONN_VALUE FROM dbo.SAT_LOCATION_AUTHS WHERE CONN_NAME = 'ETL_WEB_DIRECTORY_BIN'").ToString();

            var file = string.Empty;

            file = filePath.Replace(string.Concat(srcDirectory,"\\"), string.Empty);

            try
            {
                Dictionary<string, string> Input = new Dictionary<string, string>()
                {
                    { "RejectDirectory", string.Format("{0}\\{1}", srcDirectory, "REJECT") },
                    { "FailedDirectory", string.Format("{0}\\{1}", srcDirectory, "FAILED")},
                    { "CompleteDirectory", string.Format("{0}\\{1}", srcDirectory, "COMPLETE")},
                    { "SourceDirectory", srcDirectory},
                    { "ListOfFiles", file}
                };

                var wfParameterPool = new Dictionary<string, object>()
                {
                    { WFConstant.WorkflowParamTypeEnum.INPUT_DATASETS.ToString(), Input },
                    { WFConstant.WorkflowParamTypeEnum.OUTPUT_DATASETS.ToString(), new Dictionary<string, string>() },
                    { WFConstant.WorkflowParamTypeEnum.PARAMETERS.ToString(), new Dictionary<string, string>() }
                };

                var workflow = WorkflowOperation.WorkflowOperation.GetSystemWorkflowByName(WFConstant.ItbWorkflowName);

                workflow.ConsumerID = WFConstant.ConsumerID;

                foreach (var transf in workflow.Transformations)
                {
                    LoadTransfParams(transf.Input_Datasets.Items, WFConstant.WorkflowParamTypeEnum.INPUT_DATASETS, wfParameterPool);
                    LoadTransfParams(transf.Output_Datasets.Items, WFConstant.WorkflowParamTypeEnum.OUTPUT_DATASETS, wfParameterPool);
                    LoadTransfParams(transf.Parameters, WFConstant.WorkflowParamTypeEnum.PARAMETERS, wfParameterPool);
                }

                ExecuteCreateWorkflow(workflow, activityLogId);
            }
            catch (Exception ex)
            {
                ActivityLogHelper.SetActivityLogStatus(activityLogId, ActivityStatusConstant.FAILED, ToActivityLogMessage(ex));
            }

            return activityLogId;
        }

        protected static void LoadTransfParams(List<Parameter> reqTransfParams, WFConstant.WorkflowParamTypeEnum transfParamType, IDictionary<string, object> wfParams)
        {
            if (reqTransfParams != null)
            {
                object parameters;
                if (wfParams.TryGetValue(transfParamType.ToString(), out parameters))
                {
                    var inpTransfParams = parameters as Dictionary<string, string>;
                    if (inpTransfParams != null)
                    {
                        foreach (var param in reqTransfParams)
                        {
                            if (!string.IsNullOrWhiteSpace(param.Name))
                            {
                                string paramValue;
                                if (inpTransfParams.TryGetValue(param.Name, out paramValue))
                                {
                                    param.Value = paramValue;
                                }
                            }
                        }
                    }
                }
            }
        }
        #endregion
    }
}
