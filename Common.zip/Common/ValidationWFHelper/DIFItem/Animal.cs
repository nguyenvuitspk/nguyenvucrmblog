﻿namespace ValidationWFHelper.DIFItem
{
    using FileHelpers;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot("Data")]
    [FixedLengthRecord()]
    public class Animal
    {
        [XmlAttribute("Data_Supplier")]
        public string DATA_SUPPLIER { get; set; }

        [XmlAttribute("DPC")]
        public string DPC { get; set; }

        [XmlAttribute("Bull_Owner_code")]
        public string BULL_OWNER_CODE { get; set; }
    }
}
