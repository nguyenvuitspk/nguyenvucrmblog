﻿namespace ValidationWFHelper.Common
{
    using System;
    using System.IO;

    public class DirectoryHelper
    {
        #region Static members
        public static bool TryCreateDirectory(string folderPath, string rootPath, string domain, string username, string password)
        {
            bool isSuccess;

            if (Directory.Exists(folderPath))
            {
                isSuccess = true;
            }
            else
            {
                using (UNCAccessWithCredentials unc = new UNCAccessWithCredentials())
                {
                    try
                    {
                        if (unc.NetUseWithCredentials(rootPath, username, domain, password))
                        {
                            Directory.CreateDirectory(folderPath);
                            isSuccess = true;
                        }
                        else
                        {
                            isSuccess = false;
                        }
                    }
                    catch (Exception ex)
                    {
                        isSuccess = false;
                    }
                }
            }

            return isSuccess;
        }

        public static string TryToSaveFile(byte[] fileByte, string path, string root, string domain, string username, string password)
        {
            using (UNCAccessWithCredentials unc = new UNCAccessWithCredentials())
            {
                string savedFilePath = null;
                try
                {
                    if (unc.NetUseWithCredentials(root, username, domain, password))
                    {
                        File.WriteAllBytes(path, fileByte);
                        savedFilePath = path;
                    }
                }
                catch (Exception ex)
                {
                    savedFilePath = string.Empty;
                }

                return savedFilePath;
            }
        }
        #endregion
    }
}