﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;

namespace ValidationWFHelper.Common
{
    public class CSVHelper
    {
        public static void Write(List<dynamic> records, string fullPathFile)
        {
            using (var sw = new StreamWriter(fullPathFile))
            {
                var csv = new CsvWriter(sw);
                // Dynamic
                csv.WriteRecords(records);
            }
        }

        public static void WriteDataTable(DataTable table, string fullPathFile)
        {
            var result = new StringBuilder();
            foreach (DataRow row in table.Rows)
            {
                for (int i = 0; i < table.Columns.Count; i++)
                {
                    var text = @"""""";
                    if(!DBNull.Value.Equals(row[i]))
                    {
                        text = row[i].ToString();
                    }
                    result.Append(text);

                    result.Append(i == table.Columns.Count - 1 ? "\n" : ",");
                }
            }
            File.WriteAllText(fullPathFile, result.ToString());
        }
    }
}
