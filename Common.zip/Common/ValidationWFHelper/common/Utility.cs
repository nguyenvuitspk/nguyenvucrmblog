﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidationWFHelper.Common
{
    public class Utility
    {
        public static string SaveConvertedEOL(string fullPathFile)
        {
            string data = null;
            //Open and read the file
            using (StreamReader srFileName = new StreamReader(fullPathFile, Encoding.Default))
            {
                data = srFileName.ReadToEnd();
                data = data.Replace("\r\n", "\n"); // Convert end of line (eol) to UNIX/OSX format
                srFileName.Close();
            }

            using (StreamWriter swFileName = new StreamWriter(fullPathFile))
            {
                swFileName.Write(data);
                swFileName.Close();
            } // Rewrite after converting end of line
            return fullPathFile;
        }

    }
}
