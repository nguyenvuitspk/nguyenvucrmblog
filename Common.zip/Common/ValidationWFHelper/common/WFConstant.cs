﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidationWFHelper.Common
{
    public class WFConstant
    {
        #region Cow || 102
        public const string CowRecordType = "102";
        public const string CowRecordVersion = "1";
        public const string CowWorkflowName = "WF-F2D-102-EXTENT-CSV";
        #endregion

        #region Cow || 115
        public const string CowWorkflowName115 = "WF-F2D-115";
        #endregion

        #region Bull || 105
        public const string BullRecordType = "105";
        public const string BullRecordVersion = "3";
        public const string BullWorkflowName = "WF-F2D-105-EXTENT-CSV";
        #endregion

        #region Itb 200
        public const string ItbWorkflowName = "WF-F2D-ITB200";
        #endregion

        #region Common
        public const string ConsumerID = "OD";

        #endregion
        public enum WorkflowParamTypeEnum
        {
            INPUT_DATASETS,
            OUTPUT_DATASETS,
            PARAMETERS
        }
    }
}
