﻿using DataReaderUtilsLib;
using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using OfficeOpenXml;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.IO;
using SQLUtilsLib;
using System.Drawing;

namespace ABVReportLib
{
    public class WEBHaplotype : ABVReport
    {
        public WEBHaplotype(string reportName) : base(reportName)
        {
            FileOutputExt = "xlsx";
        }

        public override string GenerateReportWithMessage(int rptInstanceId)
        {
            string sMessage = "";
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            string searchFields = ReportParameters.Where(x => x.ParamName == "searchFields").Select(x => x.ParamValue).First();
            string sortingField = ReportParameters.Where(x => x.ParamName == "sortingField").Select(x => x.ParamValue).First();
            string sortingDesc = ReportParameters.Where(x => x.ParamName == "sortingDesc").Select(x => x.ParamValue).First();
            string PARTY_CODE = ReportParameters.Where(x => x.ParamName == "SESSION_ID").Select(x => x.ParamValue).First();

            DateTime reportTime = DateTime.Now;
            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportTime.Ticks.ToString());
            string reportFileName = ManageReports.GetReportOutputName(SystemReportId);
            string reportFilePath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName, FileOutputExt);
            string reportFullPath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportDirectory, reportFileName, FileOutputExt);
            string reportFileDirectory = string.Format(@"{0}/{1}", "WEBReport", reportTime.Ticks.ToString());
            string reportFileFullPath = string.Format(ABVReportConstant.WEB_REPORT_PATH_FORMAT, reportFileDirectory, reportFileName, FileOutputExt);

            // Create workbook
            try
            {
                DataTable dtTable = DataReaderUtilities.GetData(DBReference.ConnStr_DV, string.Format(@"EXEC dbo.wsp_web_get_selected_bull_haplotype @searchFields = '{0}', @sortingField = '{1}', @sortingDesc = '{2}', @PARTY_CODE = '{3}'", searchFields, sortingField, sortingDesc, PARTY_CODE)).Tables[0];


                if (dtTable.Rows.Count > 0)
                {
                    if (!Directory.Exists(Path.GetDirectoryName(reportFullPath)))
                    {
                        Directory.CreateDirectory(Path.GetDirectoryName(reportFullPath));
                    }

                    FileComposer.ExportExcelFileWithOutTemplate(dtTable, reportFullPath, reportFileName);
                }
                else
                {
                    FileComposer.ExportExcelForNoData(reportFullPath);
                    sMessage = "No Data";
                }

                Requestor = ManageReports.GetRequestor(rptInstanceId);
                ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);

                return sMessage;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }

        public override IDictionary<string, object> GenerateReportWithDictionary(int rptInstanceId, int sessionId)
        {
            string sMessage = "";
            string timeStamp = "";
            string strBreedCondition;
            string tempFileName;
            DataRow[] dtRows;
            int iLengthAnimalList = 0;
            List<string> sheetNameList = new List<string>();
            string sheetName;
            Dictionary<string, object> reportMessage = new Dictionary<string, object>();
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            string searchFields = ReportParameters.Where(x => x.ParamName == "searchFields").Select(x => x.ParamValue).First();
            string sortingField = ReportParameters.Where(x => x.ParamName == "sortingField").Select(x => x.ParamValue).First();
            string sortingDesc = ReportParameters.Where(x => x.ParamName == "sortingDesc").Select(x => x.ParamValue).First();

            DateTime reportTime = DateTime.Now;
            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportTime.Ticks.ToString());
            string reportFileName = ManageReports.GetReportOutputName(SystemReportId);
            string reportFilePath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName, FileOutputExt);
            string reportFullPath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportDirectory, reportFileName, FileOutputExt);
            string outputFileName = string.Format(ABVReportConstant.WEB_REPORT_FILENAME_FORMAT, reportFileName, FileOutputExt);

            // Create workbook
            try
            {
                //Get Breed Code
                DataTable tblBreedCode = ManageReports.GetBreedCodeReport();
                Dictionary<string, string> dicBreed = tblBreedCode.AsEnumerable().ToDictionary<DataRow, string, string>(row => row.Field<string>(0), row => row.Field<string>(1));
                 
                //Get Data
                DataTable dtTable = DataReaderUtilities.GetData(DBReference.ConnStr_DV, string.Format(@"EXEC dbo.wsp_web_get_selected_bull_haplotype @searchFields = '{0}', @sortingField = '{1}', @sortingDesc = '{2}', @SESSION_ID = '{3}'", searchFields, sortingField, sortingDesc, sessionId)).Tables[0];

                if (dtTable.Rows.Count > 0 && tblBreedCode.Rows.Count > 0)
                {
                    if (!Directory.Exists(Path.GetDirectoryName(reportFullPath)))
                    {
                        Directory.CreateDirectory(Path.GetDirectoryName(reportFullPath));
                    }
                    DataTable[] dtTableSheet = new DataTable[dicBreed.Keys.Count];
                    // Filter Breed Code
                    foreach (var keyBreed in dicBreed.Keys)
                    {
                        strBreedCondition = "YGEN_BREED = '" + keyBreed + "'";
                        dtRows = dtTable.Select(strBreedCondition);
                        if (dtRows.Length > 0)
                        {
                            reportTime = DateTime.Now;
                            timeStamp = string.Format(reportTime.Ticks.ToString());
                            dtTableSheet[iLengthAnimalList] = dtRows.CopyToDataTable();
                            sheetName = dicBreed[keyBreed];
                            //Export excel file
                            tempFileName = string.Format(ABVReportConstant.REPORT_PATH_FORMAT, reportDirectory, timeStamp);
                            FileComposer.ExportExcelFileWithOutTemplate(dtTableSheet[iLengthAnimalList], tempFileName, sheetName);
                            sheetNameList.Add(tempFileName);
                            iLengthAnimalList++;
                        }
                    }
                    FileComposer.ExcelSheetMerging(sheetNameList, reportFullPath);
                    reportMessage = AddReportObject(reportFullPath, outputFileName);
                }
                else
                {
                    sMessage = "No Data.";
                    reportMessage.Add("Message", sMessage);
                }

                Requestor = ManageReports.GetRequestor(rptInstanceId);
                ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                return reportMessage;
            }
            catch (Exception ex)
            {
                reportMessage.Add("Message", ex.Message);
                return reportMessage;
            }

        }


    }
}
