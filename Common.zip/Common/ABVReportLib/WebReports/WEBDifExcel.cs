﻿using DataReaderUtilsLib;
using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using OfficeOpenXml;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.IO;
using SQLUtilsLib;
using System.Drawing;

namespace ABVReportLib
{
    public class WEBDifExcel : ABVReport
    {
        public WEBDifExcel(string reportName) : base(reportName)
        {
            FileOutputExt = "xlsx";
        }

        public override string GenerateReportWithMessage(int rptInstanceId)
        {
            string sMessage = "";
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            string searchFields = ReportParameters.Where(x => x.ParamName == "searchFields").Select(x => x.ParamValue).First();
            string sortingField = ReportParameters.Where(x => x.ParamName == "sortingField").Select(x => x.ParamValue).First();
            string sortingDesc = ReportParameters.Where(x => x.ParamName == "sortingDesc").Select(x => x.ParamValue).First();
            string PARTY_CODE = ReportParameters.Where(x => x.ParamName == "PARTY_CODE").Select(x => x.ParamValue).First();

            DateTime reportTime = DateTime.Now;
            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportTime.Ticks.ToString());
            string reportFileName = ManageReports.GetReportOutputName(SystemReportId);
            string reportFilePath = string.Format(ABVReportConstant.DIF_REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName);
            string reportFullPath = string.Format(ABVReportConstant.DIF_REPORT_DIRECTORY_FORMAT, reportDirectory, reportFileName, FileOutputExt);

            string reportFileDirectory = string.Format(ABVReportConstant.WEB_DIF_REPORT_PATH_FORMAT, "WEBReport", reportTime.Ticks.ToString());
            string reportFileFullPath = string.Format(ABVReportConstant.WEB_DIF_REPORT_PATH_FORMAT, reportFileDirectory, reportFileName, FileOutputExt);
            string xmlTemplatePath = "";
            string maskPath = "";

            // Create workbook
            try
            {
                DataTable dtTable = DataReaderUtilities.GetData(DBReference.ConnStr_CDRDW, string.Format(@"EXEC dbo.usp_web_export_dif_201 @searchFields = '{0}', @sortingField = '{1}', @sortingDesc = '{2}', @PARTY_CODE = '{3}'", searchFields, sortingField, sortingDesc, PARTY_CODE)).Tables[0];


                if (dtTable.Rows.Count > 0)
                {
                    xmlTemplatePath = ManageReports.GetPathToTemplateFile();
                    maskPath = string.Format(@"{0}\{1}.xml", xmlTemplatePath, ReportID);
                    FileComposer.ExportDIFFile(maskPath, dtTable, reportFullPath);
                }
                else
                {
                    sMessage = "No Data";
                }

                Requestor = ManageReports.GetRequestor(rptInstanceId);
                ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);

                return sMessage;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }

        public virtual IDictionary<string, object> GenerateReportWithDictionary(int rptInstanceId, int sessionId, string rptRunName)
        {
            string sMessage = "";
            Dictionary<string, object> reportMessage = new Dictionary<string, object>();
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            string searchFields = ReportParameters.Where(x => x.ParamName == "searchFields").Select(x => x.ParamValue).First();
            string sortingField = ReportParameters.Where(x => x.ParamName == "sortingField").Select(x => x.ParamValue).First();
            string sortingDesc = ReportParameters.Where(x => x.ParamName == "sortingDesc").Select(x => x.ParamValue).First();

            //Get file path
            DateTime reportTime = DateTime.Now;
            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportTime.Ticks.ToString());
            string reportFileName = ManageReports.GetReportOutputName(SystemReportId) + reportTime.ToString("MMyy");
            string reportFilePath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName, FileOutputExt);
            string reportFullPath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportDirectory, reportFileName, FileOutputExt);
            string outputFileName = string.Format(ABVReportConstant.WEB_REPORT_FILENAME_FORMAT, reportFileName, FileOutputExt);

            // Create workbook
            try
            {
                DataTable dtTable = new DataTable();
                if (rptRunName == ABVReportConstant.DIF_201_EXCEL_REPORT)
                {
                    dtTable = DataReaderUtilities.GetData(DBReference.ConnStr_DV, string.Format(@"EXEC dbo.usp_web_export_dif_201 @searchFields = '{0}', @sortingField = '{1}', @sortingDesc = '{2}', @SESSION_ID = '{3}'", searchFields, sortingField, sortingDesc, sessionId)).Tables[0];
                }
                if (rptRunName == ABVReportConstant.DIF_202_EXCEL_REPORT)
                {
                    dtTable = DataReaderUtilities.GetData(DBReference.ConnStr_DV, string.Format(@"EXEC dbo.usp_web_export_dif_202 @searchFields = '{0}', @sortingField = '{1}', @sortingDesc = '{2}', @SESSION_ID = '{3}'", searchFields, sortingField, sortingDesc, sessionId)).Tables[0];
                }

                if (dtTable.Rows.Count > 0)
                {
                    if (!Directory.Exists(Path.GetDirectoryName(reportFullPath)))
                    {
                        Directory.CreateDirectory(Path.GetDirectoryName(reportFullPath));
                    }

                    FileComposer.ExportExcelFileWithOutTemplate(dtTable, reportFullPath, reportFileName);
                    reportMessage = AddReportObject(reportFullPath, outputFileName);
                }
                else
                {
                    sMessage = "No Data.";
                    reportMessage.Add("Message", sMessage);
                }
                Requestor = ManageReports.GetRequestor(rptInstanceId);
                ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                return reportMessage;
            }
            catch (Exception ex)
            {
                reportMessage.Add("Message", ex.Message);
                return reportMessage;
            }

        }


    }
}
