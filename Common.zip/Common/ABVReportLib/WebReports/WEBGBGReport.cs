﻿using DataReaderUtilsLib;
using SQLUtilsLib;

namespace ABVReportLib
{
    public class WEBGBGReport : ABVReport
    {
        public WEBGBGReport(string reportName) : base(reportName)
        {
            ProjectName = "WEBReports";
        }

        public override bool CheckData(string xmlSearchFields, string partyCode)
        {
            var checkData = DataReaderUtilities.GetData(DBReference.ConnStr_DV,
                   string.Format(@"DECLARE	@return_value int,
		                                    @RountCow int
                                    EXEC	@return_value = [dbo].[usp_web_check_gbg]
		                                    @searchFields = '{0}',
		                                    @PARTY_CODE = '{1}',
		                                    @RountCow = @RountCow OUTPUT
                                    SELECT	@RountCow as N'@RountCow'", xmlSearchFields, partyCode)).Tables[0].Rows[0][0].ToString();

            if (int.Parse(checkData) > 0) 
            {
                return true; 
            }
            return false;
        }
    }
}
