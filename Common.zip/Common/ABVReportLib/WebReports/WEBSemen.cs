﻿using DataReaderUtilsLib;
using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using OfficeOpenXml;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.IO;
using SQLUtilsLib;
using System.Drawing;

namespace ABVReportLib
{
    public class WEBSemen : ABVReport
    {
        public WEBSemen(string reportName) : base(reportName)
        {
            ProjectName = "WEBReports";
        }
    }
}
