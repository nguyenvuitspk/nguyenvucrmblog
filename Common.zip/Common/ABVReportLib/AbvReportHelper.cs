﻿using SQLUtilsLib;
using SSRSReportLib;
using System.Collections.Generic;

namespace ABVReportLib
{
    public class AbvReportHelper
    {
        public static void SubmitReports(string reportName, List<ReportParameter> parameters)
        {

        }

        public static void GenerateReports(int rptInstanceId, string[] fileTypes, string fileXML = "", string forType = "")
        {
            string reportName = ManageReports.GetReportName(rptInstanceId);
            var reporting = new ABVReport(reportName);

            fileXML = fileXML.Replace("'", "''");
            reporting.GenerateReports(rptInstanceId, fileTypes, fileXML, forType);
        }
    }
}
