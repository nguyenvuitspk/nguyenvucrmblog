﻿using DataReaderUtilsLib;
using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ABVReportLib
{
    public class NasisGenomicCSV : ABVReport
    {
        private string xmlSearchFields = string.Empty;
        private const string FILE_TYPE = "CSV3LINES_201";
        private const string SEARCH_FIELDCONDITION_PATTERN = "</FieldConditions";
        private const string MULTIPLE_SEARCH_FIELDCONDITION_PATTERN = "</TextSearchRegrexs>";
        private const string XML_FULL_FIELD_CONDITION_FORMAT = "<FieldConditions><FieldCondition FieldName =\"{0}\" Value=\"{1}\"/></FieldConditions>";
        private const string XML_FIELD_CONDITION_FORMAT = "<FieldCondition FieldName =\"{0}\" Value=\"{1}\"/>";

        public NasisGenomicCSV() : base("NASIS_GEN_SCREENING_CSV")
        {
            FileOutputExt = "xlsx";
        }
        
        public override void GenerateReport(int rptInstanceId)
        {
            // Report file info
            Requestor = ManageReports.GetRequestor(rptInstanceId);
            DateTime reportTime = DateTime.Now;
            string sMessage = "";

            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportTime.Ticks.ToString());
            if (!Directory.Exists(reportDirectory))
                Directory.CreateDirectory(reportDirectory);
            string reportFileName = ManageReports.GetReportOutputName(SystemReportId);
            string reportFilePath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName, FileOutputExt);
            string reportFullPath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportDirectory, reportFileName, FileOutputExt);

            // Get parameters
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            string activeRunId = ManageReports.GetActiveRunId(ReportDBConnString);
            xmlSearchFields = ReportParameters.Where(x => x.ParamName == "XML_SEARCH_FIELDS").Select(x => x.ParamValue).First();

            if (xmlSearchFields.Contains(MULTIPLE_SEARCH_FIELDCONDITION_PATTERN))
                xmlSearchFields = xmlSearchFields.Insert(0, string.Format(XML_FULL_FIELD_CONDITION_FORMAT, "RUN_ID", activeRunId));
            else
                xmlSearchFields = xmlSearchFields.Insert(xmlSearchFields.LastIndexOf(SEARCH_FIELDCONDITION_PATTERN), string.Format(XML_FIELD_CONDITION_FORMAT, "RUN_ID", activeRunId));

            try
            {
                // Export excel file with out template
                System.Data.DataTable rptData = null;
                if (xmlSearchFields.Length > 0)
                    rptData = DataReaderUtilities.GetData(ReportDBConnString, string.Format(@"EXEC dbo.wsp_EXPORT_FILE @searchFields = '{0}', @forType = '{1}'", xmlSearchFields, FILE_TYPE)).Tables[0];
                else
                    rptData = ManageReports.GetReportWithoutTemplate(ReportDBConnString, ReportParameters, ReportID);

                if (rptData.Rows.Count > 0)
                {
                    FileComposer.ExportExcelFileWithOutTemplate(rptData, reportFullPath, reportFileName);
                }
                else
                {
                    FileComposer.ExportExcelForNoData(reportFullPath);
                    sMessage = "No Data";
                }

                // Save file info
                ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                //return sMessage;
            }
            catch (Exception ex)
            {
                //return ex.Message;
            }
        }

    }
}
