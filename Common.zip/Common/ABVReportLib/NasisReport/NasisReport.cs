﻿using DataReaderUtilsLib;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using NetworkShareHelper;
using SQLUtilsLib;
using System;
using System.Data;
using System.IO;
using System.Linq;

namespace ABVReportLib
{
    public class NasisReport: ABVReport
    {
        private SpreadsheetDocument spreedSheetDocument;
        private int curRowIdx;

        public NasisReport()
            : base("NASIS_REPORT")
        {
            FileOutputExt = "xlsx";
        }
        
        public override void GenerateReport(int rptInstanceId)
        {
            Requestor = ManageReports.GetRequestor(rptInstanceId);
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            DateTime reportTime = DateTime.Now;

            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportTime.Ticks.ToString());
            SharedGNetworkAccess web_directory_bin = new SharedGNetworkAccess("WEB_DIRECTORY_BIN");
            using (new NetworkConnection(web_directory_bin.RootFolder, new System.Net.NetworkCredential(web_directory_bin.Username, web_directory_bin.Password)))
            {
                if (!Directory.Exists(reportDirectory))
                    Directory.CreateDirectory(reportDirectory);
            }
            string reportFileName = ManageReports.GetReportOutputName(SystemReportId);
            string reportFilePath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName, FileOutputExt);
            string reportFullPath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportDirectory, reportFileName, FileOutputExt);

            string[] bullOwners = ReportParameters.Where(x => x.ParamName == "BULL_OWNER").Select(x => x.ParamValue).First().Split(',').ToArray();
            string DateFrom = ReportParameters.Where(x => x.ParamName == "DATE_FROM").Select(x => x.ParamValue).First();
            string DateTo = ReportParameters.Where(x => x.ParamName == "DATE_TO").Select(x => x.ParamValue).First();

            spreedSheetDocument = SpreadsheetDocument.Create(reportFullPath, SpreadsheetDocumentType.Workbook, true);
            spreedSheetDocument.AddWorkbookPart();
            spreedSheetDocument.WorkbookPart.Workbook = new Workbook(new BookViews(new WorkbookView()));
            spreedSheetDocument.WorkbookPart.Workbook.Sheets = new Sheets();
            WorkbookStylesPart stylesPart = spreedSheetDocument.WorkbookPart.AddNewPart<WorkbookStylesPart>();
            stylesPart.Stylesheet = GenerateStyleSheet();
            stylesPart.Stylesheet.Save();
            int curSheetIdx = 1;

            // Get data
            foreach (string bullOwner in bullOwners)
            {
                DataTable ownerDt = DataReaderUtilities.GetData(DBReference.ConnStr_DV,
                    string.Format(@"EXEC report.usp_abv_report_nasis_bull @BULL_OWNER = '{0}'
                                                                ,@DATE_FROM = '{1}'
                                                                ,@DATE_TO = '{2}'", bullOwner, DateFrom, DateTo)).Tables[0];

                Worksheet sheet = AddWorkSheet(bullOwner, curSheetIdx);
                curRowIdx = 1;
                var ptFlag_G = ownerDt.Select(@"REF_PT_CODE = 'G'");
                var ptFlag_notG = ownerDt.Select(@"REF_PT_CODE <> 'G'");

                // REF_PT_CODE <> 'G'
                AppendSectionHeader(sheet, false, bullOwner, DateFrom, DateTo);
                AppendEmptyRow(sheet);
                AppendDataHeader(sheet);
                if (ptFlag_notG.Count() > 0)
                    AppendData(sheet, ptFlag_notG);

                // REF_PT_CODE = 'G'
                AppendEmptyRow(sheet);
                AppendSectionHeader(sheet, true, bullOwner, DateFrom, DateTo);
                AppendEmptyRow(sheet);
                AppendDataHeader(sheet);
                if (ptFlag_G.Count() > 0)
                    AppendData(sheet, ptFlag_G);

                SaveWorksheet(sheet);
                curSheetIdx++;
            }
            ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
            Dispose();
        }

        public void GenerateReport(int rptInstanceId, int sessionId)
        {
            Requestor = ManageReports.GetRequestor(rptInstanceId);
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            DateTime reportTime = DateTime.Now;

            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportTime.Ticks.ToString());
            SharedGNetworkAccess web_directory_bin = new SharedGNetworkAccess("WEB_DIRECTORY_BIN");
            using (new NetworkConnection(web_directory_bin.RootFolder, new System.Net.NetworkCredential(web_directory_bin.Username, web_directory_bin.Password)))
            {
                if (!Directory.Exists(reportDirectory))
                    Directory.CreateDirectory(reportDirectory);
            }
            string reportFileName = ManageReports.GetReportOutputName(SystemReportId);
            string reportFilePath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName, FileOutputExt);
            string reportFullPath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportDirectory, reportFileName, FileOutputExt);

            string[] bullOwners = ReportParameters.Where(x => x.ParamName == "BULL_OWNER").Select(x => x.ParamValue).First().Split(',').ToArray();
            string DateFrom = ReportParameters.Where(x => x.ParamName == "DATE_FROM").Select(x => x.ParamValue).First();
            string DateTo = ReportParameters.Where(x => x.ParamName == "DATE_TO").Select(x => x.ParamValue).First();

            spreedSheetDocument = SpreadsheetDocument.Create(reportFullPath, SpreadsheetDocumentType.Workbook, true);
            spreedSheetDocument.AddWorkbookPart();
            spreedSheetDocument.WorkbookPart.Workbook = new Workbook(new BookViews(new WorkbookView()));
            spreedSheetDocument.WorkbookPart.Workbook.Sheets = new Sheets();
            WorkbookStylesPart stylesPart = spreedSheetDocument.WorkbookPart.AddNewPart<WorkbookStylesPart>();
            stylesPart.Stylesheet = GenerateStyleSheet();
            stylesPart.Stylesheet.Save();
            int curSheetIdx = 1;

            // Get data
            foreach (string bullOwner in bullOwners)
            {
                DataTable ownerDt = DataReaderUtilities.GetData(DBReference.ConnStr_DV,
                    string.Format(@"EXEC report.usp_abv_report_nasis_bull @BULL_OWNER = '{0}'
                                                                ,@DATE_FROM = '{1}'
                                                                ,@DATE_TO = '{2}'
                                                                ,@sessionId = '{3}'", bullOwner, DateFrom, DateTo, sessionId)).Tables[0];

                Worksheet sheet = AddWorkSheet(bullOwner, curSheetIdx);
                curRowIdx = 1;
                var ptFlag_G = ownerDt.Select(@"REF_PT_CODE = 'G'");
                var ptFlag_notG = ownerDt.Select(@"REF_PT_CODE <> 'G'");

                // REF_PT_CODE <> 'G'
                AppendSectionHeader(sheet, false, bullOwner, DateFrom, DateTo);
                AppendEmptyRow(sheet);
                AppendDataHeader(sheet);
                if (ptFlag_notG.Count() > 0)
                    AppendData(sheet, ptFlag_notG);

                // REF_PT_CODE = 'G'
                AppendEmptyRow(sheet);
                AppendSectionHeader(sheet, true, bullOwner, DateFrom, DateTo);
                AppendEmptyRow(sheet);
                AppendDataHeader(sheet);
                if (ptFlag_G.Count() > 0)
                    AppendData(sheet, ptFlag_G);

                SaveWorksheet(sheet);
                curSheetIdx++;
            }
            ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
            Dispose();
        }

        #region Functions
        public Worksheet AddWorkSheet(string workSheetName, int sheetId)
        {
            WorksheetPart workSheetPart = spreedSheetDocument.WorkbookPart.AddNewPart<WorksheetPart>();
            workSheetPart.Worksheet = new Worksheet(new SheetViews(new SheetView() { WorkbookViewId = 0, ShowGridLines = new BooleanValue(false) }));

            Columns columns = new Columns();

            columns.Append(new Column() { Min = 1, Max = 1, Width = 10, CustomWidth = true });
            columns.Append(new Column() { Min = 2, Max = 11, Width = 16, CustomWidth = true });
            columns.Append(new Column() { Min = 12, Max = 13, Width = 10, CustomWidth = true });

            workSheetPart.Worksheet.Append(columns);
            workSheetPart.Worksheet.AppendChild(new SheetData());

            spreedSheetDocument.WorkbookPart.Workbook.Sheets.AppendChild(new Sheet()
            {
                Id = spreedSheetDocument.WorkbookPart.GetIdOfPart(workSheetPart),
                SheetId = Convert.ToUInt32(sheetId),
                Name = workSheetName
            });


            return workSheetPart.Worksheet;
        }

        public void SaveWorksheet(Worksheet workSheet)
        {
            workSheet.Save();
            spreedSheetDocument.WorkbookPart.Workbook.Save();
        }

        public void AppendDataHeader(Worksheet workSheet)
        {
            string[] dataHeader = new string[] {
                "",
                "Registration Date",
                "Breed",
                "National Id",
                "Nasis Bull Id",
                "Name",
                "Date of Birth",
                "Sire National Id",
                "Dam National Id",
                "MGS National Id",
                "Registration Type",
                "Source",
                "PT Flag"
            };
            
            Row headerRow = new Row();
            int headerRowIdx = this.curRowIdx;
            int colIdx = 0;

            foreach (string header in dataHeader)
            {
                AppendTextToRowWithBold(headerRow, new string[] { header }, headerRowIdx, colIdx, 1);
                colIdx += 1;
            }
            
            SheetData sheetData = workSheet.Elements<SheetData>().First();
            sheetData.AppendChild(headerRow);            
            this.curRowIdx += 1;
        }

        public void AppendData(Worksheet workSheet, DataRow[] drs)
        {
            foreach (DataRow dr in drs)
            {
                Row headerRow = new Row();
                int headerRowIdx = this.curRowIdx;
                int colIdx = 1;
                AppendTextToRow(headerRow, new string[0], headerRowIdx, 0);
                foreach (string value in dr.ItemArray)
                {
                    AppendTextToRow(headerRow, new string[] { value }, headerRowIdx, colIdx);
                    colIdx += 1;
                }

                // Append row to sheetdata
                SheetData sheetData = workSheet.Elements<SheetData>().First();
                sheetData.AppendChild(headerRow);

                // Update index Row
                this.curRowIdx += 1;
            }
        }

        public void AppendSectionHeader(Worksheet workSheet, bool ptFlag, string bullOwner, string dateFrom, string dateTo)
        {
            // Get header list
            string sectionHeader = string.Format("{0}Bulls Registered for {1} between {2} and {3}",
                                                ptFlag ? "Genomic " : "",
                                                bullOwner,
                                                String.Format("{0:d MMM yyyy}", Convert.ToDateTime(dateFrom)),
                                                String.Format("{0:d MMM yyyy}", Convert.ToDateTime(dateTo)));
            
            // Init rows and mergeCells
            Row headerRow = new Row();
            int headerRowIdx = this.curRowIdx;
            int colIdx = 0;

            AppendTextToRowWithBold(headerRow, new string[] { sectionHeader }, headerRowIdx, colIdx, 3);

            // Append row to sheetdata
            SheetData sheetData = workSheet.Elements<SheetData>().First();
            sheetData.AppendChild(headerRow);

            // Update index Row
            this.curRowIdx += 1;
        }

        public void AppendEmptyRow(Worksheet workSheet)
        {
            Row headerRow = new Row();
            int headerRowIdx = this.curRowIdx;
            int colIdx = 0;

            AppendTextToRow(headerRow, new string[0], headerRowIdx, colIdx);
            SheetData sheetData = workSheet.Elements<SheetData>().First();
            sheetData.AppendChild(headerRow);
            this.curRowIdx += 1;
        }

        private void AppendTextToRow(Row row, string[] values, int idxRow, int idxCol)
        {
            foreach (string value in values)
            {
                Cell cell = new Cell();
                cell.DataType = CellValues.String;
                cell.CellReference = GetColumnName(idxRow, idxCol++);
                cell.CellValue = new CellValue(value);

                row.AppendChild(cell);
            }
        }

        private void AppendTextToRowWithBold(Row row, string[] values, int idxRow, int idxCol, int styleIndex)
        {
            foreach (string value in values)
            {
                Cell cell = new Cell();
                cell.DataType = CellValues.String;
                cell.CellReference = GetColumnName(idxRow, idxCol++);
                cell.CellValue = new CellValue(value);
                cell.StyleIndex = Convert.ToUInt32(styleIndex);

                row.AppendChild(cell);
            }
        }

        private static string GetColumnName(int indexRow, int indexColumn)
        {
            string columnName = "";
            char achar;
            int mod;

            // Get Column name
            while (true)
            {
                mod = (indexColumn % 26) + 65;
                indexColumn = (int)(indexColumn / 26);
                achar = (char)mod;
                columnName = achar + columnName;
                if (indexColumn > 0) indexColumn--;
                else if (indexColumn == 0) break;
            }

            return columnName + indexRow;
        }

        public void Dispose()
        {
            spreedSheetDocument.Dispose();
            spreedSheetDocument = null;
        }

        private Stylesheet GenerateStyleSheet()
        {
            return new Stylesheet(
                new Fonts(
                    new Font(                                                               // Index 0 - The default font.
                        new FontSize() { Val = 11 },
                        new Color() { Rgb = new HexBinaryValue() { Value = "000000" } },
                        new FontName() { Val = "Calibri" }),
                    new Font(                                                               // Index 1 - The bold font.
                        new Bold(),
                        new FontSize() { Val = 11 },
                        new Color() { Rgb = new HexBinaryValue() { Value = "000000" } },
                        new FontName() { Val = "Calibri" }),
                    new Font(                                                               // Index 2 - The Italic font.
                        new Italic(),
                        new FontSize() { Val = 11 },
                        new Color() { Rgb = new HexBinaryValue() { Value = "000000" } },
                        new FontName() { Val = "Calibri" }),
                    new Font(                                                               // Index 3 - The default font. with 16 size
                        new Bold(),
                        new FontSize() { Val = 16 },
                        new Color() { Rgb = new HexBinaryValue() { Value = "000000" } },
                        new FontName() { Val = "Calibri" })
                ),
                new Fills(
                    new Fill(                                                           // Index 0 - The default fill.
                        new PatternFill() { PatternType = PatternValues.None }),
                    new Fill(                                                           // Index 1 - The default fill of gray 125 (required)
                        new PatternFill() { PatternType = PatternValues.Gray125 }),
                    new Fill(                                                           // Index 2 - The yellow fill.
                        new PatternFill(
                            new ForegroundColor() { Rgb = new HexBinaryValue() { Value = "FFFFFF00" } }
                        )
                        { PatternType = PatternValues.Solid })
                ),
                new Borders(
                    new Border(                                                         // Index 0 - The default border.
                        new LeftBorder(),
                        new RightBorder(),
                        new TopBorder(),
                        new BottomBorder(),
                        new DiagonalBorder()),
                    new Border(                                                         // Index 1 - Applies a Left, Right, Top, Bottom border to a cell
                        new LeftBorder(
                            new Color() { Auto = true }
                        )
                        { Style = BorderStyleValues.Thin },
                        new RightBorder(
                            new Color() { Auto = true }
                        )
                        { Style = BorderStyleValues.Thin },
                        new TopBorder(
                            new Color() { Auto = true }
                        )
                        { Style = BorderStyleValues.Thin },
                        new BottomBorder(
                            new Color() { Auto = true }
                        )
                        { Style = BorderStyleValues.Thin },
                        new DiagonalBorder())
                ),
                new CellFormats(
                    new CellFormat() { FontId = 0, FillId = 0, BorderId = 0 },                          // Index 0 - The default cell style.  If a cell does not have a style index applied it will use this style combination instead
                    new CellFormat() { FontId = 1, FillId = 0, BorderId = 0, ApplyFont = true },       // Index 1 - Bold 
                    new CellFormat() { FontId = 2, FillId = 0, BorderId = 0, ApplyFont = true },       // Index 2 - Italic
                    new CellFormat() { FontId = 3, FillId = 0, BorderId = 0, ApplyFont = true },       // Index 3 - Bold, 16 font size
                    new CellFormat() { FontId = 0, FillId = 2, BorderId = 0, ApplyFill = true },       // Index 4 - Yellow Fill
                    new CellFormat(                                                                   // Index 5 - Alignment
                        new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center }
                    )
                    { FontId = 0, FillId = 0, BorderId = 0, ApplyAlignment = true },
                    new CellFormat() { FontId = 0, FillId = 0, BorderId = 1, ApplyBorder = true }      // Index 6 - Border
                )
            );
        }
        
        #endregion
    }
}
