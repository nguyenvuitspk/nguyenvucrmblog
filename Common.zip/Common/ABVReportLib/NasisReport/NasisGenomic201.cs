﻿using DataReaderUtilsLib;
using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ABVReportLib
{
    public class NasisGenomic201 : ABVReport
    {
        private string xmlSearchFields = string.Empty;
        private const string FILE_TYPE = "DIF_201";
        private const string SEARCH_FIELDCONDITION_PATTERN = "</FieldConditions";
        private const string MULTIPLE_SEARCH_FIELDCONDITION_PATTERN = "</TextSearchRegrexs>";
        private const string XML_FULL_FIELD_CONDITION_FORMAT = "<FieldConditions><FieldCondition FieldName =\"{0}\" Value=\"{1}\"/></FieldConditions>";
        private const string XML_FIELD_CONDITION_FORMAT = "<FieldCondition FieldName =\"{0}\" Value=\"{1}\"/>";

        public NasisGenomic201() : base("NASIS_GEN_SCREENING_201")
        {
            FileOutputExt = "dif";
        }
        
        public override void GenerateReport(int rptInstanceId)
        {
            // Report file info
            Requestor = ManageReports.GetRequestor(rptInstanceId);
            DateTime reportTime = DateTime.Now;

            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportTime.Ticks.ToString());
            if (!Directory.Exists(reportDirectory))
                Directory.CreateDirectory(reportDirectory);
            string reportFileName = ManageReports.GetReportOutputName(SystemReportId);
            string reportFilePath = string.Format(ABVReportConstant.DIF_REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName);
            string reportFullPath = string.Format(ABVReportConstant.DIF_REPORT_DIRECTORY_FORMAT, reportDirectory, reportFileName);

            // Get parameters
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            string activeRunId = ManageReports.GetActiveRunId(ReportDBConnString);
            xmlSearchFields = ReportParameters.Where(x => x.ParamName == "XML_SEARCH_FIELDS").Select(x => x.ParamValue).First();

            if(xmlSearchFields.Contains(MULTIPLE_SEARCH_FIELDCONDITION_PATTERN))
                xmlSearchFields = xmlSearchFields.Insert(0, string.Format(XML_FULL_FIELD_CONDITION_FORMAT, "RUN_ID", activeRunId));
            else
                xmlSearchFields = xmlSearchFields.Insert(xmlSearchFields.LastIndexOf(SEARCH_FIELDCONDITION_PATTERN), string.Format(XML_FIELD_CONDITION_FORMAT, "RUN_ID", activeRunId));

            // Export file
            System.Data.DataSet rptData = null;
            if (xmlSearchFields.Length > 0)
                rptData = DataReaderUtilities.GetData(ReportDBConnString, string.Format(@"EXEC dbo.wsp_EXPORT_FILE @searchFields = '{0}', @forType = '{1}'", xmlSearchFields, FILE_TYPE));

            string xmlTemplatePath = ManageReports.GetPathToTemplateFile();
            string maskPath = string.Format(@"{0}\{1}.xml", xmlTemplatePath, "BV_REP_DIF_201");
            FileComposer.ExportDIFFile(maskPath, rptData.Tables[0], reportFullPath);

            // remove file extension
            reportFileName = reportFileName.Substring(0, reportFileName.Length - 4);
            ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
        }

    }
}
