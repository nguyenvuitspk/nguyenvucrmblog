﻿using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABVReportLib.PTReports_v2
{
    public class PTReports_v2 : SSRSReport
    {
        #region Atributes
        private string reportName;
        private bool? isMultipleDataset;
        private Guid? ptRequestId;
        private Guid? ptServiceId;
        private int systemReportId;
        private string requestor;
        private CommonPtReports commonRpt;
        private IncomePtReports icomeRpt;
        #endregion


        #region Properties
        protected string ReportName
        {
            get
            {
                return reportName;
            }
            set
            {

            }
        }

        protected bool? IsMultipleDataset
        {
            get
            {
                return isMultipleDataset;
            }
            set
            {

            }
        }

        protected Guid? Request
        {
            get
            {
                return ptRequestId;
            }
            set
            {

            }
        }

        protected Guid? Service
        {
            get
            {
                return ptServiceId;
            }
            set
            {

            }
        }

        //protected string Requestor
        //{
        //    get
        //    {
        //        return requestor;
        //    }
        //    set
        //    {

        //    }
        //}

        public static string Requestor;


        protected int SystemReportId
        {
            get
            {
                return systemReportId;
            }
        }

        protected CommonPtReports CommonReport
        {
            get
            {
                return commonRpt;
            }
        }

        protected IncomePtReports IncomeReport
        {
            get
            {
                return icomeRpt;
            }
        }
        #endregion

        #region Contructors
        public PTReports_v2(string reportName, bool? isMultiple = null, Guid? requestId = null, Guid? serviceId = null)
        {
            //commonRpt = new CommonPtReports(reportName, isMultiple, requestId, serviceId);
            //icomeRpt = new IncomePtReports(reportName);
            ReportServer server = ManageReports.GetReportServerInformation();
            base.ReportServiceURL = server.ReportServiceURL;
            base.ReportServiceUsername = server.ReportServiceUsername;
            base.ReportServicePassword = server.ReportServicePassword;

            base.ProjectName = "ProgenyTestReport";
            base.ReportID = reportName;
            systemReportId = ManageReports.GetSystemReportId(reportName);

            isMultipleDataset = isMultiple;
            ptServiceId = serviceId;
            ptRequestId = requestId;
        }
        #endregion

        #region Main Methods
        public int SubmitPtReport(string requestor, List<ReportParameter> parameters)
        {
            //this.requestor = requestor;
            Requestor = requestor;
            return ManageReports.SubmitReport(SystemReportId, Requestor, parameters);
        }

        public string[] GeneratePtReports(int rptInstanceId)
        {
            string[] outputFilePaths = null;
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            string[] fileType = PTManageReportsV2.GetFileTypeByReport(ReportID);

            if (Request.HasValue && Service.HasValue)
            {
                commonRpt = new CommonPtReports(ReportID, isMultipleDataset, ptRequestId, ptServiceId);
                outputFilePaths = CommonReport.GenerateReport(ReportParameters, rptInstanceId, fileType);
            }
            else if (!Request.HasValue && !Service.HasValue)
            {
                icomeRpt = new IncomePtReports(ReportID);
                outputFilePaths = IncomeReport.GenerateReport(ReportParameters, rptInstanceId, fileType);
            }
            
            return outputFilePaths;
        }
        #endregion

        #region Utilities Methods
        private void SaveRptInformations(int rptInstanceId, string[] outputFilePaths)
        {
            foreach (var fPath in outputFilePaths)
            {
                string fileName = PTReportHelpers.GetFileName(fPath);
                if (!string.IsNullOrWhiteSpace(fileName))
                {
                    PTManageReportsV2.SaveRptFiles(rptInstanceId, fileName, fPath, Requestor);
                }
            }
        }
        #endregion
    }
}
