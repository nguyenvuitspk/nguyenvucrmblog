﻿using DataReaderUtilsLib;
using SQLUtilsLib;
using System.Data;
using System.Data.SqlClient;

namespace ABVReportLib.PTReports_v2
{
    public class PTManageReportsV2
    {
        public static string GetDynamicReportName(string ptTeamId, bool? GetOwnerCode = null)
        {
            string rptName;
            if (GetOwnerCode.HasValue && GetOwnerCode.Value)
            {
                var ownerCode = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                                   string.Format(@"SELECT [ho].[BK_OWNER_CODE]
                                                    FROM [dbo].[HUB_PT_TEAMS] ptt
                                                    INNER JOIN [dbo].[LNK_PT_TEAM_OWNERS] lpto ON [lpto].[PK_PT_TEAM_ID] = [ptt].[PK_PT_TEAM_ID]
                                                    INNER JOIN [dbo].[HUB_OWNERS] ho ON [ho].[PK_OWNER_ID] = [lpto].[PK_OWNER_ID]
                                                    WHERE [ptt].[PK_PT_TEAM_ID] = '{0}'", ptTeamId));
                rptName = ownerCode?.ToString();
            }
            else
            {
                var ptTeamName = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                                   string.Format(@"SELECT [BK_PT_TEAM_NAME ]
                                                    FROM [dbo].[HUB_PT_TEAMS]
                                                    WHERE [PK_PT_TEAM_ID] = '{0}'", ptTeamId));
                rptName = ptTeamName?.ToString();
            }

            return rptName;
        }

        public static string GetCategorytRptByRpt(string rptName)
        {
            string ctgRPtName = null;
            if (!string.IsNullOrWhiteSpace(rptName))
            {
                var _ctgRpt = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                                   string.Format(@"SELECT TOP 1 [rc].[NAME]
                                                    FROM [report].[REPORTS] rpt
                                                    INNER JOIN [report].[REPORT_CATEGORY_MAPPING] rcm ON [rcm].[REPORT_ID] = [rpt].[REPORT_ID]
                                                    INNER JOIN [report].[REPORT_CATEGORIES] rc ON [rc].[REPORT_CATEGORY_ID] = [rcm].[REPORT_CATEGORY_ID]
                                                    WHERE rpt.NAME ='{0}'
                                                    GROUP BY rc.NAME", rptName));
                ctgRPtName = _ctgRpt?.ToString();
            }

            return ctgRPtName?.ToUpper();
        }

        public static void SaveRptByStoreProcedure(int rptInstanceId, string fileName, string filePath, string owner)
        {
            DataSet datasets = new DataSet();
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(DBReference.ConnStr_DV);
            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                connection.Open();
                // Configure the SqlCommand and SqlParameter. 
                SqlCommand cmd = new SqlCommand("[dbo].[wsp_pt_log_file_instance]", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter fileNameParam = cmd.Parameters.AddWithValue("@FILE_NAME", fileName);
                fileNameParam.SqlDbType = SqlDbType.VarChar;

                SqlParameter filePathParam = cmd.Parameters.AddWithValue("@FILE_PATH", filePath);
                filePathParam.SqlDbType = SqlDbType.VarChar;

                SqlParameter ownerParam = cmd.Parameters.AddWithValue("@OWNER", owner);
                ownerParam.SqlDbType = SqlDbType.VarChar;

                SqlParameter rptInstanceParam = cmd.Parameters.AddWithValue("@REPORT_INSTANCE_ID", rptInstanceId);
                rptInstanceParam.SqlDbType = SqlDbType.Int;

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                adapter.SelectCommand.CommandTimeout = 0;
                adapter.Fill(datasets);

                connection.Close();
            }
        }

        public static void SaveRptBySqlQuery()
        {

        }

        public static string[] GetFileTypeByReport(string rptName)
        {
            string[] fileType = null;
            if (!string.IsNullOrWhiteSpace(rptName))
            {
                var _ctgRpt = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                                   string.Format(@" SELECT SUPPORTED_FILE
                                                    FROM report.REPORTS
                                                    WHERE NAME = '{0}'", rptName));
                fileType = _ctgRpt?.ToString().Split(';');
            }

            return fileType;
        }
        public static void SaveRptFiles(int rptInstanceId, string fileName, string filePath, string owner)
        {
            DataSet datasets = new DataSet();
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(DBReference.ConnStr_DV);
            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                connection.Open();
                // Configure the SqlCommand and SqlParameter. 
                SqlCommand cmd = new SqlCommand("[dbo].[wsp_pt_log_file_instance]", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter fileNameParam = cmd.Parameters.AddWithValue("@FILE_NAME", fileName);
                fileNameParam.SqlDbType = SqlDbType.VarChar;

                SqlParameter filePathParam = cmd.Parameters.AddWithValue("@FILE_PATH", filePath);
                filePathParam.SqlDbType = SqlDbType.VarChar;

                SqlParameter ownerParam = cmd.Parameters.AddWithValue("@OWNER", owner);
                ownerParam.SqlDbType = SqlDbType.VarChar;

                SqlParameter rptInstanceParam = cmd.Parameters.AddWithValue("@REPORT_INSTANCE_ID", rptInstanceId);
                rptInstanceParam.SqlDbType = SqlDbType.Int;

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                adapter.SelectCommand.CommandTimeout = 0;
                adapter.Fill(datasets);

                connection.Close();
            }
        }
    }
}
