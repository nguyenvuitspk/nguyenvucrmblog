﻿using ABVReportLib.PTReports_v2;
using DataReaderUtilsLib;
using SQLUtilsLib;
using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ABVReportLib.PTReports_v2
{
    public class PTReportHelpers
    {
        
        public static string GetFileName(string path)
        {
            string fName = null;
            if (!string.IsNullOrWhiteSpace(path))
            {
                fName = Path.GetFileName(path);
            }

            return fName;
        }

        public static string[] ExtractParams(List<ReportParameter> listParams)
        {
            string[] ptTeamRptParams = null;

            if (listParams != null && listParams.Count > 0)
            {
                //ptTeamRptParams = listParams.Select(rpr => rpr.ParamValue).LastOrDefault()?.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                ptTeamRptParams = listParams.ElementAt(2).ParamValue.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            }


            return ptTeamRptParams;
        }

        public static bool CheckService(string serviceId, string serviceName)
        {
            string serviceCode = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV, string.Format("SELECT BK_PT_SERVICE_CODE FROM dbo.HUB_PT_SERVICES WHERE PK_PT_SERVICE_ID = '{0}'", serviceId)).ToString();
            return serviceName.Equals(serviceCode, StringComparison.OrdinalIgnoreCase);
        }

        public static string GetConnectionString()
        {
            string reportDBConnString = DBReference.ConnStr_DV;
            return reportDBConnString;
        }

        public static string CreateFolder4PTReport(string rptParam, string requestID, string reportID)
        {
            string ptRptDirecPath = string.Empty;
            string rootPath = ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY);
           
            if (!string.IsNullOrEmpty(requestID))
            {
                string _ctgRpt = PTManageReportsV2.GetCategorytRptByRpt(reportID);
                ptRptDirecPath = string.Format(PTReportConstantsV2.PT_RPT_DIRECTORY_BIN, rootPath, requestID, _ctgRpt ?? "default", rptParam);
            }
            else
            {
                ptRptDirecPath = string.Format(PTReportConstantsV2.PT_INCOME_RPT_DIRECTORY_BIN, rootPath);
            }
            return ptRptDirecPath;
        }

       
    }
}
