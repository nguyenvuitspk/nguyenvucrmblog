﻿using ABVReportLib.PTReports_v2;
using DataReaderUtilsLib;
using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Diagnostics;

namespace ABVReportLib.PTReports_v2
{
    public class CommonPtReports : PTReports_v2
    {

        #region Constructor
        public CommonPtReports(string reportName, bool? isMultiple, Guid? requestId, Guid? serviceId) : base(reportName, isMultiple, requestId, serviceId)
        {
        }
        #endregion

        #region Main Logic 2 Generate Report
        public string[] GenerateReport(List<ReportParameter> listParams, int rptInstanceId, string[] fileTypes)
        {
            string[] filePaths = null;
            List<string> listFilePath = new List<string>();
            string serviceId = listParams.Where(_ => _.ParamName.Equals("PT_SERVICE_ID")).FirstOrDefault().ParamValue;
            if (PTReportHelpers.CheckService(serviceId, PTReportConstantsV2.DAUGHTER_PROGRESS_SERVICE))
            {
                string[] rptParams = PTReportHelpers.ExtractParams(listParams);
                foreach (var rptParam in rptParams)
                {
                    string destOutputRpt = PTReportHelpers.CreateFolder4PTReport(rptParam, Request.ToString(), ReportID.ToString());
                    string masRptFileName = ManageReports.GetReportOutputName(SystemReportId);
                    var _listFilePath = GeneratePTReportFileType(rptInstanceId, fileTypes, rptParam, destOutputRpt, masRptFileName);

                    listFilePath.AddRange(_listFilePath);
                }
                filePaths = listFilePath.ToArray();
            }

            if (!PTReportHelpers.CheckService(serviceId, PTReportConstantsV2.DAUGHTER_PROGRESS_SERVICE))
            {
                string destOutputRpt = PTReportHelpers.CreateFolder4PTReport(string.Empty, Request.ToString(), ReportID.ToString()).TrimEnd('\\');
                string masRptFileName = ManageReports.GetReportOutputName(SystemReportId);
                var _listFilePath = GeneratePTReportFileType(rptInstanceId, fileTypes, string.Empty, destOutputRpt, masRptFileName);

                listFilePath.AddRange(_listFilePath);
                filePaths = listFilePath.ToArray();
            }
            return filePaths;
        }
        #endregion

        public List<string> GeneratePTReportFileType(int rptInstanceId, string[] fileTypes, string ptTeamId, string destOutputRpt, string maskFileName)
        {
            List<string> outputFilePaths = new List<string>();
            foreach (var fType in fileTypes)
            {
                string rptFileName = FormatFileName(maskFileName, ptTeamId);

                switch (fType.ToLower())
                {
                    case "dif":
                        var _outputDIFFilePaths = ExportDIF(rptInstanceId, ptTeamId, destOutputRpt, rptFileName);
                        outputFilePaths.AddRange(_outputDIFFilePaths);
                        break;
                    case "pdf":
                        var _outputPDFFilePaths = CallSSRS2ExportRpt(rptInstanceId, ptTeamId, destOutputRpt, rptFileName, ReportFileType.PDF);
                        outputFilePaths.AddRange(_outputPDFFilePaths);
                        break;
                    case "xlsx":
                        var _outputXLSXFilePaths = CallSSRS2ExportRpt(rptInstanceId, ptTeamId, destOutputRpt, rptFileName, ReportFileType.EXCELOPENXML);
                        outputFilePaths.AddRange(_outputXLSXFilePaths);
                        break;
                    default:
                        break;
                }
            }

            SaveRptInformations(rptInstanceId, outputFilePaths);
            return outputFilePaths;
        }

        private string FormatFileName(string maskReportFileName, string ptTeamId)
        {
            string rptFileName;
            if (PTReportConstantsV2.SPECIAL_PATTERNS.ContainsKey(ReportID))
            {
                string today = DateTime.UtcNow.ToString("yyMM");
                string rptName = PTManageReportsV2.GetDynamicReportName(ptTeamId, PTReportConstantsV2.SPECIAL_PATTERNS[ReportID]);
                rptFileName = string.Format(maskReportFileName, rptName ?? ReportID, today);
            }
            // Get report name by Breed
            else if (PTReportConstantsV2.NAME_BY_BREED.Contains(ReportID))
            {
                rptFileName = maskReportFileName;
            }
            // Get report name by DPC
            else if (PTReportConstantsV2.NAME_BY_DPC.Contains(ReportID))
            {
                rptFileName = maskReportFileName;
            }
            else
            {
                var ptTeamName = PTManageReportsV2.GetDynamicReportName(ptTeamId);
                rptFileName = string.Format(maskReportFileName, ptTeamName);
            }
            return rptFileName;
        }

        #region Generate Reports foreach file type
        // DIF
        private List<string> ExportDIF(int rptInstanceId, string ptTeamId, string destOutput, string rptFileName)
        {
            List<string> outputFilePaths = new List<string>();
            if (!IsMultipleDataset.HasValue || IsMultipleDataset.Value.Equals(false))
            {
                var _outputFilePath = GenerateDifReportSingleDs(ptTeamId, destOutput, rptFileName);
                outputFilePaths.Add(_outputFilePath);
            }
            else
            {
                var _outputFilePath = GenerateDifReportMultiple(ptTeamId, destOutput, rptFileName);
                outputFilePaths.AddRange(_outputFilePath);
            }

            return outputFilePaths;
        }

        // Call SSRS to Generate report (EXCEL, PDF)
        private List<string> CallSSRS2ExportRpt(int rptInstanceId, string ptTeamId, string destOutputRpt, string rptFileName, ReportFileType fileType)
        {
            List<string> outputFilePaths = new List<string>();
            string reportFileExt;
            ABVReportConstant.FILE_TYPE_EXTENSIONS.TryGetValue(fileType, out reportFileExt);

            var fullPath2File = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, destOutputRpt, rptFileName, reportFileExt);
            var subReports = ManageReports.GetSubReports(SystemReportId, fileType);

            if (subReports == null || subReports.Count == 0)
            {
                PrepareParams2CallSSRS(ptTeamId);
                var rptFilePath = base.GetReport(fullPath2File, fileType);
                outputFilePaths.Add(rptFilePath);
            }
            else
            {
                // Case export report has multiple sub report
            }

            return outputFilePaths;
        }
        #endregion


        #region Methods
        public int SubmitReport(string requestor, List<ReportParameter> parameters)
        {
            return ManageReports.SubmitReport(SystemReportId, requestor, parameters);
        }

        private string GenerateDifReportSingleDs(string ptTeamId, string destOutputRpt, string reportFileName)
        {
            DataSet rptData = null;
            string outputFilePath = null;

            if (!string.IsNullOrWhiteSpace(ptTeamId))
            {
                var query = string.Format(@"EXEC dbo.usp_{0} @PT_TEAM_ID = '{1}', @PT_REQUEST_ID = '{2}', @PT_SERVICE_ID = '{3}'", ReportID, ptTeamId, Request.ToString(), Service.ToString());
                rptData = DataReaderUtilities.GetData(PTReportHelpers.GetConnectionString(), query);
            }

            if ((rptData != null) && (rptData.Tables.Count > 0))
            {
                outputFilePath = string.Concat(destOutputRpt, @"\", reportFileName);
                string xmlTemplatePath = ManageReports.GetPathToTemplateFile();
                string maskPath = string.Format(@"{0}\{1}.xml", xmlTemplatePath, ReportID);
                FileComposer.ExportDIFFile(maskPath, rptData.Tables[0], outputFilePath);
            }

            return outputFilePath;
        }

        private List<string> GenerateDifReportMultiple(string ptTeamId, string destOutputRpt, string reportFileName)
        {
            List<string> outputFilePaths;

            using (SqlConnection sqlConnection = new SqlConnection(PTReportHelpers.GetConnectionString()))
            {
                DataSet loopValues = new DataSet();
                List<string> param = new List<string>();
                param.Add(ReportID);
                param.Add(Request.ToString());
                param.Add(Service.ToString());
                // Build query to execute SP getting loop values
                string query = string.Format("EXEC dbo.usp_{0}_prepare_data @PT_REQUEST_ID = '{1}',@PT_SERVICE_ID = '{2}'", param.ToArray());
                Debug.WriteLine(query);
                try
                {
                    loopValues = DataReaderUtilities.GetData(sqlConnection, query);
                }
                catch (Exception ex)
                {
                    string queryToDrop = string.Format("DROP TABLE IF EXISTS dbo.{0}", ReportID);
                    DataReaderUtilities.GetData(sqlConnection, queryToDrop);
                }   

                outputFilePaths = ExportDifFilesForMultiple(loopValues, destOutputRpt, reportFileName);
            }

            return outputFilePaths;
        }

        private List<string> ExportDifFilesForMultiple(DataSet loopValues, string destOutputRpt, string reportFileName)
        {
            var outputFilePaths = new List<string>();
            
            using (SqlConnection sqlConnection = new SqlConnection(PTReportHelpers.GetConnectionString()))
            {
                string queryToDrop = string.Format("DROP TABLE IF EXISTS dbo.{0}", ReportID);

                foreach (DataRow loopValue in loopValues.Tables[0].Rows)
                {
                    try
                    {
                        DataSet data = new DataSet();

                        // Build query to execute SP getting loop values
                        string query = string.Format(@"EXEC dbo.usp_{0}_return_data @LOOP_VALUE = '{1}'", ReportID, loopValue.ItemArray[0].ToString());

                        // Get data
                        DataTable datatable = DataReaderUtilities.GetData(sqlConnection, query).Tables[0];

                        // Export file
                        var file = ExportDifFileForMultiple(datatable, loopValue.ItemArray[0].ToString(), destOutputRpt, reportFileName);
                        outputFilePaths.Add(file);
                    }
                    catch (Exception ex)
                    {
                        // Drop data table on error
                        DataReaderUtilities.GetData(sqlConnection, queryToDrop);
                    }
                }

                // Drop data table when done
                DataReaderUtilities.GetData(sqlConnection, queryToDrop);
            }

            return outputFilePaths;
        }

        //private DataTable CreateDataTableWithColumn(SqlDataReader reader)
        //{
        //    var dataTable = new DataTable();
        //    DataTable schemaTable = reader.GetSchemaTable();
        //    if (schemaTable?.Rows != null)
        //    {
        //        foreach (DataRow row in schemaTable.Rows)
        //        {
        //            string colName = row.Field<string>("ColumnName");
        //            Type t = row.Field<Type>("DataType");
        //            dataTable.Columns.Add(colName, t);
        //        }
        //    }

        //    return dataTable;
        //}

        private string ExportDifFileForMultiple(DataTable dataTable, string dpcName, string destOutputRpt, string reportFileName)
        {
            var outputFilePath = string.Concat(destOutputRpt, @"\", string.Format(reportFileName, dpcName));
            string xmlTemplatePath = ManageReports.GetPathToTemplateFile();
            string maskPath = string.Format(@"{0}\{1}.xml", xmlTemplatePath, ReportID);
            FileComposer.ExportDIFFile(maskPath, dataTable, outputFilePath);

            return outputFilePath;
        }

        //private DataRow GetRowForMultiple(SqlDataReader reader, DataTable data)
        //{
        //    DataRow newRow = data.Rows.Add();

        //    foreach (DataColumn col in data.Columns)
        //    {
        //        newRow[col.ColumnName] = reader[col.ColumnName];
        //    }

        //    return newRow;
        //}
        private void PrepareParams2CallSSRS(string ptTeamId)
        {
            ReportParameters = new List<ReportParameter>
            {
                new ReportParameter()
                {
                    ParamName = "PT_TEAM_ID",
                    ParamValue = ptTeamId
                },
                new ReportParameter()
                {
                    ParamName = "PT_REQUEST_ID",
                    ParamValue = Request.ToString() ?? string.Empty
                },
                new ReportParameter()
                {
                    ParamName = "PT_SERVICE_ID",
                    ParamValue = Service.ToString() ?? string.Empty
                }
            };
        }

        private void SaveRptInformations(int rptInstanceId, List<string> outputFilePaths)
        {
            foreach (var fPath in outputFilePaths)
            {
                string fileName = Path.GetFileName(fPath);
                if (!string.IsNullOrWhiteSpace(fileName))
                {
                    PTManageReportsV2.SaveRptFiles(rptInstanceId, fileName, fPath, Requestor);
                }
            }
        }
        #endregion

    }
}