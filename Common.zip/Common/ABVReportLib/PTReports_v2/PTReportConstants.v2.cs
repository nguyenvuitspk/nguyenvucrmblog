﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABVReportLib.PTReports_v2
{
    public class PTReportConstantsV2
    {
        public const string PT_RPT_DIRECTORY_BIN = @"{0}\PT\{1}\{2}\{3}";

        public const string PT_INCOME_RPT_DIRECTORY_BIN = @"{0}\PT\ACCOUNTING";

        public const string WEB_DIRECTORY_BIN = "WEB_DIRECTORY_BIN";

        public const string CONFORMATION_SERVICE = "CONFORMATION";
        public const string WORKABILITY_SERVICE = "WORKABILITY";
        public const string DAUGHTER_PROGRESS_SERVICE = "DAUGHTER_PROGRESS";

        public static readonly string[] NAME_BY_DPC = new string[] { "PT_RPT_008", "PT_RPT_009" };
        public static readonly string[] NAME_BY_BREED = new string[] { "PT_RPT_010", "PT_RPT_011" };

        // Key: Report 
        // Value: Is get By Owner Code
        public static readonly Dictionary<string, bool> SPECIAL_PATTERNS = new Dictionary<string, bool>
        {
            {
                "PT_RPT_006", true
            },
            {
                "PT_RPT_007", false
            }
        };
    }
}
