﻿using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.Linq;
using ABVReportLib.PTReports_v2;
using System.Data;
using DataReaderUtilsLib;
using System.Data.SqlClient;
using System.IO;
using System.Globalization;

namespace ABVReportLib.PTReports_v2
{
    public class IncomePtReports : PTReports_v2
    {

        #region Constructor
        public IncomePtReports(string reportName, bool? isMultiple = default(bool?), Guid? requestId = default(Guid?), Guid? serviceId = default(Guid?)) : base(reportName, isMultiple, requestId, serviceId)
        {
        }
        #endregion

        #region Main Logic 2 Generate Report
        public string[] GenerateReport(List<ReportParameter> listParams, int rptInstanceId, string[] fileTypes)
        {
            string[] filePaths = null;
            List<string> listFilePath = new List<string>();
                
            string destOutputRpt = PTReportHelpers.CreateFolder4PTReport(null, Request.ToString(), ReportID.ToString());
            string masRptFileName = ManageReports.GetReportOutputName(SystemReportId);
            var _listFilePath = GeneratePTReportFileType(rptInstanceId, fileTypes, listParams, destOutputRpt, masRptFileName);

            listFilePath.AddRange(_listFilePath);
                
            filePaths = listFilePath.ToArray();
           
            return filePaths;
        }

        public List<string> GeneratePTReportFileType(int rptInstanceId, string[] fileTypes, List<ReportParameter> listParams, string destOutputRpt, string maskFileName)
        {
            List<string> outputFilePaths = new List<string>();
            foreach (var fType in fileTypes)
            {
                string rptFileName = FormatFileName(maskFileName, listParams);

                switch (fType.ToLower())
                {
                    case "xlsx":
                        var _outputXLSXFilePaths = CallSSRS2ExportRpt(rptInstanceId, listParams, destOutputRpt, rptFileName, ReportFileType.EXCELOPENXML);
                        outputFilePaths.AddRange(_outputXLSXFilePaths);
                        break;
                    default:
                        break;
                }
            }
            return outputFilePaths;
        }

        private string FormatFileName(string maskReportFileName, List<ReportParameter> listParams)
        {
            string rptFileName;
            DateTime from_date = DateTime.MinValue, to_date = DateTime.MaxValue;
            if(!string.IsNullOrEmpty(listParams.ElementAt(0).ParamValue.ToString()) && !string.IsNullOrEmpty(listParams.ElementAt(1).ParamValue.ToString()))
            {
                from_date = DateTime.ParseExact(listParams.ElementAt(0).ParamValue.ToString(), "MM/dd/yyyy", new CultureInfo("en-US"));
                to_date = DateTime.ParseExact(listParams.ElementAt(1).ParamValue.ToString(), "MM/dd/yyyy", new CultureInfo("en-US"));
                rptFileName = string.Concat(maskReportFileName, "_", from_date.ToString("yyMMdd"), "_to_", to_date.ToString("yyMMdd"));
            }
            else if (!string.IsNullOrEmpty(listParams.ElementAt(0).ParamValue.ToString()) && string.IsNullOrEmpty(listParams.ElementAt(1).ParamValue.ToString()))
            {
                from_date = DateTime.ParseExact(listParams.ElementAt(0).ParamValue.ToString(), "MM/dd/yyyy", new CultureInfo("en-US"));
                rptFileName = string.Concat(maskReportFileName, "_", from_date.ToString("yyMMdd"));
            }
            else if (!string.IsNullOrEmpty(listParams.ElementAt(1).ParamValue.ToString()) && string.IsNullOrEmpty(listParams.ElementAt(0).ParamValue.ToString()))
            {
                to_date = DateTime.ParseExact(listParams.ElementAt(1).ParamValue.ToString(), "MM/dd/yyyy", new CultureInfo("en-US"));
                rptFileName = string.Concat(maskReportFileName, "_to_", to_date.ToString("yyMMdd"));
            }
            else
            {
                rptFileName = maskReportFileName;
            }
                
            return rptFileName;
        }
        #endregion

        #region Generate Reports foreach file type
        // Call SSRS to Generate report (EXCEL, PDF)
        private List<string> CallSSRS2ExportRpt(int rptInstanceId, List<ReportParameter> listParams, string destOutputRpt, string rptFileName, ReportFileType fileType)
        {
            List<string> outputFilePaths = new List<string>();
            string reportFileExt;
            ABVReportConstant.FILE_TYPE_EXTENSIONS.TryGetValue(fileType, out reportFileExt);

            var fullPath2File = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, destOutputRpt, rptFileName, reportFileExt);
            var subReports = ManageReports.GetSubReports(SystemReportId, fileType);

            if (subReports == null || subReports.Count == 0)
            {
                PrepareParams2CallSSRS(listParams);
                var rptFilePath = base.GetReport(fullPath2File, fileType);
                outputFilePaths.Add(rptFilePath);
            }
            else
            {
                // Case export report has multiple sub report
            }

            return outputFilePaths;
        }
        #endregion


        #region Methods
        public int SubmitReport(string requestor, List<ReportParameter> parameters)
        {
            return ManageReports.SubmitReport(SystemReportId, requestor, parameters);
        }

        private void PrepareParams2CallSSRS(List<ReportParameter> listParams)
        {
            ReportParameters = new List<ReportParameter>
            {
                new ReportParameter()
                {
                    ParamName = "param_DATE_FROM",
                    ParamValue = listParams.ElementAt(0).ParamValue
                },
                new ReportParameter()
                {
                    ParamName = "param_DATE_TO",
                    ParamValue = listParams.ElementAt(1).ParamValue
                }
            };
        }

        private void SaveRptInformations(int rptInstanceId, List<string> outputFilePaths)
        {
            foreach (var fPath in outputFilePaths)
            {
                string fileName = Path.GetFileName(fPath);
                if (!string.IsNullOrWhiteSpace(fileName))
                {
                    PTManageReportsV2.SaveRptFiles(rptInstanceId, fileName, fPath, Requestor);
                }
            }
        }
        #endregion
    }
}
