﻿using System.IO;
using ABVReportLib.Export.FileStructure;
using ABVReportLib.Export.Model;
using ABVReportLib.Export.Model.Excel;
using DocumentFormat.OpenXml.Packaging;

namespace ABVReportLib.Export
{
    public class ExportFactory
    {
        public IWorkbook GetWoorkbook(ExportConfiguration exportConfiguration)
        {
            if (exportConfiguration.ExportModel.NewFile)
                return CreateWoorkbook(exportConfiguration);

            return OpenWoorkbook(exportConfiguration);
        }

        public IWorkbook CreateWoorkbook(ExportConfiguration exportConfiguration)
        {
            if(exportConfiguration is ExcelExportConfiguration)
                return new ExcelWorkbook(exportConfiguration.ExportModel.FilePath);
            if (exportConfiguration is DifExportConfiguration)
                return new DifWorkbook(exportConfiguration.ExportModel.FilePath);

            return null;
        }

        public IWorkbook OpenWoorkbook(ExportConfiguration exportConfiguration)
        {
            if (exportConfiguration is ExcelExportConfiguration)
                return new ExcelWorkbook(exportConfiguration.ExportModel.FilePath, false);
            if (exportConfiguration is DifExportConfiguration)
                return new DifWorkbook(exportConfiguration.ExportModel.FilePath, false);

            return null;
        }

        public IWorksheet GetWoorksheet(ExportConfiguration exportConfiguration, object workSheetPart)
        {
            if (exportConfiguration is ExcelExportConfiguration)
                return new ExcelWorksheet(workSheetPart as WorksheetPart);
            if (exportConfiguration is DifExportConfiguration)
                return new DifWorksheet(workSheetPart as FileStream, exportConfiguration.ExportModel.FormatFilePath);

            return null;
        }

    }
}
