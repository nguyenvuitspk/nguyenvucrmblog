﻿using System.Threading.Tasks;
using ABVReportLib.Export.Model;

namespace ABVReportLib.Export.Process
{
    public class ExcelExport : AExport
    {
        public ExcelExport(ExportConfiguration exportConfiguration): base(exportConfiguration)
        {
        }

        public override void ExportFromDataReader()
        {
            using (var exportDataSource = new ExcelExportDataReader(base.ExportConfiguration))
                exportDataSource.LoadIntoFile();
        }

        public override async Task ExportFromDataReaderAsync()
        {
            using (var exportDataSource = new ExportDataReaderAsync(base.ExportConfiguration))
            {
                await exportDataSource.LoadIntoFileAsync();
            }
        }
    }
}