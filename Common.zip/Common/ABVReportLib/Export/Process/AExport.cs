﻿using ABVReportLib.Export.Model;
using System;
using System.IO;
using System.Threading.Tasks;

namespace ABVReportLib.Export.Process
{
    public abstract class AExport : IExport
    {
        protected readonly ExportConfiguration ExportConfiguration;

        protected AExport(ExportConfiguration exportConfiguration)
        {
            ExportConfiguration = exportConfiguration;
            PrepareEnviroment();
        }

        private void PrepareEnviroment()
        {
            // create file path
            if (!Directory.Exists(Path.GetDirectoryName(ExportConfiguration.ExportModel.FilePath)))
                Directory.CreateDirectory(Path.GetDirectoryName(ExportConfiguration.ExportModel.FilePath));
        }

        public virtual void ExportFromDataReader()
        {
            throw new NotImplementedException();
        }

        public virtual Task ExportFromDataReaderAsync()
        {
            throw new NotImplementedException();
        }
    }
}
