﻿using ABVReportLib.Export.Model;

namespace ABVReportLib.Export.Process
{
    public class DifExport : AExport
    {
        public DifExport(ExportConfiguration exportConfiguration): base(exportConfiguration)
        {
        }

        public override void ExportFromDataReader()
        {
            using (var exportDataSource = new DifExportDataReader(base.ExportConfiguration))
                exportDataSource.LoadIntoFile();
        }
        
    }
}