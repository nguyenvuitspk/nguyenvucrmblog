﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ABVReportLib.Export.Model;
using ABVReportLib.Export.Model.Excel;
using ABVReportLib.Export.Process;
using DataReaderUtilsLib;
using SSRSReportLib;

namespace ABVReportLib.Export
{
    public class AbvExportReport
    {
        #region code
        //public void ReportWithoutTemplate(string finalOutputFile, string outputName, string fileXml, string forType, string reportName, string reportDbConnString, List<ReportParameter> reportParameters, string reportId)
        //{
        //    //// Export excel file with out template
        //    //string xmlTemplatePath = ManageReports.GetPathToTemplateFile();
        //    //string destFilePath = $@"{xmlTemplatePath}/{reportName}.xml";

        //    //var query = $@"EXEC dbo.wsp_EXPORT_FILE @searchFields = '{fileXml}', @forType = '{forType}'";
        //    ////System.Data.DataTable rptData;

        //    //if (fileXml.Length > 0)
        //    //{
        //    //    var config = new ExcelExportConfiguration()
        //    //    {
        //    //        ConnectionString = reportDbConnString,
        //    //        SqlQuery = query,
        //    //        ExportModel = new ExportModel()
        //    //        {
        //    //            FilePath = destFilePath,
        //    //            SheetName = ""
        //    //        }
        //    //    };

        //    //    new ExcelExport(config).ExportFromDataReader();
        //    //}

        //        //new ExportHandle().Export(new ExcelExportConfiguration()
        //        //{
        //        //    ConnectionString = reportDbConnString,
        //        //    RowPerSheet = 1048576,
        //        //    SqlQuery = query
        //        //}, new ExportModel()
        //        //{
        //        //    FileName = destFilePath
        //        //});


        //}

        ////string xmlTemplatePath = ManageReports.GetPathToTemplateFile();
        ////string destFilePath = $@"{xmlTemplatePath}/{reportName}.xml";

        ////var query = $@"EXEC dbo.wsp_EXPORT_FILE @searchFields = '{fileXml}', @forType = '{forType}'";
        ////System.Data.DataTable rptData;
        ////if (fileXml.Length > 0)
        //////rptData = DataReaderUtilities.GetData(reportDbConnString,
        //////        query)
        //////        .Tables[0];
        ////else
        ////    rptData = ManageReports.GetReportWithoutTemplate(reportDbConnString, reportParameters, reportId);

        ////if (rptData.Rows.Count > 0)
        ////{
        ////    if (File.Exists(destFilePath))
        ////    {
        ////        FileComposer.ExportExcelFileWithOutTemplate(rptData, finalOutputFile, outputName,
        ////            new FileStream(destFilePath, FileMode.Open, FileAccess.Read));
        ////    }
        ////    else
        ////    {
        ////        FileComposer.ExportExcelFileWithOutTemplate(rptData, finalOutputFile, outputName);
        ////    }
        ////}
        ////else
        ////{
        ////    FileComposer.ExportExcelForNoData(finalOutputFile);
        ////}


        ////public void ReportWithoutTemplateV2(string finalOutputFile, string outputName, string fileXml, string forType, string reportName, string reportDbConnString, List<ReportParameter> reportParameters, string reportId)
        ////{
        ////    // Export excel file with out template
        ////    string xmlTemplatePath = ManageReports.GetPathToTemplateFile();
        ////    string destFilePath = $@"{xmlTemplatePath}/{reportName}.xml";

        ////    var query = $@"EXEC dbo.wsp_EXPORT_FILE @searchFields = '{fileXml}', @forType = '{forType}'";
        ////    System.Data.DataTable rptData;

        ////    if (fileXml.Length > 0)
        ////        rptData = DataReaderUtilities.GetData(reportDbConnString,
        ////                query)
        ////                .Tables[0];
        ////    else
        ////        rptData = ManageReports.GetReportWithoutTemplate(reportDbConnString, reportParameters, reportId);

        ////    //ReportParameter param = reportParameters.Where(x => x.ParamName.Equals("param_Runs")).FirstOrDefault();
        ////    //var data = DataReaderUtilities.GetData(connReport, string.Format(@"EXEC dbo.usp_{0} @param_Runs = '{1}'", reportId, param.ParamValue));

        ////    if (rptData.Rows.Count > 0)
        ////    {
        ////        if (File.Exists(destFilePath))
        ////        {
        ////            FileComposer.ExportExcelFileWithOutTemplate(rptData, finalOutputFile, outputName,
        ////                new FileStream(destFilePath, FileMode.Open, FileAccess.Read));
        ////        }
        ////        else
        ////        {
        ////            FileComposer.ExportExcelFileWithOutTemplate(rptData, finalOutputFile, outputName);
        ////        }
        ////    }
        ////    else
        ////    {
        ////        FileComposer.ExportExcelForNoData(finalOutputFile);
        ////    }

        ////}
        /// 
        /// //private void ExportExcelWithoutTemplate(ExportModel exportModel)
        //{
        //    if (File.Exists(exportModel.FileName))
        //    {
        //        FileComposer.ExportExcelFileWithOutTemplate(exportModel.DataTable, exportModel.FinalOutputFile, exportModel.OutputName,
        //            new FileStream(exportModel.FileName, FileMode.Open, FileAccess.Read));
        //    }
        //    else
        //    {
        //        FileComposer.ExportExcelFileWithOutTemplate(exportModel.DataTable, exportModel.FinalOutputFile, exportModel.OutputName);
        //    }
        //}

        //private void ExportExcelWithNoData(ExportModel exportModel)
        //{
        //    FileComposer.ExportExcelForNoData(exportModel.FinalOutputFile);
        //}
        #endregion

        private string GetQuery(string fileXml, string forType, List<ReportParameter> reportParameters, string reportId, int SessionId = 0)
        {
            if (!string.IsNullOrWhiteSpace(fileXml))
                return $@"EXEC dbo.wsp_EXPORT_FILE @searchFields = '{fileXml}', @forType = '{forType}', @SESSION_ID = '{SessionId}'";

            var param = reportParameters?.Where(x => x.ParamName.Equals("param_Runs")).FirstOrDefault();
            return param != null ? $@"EXEC dbo.usp_{reportId} @param_Runs = '{param.ParamValue}'" : null;
        }
        

        public void ExcelWithoutTemplate(string finalOutputFile, string outputName, string fileXml,
            string forType, string reportName, string reportDbConnString, List<ReportParameter> reportParameters,
            string reportId, string outpDirectory, string oneClickQuery, int SessionId = 0)
        {
            string query = string.Empty;
            if (string.IsNullOrEmpty(oneClickQuery))
            {
                query = GetQuery(fileXml, forType, reportParameters, reportId, SessionId);
            }
            else
            {
                query = oneClickQuery;
            }

            // GetTemplate
            //string xmlTemplatePath = ManageReports.GetPathToTemplateFile();
            //string templateFile = $@"{xmlTemplatePath}/{reportName}.xml";

            var config = new ExcelExportConfiguration()
            {
                ConnectionString = reportDbConnString,
                SqlQuery = query,
                ExportModel = new ExportModel()
                {
                    FilePath = finalOutputFile,
                    SheetName = forType,
                    FileName = outputName,
                    Directory = outpDirectory
                }
            };

            var excel = new ExcelExport(config);
            excel.ExportFromDataReader();
        }


        public void DifWithTemplate(string finalOutputFile, string fileXml,
            string forType, string reportName, string reportDbConnString, List<ReportParameter> reportParameters,
            string reportId, string oneClickQuery = "", int SessionId = 0)
        {
            string query = string.Empty;
            if (!string.IsNullOrEmpty(fileXml))
            {
               query = GetQuery(fileXml, forType, reportParameters, reportId, SessionId);
            }
            else
            {
                query = oneClickQuery;
            }

            //// GetTemplate
            string xmlTemplatePath = ManageReports.GetPathToTemplateFile();
            string templateFilePath = $@"{xmlTemplatePath}/{reportName}.xml";

            var config = new DifExportConfiguration()
            {
                ConnectionString = reportDbConnString,
                SqlQuery = query,
                ExportModel = new ExportModel()
                {
                    FilePath = finalOutputFile,
                    SheetName = forType,
                    FormatFilePath = templateFilePath,
                    PrintHeader = false
                }
            };

            var dif = new DifExport(config);
            dif.ExportFromDataReader();
        }


    }
}
