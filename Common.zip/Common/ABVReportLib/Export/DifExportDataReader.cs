﻿using System.Collections.Generic;
using ABVReportLib.Export.FileStructure;
using ABVReportLib.Export.Model;

namespace ABVReportLib.Export
{
    public class DifExportDataReader : ExportDataReader
    {
        public DifExportDataReader(ExportConfiguration exportConfiguration) : base(exportConfiguration)
        {
        }

        public override void LoadIntoFile()
        {
            if (!FileHasData())
            {
                _exportModel.SheetName = "No Data";
                var workBook = _exportFactory.GetWoorkbook(_exportConfiguration);
                workBook.Dispose();
            }
            else
            {
                using (var workBook = _exportFactory.GetWoorkbook(_exportConfiguration))
                using (var workSheet = _exportFactory.GetWoorksheet(_exportConfiguration, workBook.GetWorksheetPart()))
                    AddDataInSheet(workSheet);
            }
        }

        private void AddDataInSheet(IWorksheet worksheet)
        {
            int fieldCount = _reader.FieldCount;
            int row = _exportModel.FromRow;
            var rowValue = new Dictionary<string, object>();

            worksheet.StartInsertSheet();

            if (_exportModel.PrintHeader)
            {
                worksheet.StartInsertRow(row);

                for (int i = 0; i < fieldCount; i++)
                {
                    rowValue.Add(_reader.GetName(i), _reader.GetName(i));
                }

                worksheet.SetRowInner(row, rowValue);
                rowValue.Clear();

                row++;

                worksheet.CloseInsertRow();
            }


            while (_reader.Read())
            {
                worksheet.StartInsertRow(row);

                for (int i = 0; i < fieldCount; i++)
                {
                    rowValue.Add(_reader.GetName(i), _reader.GetValue(i));
                }

                worksheet.SetRowInner(row, rowValue);
                rowValue.Clear();
                row++;

                worksheet.CloseInsertRow();
            }


            worksheet.CloseInsertSheet();
        }


        ~DifExportDataReader()
        {
            base.Dispose(false);
        }
        
    }
}
