﻿using System;
using System.Threading.Tasks;

namespace ABVReportLib.Export
{
    public interface IExportDataSource : IDisposable
    {
        void LoadIntoFile();
        Task LoadIntoFileAsync();
    }
}
