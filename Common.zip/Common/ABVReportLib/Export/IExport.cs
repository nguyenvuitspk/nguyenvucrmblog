﻿using System.Threading.Tasks;

namespace ABVReportLib.Export
{
    public interface IExport
    {
        void ExportFromDataReader();
        Task ExportFromDataReaderAsync();
    }
}
