﻿using ABVReportLib.Export.Model;

namespace ABVReportLib.Export
{
    public class ExcelExportDataReader : ExportDataReader
    {
        public ExcelExportDataReader(ExportConfiguration exportConfiguration) : base(exportConfiguration)
        {
        }

        public override void LoadIntoFile()
        {
           base.LoadIntoFile();
        }

        ~ExcelExportDataReader()
        {
            base.Dispose(false);
        }
        
    }
}
