﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using ABVReportLib.Export.FileStructure;
using ABVReportLib.Export.Model;
using DocumentFormat.OpenXml.Packaging;

namespace ABVReportLib.Export
{
    public class ExportDataReader : IExportDataSource
    {
        protected readonly ExportConfiguration _exportConfiguration;
        protected readonly ExportModel _exportModel;
        protected readonly ExportFactory _exportFactory;

        protected IDataReader _reader;
        protected SqlConnection _sqlConnection;
        protected SqlCommand _sqlCommand;

        private bool _disposed;
        private bool _isNextSheet;

        public ExportDataReader(ExportConfiguration exportConfiguration)
        {
            _exportConfiguration = exportConfiguration;
            _exportModel = exportConfiguration.ExportModel;

            _exportFactory = new ExportFactory();

            InitReader(exportConfiguration);
        }

        private void InitReader(ExportConfiguration exportConfiguration)
        {
            if (!string.IsNullOrWhiteSpace(exportConfiguration.SqlQuery))
            {
                // init reader here
                _sqlConnection = new SqlConnection(exportConfiguration.ConnectionString);
                _sqlConnection.Open();

                _sqlCommand = _sqlConnection.CreateCommand();
                _sqlCommand.CommandText = exportConfiguration.SqlQuery;
                _sqlCommand.CommandTimeout = exportConfiguration.CommandTimeout;

                _reader = _sqlCommand.ExecuteReader();
            }
            else
            {
                // init reader here
                _sqlConnection = new SqlConnection(exportConfiguration.ConnectionString);
                _sqlConnection.Open();

                _sqlCommand = _sqlConnection.CreateCommand();
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                _sqlCommand.CommandText = exportConfiguration.StoreProcedure.Name;
                _sqlCommand.CommandTimeout = exportConfiguration.CommandTimeout;

                
                if (exportConfiguration.StoreProcedure.Params != null)
                {
                    foreach (KeyValuePair<string, object> kvp in exportConfiguration.StoreProcedure.Params)
                        _sqlCommand.Parameters.Add(new SqlParameter(kvp.Key, kvp.Value));
                }

                _reader = _sqlCommand.ExecuteReader();
            }


            if (_reader == null)
                throw (new ArgumentNullException(nameof(_reader), "Reader can't be null"));
        }

        public virtual void LoadIntoFile()
        {
            if (!FileHasData())
            {
                _exportModel.SheetName = "No Data";
                using (var workBook = _exportFactory.GetWoorkbook(_exportConfiguration))
                    workBook.AddWorksheet(_exportModel.SheetName);
            }
            else
            {
                int currentSheetIndex = 0;
                do
                {
                    string sheetName;
                    using (var workBook = _exportFactory.GetWoorkbook(_exportConfiguration))
                        sheetName = workBook.AddWorksheet(_exportModel.SheetName);

                    _exportConfiguration.ExportModel.NewFile = false;

                    using (var workBook = _exportFactory.GetWoorkbook(_exportConfiguration))
                    using (var workSheet = _exportFactory.GetWoorksheet(_exportConfiguration, workBook.GetWorksheetPart(sheetName) as WorksheetPart))
                        AddDataInSheet(workSheet);

                    currentSheetIndex++;
                } while (currentSheetIndex < _exportModel.MaximumSheets && _isNextSheet);
            }
        }

        protected virtual bool FileHasData()
        {
            bool fileHasData = _reader.Read();

            if (fileHasData)
            {
                _reader.Close();
                _reader = _sqlCommand.ExecuteReader();
            }

            return fileHasData;
        }

        private void AddDataInSheet(IWorksheet worksheet)
        {
            _isNextSheet = false;
            int fieldCount = _reader.FieldCount;
            int col = _exportModel.FromCol, row = _exportModel.FromRow;


            worksheet.StartInsertSheet();

            if (_exportModel.PrintHeader)
            {
                worksheet.StartInsertRow(row);

                for (int i = 0; i < fieldCount; i++)
                {
                    // If no caption is set, the ColumnName property is called implicitly.
                    worksheet.SetValueInner(row, col++, _reader.GetName(i));
                }

                row++;
                col = _exportModel.FromCol;

                worksheet.CloseInsertRow();
            }


            while (_reader.Read())
            {
                worksheet.StartInsertRow(row);

                for (int i = 0; i < fieldCount; i++)
                {
                    worksheet.SetValueInner(row, col++, _reader.GetValue(i));
                }

                row++;
                col = _exportModel.FromCol;

                worksheet.CloseInsertRow();

                if (row == _exportConfiguration.ExportModel.RowsPerSheet)
                {
                    _isNextSheet = true;
                    break;
                }
            }


            worksheet.CloseInsertSheet();
        }


        public void Close()
        {
            ThrowIfObjectDisposed();
            _reader?.Close();
            _sqlConnection?.Close();
        }
        
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (_disposed) return;
            if (disposing)
            {
                Close();
                _reader?.Dispose();
                _sqlConnection?.Dispose();
                _sqlCommand?.Dispose();
            }
            _disposed = true;
        }

        ~ExportDataReader()
        {
            Dispose(false);
        }

        private void ThrowIfObjectDisposed()
        {
            if (_disposed)
                throw new ObjectDisposedException(GetType().Name);
        }

        public Task LoadIntoFileAsync()
        {
            throw new NotImplementedException();
        }
    }
}
