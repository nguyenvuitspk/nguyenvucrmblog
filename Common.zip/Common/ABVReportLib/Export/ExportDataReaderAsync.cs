﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ABVReportLib.Export.Async;
using ABVReportLib.Export.FileStructure;
using ABVReportLib.Export.Model;
using DocumentFormat.OpenXml.Packaging;

namespace ABVReportLib.Export
{
    public class ExportDataReaderAsync : IExportDataSource
    {
        private readonly ExportConfiguration _exportConfiguration;
        private readonly ExportModel _exportModel;
        private readonly ExportFactory _exportFactory;

        private SqlDataReader _reader;
        private SqlConnection _sqlConnection;
        private SqlCommand _sqlCommand;

        private bool _disposed;
        private bool _isNextSheet;
        private readonly SemaphoreSlim _readLock = new SemaphoreSlim(1, 1);
        private readonly IEnumerable<string> _headers;
        private int _dataId = 0;

        public ExportDataReaderAsync(ExportConfiguration exportConfiguration)
        {
            _exportConfiguration = exportConfiguration;
            _exportModel = exportConfiguration.ExportModel;

            _exportFactory = new ExportFactory();

            _reader = InitReader(exportConfiguration);
            _headers = InitHeader();
        }

        void IExportDataSource.LoadIntoFile()
        {
            throw new NotImplementedException();
        }

        

        public async Task LoadIntoFileAsync()
        {
            int currentSheetIndex = 0;
            var tasks = new List<Task>();
            Task saveFile = Task.Run(() => 1);
            Tuple<bool, List<IList<string>>, int> xs = null;
            do
            {
                var t = await Task.Run(() => GetData())
                    .ContinueWith(task => WriteInFile2(task));





                //xs = await GetData().ConfigureAwait(false);
                //saveFile = Task.Run(async () => { await WriteInFile(xs); });
                tasks.Add(saveFile);

                currentSheetIndex++;
            } while (currentSheetIndex < _exportModel.MaximumSheets && _isNextSheet);
            //await Task.WhenAll(tasks.ToArray());
        }

        private async Task WriteInFile2(Task<Tuple<bool, List<IList<string>>, int>> xss)
        {
            await _readLock.WaitAsync();
            try
            {
                var xs = await xss;
                var sheetName = "";
                Stopwatch sw = new Stopwatch();
                sw.Start();
                var data = xs.Item2.Select(item => item.Clone()).ToList();
                sw.Stop();
                var xsrt = sw.Elapsed.TotalSeconds;

                using (var workBook = _exportFactory.GetWoorkbook(_exportConfiguration))
                    sheetName = workBook.AddWorksheet(_exportModel.SheetName);

                _exportConfiguration.ExportModel.NewFile = false;

                using (var workBook = _exportFactory.GetWoorkbook(_exportConfiguration))
                using (var workSheet = _exportFactory.GetWoorksheet(_exportConfiguration,
                    workBook.GetWorksheetPart(sheetName) as WorksheetPart))
                    AddDataInSheet(workSheet, data);
            }
            finally
            {
                _readLock.Release();
            }
        }

        private async Task WriteInFile(Tuple<bool, List<IList<string>>, int> xs)
        {
            await _readLock.WaitAsync();
            try
            {
                var sheetName = "";
                Stopwatch sw = new Stopwatch();
                sw.Start();
                var data = xs.Item2.Select(item => item.Clone()).ToList();
                sw.Stop();
                var xsrt = sw.Elapsed.TotalSeconds;

                using (var workBook = _exportFactory.GetWoorkbook(_exportConfiguration))
                    sheetName = workBook.AddWorksheet(_exportModel.SheetName);

                _exportConfiguration.ExportModel.NewFile = false;

                using (var workBook = _exportFactory.GetWoorkbook(_exportConfiguration))
                using (var workSheet = _exportFactory.GetWoorksheet(_exportConfiguration,
                    workBook.GetWorksheetPart(sheetName) as WorksheetPart))
                    AddDataInSheet(workSheet, data);
            }
            finally
            {
                _readLock.Release();
            }
        }

        private SqlDataReader InitReader(ExportConfiguration exportConfiguration)
        {
            // init reader here
            _sqlConnection = new SqlConnection(exportConfiguration.ConnectionString);
            _sqlConnection.Open();

            _sqlCommand = _sqlConnection.CreateCommand();
            _sqlCommand.CommandText = exportConfiguration.SqlQuery;
            _sqlCommand.CommandTimeout = exportConfiguration.CommandTimeout;

            _reader = _sqlCommand.ExecuteReader();

            if (_reader == null)
                throw (new ArgumentNullException(nameof(_reader), "Reader can't be null"));

            return _reader;
        }

        private async Task<Tuple<bool,List<IList<string>>, int>> GetData()
        {
            _isNextSheet = false;
            var data = new List<IList<string>>();
            int row = 2; // because header of file
            int fieldCount = _reader.FieldCount;
            while (_reader.Read())
            {
                data.Add(GetColumnValueIn(_reader, fieldCount));
                row++;

                if (row == _exportConfiguration.ExportModel.RowsPerSheet)
                {
                    _isNextSheet = true;
                    break;
                }
            }

            return Tuple.Create(_isNextSheet, data, _dataId++);
        }

        private IList<string> GetColumnValueIn(IDataReader reader, int fieldCount)
        {
            var res = new List<string>();
            for (int i = 0; i < fieldCount; i++)
                res.Add(reader.GetValue(i).ToString());

            return res;
        }
        
        private IEnumerable<string> InitHeader()
        {
            int fieldCount = _reader.FieldCount;
            for (int i = 0; i < fieldCount; i++)
            {
                yield return _reader.GetName(i);
                // If no caption is set, the ColumnName property is called implicitly.
            }
        }

        private void AddDataInSheet(IWorksheet worksheet, List<IList<string>> datas)
        {
            int col = _exportModel.FromCol, row = _exportModel.FromRow;

            worksheet.StartInsertSheet();

            if (_exportModel.PrintHeader)
            {
                worksheet.StartInsertRow(row);

                foreach (var header in _headers)
                {
                    worksheet.SetValueInner(row, col++, header);
                }
                
                row++;
                col = _exportModel.FromCol;

                worksheet.CloseInsertRow();
            }

            foreach (var data in datas)
            {
                worksheet.StartInsertRow(row);
                foreach (var cell in data)
                {
                    worksheet.SetValueInner(row, col++, cell);
                }
                row++;
                col = _exportModel.FromCol;

                worksheet.CloseInsertRow();
            }


            worksheet.CloseInsertSheet();
        }


        public void Close()
        {
            ThrowIfObjectDisposed();
            _reader?.Close();
            _sqlConnection?.Close();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize((object)this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (_disposed) return;
            if (disposing)
            {
                Close();
                _reader?.Dispose();
                _sqlConnection?.Dispose();
                _sqlCommand?.Dispose();
            }
            _disposed = true;
        }

        ~ExportDataReaderAsync()
        {
            Dispose(false);
        }

        private void ThrowIfObjectDisposed()
        {
            if (this._disposed)
                throw new ObjectDisposedException(this.GetType().Name);
        }
        
    }
}
