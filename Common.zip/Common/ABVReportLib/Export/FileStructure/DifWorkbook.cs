﻿using System;
using System.IO;

namespace ABVReportLib.Export.FileStructure
{
    public class DifWorkbook : IWorkbook
    {
        private FileStream _fileStream;
        private bool _disposed;

        public DifWorkbook(string docName, bool newFile = true)
        {
            if (newFile)
            {
                _fileStream = File.Create(docName);
                //_streamWriter = new StreamWriter(docName);
            }
            else
            {
                _fileStream = File.Open(docName, FileMode.Append);
                //_streamWriter = new StreamWriter(docName, true);
            }
        }

        public object GetWorksheetPart()
        {
            return _fileStream;
        }

        public object GetWorksheetPart(string sheetName)
        {
            throw new NotImplementedException();
        }

        public string AddWorksheet(string sheetName)
        {
            throw new NotImplementedException();
        }

        public void Close()
        {
            ThrowIfObjectDisposed();
            _fileStream?.Close();
        }

        public void Open(string fileName)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            // Check to see if Dispose has already been called.
            if (_disposed) return;
            // If disposing equals true, dispose all managed
            // and unmanaged resources.
            if (disposing)
            {
                // Dispose managed resources.
                Close();
                _fileStream?.Dispose();
                _fileStream = null;
            }

            // Call the appropriate methods to clean up
            // unmanaged resources here.
            // If disposing is false,
            // only the following code is executed.

            // Note disposing has been done.
            _disposed = true;
        }

        ~DifWorkbook()
        {
            Dispose(false);
        }

        private void ThrowIfObjectDisposed()
        {
            if (_disposed)
                throw new ObjectDisposedException(GetType().Name);
        }

    }
}
