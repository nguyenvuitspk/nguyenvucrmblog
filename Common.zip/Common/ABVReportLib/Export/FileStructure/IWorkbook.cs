﻿using System;

namespace ABVReportLib.Export.FileStructure
{
    public interface IWorkbook : IDisposable
    {
        object GetWorksheetPart();
        object GetWorksheetPart(string sheetName);
        string AddWorksheet(string sheetName);
        void Close();
        void Open(string fileName);
    }
}
