﻿using System;
using System.Collections.Generic;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

namespace ABVReportLib.Export.FileStructure
{
    /// <summary>
    /// Each sheet we need to new class ExcelWorksheet
    /// </summary>
    public class ExcelWorksheet : IWorksheet
    {
        private OpenXmlWriter _openXmlWriter;
        private IList<OpenXmlAttribute> _openXmlAttributes;
        //private WorksheetPart _worksheetPart;
        private bool _disposed;

        public ExcelWorksheet(WorksheetPart worksheetPart)
        {
            //_worksheetPart = worksheetPart;
            _openXmlWriter = OpenXmlWriter.Create(worksheetPart);
        }

        public void StartInsertSheet()
        {
            //_openXmlWriter = OpenXmlWriter.Create(_worksheetPart);
            _openXmlWriter.WriteStartElement(new Worksheet());
            _openXmlWriter.WriteStartElement(new SheetData());
        }

        public void CloseInsertSheet()
        {
            // this is for SheetData
            _openXmlWriter.WriteEndElement();
            // this is for Worksheet
            _openXmlWriter.WriteEndElement();
            _openXmlWriter.Close();
        }

        public void Open(object worksheetPart)
        {
            //_worksheetPart = worksheetPart;
            _openXmlWriter = OpenXmlWriter.Create(worksheetPart as WorksheetPart);
            _disposed = false;
        }

        public void Close()
        {
            ThrowIfObjectDisposed();
            _openXmlWriter?.Close();
            _openXmlAttributes?.Clear();
        }

        public void StartInsertRow(int iRow)
        {
            _openXmlAttributes = new List<OpenXmlAttribute>();
            // this is the row index
            _openXmlAttributes.Add(new OpenXmlAttribute("r", null, iRow.ToString()));

            _openXmlWriter.WriteStartElement(new Row(), _openXmlAttributes);
        }

        public void CloseInsertRow()
        {
            _openXmlWriter.WriteEndElement();
        }

        public void SetValueInner(int row, int col, object value)
        {
            // start write cell
            _openXmlAttributes = new List<OpenXmlAttribute>();

            // this is the data type ("t"), with CellValues.String ("str")
            _openXmlAttributes.Add(new OpenXmlAttribute("t", null, "str"));

            // it's suggested you also have the cell reference, but
            // you'll have to calculate the correct cell reference yourself.
            // Here's an example:
            //oxa.Add(new OpenXmlAttribute("r", null, "A1"));

            _openXmlWriter.WriteStartElement(new Cell(), _openXmlAttributes);

            //write value
            _openXmlWriter.WriteElement(new CellValue(value.ToString()));

            // close this is for Cell
            _openXmlWriter.WriteEndElement();
        }


        /// <summary>
        /// To do
        /// </summary>
        /// <param name="row"></param>
        /// <param name="values"></param>
        public void SetRowInner(int row, IDictionary<string, object> values)
        {
            //oxa = new List<OpenXmlAttribute>();
            //// this is the row index
            //oxa.Add(new OpenXmlAttribute("r", null, i.ToString()));

            //openXmlWriter.WriteStartElement(new Row(), oxa);

            //for (int j = 1; j <= Constants.NumberColumn; ++j)
            //{
            //    oxa = new List<OpenXmlAttribute>();
            //    // this is the data type ("t"), with CellValues.String ("str")
            //    oxa.Add(new OpenXmlAttribute("t", null, "str"));

            //    // it's suggested you also have the cell reference, but
            //    // you'll have to calculate the correct cell reference yourself.
            //    // Here's an example:
            //    //oxa.Add(new OpenXmlAttribute("r", null, "A1"));

            //    openXmlWriter.WriteStartElement(new Cell(), oxa);
            //    //if (sheetId != 1)
            //    //    oxw.WriteElement(new CellValue(string.Format("XR{0}C{1}", i, j)));
            //    //else
            //    openXmlWriter.WriteElement(new CellValue(string.Format("xR{0}C{1}", i, j)));

            //    // this is for Cell
            //    openXmlWriter.WriteEndElement();
            //}

            //// this is for Row
            //openXmlWriter.WriteEndElement();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        
        protected virtual void Dispose(bool disposing)
        {
            // Check to see if Dispose has already been called.
            if (_disposed) return;
            // If disposing equals true, dispose all managed
            // and unmanaged resources.
            if (disposing)
            {
                // Dispose managed resources.
                Close();
                _openXmlWriter?.Dispose();
            }

            // Call the appropriate methods to clean up
            // unmanaged resources here.
            // If disposing is false,
            // only the following code is executed.

            // Note disposing has been done.
            _disposed = true;
        }

        ~ExcelWorksheet()
        {
            Dispose(false);
        }

        private void ThrowIfObjectDisposed()
        {
            if (_disposed)
                throw new ObjectDisposedException(GetType().Name);
        }

    }
}
