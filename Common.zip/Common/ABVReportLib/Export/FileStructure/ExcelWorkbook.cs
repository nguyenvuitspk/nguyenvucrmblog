﻿using System;
using System.Linq;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

namespace ABVReportLib.Export.FileStructure
{
    public class ExcelWorkbook : IWorkbook
    {
        private SpreadsheetDocument _spreadsheetDocument;
        private bool _disposed;

        public ExcelWorkbook(string docName, bool newFile = true)
        {
            if (newFile)
            {
                _spreadsheetDocument = SpreadsheetDocument.Create(docName, SpreadsheetDocumentType.Workbook);
                // Add a WorkbookPart to the document.
                _spreadsheetDocument.AddWorkbookPart();
                _spreadsheetDocument.WorkbookPart.Workbook = new Workbook();
            }
            else
            {
                _spreadsheetDocument = SpreadsheetDocument.Open(docName, true);
            }
        }

        public object GetWorksheetPart()
        {
            return _spreadsheetDocument.WorkbookPart.AddNewPart<WorksheetPart>();
        }

        public object GetWorksheetPart(string sheetName)
        {
            string relId = _spreadsheetDocument.WorkbookPart.Workbook.Descendants<Sheet>().First(s => sheetName.Equals(s.Name)).Id;
            return (WorksheetPart)_spreadsheetDocument.WorkbookPart.GetPartById(relId);
        }

        public string AddWorksheet(string sheetName)
        {
            // Add a WorksheetPart to the WorkbookPart.
            WorksheetPart newWorksheetPart = _spreadsheetDocument.WorkbookPart.AddNewPart<WorksheetPart>();
            newWorksheetPart.Worksheet = new Worksheet(new SheetData());

            Sheets sheets = _spreadsheetDocument.WorkbookPart.Workbook?.GetFirstChild<Sheets>();
            // for create sheets and don't have any sheet
            if (sheets == null)
            {
                sheets = _spreadsheetDocument?.WorkbookPart?.Workbook?.AppendChild<Sheets>(new Sheets());
            }

            string relationshipId = _spreadsheetDocument.WorkbookPart?.GetIdOfPart(newWorksheetPart);

            // Get a unique ID for the new worksheet.
            uint sheetId = 1;
            if (sheets?.Elements<Sheet>()?.Count() > 0)
            {
                sheetId = sheets.Elements<Sheet>().Select(s => s.SheetId.Value).Max() + 1;
            }

            // Give the new worksheet a name.
            sheetName = sheetName + "_" + sheetId;

            // Append the new worksheet and associate it with the workbook.
            Sheet sheet = new Sheet() { Id = relationshipId, SheetId = sheetId, Name = sheetName };
            sheets?.Append(sheet);

            return sheetName;
        }

        public void Close()
        {
            ThrowIfObjectDisposed();
            _spreadsheetDocument?.Close();
        }

        public void Open(string fileName)
        {
            if (!_disposed)
                throw new ObjectDisposedException(GetType().Name, "Please dispose object before open it");

            _spreadsheetDocument = SpreadsheetDocument.Open(fileName, true);
            _disposed = false;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            // Check to see if Dispose has already been called.
            if (_disposed) return;
            // If disposing equals true, dispose all managed
            // and unmanaged resources.
            if (disposing)
            {
                // Dispose managed resources.
                Close();
                _spreadsheetDocument?.Dispose();
                _spreadsheetDocument = null;
            }

            // Call the appropriate methods to clean up
            // unmanaged resources here.
            // If disposing is false,
            // only the following code is executed.

            // Note disposing has been done.
            _disposed = true;
        }

        ~ExcelWorkbook()
        {
            Dispose(false);
        }

        private void ThrowIfObjectDisposed()
        {
            if (_disposed)
                throw new ObjectDisposedException(GetType().Name);
        }

    }
}
