﻿using ABVReportLib.Export.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace ABVReportLib.Export.FileStructure
{
    /// <summary>
    /// Each sheet we need to new class ExcelWorksheet
    /// </summary>
    public class DifWorksheet : IWorksheet
    {
        private StreamWriter _streamWriter;
        private StringBuilder _stringBuilder;
        private IEnumerable<CellFormat> _cellFormats;
        private bool _disposed;

        public DifWorksheet(FileStream fileStream, string xmlFormatFilePath = null)
        {
            _streamWriter = new StreamWriter(fileStream);
            if (!string.IsNullOrWhiteSpace(xmlFormatFilePath))
                InitFormat(xmlFormatFilePath);
        }

        public void StartInsertSheet()
        {

        }

        public void CloseInsertSheet()
        {

        }


        public void Open(object worksheetPart)
        {
            throw new NotImplementedException();
        }

        public void Close()
        {
            ThrowIfObjectDisposed();
            _streamWriter?.Close();
            //_cellFormats.
        }

        public void StartInsertRow(int iRow)
        {
            _stringBuilder = new StringBuilder();
        }

        public void CloseInsertRow()
        {
            _streamWriter.WriteLine(_stringBuilder.ToString());
        }

        public void SetValueInner(int row, int col, object value)
        {

        }


        /// <summary>
        /// To do
        /// </summary>
        /// <param name="row"></param>
        /// <param name="values"></param>
        public void SetRowInner(int row, IDictionary<string, object> values)
        {
            var iStart = 0;
            foreach (var cellFormat in _cellFormats)
            {
                var strValue = StandardizeColumn(values[cellFormat.Name.ToUpper()], cellFormat.DataType, cellFormat.DataFormat, cellFormat.Length);
                _stringBuilder.Insert(iStart, cellFormat.Justification == "left" ? strValue.PadRight(cellFormat.Length, ' ') : strValue.PadLeft(cellFormat.Length, ' '));
                iStart += cellFormat.Length;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            // Check to see if Dispose has already been called.
            if (_disposed) return;
            // If disposing equals true, dispose all managed
            // and unmanaged resources.
            if (disposing)
            {
                // Dispose managed resources.
                Close();
                _streamWriter?.Dispose();
            }

            // Call the appropriate methods to clean up
            // unmanaged resources here.
            // If disposing is false,
            // only the following code is executed.

            // Note disposing has been done.
            _disposed = true;
        }

        ~DifWorksheet()
        {
            Dispose(false);
        }

        private void ThrowIfObjectDisposed()
        {
            if (_disposed)
                throw new ObjectDisposedException(GetType().Name);
        }

        private void InitFormat(string xmlFormatFilePath)
        {
            using (var xmlFile = new FileStream(xmlFormatFilePath, FileMode.Open, FileAccess.Read))
            {
                XDocument xmlDoc = XDocument.Load(xmlFile);
                XElement xmlElement = xmlDoc.Element("WriteFixedWidth");

                int iStartAt = xmlElement.Attribute("StartAt") == null ? 0 : int.Parse(xmlElement.Attribute("StartAt").Value);

                _cellFormats = from des in xmlElement.Descendants("Position")
                               select new CellFormat(des, iStartAt);
            }
        }

        private string StandardizeColumn(object cell, string dataType, string dataFormat, int length)
        {
            string result = string.Empty;
            switch (dataType)
            {
                case "Date":
                    if (!string.IsNullOrEmpty(cell?.ToString()))
                    {
                        try
                        {
                            DateTime date = Convert.ToDateTime(cell);
                            result = date.ToString(dataFormat);
                        }
                        catch
                        {
                            result = cell.ToString();
                        }
                    }
                    break;

                case "Int":
                    result = cell.ToString();
                    break;

                case "Float":
                    if (!string.IsNullOrEmpty(cell?.ToString()))
                    {
                        try
                        {
                            double num = Convert.ToDouble(cell);
                            result = string.Format(dataFormat, num);
                        }
                        catch
                        {
                            result = cell.ToString();
                        }
                    }
                    break;

                default:
                    result = cell.ToString();
                    break;
            }

            if (result.Length > length)
            {
                result = result.Substring(0, length);
            }
            return result;
        }

    }
}
