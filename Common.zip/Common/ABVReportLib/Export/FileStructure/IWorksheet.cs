﻿using System;
using System.Collections.Generic;

namespace ABVReportLib.Export.FileStructure
{
    public interface IWorksheet : IDisposable
    {
        void Open(object worksheetPart);
        void Close();
        void StartInsertRow(int iRow);
        void CloseInsertRow();
        void StartInsertSheet();
        void CloseInsertSheet();
        void SetValueInner(int row, int col, object value);

        /// <summary>
        /// Will do
        /// </summary>
        /// <param name="row"></param>
        /// <param name="values"></param>
        void SetRowInner(int row, IDictionary<string, object> values);
    }
}
