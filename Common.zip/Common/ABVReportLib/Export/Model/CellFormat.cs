﻿using System;
using System.Xml.Linq;

namespace ABVReportLib.Export.Model
{
    public class CellFormat
    {
        public string Name { get; set; }
        public int Start { get; set; }
        public int Length { get; set; }
        public string DataFormat { get; set; }
        public string DataType { get; set; }
        public string Justification { get; set; }

        public CellFormat(XElement xElement)
        {
            if (xElement == null)
                throw new Exception($"{nameof(xElement)} isn't null.");

            Name = xElement.Attribute("Name").Value;
            Start = int.Parse(xElement.Attribute("Start").Value);
            Length = int.Parse(xElement.Attribute("Length").Value);
            DataFormat = xElement.Attribute("DataFormat") != null ? xElement.Attribute("DataFormat").Value : "";
            DataType = xElement.Attribute("DataType") != null ? xElement.Attribute("DataType").Value : "";
            Justification = xElement.Attribute("Justification") != null
                ? xElement.Attribute("Justification").Value.ToLower()
                : "left";
        }

        public CellFormat(XElement xElement, int iStartAt) : this(xElement)
        {
            Start -= iStartAt;
        }

    }
}
