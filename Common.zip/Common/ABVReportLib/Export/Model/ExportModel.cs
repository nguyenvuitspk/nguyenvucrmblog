﻿using System.Data;

namespace ABVReportLib.Export.Model
{
    public class ExportModel
    {
        public string FormatFilePath { get; set; }
        public string FilePath { get; set; }
        public string Directory { get; set; }
        public string FileName { get; set; }
        /// <summary>
        /// Excel start from 1
        /// </summary>
        public int FromRow { get; set; } = 1;
        /// <summary>
        /// Excel start from 1
        /// </summary>
        public int FromCol { get; set; } = 1;
        public int RowsPerSheet { get; set; } = 1000000;
        public int MaximumSheets { get; set; } = 1000;
        public bool PrintHeader { get; set; } = true;
        public string SheetName { get; set; } = "Sheet";
        public bool NewFile { get; set; } = true;
        public DataTable DataTable { get; set; }

    }
}
