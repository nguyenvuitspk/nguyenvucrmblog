﻿using System.Collections.Generic;

namespace ABVReportLib.Export.Model
{
    /// <summary>
    /// Default for excel config
    /// </summary>
    public class ExportConfiguration
    {
        public string ConnectionString { get; set; }
        /// <summary>
        /// Select or call store with query
        /// </summary>
        /// Example: EXEC dbo.wsp_EXPORT_FILE @searchFields = 'data'
        public string SqlQuery { get; set; }
        public StoreProcedure StoreProcedure { get; set; }
        public int CommandTimeout { get; set; } = 0;
        public ExportModel ExportModel { get; set; }
    }

    public enum ExportType
    {
        DataTable,
        DataReader
    }

    public class StoreProcedure
    {
        public string Name { get; set; }
        public Dictionary<string, object> Params { get; set; }
    }

    //public enum ExportFileType
    //{
    //    Excel
    //}
}
