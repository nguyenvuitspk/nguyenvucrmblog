﻿namespace ABVReportLib.Export.Model.Excel
{
    public class ExcelExportConfiguration : ExportConfiguration
    {
    }
}
