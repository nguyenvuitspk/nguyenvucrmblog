﻿namespace ABVReportLib.Export.Model.Excel
{
    public class DifExportConfiguration : ExportConfiguration
    {
        
    }
}
