﻿using OfficeOpenXml;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace ABVReportLib
{
    public static class FileComposer
    {

        #region Export Excel For No Data
        public static void ExportExcelForNoData(string reportFilePath)
        {
            string sheetname = "No Data";
            ExcelWorksheet worksheet;
            if (!Directory.Exists(Path.GetDirectoryName(reportFilePath)))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(reportFilePath));
            }
            var newFile = new FileInfo(reportFilePath);
            if (newFile.Exists)
            {
                newFile.Delete(); // ensures we create a new workbook
                newFile = new FileInfo(reportFilePath);
            }
            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                worksheet = package.Workbook.Worksheets.Add(sheetname);
                package.Save();
            }
        }
        #endregion

        #region DIF & Text File

        public static void ExportDIFFile(DataTable data, string destFilePath)
        {
            using (StreamWriter file = new StreamWriter(destFilePath, false))
            {
                foreach (DataRow row in data.Rows)
                {
                    file.WriteLine(row[0].ToString());
                }
            }
        }

        public static void ExportDIFFile(string xmlFilePath, DataTable data, string destFilePath)
        {
            FileStream xmlFile = new FileStream(xmlFilePath, FileMode.Open, FileAccess.Read);
            XDocument xmlDoc = XDocument.Load(xmlFile);
            XElement xmlElement = xmlDoc.Element("WriteFixedWidth");

            int iStartAt = xmlElement.Attribute("StartAt") == null ? 0 : int.Parse(xmlElement.Attribute("StartAt").Value);
            int iStart = 0;
            int iLineLength = 0;

            var positions = from des in xmlElement.Descendants("Position")
                            select new
                            {
                                Name = des.Attribute("Name").Value,
                                Start = int.Parse(des.Attribute("Start").Value) - iStartAt,
                                Length = int.Parse(des.Attribute("Length").Value),
                                DataFormat = des.Attribute("DataFormat") != null ? des.Attribute("DataFormat").Value : "",
                                DataType = des.Attribute("DataType") != null ? des.Attribute("DataType").Value : "",
                                Justification = des.Attribute("Justification") != null ? des.Attribute("Justification").Value.ToLower() : "left",
                            };

            iLineLength = positions.Last().Start + positions.Last().Length;
            if (!Directory.Exists(Path.GetDirectoryName(destFilePath)))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(destFilePath));
            }
            var file = File.Create(destFilePath);
            using (StreamWriter fStream = new StreamWriter(file))
            {
                foreach (DataRow row in data.Rows)
                {
                    StringBuilder line = new StringBuilder(iLineLength);
                    iStart = 0;
                    foreach (var pos in positions)
                    {
                        string strValue = string.Empty;
                        strValue = StandardizeColumn(row, pos.Name, pos.DataType, pos.DataFormat, pos.Length);
                        line.Insert(iStart, pos.Justification == "left" ? strValue.PadRight(pos.Length, ' ') : strValue.PadLeft(pos.Length, ' '));
                        iStart += pos.Length;
                    }
                    fStream.WriteLine(line.ToString());
                }
            }
        }

        public static void ExportDIFFileForNoData(string destFilePath)
        {
            if (!Directory.Exists(Path.GetDirectoryName(destFilePath)))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(destFilePath));
            }
            var file = File.Create(destFilePath);
        }

        public static void ExportTXTFile(DataTable data, string destFilePath)
        {
            if (!Directory.Exists(Path.GetDirectoryName(destFilePath)))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(destFilePath));
            }
            var file = File.Create(destFilePath);
            using (StreamWriter fStream = new StreamWriter(file))
            {
                // This loop is adding column name
                foreach (var column in data.Columns)
                {
                    fStream.Write(column.ToString() + "\t");
                }
                fStream.Write("\n");

                // This loop is adding data for each row
                foreach (DataRow row in data.Rows)
                {
                    foreach (var item in row.ItemArray)
                    {
                        fStream.Write((item != null ? item.ToString() : "\t") + "\t");
                    }
                    fStream.Write("\n");
                }
            }
        }

        #endregion

        #region EXCEL Without Template

        public static void ExportExcelFileWithOutTemplate(DataTable data, string destFilePath, string sheetName)
        {
            FileInfo outFileInfo = new FileInfo(destFilePath);
            if (outFileInfo.Exists)
            {
                outFileInfo.Delete();
            }

            using (ExcelPackage masterPackage = new ExcelPackage(new FileInfo(destFilePath)))
            {
                ExcelWorksheet workSheet = masterPackage.Workbook.Worksheets.Add(sheetName);
                workSheet.Row(1).Style.Font.Bold = true;
                workSheet.Cells["A1"].LoadFromDataTable(data, true);
                workSheet.Cells.AutoFitColumns();
                masterPackage.Save();
            }
        }

        public static void ExportExcelFileWithOutTemplate(DataTable data, string destFilePath, string sheetName, FileStream xmlFile)
        {
            FileInfo outFileInfo = new FileInfo(destFilePath);
            if (outFileInfo.Exists)
            {
                outFileInfo.Delete();
            }
            Directory.CreateDirectory(Path.GetDirectoryName(destFilePath));

            XDocument xmlDoc = XDocument.Load(xmlFile);
            XElement xmlElement = xmlDoc.Element("MappingFriendlyName");
            string fSheetName = xmlElement.Attribute("SheetName") == null ? sheetName : xmlElement.Attribute("SheetName").Value;

            ExtExportLargeExcel.ExportLargeData2Excel(data, fSheetName, destFilePath);
        }

        public static void ExportExcelFileWithOutTemplate(DataTable data, string destFilePath, string sheetName, string forType = "")
        {
            FileInfo outFileInfo = new FileInfo(destFilePath);
            if (outFileInfo.Exists)
            {
                outFileInfo.Delete();
            }
            Directory.CreateDirectory(Path.GetDirectoryName(destFilePath));

            switch (forType)
            {
                case "COMPARE":
                    ExtExportLargeExcel.ExportLargeData2Excel(data, sheetName, destFilePath);
                    break;
                default:
                    ExtExportLargeExcel.ExportLargeData2Excel(data, sheetName, destFilePath);
                    break;
            }

        }

        #endregion

        #region PDF merging

        public static void PdfMerging(List<string> pdfFiles, string outPdfFile)
        {
            using (PdfDocument outPdf = new PdfDocument())
            {
                int count = 0;
                foreach (string pdf in pdfFiles)
                {
                    PdfDocument current = PdfReader.Open(pdf, PdfDocumentOpenMode.Import);

                    // Check Good Bulls Guide About 
                    if (count == 0 || count == pdfFiles.Count - 1)
                    {
                        outPdf.AddPage(current.Pages[0]);
                    }

                    // Check other Reports
                    else if (checkPageEmpty(current))
                    {
                        for (int i = 0; i < current.PageCount; i++)
                        {
                            outPdf.AddPage(current.Pages[i]);
                        }
                    }
                    count++;
                }

                #region Decoration with graphical
                // Make a font and a brush to draw the page counter.                
                XFont font = new XFont("Segoe UI", 9);
                XBrush brush = new XSolidBrush(new XColor { R = 103, G = 112, B = 126 });
                // Add the page counter.
                string noPages = outPdf.Pages.Count.ToString();
                for (int index = 0; index < outPdf.Pages.Count; index++)
                {
                    if (index > 0 && index < outPdf.Pages.Count - 1)
                    {
                        PdfPage page = outPdf.Pages[index];
                        XRect layoutRectangle = new XRect(page.Width - 80/*X*/, page.Height - font.Height - 10/*Y*/, page.Width/*Width*/, font.Height/*Height*/);
                        using (XGraphics gfx = XGraphics.FromPdfPage(page))
                        {
                            gfx.DrawString(
                                "Page " + (index + 1).ToString() + " of " + noPages,
                                font,
                                brush,
                                layoutRectangle,
                                XStringFormats.TopLeft);
                        }
                    }
                }
                #endregion

                outPdf.Save(outPdfFile);
            }
        }

        #endregion

        #region SSRSExcelFormat

        public static void SSRSExcelFormat(string fileName, string sheetName)
        {
            FileInfo outFileInfo = new FileInfo(fileName);

            using (var package = new ExcelPackage(outFileInfo))
            {
                foreach( var srcWorksheet in package.Workbook.Worksheets)
                {                
                //var srcWorksheet = package.Workbook.Worksheets.Add(sheetName);
                //var srcWorksheet = package.Workbook.Worksheets[1];

                    var cells = srcWorksheet.Cells;
                    int rowIndex = GetIndexToFreezePanesOfCowInHerd(cells);
                    if (cells[rowIndex + 1, 1].Value != null)
                    {
                        // Fix Height Row at Header of list                        
                        srcWorksheet.Row(rowIndex - 1).Height = srcWorksheet.Row(rowIndex - 1).Height + ABVReportConstant.ADD_HEIGHT;
                        srcWorksheet.Row(rowIndex).Height = srcWorksheet.Row(rowIndex).Height + ABVReportConstant.ADD_HEIGHT;

                        // Freeze Panel at first record in list
                        srcWorksheet.View.FreezePanes(rowIndex + 1, 1);

                        // Rename sheet
                        if(package.Workbook.Worksheets.Count == 1)
                        {
                            srcWorksheet.Name = sheetName;
                        }

                    }
                }
                package.Save();
            }
        }
        #endregion

        #region Excel merging

        public static void ExcelMerging(List<string> excelFiles, Dictionary<string, string> reportFriendlyName, string outExcelFile)
        {
            FileInfo outFileInfo = new FileInfo(outExcelFile);
            if (outFileInfo.Exists)
            {
                outFileInfo.Delete();
            }

            using (var dest = new ExcelPackage(outFileInfo))
            {
                int count = 0;
                foreach (var file in excelFiles)
                {
                    var src = new ExcelPackage(new FileInfo(file));
                    var srcWorksheet = src.Workbook.Worksheets[1];
                    var rpName = reportFriendlyName.Where(rp => rp.Key.Equals(file)).Select(p => p.Value).FirstOrDefault();
                    if (count > 0)
                    {
                        var cells = srcWorksheet.Cells;
                        int rowIndex = GetIndexToFreezePanes(cells);
                        if (cells[rowIndex + 1, 1].Value != null)
                        {
                            // Fix Height Row at Header of list                        
                            srcWorksheet.Row(rowIndex - 1).Height = srcWorksheet.Row(rowIndex - 1).Height + ABVReportConstant.ADD_HEIGHT;
                            srcWorksheet.Row(rowIndex).Height = srcWorksheet.Row(rowIndex).Height + ABVReportConstant.ADD_HEIGHT;

                            // Freeze Panel at first record in list
                            srcWorksheet.View.FreezePanes(rowIndex + 1, 1);
                        }
                    }

                    dest.Workbook.Worksheets.Add(rpName, srcWorksheet);
                    count++;
                }
                dest.Save();
            }
        }

        internal static void ExcelMerging(List<string> excelFiles, string outExcelFile)
        {
            FileInfo outFileInfo = new FileInfo(outExcelFile);
            int count = 0;
            using (var dest = new ExcelPackage(outFileInfo))
            {
                foreach (string file in excelFiles)
                {
                    count++;
                    var src = new ExcelPackage(new FileInfo(file));
                    var srcWorksheet = src.Workbook.Worksheets[1];
                    dest.Workbook.Worksheets.Add(count.ToString() + "." + srcWorksheet.Name, srcWorksheet);
                }
                dest.Save();
            }
        }

        public static void ExcelSheetMerging(List<string> excelFiles, string outExcelFile)
        {
            FileInfo outFileInfo = new FileInfo(outExcelFile);
            int count = 0;
            using (var dest = new ExcelPackage(outFileInfo))
            {
                foreach (string file in excelFiles)
                {
                    count++;
                    var src = new ExcelPackage(new FileInfo(file));
                    var srcWorksheet = src.Workbook.Worksheets[1];
                    dest.Workbook.Worksheets.Add(srcWorksheet.Name, srcWorksheet);
                }
                dest.Save();
            }
        }

        public static void ExcelConfigTemplate(string excelFile)
        {
            FileInfo outFileInfo = new FileInfo(excelFile);
            if (outFileInfo.Exists)
            {
                outFileInfo.Delete();
            }

            using (var masterPackage = new ExcelPackage(outFileInfo))
            {
                var src = new ExcelPackage(new FileInfo(excelFile));
                var srcWorksheet = src.Workbook.Worksheets[1];
            }
        }

        public static string FriendlyName4SheetExcel(string subFile, string frName)
        {
            string newPath = Path.GetDirectoryName(subFile) + "\\" + frName + Path.GetExtension(subFile);
            var nFile = new FileInfo(newPath);
            using (var dest = new ExcelPackage(nFile))
            {
                var src = new ExcelPackage(new FileInfo(subFile));
                ExcelWorksheet worksheet = dest.Workbook.Worksheets.Add(frName, src.Workbook.Worksheets[1]);
                dest.Save();
            }

            File.Delete(subFile);
            return newPath;
        }

        #endregion

        #region Utilities Function

        public static string[] splitXML(string sXML, string sCondition)
        {
            string[] arrResult = null;
            string sTemp;
            int iStartIndex;
            int iEndIndex;

            try
            {
                if (sXML.Contains(sCondition))
                {
                    iStartIndex = sXML.LastIndexOf(sCondition);
                    iStartIndex = sXML.IndexOf("(''", iStartIndex) + 3;
                    if (iStartIndex > 3)
                    {
                        iEndIndex = sXML.IndexOf("'')", iStartIndex);
                        sTemp = sXML.Substring(iStartIndex, iEndIndex - iStartIndex).Replace("''", "");
                        arrResult = sTemp.Split(',');
                    }
                }
            }
            catch
            {
                return arrResult;
            }
            return arrResult;
        }

        public static string splitXML(string sXML, string sCondition, string sStart, string sEnd)
        {
            string sResult = null;
            int iStartIndex;
            int iEndIndex;

            try
            {
                if (sXML.Contains(sCondition))
                {
                    iStartIndex = sXML.LastIndexOf(sCondition);
                    iStartIndex = sXML.IndexOf(sStart, iStartIndex) + sStart.Length;
                    if (iStartIndex > 3)
                    {
                        iEndIndex = sXML.IndexOf(sEnd, iStartIndex);
                        sResult = sXML.Substring(iStartIndex, iEndIndex - iStartIndex);
                    }
                }
            }
            catch
            {
                return sResult;
            }
            return sResult;
        }

        private static string StandardizeColumn(DataRow row, string columnName, string dataType, string dataFormat, int length)
        {
            string result = string.Empty;
            switch (dataType)
            {
                case "Date":
                    if (row[columnName] != null && !string.IsNullOrEmpty(row[columnName].ToString()))
                    {
                        DateTime date = Convert.ToDateTime(row[columnName]);
                        result = date.ToString(dataFormat);
                    }
                    break;

                case "Int":
                    result = row[columnName].ToString();
                    break;

                case "Float":
                    if (row[columnName] != null && !string.IsNullOrEmpty(row[columnName].ToString()))
                    {
                        double num = Convert.ToDouble(row[columnName]);
                        result = string.Format(dataFormat, num);
                    }
                    break;

                default:
                    result = row[columnName].ToString();
                    break;
            }

            if (result.Length > length)
            {
                result = result.Substring(0, length);
            }
            return result;
        }

        public static int GetIndexToFreezePanes(ExcelRange cells)
        {
            var dictionary = cells
                                .GroupBy(c => new { c.Start.Row, c.Start.Column })
                                .ToDictionary(
                                    rcg => new KeyValuePair<int, int>(rcg.Key.Row, rcg.Key.Column),
                                    rcg => cells[rcg.Key.Row, rcg.Key.Column].Value);
            int index = dictionary.Where(dic => dic.Value != null && dic.Value.ToString().Equals(ABVReportConstant.COL_CHECK_BULLS)).Select(s => s.Key.Key).FirstOrDefault();
            return index;
        }
        public static int GetIndexToFreezePanesOfCowInHerd(ExcelRange cells)
        {
            var dictionary = cells
                                .GroupBy(c => new { c.Start.Row, c.Start.Column })
                                .ToDictionary(
                                    rcg => new KeyValuePair<int, int>(rcg.Key.Row, rcg.Key.Column),
                                    rcg => cells[rcg.Key.Row, rcg.Key.Column].Value);
            int index = dictionary.Where(dic => dic.Value != null && dic.Value.ToString().Equals(ABVReportConstant.COL_CHECK_COW)).Select(s => s.Key.Key).FirstOrDefault();
            return index;
        }

        private static bool checkPageEmpty(PdfDocument inputDocument)
        {
            bool isEmptyPage = false;
            if (inputDocument.Pages.Count > 1)
            {
                isEmptyPage = true;
            }

            else
            {
                foreach (PdfPage page in inputDocument.Pages)
                {
                    for (int index = 0; index < page.Contents.Elements.Count; index++)
                    {
                        PdfDictionary.PdfStream stream = page.Contents.Elements.GetDictionary(index).Stream;
                        string outputText = new PDFParser().ExtractTextFromPDFBytes(stream.Value);
                        if (outputText.Contains(ABVReportConstant.COL_CHECK_BULLS))
                        {
                            isEmptyPage = true;
                            break;
                        }
                    }
                }
            }

            return isEmptyPage;
        }
        public static void DeleteColumn(string outExcelFile, int iColumn)
        {
            FileInfo outFileInfo = new FileInfo(outExcelFile);

            using (var dest = new ExcelPackage(outFileInfo))
            {
                for (int i = 1; i <= dest.Workbook.Worksheets.Count; i++)
                {
                    var srcWorksheet = dest.Workbook.Worksheets[i];
                    srcWorksheet.DeleteColumn(iColumn);
                }
                dest.Save();
            }
        }

        public static void DeleteLastColumn(string fileName)
        {
            
            FileInfo outFileInfo = new FileInfo(fileName);

            using (var package = new ExcelPackage(outFileInfo))
            {
                foreach (var srcWorksheet in package.Workbook.Worksheets)
                {
                    var lastCol = srcWorksheet.Dimension.End.Column;
                    srcWorksheet.DeleteColumn(lastCol);
                }
                package.Save();
            }

        }

        public static void RenameSheets(string fileName)
        {
            FileInfo outFileInfo = new FileInfo(fileName);

            using (var package = new ExcelPackage(outFileInfo))
            {
                foreach (var srcWorksheet in package.Workbook.Worksheets)
                {              
                    var cells = srcWorksheet.Cells;
                    int rowIndex = GetIndexToFreezePanesOfCowInHerd(cells);
                    var lastCol = srcWorksheet.Dimension.End.Column;
                    if (cells[rowIndex + 1, lastCol].Value != null)
                    {
                        srcWorksheet.Name = cells[rowIndex + 1, lastCol].Value.ToString();
                    }
                }
                package.Save();
            }
        }

        public static string CreateDirectoryWithSubFolder(string destPath, string subFolder)
        {
            string path = null;
            DirectoryInfo di = new DirectoryInfo(destPath);
            if (!di.Exists)
            {
                di.Create();
                di.CreateSubdirectory(subFolder);
                path = string.Format(@"{0}\{1}", destPath, subFolder);
            }
            else
            {
                path = string.Format(@"{0}\{1}", destPath, subFolder);
            }

            return path;
        }
        #endregion
    }
}
