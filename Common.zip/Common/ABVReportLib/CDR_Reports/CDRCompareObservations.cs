﻿using DataReaderUtilsLib;
using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using OfficeOpenXml;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.IO;
using SQLUtilsLib;
using System.Drawing;

namespace ABVReportLib
{
    public class CDRCompareObservations : ABVReport
    {
        public CDRCompareObservations(string reportName) : base(reportName)
        {
            FileOutputExt = "xlsx";
        }

        public override string GenerateReportWithMessage(int rptInstanceId)
        {
            string sMessage = "";
            string[] arrCBH_NATIONAL_ID;
            //string connDV = @"Data Source=192.168.213.74,1433;User ID=sa;password=12345678x@X;Initial Catalog=GESNP;Provider=SQLNCLI11.1;Persist Security Info=True;";
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            string CurrentRun = ReportParameters.Where(x => x.ParamName == "RUN_ID_1").Select(x => x.ParamValue).First();
            string PreviousRun = ReportParameters.Where(x => x.ParamName == "RUN_ID_2").Select(x => x.ParamValue).First();
            string CBH_NATIONAL_ID = ReportParameters.Where(x => x.ParamName == "CBH_NATIONAL_ID").Select(x => x.ParamValue).First();

            string TYPE = ReportParameters.Where(x => x.ParamName == "TYPE").Select(x => x.ParamValue).First();
            string sType = char.ToUpper(TYPE[0]) + TYPE.Substring(1);
            DateTime reportTime = DateTime.Now;
            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportTime.Ticks.ToString());
            string reportFileName = ManageReports.GetReportOutputName(SystemReportId) + " For " + sType;
            string reportFilePath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName, FileOutputExt);
            string reportFullPath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportDirectory, reportFileName, FileOutputExt);
            DataSet[] lstDataSet;
            string[] sheetname;

            arrCBH_NATIONAL_ID = CBH_NATIONAL_ID.Split(',');
            lstDataSet = new DataSet[arrCBH_NATIONAL_ID.Length];
            sheetname = new string[arrCBH_NATIONAL_ID.Length];
            for (int i = 0; i < arrCBH_NATIONAL_ID.Length; i++)
            {
                DataSet dtSet = DataReaderUtilities.GetData(DBReference.ConnStr_BVReportDB, string.Format(@"EXEC dbo.wsp_{0} @CurrentRun = '{1}', @PreviousRun = '{2}', @CBH_NATIONAL_ID = '{3}', @TYPE = '{4}'", ReportID, CurrentRun, PreviousRun, arrCBH_NATIONAL_ID[i], TYPE));

                if (dtSet.Tables.Count > 0)
                    lstDataSet[i] = dtSet;

                sheetname[i] = arrCBH_NATIONAL_ID[i];
            }

            // Create workbook
            try
            {
                if (lstDataSet.Length > 0)
                {
                    if (!Directory.Exists(Path.GetDirectoryName(reportFullPath)))
                    {
                        Directory.CreateDirectory(Path.GetDirectoryName(reportFullPath));
                    }

                    ExportExcelObservation(reportFullPath, sheetname, lstDataSet, ReportID);
                }
                else
                {
                    FileComposer.ExportExcelForNoData(reportFullPath);
                    sMessage = "No Data";
                }

                Requestor = ManageReports.GetRequestor(rptInstanceId);
                ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);

                return sMessage;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }

        public static void ExportExcelObservation(string filename, string[] sheetName, DataSet[] lstDataSet, string ReportID)
        {
            string sFont = "Calibri";
            int iSize = 11;
            int iRowStart;
            int iFromCol = 1;
            var newFile = new FileInfo(filename);
            int iNumberColRecordofFert = 9;
            int iNumberColRecordofWorkAndConf = 6;
            int iNumberColRecordofSurvAndEase = 7;
            string[] sComparisonPlus = { "Yield and SCC", "Fertility", "Calving ease", "Workability", "Conformation", "Survival" };
            string sComparison = "Comparison of Extracted Observation Data for the xxx trait group ";
            string[] sLstRecord = { "Records present in the current extraction but missing from the previous", "Records present in the previous extraction but missing from the current", "Records present in both extractions, showing values from" };
            const string sNew = "------------------------------------------------------------------------------------------------------------------------------------";
            const string sComp2runs = "Comparison for two runs";
            const string sCompForbull = "Comparison for bull";
            string[] sTitle = new string[2];
            const string sTitleDif = "Difference";
            string sNoRecord = "No records found";
            string[] sListTitle2Area = { "Record Details", "Observations" };
            string[] sListTitle4Area = { "Record Details", "Lactation 1", "Lactation 2", "Lactation 3" };
            string[] sListComparison2runs = { "Current run", "Previous run" };
            string[] sListComparisonForBull = { "National ID", "Long Name", "Primary ID", "Owner" };
            string sBlue = "#00A2EA";
            string sGrey = "#D9D9D9";
            string sPink = "#FCE4D6";
            string sBlue2 = "#DAEEF3";
            string sPurple = "#E4DFEC";

            int iCountTable; ;
            int[] iCountRowTable;
            int[] iCountColTable;
            int[] iRowStarMakupTable;
            DataSet fileData;
            DataTable table;

            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                for (int iNoDataSet = 0; iNoDataSet < lstDataSet.Length; iNoDataSet++)
                {
                    fileData = lstDataSet[iNoDataSet];
                    iCountTable = fileData.Tables.Count;
                    iCountRowTable = new int[iCountTable];
                    iCountColTable = new int[iCountTable];
                    iRowStarMakupTable = new int[iCountTable];
                    iRowStart = 1;
                    for (int i = 0; i < fileData.Tables.Count; i++)
                    {
                        iCountRowTable[i] = fileData.Tables[i].Rows.Count;
                        iCountColTable[i] = fileData.Tables[i].Columns.Count;
                    }


                    ////Comparison of Extracted Observation Data for the fertility trait group 		
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(sheetName[iNoDataSet]);
                    if (iCountRowTable.Sum() < 3)
                    {
                        worksheet.Cells[1, 1].Value = "No Data";
                        continue;
                    }

                    switch (ReportID)
                    {
                        case "compare_ob_yield":
                            sComparison = sComparison.Replace("xxx", sComparisonPlus[0]);
                            break;
                        case "compare_ob_fert":
                            sComparison = sComparison.Replace("xxx", sComparisonPlus[1]);
                            break;
                        case "compare_ob_ease":
                            sComparison = sComparison.Replace("xxx", sComparisonPlus[2]);
                            break;
                        case "compare_ob_work":
                            sComparison = sComparison.Replace("xxx", sComparisonPlus[3]);
                            break;
                        case "compare_ob_conf":
                            sComparison = sComparison.Replace("xxx", sComparisonPlus[4]);
                            break;
                        case "compare_ob_surv":
                            sComparison = sComparison.Replace("xxx", sComparisonPlus[5]);
                            break;
                        default:
                            break;
                    }

                    iRowStart = PrintInfoTop(worksheet, fileData, iRowStart, iFromCol, sComparison, sComp2runs, sListComparison2runs, sCompForbull, sListComparisonForBull, ref sTitle);


                    //Print Layout
                    iRowStart += 2;
                    for (int i = 2; i < iCountTable; i++)
                    {
                        table = fileData.Tables[i];
                        if (i != iCountTable - 1)
                        {
                            iRowStart = PrintDescription(worksheet, sLstRecord[i - 2], sNew, iRowStart);

                            if (iCountRowTable[i] > 0)
                            {
                                iRowStart += 2;
                                if (i == 2 || i == 4)
                                {
                                    //Title current run
                                    PrintHeaderTitle(worksheet, iRowStart, iFromCol, sTitle[0], sBlue);
                                }
                                else
                                {
                                    //Title previous title run
                                    PrintHeaderTitle(worksheet, iRowStart, iFromCol, sTitle[1], sBlue);
                                }
                                iRowStart++;
                                iRowStarMakupTable[i] = iRowStart;
                                iRowStart++;
                                FillData(worksheet, table, iRowStart, iFromCol);
                            }
                            else
                            {
                                iRowStart++;
                                iRowStarMakupTable[i] = iRowStart;
                                worksheet.Cells[iRowStart, iFromCol].Value = sNoRecord;
                            }
                            iRowStart += iCountRowTable[i] + 2;

                        }
                        else
                        {

                            iRowStarMakupTable[i] = iRowStarMakupTable[i - 1];
                            if (iCountRowTable[i] > 0)
                            {
                                PrintHeaderTitle(worksheet, iRowStarMakupTable[i] - 1, iCountColTable[i - 1] + 2, sTitleDif, sBlue);
                                FillData(worksheet, table, iRowStarMakupTable[i] + 1, iCountColTable[i - 1] + 2);
                            }
                            else
                            {
                                continue;
                            }
                        }

                    }

                    //Makeup Table
                    switch (ReportID)
                    {
                        case "compare_ob_ease":
                        case "compare_ob_surv":
                            Export2Color(worksheet, fileData, iNumberColRecordofSurvAndEase, iRowStarMakupTable, iCountColTable, iFromCol, sListTitle2Area, sGrey, sPink, sFont, iSize);
                            break;
                        case "compare_ob_work":
                        case "compare_ob_conf":
                            Export2Color(worksheet, fileData, iNumberColRecordofWorkAndConf, iRowStarMakupTable, iCountColTable, iFromCol, sListTitle2Area, sGrey, sPink, sFont, iSize);
                            break;
                        case "compare_ob_fert":
                            Export2Color(worksheet, fileData, iNumberColRecordofFert, iRowStarMakupTable, iCountColTable, iFromCol, sListTitle2Area, sGrey, sPink, sFont, iSize);
                            break;
                        case "compare_ob_yield":
                            Export4Color(worksheet, fileData, iRowStarMakupTable, iCountColTable, iFromCol, sListTitle4Area, sGrey, sPink, sBlue2, sPurple, sFont, iSize);
                            break;
                        default:
                            break;
                    }
                }

                package.Save();
            }

        }

        //Print Infomation Top-Left 
        public static int PrintInfoTop(ExcelWorksheet worksheet, DataSet fileData, int iRowStart, int iFromCol, string sComparison, string sComp2runs, string[] sListComparison2runs, string sCompForbull, string[] sListComparisonForBull, ref string[] sTitle)
        {
            DataTable dTable;
            int iCountColum;
            int iBreak;
            string[] sRunTime;

            worksheet.Row(iRowStart).Merged = true;
            worksheet.Cells[iRowStart, iFromCol].Value = sComparison;
            worksheet.Cells[iRowStart, iFromCol].Style.Font.Bold = true;

            //Comparison for two runs
            iRowStart += 2;
            worksheet.Cells[iRowStart, iFromCol + 1].Value = sComp2runs;
            dTable = fileData.Tables[0];

            for (int i = 0; i < dTable.Columns.Count; i++)
            {
                if (dTable.Columns[i].ColumnName.Contains("CURRENT"))
                {
                    sTitle[0] = dTable.Rows[0][i].ToString();
                }
                else
                {
                    sTitle[1] = dTable.Rows[0][i].ToString();
                }
            }

            for (int i = 0; i < dTable.Columns.Count; i++)
            {
                iRowStart++;
                worksheet.Cells[iRowStart, iFromCol + 2].Value = sListComparison2runs[i];
                worksheet.Cells[iRowStart, iFromCol + 4].Value = sTitle[i];
                //sTitle[i] = dTable.Rows[0][i].ToString();
            }

            //Comparison for herd
            iRowStart += 2;
            dTable = fileData.Tables[1];
            worksheet.Cells[iRowStart, iFromCol + 1].Value = dTable.Rows[0][0];
            iCountColum = dTable.Columns.Count - 1;
            iBreak = iCountColum / 2;

            for (int i = 1; i <= iBreak; i++)
            {
                iRowStart++;
                worksheet.Cells[iRowStart, iFromCol + 2].Value = dTable.Rows[0][i];
                worksheet.Cells[iRowStart, iFromCol + 4].Value = dTable.Rows[0][i + iBreak];
            }

            return iRowStart;
        }

        //Print Description Top of Table
        public static int PrintDescription(ExcelWorksheet worksheet, string title, string sNew, int iRowStart)
        {
            worksheet.Row(iRowStart).Merged = true;
            worksheet.Cells[iRowStart, 1].Value = sNew;
            iRowStart += 2;
            worksheet.Row(iRowStart).Merged = true;
            worksheet.Cells[iRowStart, 1].Value = title;
            worksheet.Cells[iRowStart, 1].Style.Font.Bold = true;

            return iRowStart;
        }

        //Print Title top of Table
        public static void PrintHeaderTitle(ExcelWorksheet worksheet, int iRowStart, int iFromCol, string sTitle, string color)
        {
            worksheet.Cells[iRowStart, iFromCol].Style.Font.Bold = true;
            worksheet.Cells[iRowStart, iFromCol].Value = sTitle;
            worksheet.Cells[iRowStart, iFromCol].Style.Font.Color.SetColor(ColorTranslator.FromHtml(color));
        }

        //Print header in table
        public static void PrintTableTitle(ExcelWorksheet worksheet, int iRowStart, int iColumStart, int iColumFinish, string title)
        {
            worksheet.Cells[iRowStart, iColumStart, iRowStart, iColumFinish].Merge = true;
            worksheet.Cells[iRowStart, iColumStart].Value = title;
            worksheet.Cells[iRowStart, iColumStart].Style.Font.Bold = true;
            worksheet.Cells[iRowStart, iColumStart, iRowStart, iColumFinish].Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
            worksheet.Cells[iRowStart, iColumStart, iRowStart, iColumFinish].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
            //worksheet.Cells[iRowStart, iColumStart, iRowStart, iColumFinish].AutoFitColumns();
        }

        //Fill border 
        public static void FillBorder(ExcelWorksheet worksheet, int iRowStart, int iFromCol, int iRowFinish, int iFinishCol)
        {
            var range = worksheet.Cells[iRowStart, iFromCol, iRowFinish, iFinishCol].Style;
            range.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
            range.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
            range.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
            range.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
        }

        //Fill color
        public static void FillColor(ExcelWorksheet worksheet, int iRowStart, int iColumStart, int iRowFinish, int iColumFinish, string color)
        {
            worksheet.Cells[iRowStart, iColumStart, iRowFinish, iColumFinish].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
            worksheet.Cells[iRowStart, iColumStart, iRowFinish, iColumFinish].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(color));
        }

        //Fill Data
        public static int FillData(ExcelWorksheet worksheet, DataTable Table, int iRowStart, int iFromCol)
        {
            int iRowStartInExcel = iRowStart;
            int iColStartInExcel = iFromCol;
            int iColFinishInExcel = 0;
            int iCountCol = Table.Columns.Count;
            int iRowCount = Table.Rows.Count;

            for (int i = 0; i < iCountCol; i++)
            {
                worksheet.Cells[iRowStart, iFromCol + i].Value = Table.Columns[i].ColumnName.Replace("1", "").Replace("2", "");
                worksheet.Cells[iRowStart, iFromCol + i].Style.Font.Bold = true;
                worksheet.Cells[iRowStart, iFromCol + i].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                iColFinishInExcel = iFromCol + i;
            }

            iRowStart++;

            for (int i = 0; i < iRowCount; i++)
            {
                for (int j = 0; j < iCountCol; j++)
                {
                    worksheet.Cells[iRowStart, iFromCol + j].Value = Table.Rows[i][j];
                    worksheet.Cells[iRowStart, iFromCol + j].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                }

                iRowStart++;
            }

            worksheet.Cells[iRowStartInExcel, iColStartInExcel, iRowStart, iColFinishInExcel].AutoFitColumns(13);

            return iRowStart;
        }

        //Make up excel for Fert
        public static string Export2Color(ExcelWorksheet worksheet, DataSet fileData, int iNumberColRecord, int[] iRowStarMakupTable, int[] iCountColTable, int iFromCol, string[] sListTitle, string colorGrey, string colorPink, string sFont, int iSize)
        {
            int iCountTable = fileData.Tables.Count;
            int iCountColumn;
            int iRowCount;

            try
            {
                for (int i = 2; i < iCountTable; i++)
                {

                    iCountColumn = fileData.Tables[i].Columns.Count;
                    iRowCount = fileData.Tables[i].Rows.Count;

                    if (i != iCountTable - 1 && iRowCount > 0)
                    {
                        PrintTableTitle(worksheet, iRowStarMakupTable[i], iFromCol, iNumberColRecord, sListTitle[0]);
                        PrintTableTitle(worksheet, iRowStarMakupTable[i], iFromCol + iNumberColRecord, iCountColumn, sListTitle[1]);
                        worksheet.Cells[iRowStarMakupTable[i], iFromCol + iNumberColRecord, iRowStarMakupTable[i], iCountColumn].AutoFitColumns(14);
                        FillColor(worksheet, iRowStarMakupTable[i], iFromCol, iRowStarMakupTable[i] + 1, iNumberColRecord, colorGrey);
                        FillColor(worksheet, iRowStarMakupTable[i], iFromCol + iNumberColRecord, iRowCount + iRowStarMakupTable[i] + 1, iCountColumn, colorPink);

                        iRowStarMakupTable[i]++;
                        FillBorder(worksheet, iRowStarMakupTable[i], iFromCol, iRowCount + iRowStarMakupTable[i], iCountColumn);
                    }
                    else if (i == iCountTable - 1 && iRowCount > 0)
                    {
                        PrintTableTitle(worksheet, iRowStarMakupTable[i], iCountColTable[i - 1] + 2, iCountColTable[i - 1] + 1 + iCountColumn, sListTitle[1]);
                        FillBorder(worksheet, iRowStarMakupTable[i], iCountColTable[i - 1] + 2, iRowCount + iRowStarMakupTable[i] + 1, iCountColTable[i - 1] + 1 + iCountColumn);
                        FillColor(worksheet, iRowStarMakupTable[i], iCountColTable[i - 1] + 2, iRowCount + iRowStarMakupTable[i] + 1, iCountColTable[i - 1] + 1 + iCountColumn, colorPink);
                        worksheet.Cells[1, 1, iRowCount + iRowStarMakupTable[i] + 1, iCountColTable[i - 1] + 1 + iCountColumn].Style.Font.Name = sFont;
                        worksheet.Cells[1, 1, iRowCount + iRowStarMakupTable[i] + 1, iCountColTable[i - 1] + 1 + iCountColumn].Style.Font.Size = iSize;
                    }
                }

                return "OK";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public static string Export4Color(ExcelWorksheet worksheet, DataSet fileData, int[] iRowStarMakupTable, int[] iCountColTable, int iFromCol, string[] sListTitle, string colorGrey, string colorPink, string colorBlue, string colorPurple, string sFont, int iSize)
        {
            int iCountTable = fileData.Tables.Count;
            int iColStart = iFromCol;
            int iCountColumn;
            int iRowCount;

            try
            {
                for (int i = 2; i < iCountTable; i++)
                {
                    iCountColumn = fileData.Tables[i].Columns.Count;
                    iRowCount = fileData.Tables[i].Rows.Count;

                    if (i != iCountTable - 1 && iRowCount > 0)
                    {
                        iColStart = iFromCol;

                        PrintTableTitle(worksheet, iRowStarMakupTable[i], iColStart, iColStart += 5, sListTitle[0]);
                        PrintTableTitle(worksheet, iRowStarMakupTable[i], iColStart += 1, iColStart += 6, sListTitle[1]);
                        PrintTableTitle(worksheet, iRowStarMakupTable[i], iColStart += 1, iColStart += 6, sListTitle[2]);
                        PrintTableTitle(worksheet, iRowStarMakupTable[i], iColStart += 1, iColStart += 6, sListTitle[3]);

                        iColStart = iFromCol;

                        FillColor(worksheet, iRowStarMakupTable[i], iColStart, iRowStarMakupTable[i] + 1, iColStart += 5, colorGrey);
                        FillColor(worksheet, iRowStarMakupTable[i], iColStart += 1, iRowCount + iRowStarMakupTable[i] + 1, iColStart += 6, colorPink);
                        FillColor(worksheet, iRowStarMakupTable[i], iColStart += 1, iRowCount + iRowStarMakupTable[i] + 1, iColStart += 6, colorBlue);
                        FillColor(worksheet, iRowStarMakupTable[i], iColStart += 1, iRowCount + iRowStarMakupTable[i] + 1, iColStart += 6, colorPurple);

                        iRowStarMakupTable[i]++;
                        FillBorder(worksheet, iRowStarMakupTable[i], iFromCol, iRowCount + iRowStarMakupTable[i], iCountColumn);
                    }
                    else if (i == iCountTable - 1 && iRowCount > 0)
                    {
                        PrintTableTitle(worksheet, iRowStarMakupTable[i], iColStart += 2, iColStart += 8, sListTitle[1]);
                        PrintTableTitle(worksheet, iRowStarMakupTable[i], iColStart += 1, iColStart += 7, sListTitle[2]);
                        PrintTableTitle(worksheet, iRowStarMakupTable[i], iColStart += 1, iColStart += 7, sListTitle[3]);

                        FillBorder(worksheet, iRowStarMakupTable[i], iCountColTable[i - 1] + 2, iRowCount + iRowStarMakupTable[i] + 1, 53);

                        FillColor(worksheet, iRowStarMakupTable[i], iCountColTable[i - 1] + 2, iRowCount + iRowStarMakupTable[i] + 1, iCountColTable[i - 1] + 1 + iCountColumn - 1, colorPink);
                        FillColor(worksheet, iRowStarMakupTable[i], 38, iRowCount + iRowStarMakupTable[i] + 1, 45, colorBlue);
                        FillColor(worksheet, iRowStarMakupTable[i], 46, iRowCount + iRowStarMakupTable[i] + 1, 53, colorPurple);
                        worksheet.Cells[1, 1, iRowCount + iRowStarMakupTable[i] + 1, iCountColTable[i - 1] + 1 + iCountColumn - 1].Style.Font.Name = sFont;
                        worksheet.Cells[1, 1, iRowCount + iRowStarMakupTable[i] + 1, iCountColTable[i - 1] + 1 + iCountColumn - 1].Style.Font.Size = iSize;
                    }

                }

                return "OK";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

    }
}
