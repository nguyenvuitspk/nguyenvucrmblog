using DataReaderUtilsLib;
using NetworkShareHelper;
using OfficeOpenXml;
using System;
using System.Data;
using System.IO;
using System.Linq;

namespace ABVReportLib
{
    public class CDRCompareReports : ABVReport
    {
        public CDRCompareReports(string reportName) : base(reportName)
        {
            FileOutputExt = "xlsx";
        }

        public override string GenerateReportWithMessage(int rptInstanceId)
        {
            string sMessage = "";
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            DateTime reportTime = DateTime.Now;
            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportTime.Ticks.ToString());
            string reportFileName = ManageReports.GetReportOutputName(SystemReportId);
            string reportFilePath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName, FileOutputExt);
            string reportFullPath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportDirectory, reportFileName, FileOutputExt);

            string fileXML = ReportParameters.Where(x => x.ParamName == "param_xmlSearchFields").Select(x => x.ParamValue).First();
            string forType = ReportParameters.Where(x => x.ParamName == "forType").Select(x => x.ParamValue).First();
            string[] arrAnimalList = { "" };

            // Create workbook
            try
            {
                DataTable dtTable = DataReaderUtilities.GetData(ReportDBConnString, string.Format(@"EXEC dbo.wsp_EXPORT_FILE @searchFields = '{0}', @forType = '{1}'", fileXML, forType)).Tables[0];
                if (dtTable.Rows.Count > 0)
                {
                    if (!Directory.Exists(Path.GetDirectoryName(reportFullPath)))
                    {
                        SharedGNetworkAccess web_directory_bin = new SharedGNetworkAccess("WEB_DIRECTORY_BIN");
                        using (new NetworkConnection(web_directory_bin.RootFolder, new System.Net.NetworkCredential(web_directory_bin.Username, web_directory_bin.Password)))
                        {
                            Directory.CreateDirectory(Path.GetDirectoryName(reportFullPath));
                        }
                    }

                    if (fileXML.Contains(ABVReportConstant.MULTI_ANIMAL_NATIONAL_ID))
                        arrAnimalList = FileComposer.splitXML(fileXML, ABVReportConstant.MULTI_ANIMAL_NATIONAL_ID);
                    else
                        arrAnimalList[0] = FileComposer.splitXML(fileXML, ABVReportConstant.ANIMAL_NATIONAL_ID, "Value=\"", "\"");

                    ExportExcelCompare(reportFullPath, reportFileName, dtTable, arrAnimalList, forType);
                }
                else
                {
                    FileComposer.ExportExcelForNoData(reportFullPath);
                    sMessage = "No Data";
                }

                Requestor = ManageReports.GetRequestor(rptInstanceId);
                ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);

                return sMessage;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public static void ExportExcelCompare(string fileName, string sheetName, DataTable fileData, string[] arrAnimalList, string forType = "BULL_SINGLE_RELEASE")
        {
            string sFont = "Segoe UI";
            string[] arrayPositionRunType = { "ABV", "DGV", "uHat", "ABVg", "FINAL_BV" };
            int iCountMenuCommon = 9;
            int iRowStart = 0;
            int iPosition;
            int iCountRelease = 0;
            int iCountColumn = 0;
            int iFromCol = 1;
            int iLengthAnimalList = 0;
            string sAnimalCondition;
            int iPositionIndeicesMenu = 14;
            var newFile = new FileInfo(fileName);

            DataTable[] dtTable = new DataTable[arrAnimalList.Length];
            DataRow[] dtRows;
            ExcelWorksheet worksheet;

            if (arrAnimalList == null)
                return;

            if (newFile.Exists)
            {
                newFile.Delete(); // ensures we create a new workbook
                newFile = new FileInfo(fileName);
            }

            // Filter animal
            for (int i = 0; i < arrAnimalList.Length; i++)
            {
                sAnimalCondition = $"ANIMAL_NATIONAL_ID = '{ arrAnimalList[i]}'";
                dtRows = fileData.Select(sAnimalCondition);
                if (dtRows.Length > 0)
                {
                    dtTable[iLengthAnimalList] = dtRows.CopyToDataTable();
                    for(int iPositionRun = 0; iPositionRun < arrayPositionRunType.Length; iPositionRun++)
                    {
                        DataRow selectRow = dtTable[iLengthAnimalList].AsEnumerable().FirstOrDefault(src => string.Compare(src["RUN_TYPE"].ToString(), arrayPositionRunType[iPositionRun]) == 0);
                        if(selectRow != null)
                        {
                            DataRow newRow = dtTable[iLengthAnimalList].NewRow();
                            newRow.ItemArray = selectRow.ItemArray;
                            dtTable[iLengthAnimalList].Rows.Remove(selectRow);
                            dtTable[iLengthAnimalList].Rows.InsertAt(newRow, iPositionRun);
                        }                        
                    }
                    iLengthAnimalList++;
                }
            }

            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                for (int iAnimalCount = 0; iAnimalCount < iLengthAnimalList; iAnimalCount++)
                {
                    //get ANIMAL_NATIONAL_ID
                    iPosition = 0;
                    sheetName = dtTable[iAnimalCount].Rows[0][iPosition].ToString();
                    if (dtTable[iAnimalCount].Rows.Count > 0)
                    {
                        worksheet = package.Workbook.Worksheets.Add(sheetName);
                        iRowStart = 1;
                        worksheet.Cells[iRowStart, iRowStart].Value = dtTable[iAnimalCount].Rows[0][iPosition];
                        worksheet.Cells[iRowStart, iRowStart].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                        //1. For common menu
                        iPosition = 2;
                        if (forType.Contains("COW") == true)
                            iCountMenuCommon = 9;
                        else
                            iCountMenuCommon = 8;

                        for (int i = iPosition; i <= iCountMenuCommon; i++)
                        {
                            iRowStart++;
                            worksheet.Cells[i, 1].Value = dtTable[iAnimalCount].Columns[i].ColumnName.Replace("_ID", "");
                            worksheet.Cells[i, 1].Style.Font.Name = sFont;
                            worksheet.Cells[i, 1].Style.Font.Size = 10;
                            iPosition++;
                        }

                        //2. For indices menu
                        iRowStart++;
                        worksheet.Cells[iRowStart, 1].Value = "Indices";
                        worksheet.Cells[iRowStart, 1].Style.Font.Bold = true;
                        worksheet.Cells[iRowStart, 1].Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        worksheet.Cells[iRowStart, 1].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                        iPositionIndeicesMenu = iCountMenuCommon + 8;

                        for (int i = iPosition; i < iPositionIndeicesMenu; i += 2)
                        {
                            iRowStart++;
                            worksheet.Cells[iRowStart, 1].Value = dtTable[iAnimalCount].Columns[i].ColumnName.Replace("_BV", "").Replace("_REL", "");
                            worksheet.Cells[iRowStart, 1].Style.Font.Name = sFont;
                            worksheet.Cells[iRowStart, 1].Style.Font.Size = 9;
                            iPosition += 2;
                        }

                        //3. For Traits menu
                        iRowStart++;
                        worksheet.Cells[iRowStart, 1].Value = "Traits";
                        worksheet.Cells[iRowStart, 1].Style.Font.Bold = true;
                        worksheet.Cells[iRowStart, 1].Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        worksheet.Cells[iRowStart, 1].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                        iCountColumn = dtTable[iAnimalCount].Columns.Count;

                        for (int i = iPosition; i < iCountColumn; i += 2)
                        {
                            iRowStart++;
                            worksheet.Cells[iRowStart, 1].Value = dtTable[iAnimalCount].Columns[i].ColumnName.Replace("_BV", "").Replace("_REL", "");
                            worksheet.Cells[iRowStart, 1].Style.Font.Name = sFont;
                            worksheet.Cells[iRowStart, 1].Style.Font.Size = 9;
                            iPosition += 2;
                        }

                        //draw border
                        worksheet.Cells[1, 1, iRowStart, 1].Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        worksheet.Cells[iRowStart, 1].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                        //4. Fill data
                        iCountRelease = dtTable[iAnimalCount].Rows.Count;
                        for (int iRelease = 1; iRelease <= iCountRelease; iRelease++)
                        {
                            iFromCol = iRelease * 2;
                            iRowStart = 1;
                            iPosition = 1;

                            //a. Common values
                            for (iPosition = 1; iPosition <= iCountMenuCommon; iPosition++)
                            {
                                worksheet.Cells[iRowStart, iFromCol, iRowStart, iFromCol + 1].Merge = true;
                                worksheet.Cells[iRowStart, iFromCol].Value = dtTable[iAnimalCount].Rows[iRelease - 1][iPosition];
                                iRowStart++;
                            }

                            //b. Indice values
                            worksheet.Cells[iRowStart, iFromCol].Value = "BV";
                            worksheet.Cells[iRowStart, iFromCol + 1].Value = "Rel";
                            worksheet.Cells[iRowStart, iFromCol].Value = "BV";
                            worksheet.Cells[iRowStart, iFromCol + 1].Value = "Rel";
                            worksheet.Cells[iRowStart, iFromCol, iRowStart, iFromCol + 1].Style.Font.Bold = true;
                            worksheet.Cells[iRowStart, iFromCol, iRowStart, iFromCol + 1].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            worksheet.Cells[iRowStart, iFromCol, iRowStart, iFromCol + 1].Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                            for (int iColInDataTable = iPosition; iColInDataTable < iPositionIndeicesMenu; iColInDataTable += 2)
                            {
                                iRowStart++;
                                iPosition += 2;
                                //BV
                                worksheet.Cells[iRowStart, iFromCol].Value = dtTable[iAnimalCount].Rows[iRelease - 1][iColInDataTable];
                                //Rel
                                worksheet.Cells[iRowStart, iFromCol + 1].Value = dtTable[iAnimalCount].Rows[iRelease - 1][iColInDataTable + 1];
                            }
                            iRowStart++;

                            //c.Traits values
                            worksheet.Cells[iRowStart, iFromCol].Value = "BV";
                            worksheet.Cells[iRowStart, iFromCol + 1].Value = "Rel";
                            worksheet.Cells[iRowStart, iFromCol, iRowStart, iFromCol + 1].Style.Font.Bold = true;
                            worksheet.Cells[iRowStart, iFromCol, iRowStart, iFromCol + 1].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            worksheet.Cells[iRowStart, iFromCol, iRowStart, iFromCol + 1].Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                            for (int iColInDataTable = iPosition ; iColInDataTable < iCountColumn; iColInDataTable += 2)
                            {
                                iRowStart++;
                                iPosition += 2;
                                //BV
                                worksheet.Cells[iRowStart, iFromCol].Value = dtTable[iAnimalCount].Rows[iRelease - 1][iColInDataTable];
                                //Rel
                                worksheet.Cells[iRowStart, iFromCol + 1].Value = dtTable[iAnimalCount].Rows[iRelease - 1][iColInDataTable + 1];
                            }
                            worksheet.Cells[1, iFromCol, iRowStart, iFromCol + 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            worksheet.Cells[1, iFromCol + 1, iRowStart, iFromCol + 1].Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        }

                        //Format boder, font, width
                        worksheet.Cells[1, 1, 1, iFromCol + 1].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        worksheet.Cells[1, 2, 1, iFromCol].Style.Font.Bold = true;

                        worksheet.Cells[iRowStart, 1, iRowStart, iFromCol + 1].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        for (int iAutoFit = 1; iAutoFit <= iFromCol + 1; iAutoFit++)
                        {
                            worksheet.Column(iAutoFit).AutoFit(15);
                        }
                    }
                }

                package.Save();
            }
        }
    }
}