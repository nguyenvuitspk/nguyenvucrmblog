﻿using DataReaderUtilsLib;
using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using OfficeOpenXml;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.IO;
using SQLUtilsLib;
namespace ABVReportLib.CDR_Reports
{
    public class CDRCompareBull : ABVReport
    {
        public CDRCompareBull(string reportName) : base(reportName)
        {
            FileOutputExt = "xlsx";
        }
        public override string GenerateReportWithMessage(int rptInstanceId)
        {
            string sMessage = "";
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            DateTime reportTime = DateTime.Now;
            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportTime.Ticks.ToString());
            string reportFileName = ManageReports.GetReportOutputName(SystemReportId);
            string reportFilePath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName, FileOutputExt);
            string reportFullPath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportDirectory, reportFileName, FileOutputExt);

            string fileXML = ReportParameters.Where(x => x.ParamName == "param_xmlSearchFields").Select(x => x.ParamValue).First();
            string forType = ReportParameters.Where(x => x.ParamName == "forType").Select(x => x.ParamValue).First();
            string[] arrAnimalList = { "" };

            // Create workbook
            try
            {
                DataTable dtTable = DataReaderUtilities.GetData(ReportDBConnString, string.Format(@"EXEC dbo.wsp_EXPORT_FILE @searchFields = '{0}', @forType = '{1}'", fileXML, forType)).Tables[0];
                if (dtTable.Rows.Count > 0)
                {
                    if (!Directory.Exists(Path.GetDirectoryName(reportFullPath)))
                    {
                        Directory.CreateDirectory(Path.GetDirectoryName(reportFullPath));
                    }

                    if (fileXML.Contains(ABVReportConstant.MULTI_ANIMAL_NATIONAL_ID))
                        arrAnimalList = FileComposer.splitXML(fileXML, ABVReportConstant.MULTI_ANIMAL_NATIONAL_ID);
                    else
                        arrAnimalList[0] = FileComposer.splitXML(fileXML, ABVReportConstant.ANIMAL_NATIONAL_ID, "Value=\"", "\"");

                    ExportExcelCompare(reportFullPath, reportFileName, dtTable, arrAnimalList);
                }
                else
                {
                    FileComposer.ExportExcelForNoData(reportFullPath);
                    sMessage = "No Data";
                }

                Requestor = ManageReports.GetRequestor(rptInstanceId);
                ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);

                return sMessage;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }

        public static void ExportExcelCompare(string fileName, string sheetName, DataTable fileData, string[] arrAnimalList)
        {
            //string[] listMenuCommon = { "Sire", "Dam", "MGS", "Herd", "Birth", "BPI BV", "BPI Rel" };
            //string[] listHeader2 = {"bpi","asi","hwi","twi","fat","fatp","milk","prot","protp","angul","bcs","bodyd","bodyl","bone","centl","chestw", "foota", "forea", "loin", "mamm", "muzw", "otype","pinset","pinw",
            //"rearah","rearaw","rleg","rset","rumpl","stat","teatl","teatpf","teatpr","uddep","udtex","like","mspeed","temp","ease","fert","lwt","surv","survdi","scc"};
            string sFont = "Segoe UI";
            int iCountMenuCommon = 26;
            int iRowStart = 0;
            int iColumnStart = 0;
            int iCountRelease = 0;
            int iCountColumn = 0;
            //int iToCol;
            int iFromCol = 1;
            int iRow = 1 ;
            int iTotalRow;
            int iLengthAnimalList = 0;
            string sAnimalCondition;
            var newFile = new FileInfo(fileName);

            DataTable[] dtTable = new DataTable[arrAnimalList.Length];
            DataRow[] dtRows;
            ExcelWorksheet worksheet;

            if (arrAnimalList == null)
                return;

            if (newFile.Exists)
            {
                newFile.Delete(); // ensures we create a new workbook
                newFile = new FileInfo(fileName);
            }

            // Filter animal
            for (int i = 0; i < arrAnimalList.Length; i++)
            {
                sAnimalCondition = "ANIMAL_NATIONAL_ID = '" + arrAnimalList[i] + "'";
                dtRows = fileData.Select(sAnimalCondition);
                if (dtRows.Length > 0)
                {
                    dtTable[iLengthAnimalList] = dtRows.CopyToDataTable();
                    iLengthAnimalList++;
                }
            }

            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                for (int iAnimalCount = 0; iAnimalCount < iLengthAnimalList; iAnimalCount++)
                {
                    //get ANIMAL_NATIONAL_ID
                    sheetName = dtTable[iAnimalCount].Rows[0][iColumnStart].ToString();
                    if (dtTable[iAnimalCount].Rows.Count > 0)
                    {
                        worksheet = package.Workbook.Worksheets.Add(sheetName);
                        iRowStart = 1;
                        worksheet.Cells[iRowStart, iRowStart].Value = dtTable[iAnimalCount].Rows[0][iColumnStart];
                        worksheet.Cells[iRowStart, iRowStart].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                        //1. For common menu
                        for (int i = 2; i <= iCountMenuCommon; i++)
                        {
                            iRowStart++;
                            worksheet.Cells[i, 1].Value = dtTable[iAnimalCount].Columns[i].ColumnName.Replace("_ID", "");
                            worksheet.Cells[i, 1].Style.Font.Name = sFont;
                            worksheet.Cells[i, 1].Style.Font.Size = 10;
                        }

                        //2. For indices menu
                        iRowStart++;
                        worksheet.Cells[iRowStart, 1].Value = "Trait";
                        worksheet.Cells[iRowStart, 1].Style.Font.Bold = true;
                        worksheet.Cells[iRowStart, 1].Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        worksheet.Cells[iRowStart, 1].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                        iCountColumn = dtTable[iAnimalCount].Columns.Count;
                        iTotalRow = (iCountColumn / 2) + (iCountMenuCommon - 1);

                        for (int i = iCountMenuCommon +1 ; i < iCountColumn; i+=2)
                        {
                            iRowStart++;
                            worksheet.Cells[iRowStart, 1].Value = dtTable[iAnimalCount].Columns[i].ColumnName.Replace("_BV", "").Replace("_REL", "");
                            worksheet.Cells[iRowStart, 1].Style.Font.Name = sFont;
                            worksheet.Cells[iRowStart, 1].Style.Font.Size = 9;
                        }

                        //draw border
                        worksheet.Cells[1, 1, iRowStart, 1].Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        worksheet.Cells[iRowStart, 1].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                        //3. Fill data
                        iCountRelease = dtTable[iAnimalCount].Rows.Count;
                        for (int iRelease = 1; iRelease <= iCountRelease; iRelease++)
                        {
                            iFromCol = iRelease * 2;

                            //a. Common values 
                            for (iRow = 1; iRow <= iCountMenuCommon; iRow++)
                            {
                                worksheet.Cells[iRow, iFromCol, iRow, iFromCol + 1].Merge = true;
                                worksheet.Cells[iRow, iFromCol].Value = dtTable[iAnimalCount].Rows[iRelease - 1][iRow];
                                //worksheet.Cells[iRow, iFromCol].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            }
                            //worksheet.Cells[iRow, iFromCol, iRow, iFromCol + 1].Merge = true;
                            //worksheet.Cells[1, iFromCol + 1, iTotalRow, iFromCol + 1].Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            //iRow++;

                            //b. Indice values
                            worksheet.Cells[iRow, iFromCol].Value = "BV";
                            worksheet.Cells[iRow, iFromCol + 1].Value = "Rel";
                            worksheet.Cells[iRow, iFromCol, iRow, iFromCol + 1].Style.Font.Bold = true;
                            worksheet.Cells[iRow, iFromCol, iRow, iFromCol + 1].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            worksheet.Cells[iRow, iFromCol, iRow, iFromCol + 1].Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                            for (int iColInDataTable = iCountMenuCommon+1; iColInDataTable < iCountColumn; iColInDataTable += 2)
                            {
                                iRow++;
                                //BV
                                worksheet.Cells[iRow, iFromCol].Value = dtTable[iAnimalCount].Rows[iRelease - 1][iColInDataTable - 1];
                                //Rel
                                worksheet.Cells[iRow, iFromCol + 1].Value = dtTable[iAnimalCount].Rows[iRelease - 1][iColInDataTable];
                                
                            }
                            worksheet.Cells[1, iFromCol + 1, iRow, iFromCol + 1].Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            worksheet.Cells[1, iFromCol, iRow, iFromCol].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            worksheet.Cells[1, iFromCol + 1, iRow, iFromCol + 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                        }

                        //Format boder, font, width
                        worksheet.Cells[1, 1, 1, iFromCol + 1].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        worksheet.Cells[1, 2, 1, iFromCol].Style.Font.Bold = true;
                        
                        worksheet.Cells[iRow, 1, iRow, iFromCol + 1].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                        for (int iAutoFit = 1; iAutoFit <= iFromCol + 1; iAutoFit++)
                        {
                            worksheet.Column(iAutoFit).AutoFit(15);
                        }
                    }

                }


                package.Save();
            }
        }

    }
}
