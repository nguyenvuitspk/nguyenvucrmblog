﻿using DataReaderUtilsLib;
using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using OfficeOpenXml;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.IO;
using SQLUtilsLib;
using System.Drawing;

namespace ABVReportLib
{
    public class CDRGenotype : ABVReport
    {
        public CDRGenotype(string reportName) : base(reportName)
        {
            FileOutputExt = "xlsx";
        }

        public override string GenerateReportWithMessage(int rptInstanceId)
        {
            string sMessage = "";
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            string ANIMAL_LIST = ReportParameters.Where(x => x.ParamName == "ANIMAL_LIST").Select(x => x.ParamValue).First();
            string FROM_DATE_LINKED = ReportParameters.Where(x => x.ParamName == "FROM_DATE_LINKED").Select(x => x.ParamValue).First();
            string TO_DATE_LINKED = ReportParameters.Where(x => x.ParamName == "TO_DATE_LINKED").Select(x => x.ParamValue).First();
            string TYPE = ReportParameters.Where(x => x.ParamName == "TYPE").Select(x => x.ParamValue).First();

            DateTime reportTime = DateTime.Now;
            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportTime.Ticks.ToString());
            string reportFileName = ManageReports.GetReportOutputName(SystemReportId);
            string reportFilePath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName, FileOutputExt);
            string reportFullPath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportDirectory, reportFileName, FileOutputExt);

            // Create workbook
            try
            {
                DataTable dtTable = DataReaderUtilities.GetData(DBReference.ConnStr_DV, string.Format(@"EXEC dbo.wsp_genotype_load_report @ANIMAL_LIST = '{0}', @FROM_DATE_LINKED = '{1}', @TO_DATE_LINKED = '{2}', @TYPE = '{3}'", ANIMAL_LIST, FROM_DATE_LINKED, TO_DATE_LINKED, TYPE)).Tables[0];


                if (dtTable.Rows.Count > 0)
                {
                    if (!Directory.Exists(Path.GetDirectoryName(reportFullPath)))
                    {
                        Directory.CreateDirectory(Path.GetDirectoryName(reportFullPath));
                    }

                    FileComposer.ExportExcelFileWithOutTemplate(dtTable, reportFullPath, reportFileName);
                }
                else
                {
                    FileComposer.ExportExcelForNoData(reportFullPath);
                    sMessage = "No Data";
                }

                Requestor = ManageReports.GetRequestor(rptInstanceId);
                ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);

                return sMessage;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }


    }
}
