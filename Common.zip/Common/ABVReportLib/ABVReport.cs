﻿using DataReaderUtilsLib;
using SQLUtilsLib;
using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ABVReportLib.Export;
using System.Data;

namespace ABVReportLib
{
    public class ABVReport : SSRSReport
    {
        #region Properties

        public string ReportName { get; set; }
        public int SystemReportId { get; set; }
        public string Requestor { get; set; }
        public string ReportDBConnString { get; set; }
        public string FileOutputExt { get; set; }

        #endregion

        #region Constructors

        public ABVReport(string reportName) : base()
        {
            ReportServer server = ManageReports.GetReportServerInformation();
            base.ReportServiceURL = server.ReportServiceURL;
            base.ReportServiceUsername = server.ReportServiceUsername;
            base.ReportServicePassword = server.ReportServicePassword;
            ReportDBConnString = server.ReportDBConnString;

            base.ProjectName = "ABVReport";
            base.ReportID = reportName;

            ReportName = reportName;
            SystemReportId = ManageReports.GetSystemReportId(ReportID);
        }

        #endregion

        #region Methods

        public virtual int SubmitReport(string requestor, List<ReportParameter> parameters)
        {
            return ManageReports.SubmitReport(SystemReportId, requestor, parameters);
        }

        public virtual string GetRequestorName(string sessionID)
        {
            return ManageReports.GetRequestorName(sessionID);
        }

        public virtual void GenerateReport(int rptInstanceId)
        {

        }

        public virtual string GenerateReportWithMessage(int rptInstanceId)
        {
            return "";
        }

        public static Dictionary<string, object> AddReportObject(string reportFullPath, string reportFileName)
        {
            Dictionary<string, object> reportMessage = new Dictionary<string, object>();
            reportMessage.Add("Message", reportFullPath);
            reportMessage.Add("FileName", reportFileName);
            return reportMessage;
        }

        public virtual IDictionary<string, object> GenerateReportWithDictionary(int rptInstanceId, int sessionId)
        {
            Dictionary<string, object> reportMessage = new Dictionary<string, object>();
            return reportMessage;
        }

        public void GenerateReports(int rptInstanceId, string[] fileTypes, string fileXML = "", string forType = "", string party = "",
            string rptfileName = "", string oneClickQuery = "", DataTable fileTags = null, string reportFolder = "", int SessionId = 0)
        {
            Requestor = ManageReports.GetRequestor(rptInstanceId);
            foreach (var fType in fileTypes)
            {
                try
                {
                    switch (fType.ToLower())
                    {
                        case "pdf":
                            GetReport(rptInstanceId, ReportFileType.PDF, fileXML, forType, party, rptfileName, oneClickQuery, fileTags, reportFolder);
                            break;
                        case "xlsx":
                            GetReport(rptInstanceId, ReportFileType.EXCELOPENXML, fileXML, forType, party, rptfileName, oneClickQuery, fileTags, reportFolder, SessionId);
                            break;
                        case "dif":
                            GetReport(rptInstanceId, ReportFileType.DIF, fileXML, forType, party, rptfileName, oneClickQuery, fileTags, reportFolder, SessionId);
                            break;
                        case "txt":
                            GetReport(rptInstanceId, ReportFileType.TXT);
                            break;
                        default:
                            break;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public Dictionary<string, object> GenerateWebsiteReports(int rptInstanceId, string[] fileTypes, string fileXML = "", string forType = "")
        {
            Requestor = ManageReports.GetRequestor(rptInstanceId);
            Dictionary<string, object> reportMessage = new Dictionary<string, object>();
            foreach (var fType in fileTypes)
            {
                switch (fType.ToLower())
                {
                    case "pdf":
                        reportMessage = GetWebsiteReport(rptInstanceId, ReportFileType.PDF, fileXML, forType);
                        break;
                    case "xlsx":
                        reportMessage = GetWebsiteReport(rptInstanceId, ReportFileType.EXCELOPENXML, fileXML, forType);
                        break;
                    case "dif":
                        reportMessage = GetWebsiteReport(rptInstanceId, ReportFileType.DIF, fileXML, forType);
                        break;
                    case "txt":
                        reportMessage = GetWebsiteReport(rptInstanceId, ReportFileType.TXT);
                        break;
                    default:
                        break;
                }
            }
            return reportMessage;
        }

        protected void GetReport(int rptInstanceId, ReportFileType fileType, string fileXML = "", string forType = "", string party = "",
            string rptfileName = "", string oneClickQuery = "", DataTable fileTags = null, string reportFolder = "", int SessionId = 0)
        {
            string reportFilePath = string.Empty;
            string reportFullPath = string.Empty;
            string reportFileName = string.Empty;
            string reportDirectory = string.Empty;
            string reportGenerateDirectory = string.Empty;
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            DateTime reportTime = DateTime.Now;

            if (string.IsNullOrEmpty(reportFolder))
            {
                reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportTime.Ticks.ToString());
                reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            }
            else
            {
                reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportFolder);
                reportGenerateDirectory = reportFolder;
            }

            if (string.IsNullOrEmpty(rptfileName))
            {
                reportFileName = ManageReports.GetReportOutputName(SystemReportId);
            }
            else
            {
                reportFileName = rptfileName;
            }

            if (forType.Contains("multiple") == true)
            {
                reportFileName += forType.Replace("multiple", "");
            }

            string reportFileExt;
            ABVReportConstant.FILE_TYPE_EXTENSIONS.TryGetValue(fileType, out reportFileExt);

            
            reportFilePath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName, reportFileExt);
            reportFullPath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportDirectory, reportFileName, reportFileExt);

            string reportFileDirectory = string.Format(@"{0}/{1}", "WEBReport", reportTime.Ticks.ToString());
            string reportFileFullPath = string.Format(ABVReportConstant.WEB_REPORT_PATH_FORMAT, reportFileDirectory, reportFileName, reportFileExt);

            List<string> subReports;
            try
            {
                switch (fileType)
                {
                    case ReportFileType.PDF:
                        subReports = ManageReports.GetSubReports(SystemReportId, fileType);
                        Export2Pdf(ABVReportConstant.REPORT_TEMP_PATH_FORMAT, reportDirectory, rptInstanceId, reportTime, reportFileExt, fileType, subReports, reportFullPath);
                        ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor, party, fileTags);
                        break;
                    case ReportFileType.EXCELOPENXML:
                        subReports = ManageReports.GetSubReports(SystemReportId, fileType);
                        List<string> listFileWithoutMergeSheet = Export2Excel(ABVReportConstant.REPORT_TEMP_PATH_FORMAT, reportDirectory, rptInstanceId, reportTime, reportFileExt, fileType, subReports, reportFullPath, reportFileName, fileXML, forType, oneClickQuery, SessionId);

                        if (listFileWithoutMergeSheet.Count > 0)

                        {
                            foreach (var fileNotMerge in listFileWithoutMergeSheet)
                            {
                                var fileName = Path.GetFileName(fileNotMerge);
                                ManageReports.SaveGeneratedRptFile(rptInstanceId, fileName, fileNotMerge, Requestor, party, fileTags);
                            }
                        }
                        else
                            ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor, party, fileTags);
                        break;
                    case ReportFileType.DIF:
                        reportFilePath = string.Format(ABVReportConstant.DIF_REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName);
                        Export2Dif(reportFullPath, fileXML, forType, oneClickQuery, SessionId);
                        ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor, party, fileTags);
                        break;
                    case ReportFileType.TXT:
                        Export2Txt(reportFullPath);
                        ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                        break;
                    default:
                        break;
                }
            }
            catch(Exception ex)
            {
                ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor, party, fileTags, "FAILED", string.Format("{0}-{1}",ex.Message,ex.InnerException != null ? ex.InnerException.Message : ""));
                throw ex;
            }
        }

        protected Dictionary<string, object> GetWebsiteReport(int rptInstanceId, ReportFileType fileType, string fileXML = "", string forType = "")
        {
            Dictionary<string, object> reportMessage = new Dictionary<string, object>();
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            DateTime reportTime = DateTime.Now;
            string reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportTime.Ticks.ToString());
            string reportFileName = ManageReports.GetReportOutputName(SystemReportId);

            if (forType.Contains("multiple") == true)
            {
                reportFileName += forType.Replace("multiple", "");
            }

            string reportFileExt;
            ABVReportConstant.FILE_TYPE_EXTENSIONS.TryGetValue(fileType, out reportFileExt);

            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string reportFilePath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName, reportFileExt);
            string reportFullPath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportDirectory, reportFileName, reportFileExt);

            string outputFileName = string.Format(ABVReportConstant.WEB_REPORT_FILENAME_FORMAT, reportFileName, reportFileExt);
            //string reportFileDirectory = string.Format(@"{0}/{1}", "WEBReport", reportTime.Ticks.ToString());
            //string reportFileFullPath = string.Format(ABVReportConstant.WEB_REPORT_PATH_FORMAT, reportFileDirectory, reportFileName, reportFileExt);

            List<string> subReports;
            switch (fileType)
            {
                case ReportFileType.PDF:
                    subReports = ManageReports.GetSubReports(SystemReportId, fileType);
                    Export2Pdf(ABVReportConstant.REPORT_TEMP_PATH_FORMAT, reportDirectory, rptInstanceId, reportTime, reportFileExt, fileType, subReports, reportFullPath);
                    ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                    break;
                case ReportFileType.EXCELOPENXML:
                    subReports = ManageReports.GetSubReports(SystemReportId, fileType);
                    List<string> listFileWithoutMergeSheet = Export2Excel(ABVReportConstant.REPORT_TEMP_PATH_FORMAT, reportDirectory, rptInstanceId, reportTime, reportFileExt, fileType, subReports, reportFullPath, reportFileName, fileXML, forType);

                    if (listFileWithoutMergeSheet.Count > 0)
                    {
                        foreach (var fileNotMerge in listFileWithoutMergeSheet)
                        {
                            var fileName = Path.GetFileName(fileNotMerge);
                            ManageReports.SaveGeneratedRptFile(rptInstanceId, fileName, fileNotMerge, Requestor);
                        }
                    }
                    else
                    {
                        ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                        reportMessage = AddReportObject(reportFullPath, outputFileName);
                    }
                    break;
                case ReportFileType.DIF:
                    reportFilePath = string.Format(ABVReportConstant.DIF_REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName);
                    Export2Dif(reportFullPath, fileXML, forType);
                    ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                    break;
                case ReportFileType.TXT:
                    Export2Txt(reportFullPath);
                    ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                    break;
                default:
                    break;
            }
            return reportMessage;
        }
        #endregion

        #region Handle Main logic

        protected void Export2Pdf(string maskPath, string outpDirectory, int rptHistoryId, DateTime execTime, string fileExt, ReportFileType fileType, List<string> subReports, string finalOutputFile)
        {
            if (subReports.Count > 0)
            {
                int count = 0;
                List<string> allSubFiles = new List<string>();

                foreach (var subReportID in subReports)
                {
                    count++;
                    string subFile = string.Format(maskPath, outpDirectory, rptHistoryId, SystemReportId, execTime.ToString(ABVReportConstant.DATETIME_FORMAT), fileExt, count.ToString());
                    ReportID = subReportID;
                    base.GetReport(subFile, fileType);
                    allSubFiles.Add(subFile);
                }

                FileComposer.PdfMerging(allSubFiles, finalOutputFile);
                foreach (string file in allSubFiles)
                {
                    File.Delete(file);
                }
            }
            else
            {
                ReportID = ReportName + "_PDF";
                base.GetReport(finalOutputFile, fileType);
            }
        }

        protected List<string> Export2Excel(string maskPath, string outpDirectory, int rptHistoryId, DateTime execTime, string fileExt, ReportFileType fileType, List<string> subReports, string finalOutputFile, string outputName, string fileXML = "", string forType = "", string oneClickQuery = "", int SessionId = 0)
        {
            List<string> listFileWithoutMerge = new List<string>();
            if (subReports.Count > 0)
            {
                if (Array.Exists(ABVReportConstant.REPORT_WITHOUT_MERGE, elem => elem.Equals(this.ReportName)))
                {
                    foreach (var subReportID in subReports)
                    {
                        string subFile = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, outpDirectory, subReportID, fileExt);
                        ReportID = subReportID;
                        base.GetReport(subFile, fileType);
                        string frName = ManageReports.GetFriendlyName(SystemReportId, subReportID);
                        string fileWithoutMerge = FileComposer.FriendlyName4SheetExcel(subFile, frName);
                        listFileWithoutMerge.Add(fileWithoutMerge);
                    }
                }
                else
                {
                    int count = 0;
                    List<string> allSubFiles = new List<string>();

                    /** Dictionary <Key, Value> subReportsWithFriendlyName    
                    ** Key: Path to Report 
                    ** Value: Report Friendly name 
                    **/
                    Dictionary<string, string> subReportsWithFriendlyName = new Dictionary<string, string>();

                    foreach (var subReportID in subReports)
                    {
                        count++;
                        string subFile = string.Format(maskPath, outpDirectory, rptHistoryId, SystemReportId, execTime.ToString(ABVReportConstant.DATETIME_FORMAT), fileExt, count.ToString());
                        ReportID = subReportID;
                        base.GetReport(subFile, fileType);
                        allSubFiles.Add(subFile);
                        subReportsWithFriendlyName.Add(subFile, ManageReports.GetFriendlyName(SystemReportId, subReportID));
                    }

                    FileComposer.ExcelMerging(allSubFiles, subReportsWithFriendlyName, finalOutputFile);
                    foreach (string file in allSubFiles)
                    {
                        File.Delete(file);
                    }
                }
            }
            else
            {
                if (Array.Exists(ABVReportConstant.REPORT_WITHOUT_TEMPLATE, elem => elem.Equals(this.ReportName)))
                {
                    new AbvExportReport().ExcelWithoutTemplate(finalOutputFile, outputName, fileXML, forType,
                        ReportName, ReportDBConnString, ReportParameters, ReportID, outpDirectory, oneClickQuery, SessionId);
                }
                else if (Array.Exists(ABVReportConstant.REPORT_CONFIG_TEMPLATE, elem => elem.Equals(this.ReportName)))
                {
                    FileComposer.ExcelConfigTemplate(finalOutputFile);
                }
                else
                {
                    base.GetReport(finalOutputFile, fileType);
                    FileComposer.SSRSExcelFormat(finalOutputFile, outputName);
                    if (ReportID == "COW_IN_HERD")
                    {
                        FileComposer.RenameSheets(finalOutputFile);
                        FileComposer.DeleteLastColumn(finalOutputFile);
                    }

                }
            }

            return listFileWithoutMerge;
        }

        public void Export2Dif(string finalOutputFile, string fileXML = "", string forType = "", string query = "", int SessionId = 0)
        {
            if (!string.IsNullOrEmpty(fileXML))
            {
                new AbvExportReport().DifWithTemplate(finalOutputFile, fileXML, forType,
                    ReportName, ReportDBConnString, ReportParameters, ReportID, "", SessionId);
            }
            else
            {
                new AbvExportReport().DifWithTemplate(finalOutputFile, fileXML, forType,
                    ReportName, ReportDBConnString, ReportParameters, ReportID, query);
            }
        }

        private void Export2File(string finalOutputFile, string fileXML = "", string forType = "")
        {
            var rptData = DataReaderUtilities.GetData(ReportDBConnString, string.Format(@"EXEC dbo.wsp_EXPORT_FILE @searchFields = '{0}', @forType = '{1}'", fileXML, forType));
            if ((rptData != null) && (rptData.Tables.Count > 0))
            {
                string xmlTemplatePath = ManageReports.GetPathToTemplateFile();
                string maskPath = string.Format(@"{0}\{1}.xml", xmlTemplatePath, ReportID);
                FileComposer.ExportDIFFile(maskPath, rptData.Tables[0], finalOutputFile);
            }
        }

        private void Export2Txt(string finalOutputFile)
        {
            ReportParameter param = ReportParameters.Where(rp => rp.ParamName.Equals("param_Runs")).FirstOrDefault();
            if (param != null)
            {
                var rptData = DataReaderUtilities.GetData(ReportDBConnString, string.Format(@"EXEC dbo.usp_{0} @param_Runs = '{1}'", ReportID, param.ParamValue));
                if ((rptData != null) && (rptData.Tables.Count > 0))
                {
                    FileComposer.ExportTXTFile(rptData.Tables[0], finalOutputFile);
                }
            }
        }

        public virtual bool CheckData(string xmlSearchFields, string partyCode)   
        {
            return true; 
        }
        #endregion
    }
}
