﻿using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ABVReportLib;
using DataReaderUtilsLib;

namespace ABVReportLib
{
    public class GPRReport : SSRSReport
    {
        #region Properties

        public string ReportName { get; set; }
        public int SystemReportId { get; set; }
        public string Requestor { get; set; }
        public string ReportDBConnString { get; set; }
        public string FileOutputExt { get; set; }

        #endregion

        #region Constructors
        public GPRReport(string reportName) : base()
        {
            ReportServer server = ManageReports.GetGPRReportServerInformation();
            base.ReportServiceURL = server.ReportServiceURL;
            base.ReportServiceUsername = server.ReportServiceUsername;
            base.ReportServicePassword = server.ReportServicePassword;
            ReportDBConnString = server.ReportDBConnString;

            base.ProjectName = "GPR";
            base.ReportID = reportName;

            ReportName = reportName;
            SystemReportId = ManageReports.GetSystemReportId(ReportID);
        }

        #endregion

        #region Methods

        public virtual int SubmitReport(string requestor, List<ReportParameter> parameters)
        {
            return ManageReports.SubmitReport(SystemReportId, requestor, parameters);
        }

        public virtual void GenerateReport(int rptInstanceId)
        {

        }

        public virtual string GenerateReportWithMessage(int rptInstanceId)
        {
            return "";
        }

        public static Dictionary<string, object> AddReportObject(string reportFullPath, string reportFileName)
        {
            Dictionary<string, object> reportMessage = new Dictionary<string, object>();
            reportMessage.Add("Message", reportFullPath);
            reportMessage.Add("FileName", reportFileName);
            return reportMessage;
        }

        public virtual IDictionary<string, object> GenerateReportWithDictionary(int rptInstanceId)
        {
            Dictionary<string, object> reportMessage = new Dictionary<string, object>();
            return reportMessage;
        }

        public Dictionary<string, object> GenerateWebsiteReports(int rptInstanceId, string[] fileTypes, List<string> paramRpt, string fileXML = "", string forType = "")
        {
            Requestor = ManageReports.GetRequestor(rptInstanceId);
            Dictionary<string, object> reportMessage = new Dictionary<string, object>();
            foreach (var fType in fileTypes)
            {
                switch (fType.ToLower())
                {
                    case "pdf":
                        reportMessage = GetWebsiteReport(rptInstanceId, ReportFileType.PDF, paramRpt, fileXML, forType);
                        break;
                    case "xlsx":
                        reportMessage = GetWebsiteReport(rptInstanceId, ReportFileType.EXCELOPENXML, paramRpt, fileXML, forType);
                        break;
                    case "dif":
                        reportMessage = GetWebsiteReport(rptInstanceId, ReportFileType.DIF, paramRpt, fileXML, forType);
                        break;
                    case "txt":
                        reportMessage = GetWebsiteReport(rptInstanceId, ReportFileType.TXT, paramRpt);
                        break;
                    default:
                        break;
                }
            }
            return reportMessage;
        }

        protected void GetReport(int rptInstanceId, ReportFileType fileType, string fileXML = "", string forType = "")
        {
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            DateTime reportTime = DateTime.Now;
            string reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportTime.Ticks.ToString());
            string reportFileName = ManageReports.GetReportOutputName(SystemReportId);

            if (forType.Contains("multiple") == true)
            {
                reportFileName += forType.Replace("multiple", "");
            }

            string reportFileExt;
            ABVReportConstant.FILE_TYPE_EXTENSIONS.TryGetValue(fileType, out reportFileExt);

            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string reportFilePath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName, reportFileExt);
            string reportFullPath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportDirectory, reportFileName, reportFileExt);

            string reportFileDirectory = string.Format(@"{0}/{1}", "WEBReport", reportTime.Ticks.ToString());
            string reportFileFullPath = string.Format(ABVReportConstant.WEB_REPORT_PATH_FORMAT, reportFileDirectory, reportFileName, reportFileExt);

            List<string> subReports;
            switch (fileType)
            {
                case ReportFileType.PDF:
                    subReports = ManageReports.GetSubReports(SystemReportId, fileType);
                    Export2Pdf(ABVReportConstant.REPORT_TEMP_PATH_FORMAT, reportDirectory, rptInstanceId, reportTime, reportFileExt, fileType, subReports, reportFullPath);
                    ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                    break;
                case ReportFileType.EXCELOPENXML:
                    subReports = ManageReports.GetSubReports(SystemReportId, fileType);
                    List<string> listFileWithoutMergeSheet = Export2Excel(ABVReportConstant.REPORT_TEMP_PATH_FORMAT, reportDirectory, rptInstanceId, reportTime, reportFileExt, fileType, subReports, reportFullPath, reportFileName, fileXML, forType);

                    if (listFileWithoutMergeSheet.Count > 0)

                    {
                        foreach (var fileNotMerge in listFileWithoutMergeSheet)
                        {
                            var fileName = Path.GetFileName(fileNotMerge);
                            ManageReports.SaveGeneratedRptFile(rptInstanceId, fileName, fileNotMerge, Requestor);
                        }
                    }
                    else
                        ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                    break;
                case ReportFileType.DIF:
                    reportFilePath = string.Format(ABVReportConstant.DIF_REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName);
                    Export2Dif(reportFullPath, fileXML, forType);
                    ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                    break;
                case ReportFileType.TXT:
                    Export2Txt(reportFullPath);
                    ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                    break;
                default:
                    break;
            }
        }

        protected Dictionary<string, object> GetWebsiteReport(int rptInstanceId, ReportFileType fileType, List<string> paramRpt, string fileXML = "", string forType = "")
        {
            Dictionary<string, object> reportMessage = new Dictionary<string, object>();
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            DateTime reportTime = DateTime.Now;
            string reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportTime.Ticks.ToString());
            string reportFileName = ManageReports.GetReportOutputName(SystemReportId) + paramRpt[0] + reportTime.ToString("_dd_M_yyyy");

            if (forType.Contains("multiple") == true)
            {
                reportFileName += forType.Replace("multiple", "");
            }

            string reportFileExt;
            ABVReportConstant.FILE_TYPE_EXTENSIONS.TryGetValue(fileType, out reportFileExt);

            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string reportFilePath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName, reportFileExt);
            string reportFullPath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportDirectory, reportFileName, reportFileExt);

            string outputFileName = string.Format(ABVReportConstant.WEB_REPORT_FILENAME_FORMAT, reportFileName, reportFileExt);

            List<string> subReports =  new List<string>();
            switch (fileType)
            {
                case ReportFileType.PDF:
                    try
                    {
                        subReports.Add(paramRpt[2]);
                        Export2Pdf(ABVReportConstant.REPORT_TEMP_PATH_FORMAT, reportDirectory, rptInstanceId, reportTime, reportFileExt, fileType, subReports, reportFullPath);
                        ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                        reportMessage = AddReportObject(reportFullPath, outputFileName);
                    }
                    catch (Exception ex)
                    {
                        reportMessage = AddReportObject(reportFullPath, ex.Message);
                    }
                  
                    break;
                case ReportFileType.EXCELOPENXML:
                    subReports = ManageReports.GetSubReports(SystemReportId, fileType);
                    List<string> listFileWithoutMergeSheet = Export2Excel(ABVReportConstant.REPORT_TEMP_PATH_FORMAT, reportDirectory, rptInstanceId, reportTime, reportFileExt, fileType, subReports, reportFullPath, reportFileName, fileXML, forType);

                    if (listFileWithoutMergeSheet.Count > 0)
                    {
                        foreach (var fileNotMerge in listFileWithoutMergeSheet)
                        {
                            var fileName = Path.GetFileName(fileNotMerge);
                            ManageReports.SaveGeneratedRptFile(rptInstanceId, fileName, fileNotMerge, Requestor);
                        }
                    }
                    else
                    {
                        ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                        reportMessage = AddReportObject(reportFullPath, outputFileName);
                    }
                    break;
                case ReportFileType.DIF:
                    reportFilePath = string.Format(ABVReportConstant.DIF_REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName);
                    Export2Dif(reportFullPath, fileXML, forType);
                    ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                    break;
                case ReportFileType.TXT:
                    Export2Txt(reportFullPath);
                    ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                    break;
                default:
                    break;
            }
            return reportMessage;
        }
        #endregion

        #region Handle Main logic

        protected void Export2Pdf(string maskPath, string outpDirectory, int rptHistoryId, DateTime execTime, string fileExt, ReportFileType fileType, List<string> subReports, string finalOutputFile)
        {
            if (subReports.Count > 0)
            {
                //int count = 0;
                //List<string> allSubFiles = new List<string>();

                //foreach (var subReportID in subReports)
                //{
                //    count++;
                //    string subFile = string.Format(maskPath, outpDirectory, rptHistoryId, SystemReportId, execTime.ToString(ABVReportConstant.DATETIME_FORMAT), fileExt, count.ToString());
                //    ReportID = subReportID;
                //    base.GetFFReport(subFile, fileType);
                //    allSubFiles.Add(subFile);
                //}

                //FileComposer.PdfMerging(allSubFiles, finalOutputFile);
                //foreach (string file in allSubFiles)
                //{
                //    File.Delete(file);
                //}
                base.GetFFReport(finalOutputFile, fileType, subReports[0]);
            }
            else
            {
                ReportID = ReportName + "_PDF";
                base.GetFFReport(finalOutputFile, fileType, subReports[0]);
            }
        }

        protected List<string> Export2Excel(string maskPath, string outpDirectory, int rptHistoryId, DateTime execTime, string fileExt, ReportFileType fileType, List<string> subReports, string finalOutputFile, string outputName, string fileXML = "", string forType = "")
        {
            List<string> listFileWithoutMerge = new List<string>();
            if (subReports.Count > 0)
            {
                if (Array.Exists(ABVReportConstant.REPORT_WITHOUT_MERGE, elem => elem.Equals(this.ReportName)))
                {
                    foreach (var subReportID in subReports)
                    {
                        string subFile = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, outpDirectory, subReportID, fileExt);
                        ReportID = subReportID;
                        base.GetReport(subFile, fileType);
                        string frName = ManageReports.GetFriendlyName(SystemReportId, subReportID);
                        string fileWithoutMerge = FileComposer.FriendlyName4SheetExcel(subFile, frName);
                        listFileWithoutMerge.Add(fileWithoutMerge);
                    }
                }
                else
                {
                    int count = 0;
                    List<string> allSubFiles = new List<string>();

                    /** Dictionary <Key, Value> subReportsWithFriendlyName    
                    ** Key: Path to Report 
                    ** Value: Report Friendly name 
                    **/
                    Dictionary<string, string> subReportsWithFriendlyName = new Dictionary<string, string>();

                    foreach (var subReportID in subReports)
                    {
                        count++;
                        string subFile = string.Format(maskPath, outpDirectory, rptHistoryId, SystemReportId, execTime.ToString(ABVReportConstant.DATETIME_FORMAT), fileExt, count.ToString());
                        ReportID = subReportID;
                        base.GetReport(subFile, fileType);
                        allSubFiles.Add(subFile);
                        subReportsWithFriendlyName.Add(subFile, ManageReports.GetFriendlyName(SystemReportId, subReportID));
                    }

                    FileComposer.ExcelMerging(allSubFiles, subReportsWithFriendlyName, finalOutputFile);
                    foreach (string file in allSubFiles)
                    {
                        File.Delete(file);
                    }
                }
            }
            else
            {
                if (Array.Exists(ABVReportConstant.REPORT_WITHOUT_TEMPLATE, elem => elem.Equals(this.ReportName)))
                {
                    // Export excel file with out template
                    string xmlTemplatePath = ManageReports.GetPathToTemplateFile();
                    string destFilePath = string.Format(@"{0}/{1}.xml", xmlTemplatePath, this.ReportName);
                    System.Data.DataTable rptData;

                    if (fileXML.Length > 0)
                        rptData = DataReaderUtilities.GetData(ReportDBConnString, string.Format(@"EXEC dbo.wsp_EXPORT_FILE @searchFields = '{0}', @forType = '{1}'", fileXML, forType)).Tables[0];
                    else
                        rptData = ManageReports.GetReportWithoutTemplate(ReportDBConnString, ReportParameters, ReportID);

                    if (File.Exists(destFilePath))
                    {
                        FileComposer.ExportExcelFileWithOutTemplate(rptData, finalOutputFile, outputName, new FileStream(destFilePath, FileMode.Open, FileAccess.Read));
                    }
                    else
                    {
                        FileComposer.ExportExcelFileWithOutTemplate(rptData, finalOutputFile, outputName);
                    }
                }
                else if (Array.Exists(ABVReportConstant.REPORT_CONFIG_TEMPLATE, elem => elem.Equals(this.ReportName)))
                {
                    FileComposer.ExcelConfigTemplate(finalOutputFile);
                }
                else
                {
                    base.GetReport(finalOutputFile, fileType);
                    FileComposer.SSRSExcelFormat(finalOutputFile, outputName);
                    if (ReportID == "COW_IN_HERD")
                    {
                        FileComposer.RenameSheets(finalOutputFile);
                        FileComposer.DeleteLastColumn(finalOutputFile);
                    }

                }
            }

            return listFileWithoutMerge;
        }

        public void Export2Dif(string finalOutputFile, string fileXML = "", string forType = "")
        {
            System.Data.DataSet rptData = null;

            if (fileXML.Length > 0)
                rptData = DataReaderUtilities.GetData(ReportDBConnString, string.Format(@"EXEC dbo.wsp_EXPORT_FILE @searchFields = '{0}', @forType = '{1}'", fileXML, forType));
            else
            {
                ReportParameter param = ReportParameters.Where(rp => rp.ParamName.Equals("param_Runs")).FirstOrDefault();
                if (param != null)
                {
                    rptData = DataReaderUtilities.GetData(ReportDBConnString, string.Format(@"EXEC dbo.usp_{0} @param_Runs = '{1}'", ReportID, param.ParamValue));
                }
            }

            if ((rptData != null) && (rptData.Tables.Count > 0))
            {
                string xmlTemplatePath = ManageReports.GetPathToTemplateFile();
                string maskPath = string.Format(@"{0}\{1}.xml", xmlTemplatePath, ReportID);
                FileComposer.ExportDIFFile(maskPath, rptData.Tables[0], finalOutputFile);
            }
            else
            {
                FileComposer.ExportDIFFileForNoData(finalOutputFile);
            }
        }

        private void Export2File(string finalOutputFile, string fileXML = "", string forType = "")
        {
            var rptData = DataReaderUtilities.GetData(ReportDBConnString, string.Format(@"EXEC dbo.wsp_EXPORT_FILE @searchFields = '{0}', @forType = '{1}'", fileXML, forType));
            if ((rptData != null) && (rptData.Tables.Count > 0))
            {
                string xmlTemplatePath = ManageReports.GetPathToTemplateFile();
                string maskPath = string.Format(@"{0}\{1}.xml", xmlTemplatePath, ReportID);
                FileComposer.ExportDIFFile(maskPath, rptData.Tables[0], finalOutputFile);
            }
        }

        private void Export2Txt(string finalOutputFile)
        {
            ReportParameter param = ReportParameters.Where(rp => rp.ParamName.Equals("param_Runs")).FirstOrDefault();
            if (param != null)
            {
                var rptData = DataReaderUtilities.GetData(ReportDBConnString, string.Format(@"EXEC dbo.usp_{0} @param_Runs = '{1}'", ReportID, param.ParamValue));
                if ((rptData != null) && (rptData.Tables.Count > 0))
                {
                    FileComposer.ExportTXTFile(rptData.Tables[0], finalOutputFile);
                }
            }
        }

        public virtual bool CheckData(string xmlSearchFields, string partyCode)
        {
            return true;
        }
        #endregion
    }
}
