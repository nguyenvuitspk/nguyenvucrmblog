﻿using System;
using DataReaderUtilsLib;
using SQLUtilsLib;
using CommonETLLibs;
using System.Globalization;

namespace CDRRunHelper
{
    public static class CDRRunHelper
    {
        public static int CreateRun()
        {
            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV, string.Format(@"INSERT INTO DV_RUNS DEFAULT VALUES; SELECT @@IDENTITY;"));
            return Convert.ToInt32(value);
        }

        public static int CreateRunStatus(int DV_RUN_ID, string STATUS_CD)
        {
            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                 string.Format(@"insert into [dbo].[DV_RUN_STATUS]
                                                    ([DV_RUN_ID]
													 ,[STATUS_CD]
                                                     ,[STATUS_CHANGE_TS])
                                                    values
                                                    (
                                                    {0},'{1}','{2}'
                                                    )", DV_RUN_ID, STATUS_CD, DateTime.Now.ToString(Constant.SqlDateTimeFortmat)));
            return Convert.ToInt32(value);
        }

        public static string GetDefaultAnimalDataset()
        {
            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV, string.Format(@"select PK_DATASET_ID from SAT_DATASET_DETAILS where NAME_DATASET = 'All Animal DS'"));
            return Convert.ToString(value);
        }

        public static void UpdateProcessTime(string configname)
        {
            DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, string.Format(@"Update[dbo].[SSISConfiguration] set[ConfiguredValue] = getdate() where[ConfigurationName] = '{0}'", configname));

        }

        public static string GetLastUpdateTime(string configName)
        {
            return Convert.ToDateTime(DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, string.Format(@"select [ConfiguredValue] from [dbo].[SSISConfiguration] where[ConfigurationName] = '{0}'", configName))).ToString("yyyy-MM-dd HH:mm:ss.fff");
        }
    }
}
