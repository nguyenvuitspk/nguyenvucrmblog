﻿namespace ImportHelperLib
{
    public class ITBMix99BBConstant
    {
        public const string ITB_FOLDER_NAME = "itb";
        public const string EB_ZONE_CONN_NAME = "ETL_DIRECTORY_BIN";
        public const string LINUX_ZONE_CONN_NAME = "BB_BIN_DIRECTORY";

        public const string TEXT_FILE_TAB_DELIMITER_CHAR = "\t";
        public const string TEXT_FILE_NEWLINE_CHAR = "\n";

        // Export file name
        public const string ITB_MIX99_PEDIGREE_FILE_NAME = "itb.ped.txt";
        public const string ITB_MIX99_CONTROL_FILE_NAME = "itb.control.txt";
        public const string ITB_MIX99_DATA_FILE_NAME = "itb.data.txt";
        public const string ITB_BLENDED_PATH_FILE = "blendedbvs.txt";
        public const string ITB_MIX99_LOG_BB_PATH_FILE = "itb.log.txt";

        // ERR message
        public const string MSG_ERR_POST_PROGRESSING_DB_FAILED = "Post Progressing for per trait group failed!";
        public const string MSG_ERR_IMPORT_DB_FAILED = "Import into database failed!";
        public const string MSG_ERR_INVALID_INPUT = "Input parameter is invalid!";
        public const string MSG_ERR_NOT_HAVE_HERITABILITY_VALUE = "Database have not heritability value of trait {0} and breed {1}";

        public const string MSG_ERR_RUN_ITB_MIX99_BB_PER_TRAIT_FAILED = "Run ITB Mix99 BB failed for trait {0} of trait group {1}";
        public const string MSG_ERR_RUN_ITB_MIX99_BB_PER_TRAIT_PER_BREED_FAILED = "Run ITB Mix99 BB failed for trait {0} of breed {1} of trait group {2}";
    }

    public class ITB_Im_Ex_Folder
    {
        public const string Import = "itb_imports";
        public const string Export = "itb_exports";
    }

    public enum ITBConformationTrait
    {
        ocs,
        ous,
        sta,
        ang,
        bde,
        cwi,
        rwi,
        ran,
        fan,
        rls,
        rlr,
        ude,
        fua,
        ruh,
        usu,
        ftp,
        ftl,
        rtp
    }

    public enum ITBWorkabilityTrait
    {
        msp,
        tem
    }

    public class ITBTraitGroup
    {
        public const string CalvingEase = "calv";
        public const string Conformation = "conf";
        public const string Fertility = "fert";
        public const string Scc = "uder";
        public const string Survival = "long";
        public const string Yield = "prod";
        public const string Workability = "work";

    }

    public enum ITBMACEType
    {
        MACE,
        GMACE
    }

    public enum ITBYieldBreedEvaluation
    {
        HOL ,
        JER ,
        GUE ,
        RDC ,
        BSW 
    }

    public enum ITBWCSSFBreedEvaluation
    {
        HOL,
        JER,
        GUE,
        RDC 
    }

    public enum ITBEaseBreedEvaluation
    {
        HOL
    }

    public enum ITBYieldTrait
    {
        Milk,
        Fat,
        Prot
    }

    public enum ITBWorkabilityControlTrait
    {
        Mspeed,
        Temp
    }
    public enum ITBConformationControlTrait
    {
        OType,
        Mamm,
        Stat,
        Angul,
        BodyD,
        ChestW,
        PinW,
        PinSet,
        FootA,
        RSet,
        RLeg,
        UdDep,
        ForeA,
        RearAH,
        CentL,
        TeatPF,
        TeatL,
        TeatPR
    }

    public class Observation
    {
        public const string Workability = "work";
        public const string Conformation = "conf";
        public const string Survival = "surv";
        public const string Yield = "yield";
        public const string Scc = "scc";
        public const string CalvingEase = "ease";
        public const string Fertility = "fert";
    }

    public class FertExportFileName
    {
        public const string Pedfilename = Observation.Fertility + ".ped.bin";
        public const string Obsfilename = Observation.Fertility + ".data.bin";
        public const string Cowrelfilename = Observation.Fertility + ".cowrel.bin";
        public const string Bullrelfilename = Observation.Fertility + ".bullrel.bin";

        public const string ITB_Adjustedsfilename = Observation.Fertility + ".ITBAdjusted." + Observation.Fertility;
        public const string ABV_blendedabvsfilename = Observation.Fertility + ".ABVBase_Adjusted." + "{0}" + "." + Observation.Fertility + ".bin";
        public const string AbvBreedFile = Observation.Fertility + ".breed.txt";
        public const string ABVBlendFile = Observation.Fertility + ".ABVBase_Adjusted.blended." + Observation.Fertility + ".bin";
        public const string CowBlendFile = Observation.Fertility + ".cowrel.blended." + Observation.Fertility + ".bin";
        public const string BullBlendFile = Observation.Fertility + ".bullrel.blended." + Observation.Fertility + ".bin";
     
        public const string control = "fert.control.blend.{PABV}.fert";
    }

    public class SurvExportFileName
    {
        public const string Pedfilename = Observation.Survival + ".ped.bin";
        public const string Obsfilename = Observation.Survival + ".data.bin";
        public const string Cowrelfilename = Observation.Survival + ".cowrel.bin";
        public const string Bullrelfilename = Observation.Survival + ".bullrel.bin";

        public const string ITB_Adjustedsfilename = Observation.Survival + ".ITBAdjusted." + Observation.Survival;
        public const string ABV_blendedabvsfilename = Observation.Survival + ".ABVBase_Adjusted." + "{0}" + "." + Observation.Survival + ".bin";
        public const string AbvBreedFile = Observation.Survival + ".breed.txt";
        public const string ABVBlendFile = Observation.Survival + ".ABVBase_Adjusted.blended." + Observation.Survival + ".bin";
        public const string CowBlendFile = Observation.Survival + ".cowrel.blended." + Observation.Survival + ".bin";
        public const string BullBlendFile = Observation.Survival + ".bullrel.blended." + Observation.Survival + ".bin";

        public const string control = "surv.control.blend.{PABV}.surv";

    }

    public class ITBCalvingEaseExportImportFileName
    {
        public const string control = "ease.control.blend.{PABV}.{trait}";
        public const string ITB_Adjusted = "ease.ITBAdjusted.{trait}";
        public const string ABV_Adjusted = "ease.ABVBase_Adjusted.{trait}.bin";

        public const string bullrel = "ease.bullrel.blended.{trait}.bin";
        public const string cowrel = "ease.cowrel.blended.{trait}.bin";
        public const string blended_Adjusted = "ease.ABVBase_Adjusted.blended.{trait}.bin";
    }

    public class ITBYieldExportImportFileName
    {
        public const string control = "yield.control.blend";
        public const string ITB_Adjusted = "yield.ITBAdjusted";
        public const string ABV_Adjusted = "yield.ABVBase_Adjusted.bin";
        public const string ABV_Sent_Adjusted = "yield.ABVBase_Adjusted.Sent.bin";
        public const string bullrel = "yield.bullrel.blended.bin";
        public const string cowrel = "yield.cowrel.blended.bin";
        public const string blended_Adjusted = "yield.ABVBase_Adjusted.blended.bin";
        public const string AbvBreedFile = "yield.breed.txt";
        public const string AbvDataFile = "yield.data.bin";
        public const string AbvPedFile = "yield.ped.bin";
    }
	
	public class ITBConformationExportImportFileName
    {
        public const string control = "conf.control.{breed}.blend.{PABV}.{trait}";
        public const string ITB_Adjusted = "conf.{breed}.ITBAdjusted.{trait}";
        public const string breed = "conf.{breed}.{trait}.breed.txt";
        public const string ABV_Adjusted = "conf.{breed}.ABVBaseAdjusted.{trait}.bin";
        public const string Pedfilename = "conf.ped.{breed}.{trait}" + ".bin";
        public const string Datafilename = "conf.data.{breed}.{trait}" + ".bin";
        public const string bullrel = "conf.bullrel.{breed}.{trait}.bin";
        public const string cowrel = "conf.cowrel.{breed}.{trait}.bin";
        public const string blended_Adjusted = "conf.ABVBase_Adjusted.blended.{breed}.{trait}.bin";
        public const string CowBlendFile = "conf.cowrel.blended.{breed}.{trait}" + ".bin";
        public const string BullBlendFile = "conf.bullrel.blended.{breed}.{trait}" + ".bin";
    }
    public class ITBSCCExportImportFileName
    {
        public const string control = "scc.control.blend";
        public const string ITB_Adjusted = "scc.ITBAdjusted";
        public const string ABV_Adjusted = "scc.ABVBase_Adjusted.bin";
        public const string ABV_Sent_Adjusted = "scc.ABVBase_Adjusted.Sent.bin";
        public const string blended_Adjusted = "scc.ABVBase_Adjusted.blended.bin";
        public const string BullBlendFile = "scc.bullrel.blended.bin";
        public const string CowBlendFile = "scc.cowrel.blended.bin";
        public const string relAll = "reliabilityBruce.out";
        public const string Pedfilename_txt = "scc.ped.txt";
    }

    public class ITBWorkExportImportFileName
    {
        public const string control = Observation.Workability + ".control.blend.{PABV}.{trait}";
        public const string Pedfilename = Observation.Workability + "." + "{trait}" + ".ped.bin";
        public const string Obsfilename = Observation.Workability + "." + "{trait}" + ".data.bin";
        public const string Cowrelfilename = Observation.Workability + "." + "{trait}" + ".cowrel.bin";
        public const string Bullrelfilename = Observation.Workability + "." + "{trait}" + ".bullrel.bin";
        public const string ITB_Adjustedsfilename = Observation.Workability + ".itbAdjusted.{trait}" ;
        public const string ABV_blendedabvsfilename = Observation.Workability + ".ABVBase_Adjusted.{trait}" + ".bin";
        public const string AbvBreedFile = Observation.Workability + ".breed.txt";
        public const string ABVBlendFile = Observation.Workability + ".ABVBase_Adjusted.blended.{trait}" +".bin";
        public const string CowBlendFile = Observation.Workability + ".cowrel.blended.{trait}" +".bin";
        public const string BullBlendFile = Observation.Workability + ".bullrel.blended.{trait}" + ".bin";

    }
}
