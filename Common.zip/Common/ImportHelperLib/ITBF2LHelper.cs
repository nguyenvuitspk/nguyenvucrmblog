﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;

namespace ImportHelperLib
{
    public class ITBF2LHelper
    {
        public bool CheckITBFileName(string filename, string filetype)
        {
            string traitcode = string.Empty;
            string breedcode = string.Empty;
            string version = string.Empty;
            string routinerun = string.Empty;
            string format = string.Empty;
            string extention = string.Empty;
            string pedType = string.Empty;

            List<string> itbTraitCode = new List<string> { "calv", "conf", "fert", "long", "prod", "uder", "work" };
            List<string> itbBreedCode = new List<string> { "HOL", "GUE", "JER", "BSW", "RDC", "SIM" };

            if (filename.StartsWith("crossref_ALL"))
            {
                if (filename.Length < 22)
                {
                    return false;
                }
                else
                {
                    traitcode = "";
                    breedcode = "";
                    version = filename.Substring(13, 4);
                    routinerun = filename.Substring(17, 1);
                    format = filename.Substring(18, 4);
                    extention = filename.Substring(filename.Length - 4);
                }
            }
            else if (filename.StartsWith("g_"))
            {
                string startwith = filename.Substring(2, 4);
                if (startwith == "pedi")
                {
                    if (filename.Length < 19)
                    {
                        return false;
                    }
                    else
                    {
                        traitcode = "";
                        breedcode = filename.Substring(7, 3);
                        version = filename.Substring(10, 4);
                        routinerun = filename.Substring(14, 1);
                        format = filename.Substring(15, 4);
                        extention = filename.Substring(filename.Length - 4);
                    }
                }
                else
                {
                    if (filename.Length < 16)
                    {
                        return false;
                    }
                    else
                    {
                        traitcode = filename.Substring(2, 4);
                        breedcode = filename.Substring(6, 3);
                        version = filename.Substring(9, 4);
                        routinerun = filename.Substring(13, 1);
                        format = filename.Substring(14, 4);
                        extention = filename.Substring(filename.Length - 4);
                    }
                }
            }
            else if (filename.StartsWith("pedig_"))
            {
                if (filename.Length < 19)
                {
                    return false;
                }
                else
                {
                    traitcode = "";
                    breedcode = filename.Substring(6, 3);
                    version = filename.Substring(10, 4);
                    routinerun = filename.Substring(14, 1);
                    format = filename.Substring(15, 4);
                    extention = filename.Substring(filename.Length - 4);
                }

            }
            else
            {
                if (filename.Length < 16)
                {
                    return false;
                }
                else
                {
                    traitcode = filename.Substring(0, 4);
                    breedcode = filename.Substring(4, 3);
                    version = filename.Substring(7, 4);
                    routinerun = filename.Substring(11, 1);
                    format = filename.Substring(12, 4);
                    extention = filename.Substring(filename.Length - 4);
                }
            }

            int fileversion;
            bool isVersionCorrect= Int32.TryParse(version, out fileversion);
            if ((itbTraitCode.Contains(traitcode) || traitcode == "") && (itbBreedCode.Contains(breedcode) || breedcode == "") && (routinerun == "r" || routinerun == "t")
                && (format == ".itb" || format == ".csv") && (extention == ".zip" || extention == ".itb" || extention == ".csv" || extention == "cale") 
                && isVersionCorrect)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
		
		//public void UploadSendingFiles(string ConnStr_DV, string uploadFolder)
  //      {
  //          // get information to connect to the folder to store itb file
  //          // get information to connect sftp to download file
  //          var ftpserverConfig = DataReaderUtilities.GetRowValue(ConnStr_DV, "select * from SAT_LOCATION_AUTHS where CONN_NAME = 'ITB_FTP'");
  //          var ftphost = ftpserverConfig["CONN_VALUE"].ToString().Split(':');
  //          var ftphostname = ftphost[0];
  //          var ftphostport = Convert.ToInt32(ftphost[1]);

  //          var ftpusername = ftpserverConfig["USER_NAME"].ToString();
  //          var ftppwd = ftpserverConfig["USER_SECRET"].ToString();
  //          string remoteFolder = "/upload";

  //          using (var sftp = new SftpClient(ftphostname, ftphostport, ftpusername, ftppwd))
  //          {
  //              sftp.Connect();
  //              sftp.ChangeDirectory(remoteFolder);
  //              var listFiles = new List<string>();
  //              if (Directory.Exists(uploadFolder))
  //              {
  //                  var files = Directory.GetFiles(uploadFolder).Select(f => Path.GetFileName(f)).ToList();
  //                  listFiles.AddRange(files);
  //              }

  //              foreach (var file in listFiles)
  //              {
  //                  using (FileStream file1 = new FileStream(Path.Combine(uploadFolder, file), FileMode.Open))
  //                  {
  //                      sftp.UploadFile(file1, file);
  //                  }
  //              }
  //          }
  //      }

        //public void DownLoadITBFile(string itbType, string ConnStr_DV, List<string> downloadedFiles)
        //{
        //    // get information to connect to the folder to store itb file
        //    // get information to connect sftp to download file
        //    var ftpserverConfig = DataReaderUtilities.GetRowValue(ConnStr_DV, "select * from SAT_LOCATION_AUTHS where CONN_NAME = 'ITB_FTP'");
        //    var ftphost = ftpserverConfig["CONN_VALUE"].ToString().Split(':');
        //    var ftphostname = ftphost[0];
        //    var ftphostport = Convert.ToInt32(ftphost[1]);

        //    var ftpusername = ftpserverConfig["USER_NAME"].ToString();
        //    var ftppwd = ftpserverConfig["USER_SECRET"].ToString();

        //    var srcserverConfig = DataReaderUtilities.GetRowValue(ConnStr_DV, "select * from SAT_LOCATION_AUTHS where CONN_NAME = 'ETL_SOURCE_DIRECTORY_B'");
        //    var rootfolder = srcserverConfig["CONN_VALUE"].ToString();

        //    var username = srcserverConfig["USER_NAME"].ToString();
        //    var pwd = srcserverConfig["USER_SECRET"].ToString();

        //    string remoteDirectory = "/downloads";
        //    NetworkCredential credentials = new NetworkCredential(username, pwd);
        //    using (new NetworkConnection(rootfolder, credentials))
        //    {
        //        string datetime = DateTime.Now.ToString("yyyyMMdd");
        //        string downloadFolder = Path.Combine(rootfolder, datetime);
        //        List<string> processedFiles = new List<string>();

        //        if (!Directory.Exists(downloadFolder))
        //            Directory.CreateDirectory(downloadFolder);

        //        using (var sftp = new SftpClient(ftphostname, ftphostport, ftpusername, ftppwd))
        //        {
        //            sftp.Connect();

        //            var items = sftp.ListDirectory(remoteDirectory);
        //            foreach (var d in items)
        //            {
        //                if (d.IsDirectory && (d.Name.ToUpper() == "MACE" || d.Name.ToUpper() == "GMACE"))
        //                {
        //                    var files = sftp.ListDirectory(remoteDirectory + "/" + d.Name);
        //                    foreach (var file in files)
        //                    {
        //                        if (!file.IsDirectory)
        //                        {
        //                            if (file.Name != "." && file.Name != "..")
        //                            {
        //                                ITBF2LHelper itbFileHelper = new ITBF2LHelper();
        //                                var isITBfile = itbFileHelper.CheckITBFileName(file.Name, "zip");
        //                                var isCorrectFileType = itbFileHelper.CheckITBTypeFile(itbType, file.Name);
        //                                if (isITBfile && isCorrectFileType && !downloadedFiles.Contains(file.Name))
        //                                {
        //                                    using (var file1 = File.OpenWrite(Path.Combine(downloadFolder, file.Name)))
        //                                    {
        //                                        sftp.DownloadFile(file.FullName, file1);
        //                                    }
        //                                }
        //                            }
        //                        }
        //                    }
        //                }
        //            }

        //            sftp.Disconnect();
        //        }
        //    }
        //}

        public void ExtractITBFile(string sourceFilePath, string extractFilePath)
        {
            using (ZipArchive archive = ZipFile.OpenRead(sourceFilePath))
            {
				int check = 1;
                foreach (ZipArchiveEntry entry in archive.Entries)
                {
                    if (File.Exists(extractFilePath) && check == 1)
                        File.Delete(extractFilePath);
                    if (entry.FullName.EndsWith(".itb", StringComparison.OrdinalIgnoreCase) && check == 1) 
                    {
                        entry.ExtractToFile(extractFilePath);
						check = 0;
                    }
					else if (entry.FullName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase) && check == 1)
					{
						entry.ExtractToFile(extractFilePath);
						check = 0;
					}
                    else if (entry.FullName.EndsWith(".itb.solscale", StringComparison.OrdinalIgnoreCase) && check == 1)
                    {
                        entry.ExtractToFile(extractFilePath);
                        check = 0;
                    }

                }
            }

            //ZipFile.ExtractToDirectory(fileName, desFolder);
        }

        public List<string> GetListITBFilesByType(string rootFolder, string ITBType, List<string> alreadyRunFiles)
        {
            var listFiles = new List<string>();
            var timestampFolders = Directory.GetDirectories(rootFolder).Where(f => TryParseUnixTimeStamp(Path.GetFileName(f)) != null).OrderBy(f => Convert.ToInt64(Path.GetFileName(f))).ToList();
            // Ensure there are existing vendor folder
            foreach (var versionFolder in timestampFolders)
            {
                var maceType = Enum.GetNames(typeof(ITBMACEType)).ToList();
                // Ensure there are existing DIF folder
                foreach (var typeFolder in maceType)
                {
                    string sourcepath = Path.Combine(rootFolder, versionFolder, typeFolder);
                    if (Directory.Exists(sourcepath))
                    {
                        var files =
                        Directory.GetFiles(sourcepath, "*.itb")
                                 .Where(f => CheckITBFileName(new FileInfo(f).Name, "itb") && CheckITBTypeFile(ITBType, new FileInfo(f).Name) && !alreadyRunFiles.Contains(Path.GetFileName(f)))
                                 .ToList();

                        listFiles.AddRange(files);
                    }
                }
            }

            return listFiles;
        }

        public List<string> GetListZipFilesDownloaded(string rootFolder)
        {
            var listFiles = new List<string>();
            var timestampFolders = Directory.GetDirectories(rootFolder).Where(f => TryParseUnixTimeStamp(Path.GetFileName(f)) != null).OrderBy(f => Convert.ToInt64(Path.GetFileName(f))).ToList();
            // Ensure there are existing vendor folder
            foreach (var versionFolder in timestampFolders)
            {
                    string sourcepath = Path.Combine(rootFolder, versionFolder);
                    if (Directory.Exists(sourcepath))
                    {
                        var files =
                        Directory.GetFiles(sourcepath, "*.zip").Select(f=>Path.GetFileName(f))
                                 .ToList();

                        listFiles.AddRange(files);
                    }
            }

            return listFiles;
        }

        public void ExtractZipFile(string rootFolder, string workflowType)
        {
            var timestampFolders = Directory.GetDirectories(rootFolder).Where(f => TryParseUnixTimeStamp(Path.GetFileName(f)) != null).OrderBy(f => Convert.ToInt64(Path.GetFileName(f))).ToList();

            foreach (var version in timestampFolders)
            {
                string desMaceFolder = Path.Combine(rootFolder, version, "MACE");
                string desGMaceFolder = Path.Combine(rootFolder, version, "GMACE");
                var versonname = new DirectoryInfo(version).Name;
                string failedFolder = Path.Combine(rootFolder, "FAILED", versonname);
                if (!Directory.Exists(desMaceFolder))
                {
                    Directory.CreateDirectory(desMaceFolder);
                }
                if (!Directory.Exists(desGMaceFolder))
                {
                    Directory.CreateDirectory(desGMaceFolder);
                }
                if (!Directory.Exists(failedFolder))
                {
                    Directory.CreateDirectory(failedFolder);
                }

                DirectoryInfo dir = new DirectoryInfo(Path.Combine(rootFolder, version));
                var zipfiles = dir.GetFiles("*.zip");
                foreach (var file in zipfiles)
                {
                    string itbFileName = string.Empty;
                    if (CheckITBFileName(file.Name, "zip") && CheckITBTypeFile(workflowType, file.Name))
                    {
                        if (file.Name.StartsWith("g_"))
                        {
                            //string itbFileName = string.Empty;
                            try
                            {
                                ExtractITBFile(file.FullName, Path.Combine(desGMaceFolder, file.Name.Substring(0, file.Name.Length - 4)));
                            }
                            catch
                            {
                                ImportDIFHelper.MoveFile(file.FullName, Path.Combine(failedFolder, file.Name));
                            }
                        }
                        else
                        {
                            try
                            {
                                ExtractITBFile(file.FullName, Path.Combine(desMaceFolder, file.Name.Substring(0, file.Name.Length - 4)));
                            }
                            catch
                            {
                                ImportDIFHelper.MoveFile(file.FullName, Path.Combine(failedFolder, file.Name));
                            }
                        }
                    }
                }
            }
        }

        public List<string> GetListInvalidFile(string rootFolder)
        {
            var listFiles = new List<string>();
            var timestampFolders = Directory.GetDirectories(rootFolder).Where(f => TryParseUnixTimeStamp(Path.GetFileName(f)) != null).OrderBy(f => Convert.ToInt64(Path.GetFileName(f))).ToList();
            // Ensure there are existing vendor folder
            foreach (var versionFolder in timestampFolders)
            {
                var maceType = Enum.GetNames(typeof(ITBMACEType)).ToList();
                // Ensure there are existing DIF folder
                foreach (var typeFolder in maceType)
                {
                    string sourcepath = Path.Combine(rootFolder, versionFolder, typeFolder);
                    if (Directory.Exists(sourcepath))
                    {
                        var files =
                        Directory.GetFiles(sourcepath, "*.*")
                                 .Where(f => !CheckITBFileName(new FileInfo(f).Name, "itb") || !CheckITBFileName(new FileInfo(f).Name, "csv"))
                                 .ToList();

                        listFiles.AddRange(files);
                    }
                }
            }

            return listFiles;
        }

        public static DateTime? TryParseUnixTimeStamp(string unixTimestamp)
        {
            // string unixTimestamp = "1469762567";
            try
            {
                System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
                dtDateTime = dtDateTime.AddSeconds(Convert.ToDouble(unixTimestamp)).ToLocalTime();
                return dtDateTime;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<string> GetListPEDFilesByType(string rootFolder, string ITBType, List<string> alreadyRunFiles)
        {
            var listFiles = new List<string>();
            var timestampFolders = Directory.GetDirectories(rootFolder).Where(f => TryParseUnixTimeStamp(Path.GetFileName(f)) != null).OrderBy(f => Convert.ToInt64(Path.GetFileName(f))).ToList();
            // Ensure there are existing vendor folder
            foreach (var versionFolder in timestampFolders)
            {
                var maceType = Enum.GetNames(typeof(ITBMACEType)).ToList();
                // Ensure there are existing DIF folder
                foreach (var typeFolder in maceType)
                {
                    string sourcepath = Path.Combine(rootFolder, versionFolder, typeFolder);
                    if (Directory.Exists(sourcepath))
                    {
                        var files =
                        Directory.GetFiles(sourcepath, "*.CSV")
                                  .Where(f=>(Path.GetFileName(f).StartsWith("pedi") || Path.GetFileName(f).StartsWith("g_pedi"))  && !alreadyRunFiles.Contains(Path.GetFileName(f)))
                                 .ToList();

                        listFiles.AddRange(files);
                    }
                }
            }

            return listFiles;
        }

        public List<string> GetListCrossRefFilesByType(string rootFolder, string ITBType, List<string> alreadyRunFiles)
        {
            var listFiles = new List<string>();
            var timestampFolders = Directory.GetDirectories(rootFolder).Where(f => TryParseUnixTimeStamp(Path.GetFileName(f)) != null).OrderBy(f => Convert.ToInt64(Path.GetFileName(f))).ToList();
            // Ensure there are existing vendor folder
            foreach (var versionFolder in timestampFolders)
            {
                var maceType = Enum.GetNames(typeof(ITBMACEType)).ToList();
                // Ensure there are existing DIF folder
                foreach (var typeFolder in maceType)
                {
                    string sourcepath = Path.Combine(rootFolder, versionFolder, typeFolder);
                    if (Directory.Exists(sourcepath))
                    {
                        var files =
                        Directory.GetFiles(sourcepath, "*.CSV")
                                  .Where(f => Path.GetFileName(f).StartsWith("crossref_ALL") && !alreadyRunFiles.Contains(Path.GetFileName(f)))
                                 .ToList();

                        listFiles.AddRange(files);
                    }
                }
            }

            return listFiles;
        }

        public bool CheckITBTypeFile(string itbType, string filename)
        {
            string m_fileStartWith = string.Empty;
            string gm_fileStartWith = string.Empty;
            switch (itbType)
            {
                case "ITB030":
                    m_fileStartWith = ITBTraitGroup.Yield;
                    gm_fileStartWith = "g_" + ITBTraitGroup.Yield;
                    break;
                case "ITB035":
                    m_fileStartWith = ITBTraitGroup.Conformation;
                    gm_fileStartWith = "g_" + ITBTraitGroup.Conformation;
                    break;
                case "ITB036":
                    m_fileStartWith = ITBTraitGroup.Scc;
                    gm_fileStartWith = "g_" + ITBTraitGroup.Scc;
                    break;
                case "ITB037":
                    m_fileStartWith = ITBTraitGroup.Survival;
                    gm_fileStartWith = "g_" + ITBTraitGroup.Survival;
                    break;
                case "ITB038":
                    m_fileStartWith = ITBTraitGroup.CalvingEase;
                    gm_fileStartWith = "g_" + ITBTraitGroup.CalvingEase;
                    break;
                case "ITB039":
                    m_fileStartWith = ITBTraitGroup.Fertility;
                    gm_fileStartWith = "g_" + ITBTraitGroup.Fertility;
                    break;
                case "ITB040":
                    m_fileStartWith = ITBTraitGroup.Workability;
                    gm_fileStartWith = "g_" + ITBTraitGroup.Workability;
                    break;
                case "PED012":
                    m_fileStartWith = "pedi";
                    gm_fileStartWith = "g_pedi";
                    break;
                case "CrossRef":
                    m_fileStartWith = "crossref_ALL";
                    gm_fileStartWith = "crossref_ALL";
                    break;
                default:
                    throw new Exception("This helper not support for type " + itbType);
            }

            if (filename.StartsWith(m_fileStartWith) || filename.StartsWith(gm_fileStartWith))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public string GetITBTypeByFileName(string fileFullName)
        {
            string fileName = Path.GetFileName(fileFullName);
            if (fileName.StartsWith("crossref_ALL")) {
                return "CrossRef";
            }
            string filetype = string.Empty;
            if (Path.GetFileName(fileFullName).StartsWith("g_"))
            {
                filetype = fileName.Substring(2, 4);
            }
            else
            {
                filetype = fileName.Substring(0, 4);
            }
           
            string itbType = string.Empty;
            switch (filetype)
            {
                case ITBTraitGroup.CalvingEase:
                    itbType = "ITB038";
                    break;
                case ITBTraitGroup.Conformation:
                    itbType = "ITB035";
                    break;
                case ITBTraitGroup.Fertility:
                    itbType = "ITB039";
                    break;
                case ITBTraitGroup.Scc:
                    itbType = "ITB036";
                    break;
                case ITBTraitGroup.Survival:
                    itbType = "ITB037";
                    break;
                case ITBTraitGroup.Yield:
                    itbType = "ITB030";
                    break;
                case ITBTraitGroup.Workability:
                    itbType = "ITB040";
                    break;
                case "pedi":
                    itbType = "PED012";
                    break;
            }
            return itbType;
        }
    }
}
