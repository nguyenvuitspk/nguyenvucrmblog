﻿namespace ImportHelperLib
{
    using CommonETLLibs;
    using DataReaderUtilsLib;
    using SQLUtilsLib;
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;
    using System.Linq;
    using System.Text.RegularExpressions;
    using System.Threading;

    public class ImportDIFHelper
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="isImportDifFromUI">true if Dif file is imported from UI else false</param>
        /// <returns></returns>
        public int CreateRun(string fileName, bool isImportDifFromUI = false)
        {
            if (!File.Exists(fileName))
            {
                throw new FileCannotFoundException(fileName);
            }
            var type = GetDIFTypeFromFileName(fileName);
            string SOURCE_PARTY_NAME = "";

            if (!isImportDifFromUI)
                SOURCE_PARTY_NAME = new DirectoryInfo(fileName).Parent.Parent.ToString();
            else
            {
                string guildOrPartyName = new DirectoryInfo(fileName).Parent.Parent.ToString();
                Guid guid;

                if (Guid.TryParse(guildOrPartyName, out guid))
                    SOURCE_PARTY_NAME = GetPartyName(guildOrPartyName);
                else SOURCE_PARTY_NAME = guildOrPartyName;
            }

            string FILE_PATH = Path.GetDirectoryName(fileName);
            string FILE_NAME = new FileInfo(fileName).Name;
            int DATASET_KEY = GetDSKeyByType(type);

            int RUN_ID = CreateRun(DATASET_KEY, SOURCE_PARTY_NAME, FILE_PATH, FILE_NAME);
            return RUN_ID;
        }
        
        public int CreateITBRun(string fileName)
        {
            ITBF2LHelper helper = new ITBF2LHelper();
            if (!File.Exists(fileName))
            {
                throw new FileCannotFoundException(fileName);
            }
            var type = helper.GetITBTypeByFileName(fileName);
            string SOURCE_PARTY_NAME = new DirectoryInfo(fileName).Parent.Parent.ToString();
            string FILE_PATH = Path.GetDirectoryName(fileName);
            string FILE_NAME = new FileInfo(fileName).Name;
            int DATASET_KEY = GetDSKeyByType(type);

            int RUN_ID = CreateRun(DATASET_KEY, SOURCE_PARTY_NAME, FILE_PATH, FILE_NAME);
            return RUN_ID;
        }

        public int CreateRun(int DATASET_KEY, string RUN_SOURCE_PARTY_NAME, string RUN_PATH, string RUN_FILE)
        {
            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_LND,
                 string.Format(@"
                                DECLARE @MyNewIdentityValues table(ID BIGINT)
                                insert into [dbo].[LND_RUNS]
                                        ([DATASET_KEY]
                                        ,[RUN_SOURCE_PARTY_NAME]
                                        ,[RUN_PATH]
                                        ,[RUN_FILE])
                                OUTPUT Inserted.RUN_ID INTO @MyNewIdentityValues
                                        values
                                        (
                                        {0},'{1}','{2}','{3}'
                                        )

                                select ID FROM @MyNewIdentityValues
                               ", DATASET_KEY, RUN_SOURCE_PARTY_NAME, RUN_PATH, RUN_FILE));
            return Convert.ToInt32(value);
        }
        
        public int CreateRunStatus(int RUN_ID, string STATUS_CD)
        {
            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_LND,
                 string.Format(@"
                                DECLARE @MyNewIdentityValues table(ID BIGINT)
                                insert into [dbo].[LND_RUN_STATUS]
                                                    ([RUN_ID]
                                                        ,[STATUS_CD]
                                                        ,[STATUS_CHANGE_TS])
                                OUTPUT Inserted.STATUS_ID INTO @MyNewIdentityValues
                                                    values
                                                    (
                                                    {0},'{1}','{2}'
                                                    )

                                select ID FROM @MyNewIdentityValues
                               ", RUN_ID, STATUS_CD, DateTime.Now.ToString(Constant.SqlDateTimeFortmat)));
            return Convert.ToInt32(value);
        }
        
        public string GetDIFTypeFromFileName(string fileName)
        {
            // file name address will have structure: ETL_SOURCE_DIRECTORY_A\1030494932\HICO\DIF101\FarmWestJuly2015.1468479688.DIF";
            // the file type will be DIF101
            return new DirectoryInfo(fileName).Parent.ToString();
        }

        public int GetDSKeyByType(string DS_Type)
        {
            return (int)DataReaderUtilities.GetScalaValue(DBReference.ConnStr_LND,
                                        string.Format(@"select top 1 [DATASET_KEY]  
                                                        from [dbo].[LND_DATASETS]
                                                        WHERE[DATASET_TYPE_CD] = '{0}'", DS_Type));
        }

        public string GetDsTypeByRunID(string run_id)
        {
            return  DataReaderUtilities.GetScalaValue(DBReference.ConnStr_LND,
                                        string.Format(@"select top 1 [DATASET_TYPE_CD]  
                                                        from [dbo].[LND_DATASETS] ds
	                                                    INNER JOIN dbo.LND_RUNS r ON r.DATASET_KEY = ds.DATASET_KEY
                                                        WHERE r.RUN_ID ={0}", run_id)).ToString();
        }

        public string GetPartyName(string pkPartyId)
        {
            string sqlCommand = string.Format(@"SELECT sParties.NAME
                                                FROM dbo.HUB_PARTIES (NOLOCK) hParties
                                                JOIN dbo.SAT_PARTIES (NOLOCK) sParties ON sParties.PK_PARTY_ID = hParties.PK_PARTY_ID AND sParties.MD_LOADEND_TS IS NULL
                                                WHERE hParties.PK_PARTY_ID = '{0}'", pkPartyId);

            return DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV, sqlCommand).ToString();
        }

        public static void InsertNewLineAtEndOfLastLineForDifFile(string pathFileName)
        {
            if (!File.ReadAllText(pathFileName).EndsWith("\n"))
            {
                using (StreamWriter sw = new StreamWriter(pathFileName, true))
                {
                    sw.Write(Environment.NewLine);
                }
            }  
        }

        public static List<string> GetListDIFFilesByType(string rootFolder, string DIFType)
        {
            var listFiles = new List<string>();
            // Retrive timestamp folder under Root
            var timestampFolders = Directory.GetDirectories(rootFolder).Where(f => TryParseUnixTimeStamp(Path.GetFileName(f)) != null).OrderBy(f => Convert.ToInt64(Path.GetFileName(f))).ToList();

            foreach (var timestampFolder in timestampFolders)
            {
                // Ensure there are existing vendor folder
                foreach (var vendorFolder in Directory.GetDirectories(timestampFolder))
                {
                    // Ensure there are existing DIF folder
                    foreach (var difFolder in Directory.GetDirectories(vendorFolder).Where(f => Path.GetFileName(f) == DIFType))
                    {
                        var files =
                        Directory.GetFiles(difFolder, "*.*")
                                 //.Where(f => CheckCorrectFormatFileName(new FileInfo(f).Name)) Remove check file name CDR-485
                                 .OrderBy(f => new FileInfo(f).Name)
                                 .ToList();

                        listFiles.AddRange(files);
                    }
                }
            }

            return listFiles;
        }
        
        public static DateTime? TryParseUnixTimeStamp(string unixTimestamp)
        {
            // string unixTimestamp = "1469762567";
            try
            {
                System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
                dtDateTime = dtDateTime.AddMilliseconds(Convert.ToDouble(unixTimestamp)).ToLocalTime();
                return dtDateTime;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static Int64 GetTimestampFromName(string fileName)
        {
            string timestamp = string.Empty;

            //Check the file name must contain Unix timestamp
            foreach (var part in fileName.Split('.'))
            {
                if (TryParseUnixTimeStamp(part) != null)
                {
                    timestamp = part;
                    break;
                }
            }

            //Check the file name must have extension
            return Convert.ToInt64(timestamp);
        }
        
        public static bool CheckCorrectFormatFileName(string fileName)
        {
            bool isValid = false;
            //Check the file name must contain Unix timestamp, exclude extension

            string[] parts = fileName.Split('.');
            for (int i = 0; i < parts.Length - 1; i++)
            {
                var part = parts[i];
                if (TryParseUnixTimeStamp(part) != null)
                {
                    isValid = true;
                    break;
                }
            }

            //Check the file name must have extension

            isValid = isValid && fileName.Split('.').Length > 1;
            return isValid;

        }

        public static void MoveFile(string fileSource, string fileTarget)
        {

            string targetPath = Path.GetDirectoryName(fileTarget);

            //try
            //{
            if (!Directory.Exists(targetPath))
                Directory.CreateDirectory(targetPath);

            if (File.Exists(fileSource))
            {
                if (File.Exists(fileTarget))
                    File.Delete(fileTarget);

                File.Move(fileSource, fileTarget);
            }

            DeleteEmptyFolder(Path.GetDirectoryName(fileSource));
            //}
            //catch (Exception x)
            //{
            //}
        }
        
        public static void MoveCompleteImportFile(string RootFolder, string filePath, string timeStamp = null)
        {
            var sourceFloder = string.Empty;
            var filename = new FileInfo(filePath).Name;
            if (timeStamp == null)
            {
                sourceFloder = new DirectoryInfo(filePath).Parent.Parent.Parent + @"\" + new DirectoryInfo(filePath).Parent.Parent + @"\" + new DirectoryInfo(filePath).Parent;
            }
            else
            {
                sourceFloder = new DirectoryInfo(filePath).Parent.Parent + @"\" + new DirectoryInfo(filePath).Parent;
            }
            //var sourceFloder = new DirectoryInfo(filePath).Parent.Parent.Parent + @"\" + new DirectoryInfo(filePath).Parent.Parent + @"\" + new DirectoryInfo(filePath).Parent;


            string targetPath = Path.Combine(RootFolder, ProcessDIFFileStatus.COMPLETE, timeStamp, sourceFloder);
            string targetFile = Path.Combine(RootFolder, ProcessDIFFileStatus.COMPLETE, timeStamp, sourceFloder, filename);
            //try
            //{
            if (!Directory.Exists(targetPath))
                Directory.CreateDirectory(targetPath);

            if (File.Exists(filePath))
            {
                if (File.Exists(targetFile))
                    File.Delete(targetFile);

                File.Move(filePath, targetFile);
            }

            DeleteEmptyFolder(Path.GetDirectoryName(filePath));
            //}
            //catch (Exception x)
            //{
            //}
        }
        
        public static void MoveReadyFileToComplete(string RootFolder, string filePath, string timestamp)
        {
            var filename = new FileInfo(filePath).Name;

            string targetPath = Path.Combine(RootFolder, ProcessDIFFileStatus.COMPLETE, timestamp);
            string targetFile = Path.Combine(RootFolder, ProcessDIFFileStatus.COMPLETE, timestamp, filename);
            //try
            //{
            if (!Directory.Exists(targetPath))
                Directory.CreateDirectory(targetPath);

            if (File.Exists(filePath))
            {
                if (File.Exists(targetFile))
                    File.Delete(targetFile);

                File.Move(filePath, targetFile);
            }

            DeleteEmptyFolder(Path.GetDirectoryName(filePath));
            //}
            //catch (Exception x)
            //{
            //}
        }

        public static void DeleteEmptyFolder(string folder)
        {
            try
            {
                var di = new DirectoryInfo(folder);
                if (di.GetFiles().Count() == 0)
                {
                    Directory.Delete(di.FullName);
                    // Waiting for window delete folder
                    Thread.Sleep(1000);
                }

                if (di.Parent.GetFiles().Count() == 0)
                {

                    Directory.Delete(di.Parent.FullName);
                    // Waiting for window delete folder
                    Thread.Sleep(1000);
                }

                if (di.Parent.Parent.GetFiles().Count() == 0)
                {
                    Directory.Delete(di.Parent.Parent.FullName);
                    // Waiting for window delete folder
                    Thread.Sleep(1000);
                }

            }
            catch (Exception ex)
            { }

        }

        public static void DeleteEmptyFolderRecursive(string RootFolder, DirectoryInfo dir)
        {
            if (dir.EnumerateFiles().Any() || dir.EnumerateDirectories().Any())
                return;

            if (dir.FullName == RootFolder)
                return;

            DirectoryInfo parent = dir.Parent;
            dir.Delete();

            // Climb up to the parent
            DeleteEmptyFolderRecursive(RootFolder, parent);
        }

        //public static void DeleteTimeEmptyFolder(string fileName)
        //{
        //    var sourceFloder = new DirectoryInfo(fileName).Parent.Parent.Parent + @"\" + new DirectoryInfo(fileName).Parent.Parent + @"\" + new DirectoryInfo(fileName).Parent;
        //    var filePath = Path.GetDirectoryName(fileName);
        //    foreach (var dir in Directory.GetDirectories(filePath))
        //    {
        //        if (Directory.GetFiles(dir).Length < 1)
        //        {
        //            Directory.Delete(dir);
        //        }
        //    }
        //}
        
        public static void MoveFileToFailedDir(string RootFolder, string filePath)
        {
            var sourceFloder = new DirectoryInfo(filePath).Parent.Parent.Parent + @"\" + new DirectoryInfo(filePath).Parent.Parent + @"\" + new DirectoryInfo(filePath).Parent;

            var filename = new FileInfo(filePath).Name;
            string targetPath = Path.Combine(RootFolder, ProcessDIFFileStatus.FAILED, sourceFloder);
            string targetFile = Path.Combine(RootFolder, ProcessDIFFileStatus.FAILED, sourceFloder, filename);
            try
            {
                if (!Directory.Exists(targetPath))
                    Directory.CreateDirectory(targetPath);

                if (File.Exists(filePath))
                {
                    if (File.Exists(targetFile))
                        File.Delete(targetFile);

                    File.Move(filePath, targetFile);
                }

                DeleteEmptyFolder(Path.GetDirectoryName(filePath));
            }
            catch (Exception x)
            { }
        }

        public static void MoveReadyFileToFailedDir(string RootFolder, string filePath, string timestamp)
        {
            var filename = new FileInfo(filePath).Name;
            string targetPath = Path.Combine(RootFolder, ProcessDIFFileStatus.FAILED, timestamp);
            string targetFile = Path.Combine(RootFolder, ProcessDIFFileStatus.FAILED, timestamp, filename);
            try
            {
                if (!Directory.Exists(targetPath))
                    Directory.CreateDirectory(targetPath);

                if (File.Exists(filePath))
                {
                    if (File.Exists(targetFile))
                        File.Delete(targetFile);

                    File.Move(filePath, targetFile);
                }

                DeleteEmptyFolder(Path.GetDirectoryName(filePath));
            }
            catch (Exception x)
            { }
        }

        public static void ExportRejectRecords(string ConnStr_Source, string exportQuery, string fileDest, int run_id = -1)
        {
            string message = string.Empty;

            var rowsExported = ExportToFile(ConnStr_Source, exportQuery, fileDest, ",", run_id);
            if (rowsExported == 0)
            {
                File.Delete(fileDest);
                DeleteEmptyFolder(Path.GetDirectoryName(fileDest));
            }
            else
            {
                if (!File.Exists(fileDest))
                {
                    throw new Exception("Export failed: " + fileDest);
                }
            }
        }

        public static int ExportToFile(string ConnStr_Source, string exportQuery, string filePath, string delimiterChar, int run_id = -1)
        {
            System.Data.Common.DbConnectionStringBuilder builder = new System.Data.Common.DbConnectionStringBuilder();
            builder.ConnectionString = ConnStr_Source;
            string serverName = builder["Data Source"] as string;
            string dbName = builder["Initial Catalog"] as string;
            string outFile = filePath + "_out" + "_" + run_id.ToString();
            string fileEncoding = "-w";

            exportQuery = @"""" + exportQuery + @"""";
            serverName = @"""" + serverName + @"""";
            delimiterChar = @"""" + delimiterChar + @"""";

            string outFiletemp = @"""" + outFile + @"""";
            string filePathTemp = @"""" + filePath + @"""";

            string command = exportQuery + " queryout " + filePathTemp + " -c " + fileEncoding + " -d " + dbName + " -U -T -S " + serverName + " -t" + delimiterChar + " -o " + outFiletemp;

            var p = new Process();
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.RedirectStandardError = true;
            p.StartInfo.CreateNoWindow = true;
            p.StartInfo.FileName = "BCP";

            p.StartInfo.Arguments = command;

            try
            {
                p.Start();
                p.BeginOutputReadLine();

                StreamReader myStreamReader = p.StandardError;
                Console.WriteLine(myStreamReader.ReadLine());
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace.ToString());
                Console.WriteLine(e.Message);
                Console.ReadLine();
            }
            p.WaitForExit();

            int rowsExported = 0;

            string outputMessage = File.ReadAllText(outFile);

            if (File.Exists(outFile))
            {
                File.Delete(outFile);
            }

            var regex = new Regex(@"\r\n");
            var strMessages = regex.Split(outputMessage);

            var index = Array.FindIndex(strMessages, s => s.EndsWith("rows copied."));
            if (index != -1)
            {
                // Get export row count minus header row
                rowsExported = Convert.ToInt32(strMessages[index].Split(' ')[0]) - 1;
            }
            else
            {
                throw new InvalidOperationException(outputMessage);

            }

            return rowsExported;

        }

        public static void SaveFormatFile(string fileDest, string content)
        {
            FileStream fs1 = new FileStream(fileDest, FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter writer = new StreamWriter(fs1);
            writer.Write(content);
            writer.Close();

        }

        public static void DeleteFile(string fileName)
        {
            try
            {
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }
            }
            catch (Exception ex)
            { }

        }

        public static bool CheckCorrectDSType(string difType)
        {
            bool exist = false;
            string sql = string.Format("select count(*) from [dbo].[LND_DATASETS] where DATASET_TYPE_CD = '{0}'", difType);
            if (Convert.ToInt32(DataReaderUtilities.GetScalaValue(DBReference.ConnStr_LND, sql).ToString()) > 0)
            {
                exist = true;
            }
            return exist;
        }


    }
}
