﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ImportHelperLib
{
    public class ImportHelper
    {
        public static List<string> GetReadyFile(string rootFolder)
        {
            List<string> listReadyFile = new List<string>();

            listReadyFile =
                        Directory.GetFiles(rootFolder, "*.READY")
                                 .Where(f => CheckCorrectFormatFileName(new FileInfo(f).Name))
                                 .OrderBy(f => GetTimestampFromName(new FileInfo(f).Name))
                                 .ToList();

            return listReadyFile;
        }

        public static string GetFilePathByReadyFile(string readyfile)
        {
            string rootFolder = Path.GetDirectoryName(readyfile);// new DirectoryInfo(readyfile).FullName;
            var listfiles = new List<string>();

            var actualfile = File.ReadLines(readyfile).FirstOrDefault();
            var filepath = Path.Combine(rootFolder, actualfile);
            return filepath;
        }

        public static DateTime? TryParseUnixTimeStamp(string unixTimestamp)
        {
            // string unixTimestamp = "1469762567";
            try
            {
                System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
                dtDateTime = dtDateTime.AddSeconds(Convert.ToDouble(unixTimestamp)).ToLocalTime();
                return dtDateTime;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static Int64 GetTimestampFromName(string fileName)
        {
            Int64 value = -1;
            string timestamp = string.Empty;

            //Check the file name must contain Unix timestamp
            foreach (var part in fileName.Split('.'))
            {
                if (TryParseUnixTimeStamp(part) != null)
                {
                    timestamp = part;
                    break;
                }
            }

            return timestamp == string.Empty ? -1 : Convert.ToInt64(timestamp);
           
        }


        public static bool CheckCorrectFormatFileName(string fileName)
        {
            bool isValid = false;
            //Check the file name must contain Unix timestamp, exclude extension

            string[] parts = fileName.Split('.');
            for (int i = 0; i < parts.Length - 1; i++)
            {
                var part = parts[i];
                if (TryParseUnixTimeStamp(part) != null)
                {
                    isValid = true;
                    break;
                }
            }

            //Check the file name must have extension

            isValid = isValid && fileName.Split('.').Length > 1;
            return isValid;

        }
    }
}
