﻿namespace ImportHelperLib
{
    public class DSTypeCodeConstant
    {
        public const string BULL_EXTENT_CSV = "BULL_EXTENT_CSV";
        public const string DIF105 = "DIF105";
        public const string DIF105_NASIS = "DIF105_NASIS";
        public const string NASISBULL_EX_CSV = "NASISBULL_EX_CSV";
        public const string COW_EXTENT_CSV = "COW_EXTENT_CSV";
        public const string BULL_EXTENT_XLSX = "BULL_EXTENT_XLSX";
        public const string COW_EXTENT_XLSX = "COW_EXTENT_XLSX";
        public const string DIF115 = "DIF115";
    }
}
