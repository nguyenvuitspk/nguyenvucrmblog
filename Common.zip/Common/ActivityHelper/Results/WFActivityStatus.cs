﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActivityHelper.Results
{
    public class WFActivityStatus
    {
        public string WorkflowStatus { get; set; }
        public ActivityLog ActivityLog { get; set; }
        public List<WorkFlowOutput> WorkFlowOutputs { get; set; }
    }
}
