﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActivityHelper.Results
{
    public class LNDTableDIF
    {
        public int ROW_ID { get; set; }
        public int RUN_ID { get; set; }
        public DateTime ROW_TS { get; set; }
        public string ROW_REJECT_FLAG { get; set; }
        public string ROW_REJECT_CD { get; set; }
        public string ROW_REJECT_MESSAGE { get; set; }
        public string ROW_LINE_ID { get; set; }
        public string ROW_PHYSICAL_ID { get; set; }
    }
}
