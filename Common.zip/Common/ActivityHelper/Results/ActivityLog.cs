﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActivityHelper.Results
{
    public class ActivityLog
    {
        public string RUN_NAME { get; set; }
        public DateTime RUN_AT { get; set; }
        public string STATUS { get; set; }
        public string RUN_BY { get; set; }
        public string ERROR_MESSAGE { get; set; }
        public string FRESH { get; set; }
        public string CLONE { get; set; }
        public string EXTRACT_ONLY { get; set; }
        public string CACL_DQI_FFP { get; set; }
        public DateTime START_TIME { get; set; }
        public DateTime END_TIME { get; set; }
        public string RUN_TIME { get; set; }
        public string RELATED_WPID { get; set; }
        
        public List<ActivityLogFile> FILES { get; set; }
    }

    public class ActivityLogFile
    {
        public string FILE_NAME { get; set; }
        public string DESCRIPTION { get; set; }
        public string FILE_PATH { get; set; }
        public string FILE_ID { get; set; }
    }
}
