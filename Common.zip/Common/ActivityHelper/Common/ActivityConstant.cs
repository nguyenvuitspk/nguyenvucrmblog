﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActivityHelper.Common
{
    public class ActivityConstant
    {
        public const string CowDatasetTypeCD = "DIF102";
        public const string BullDatasetTypeCD = "DIF105";
    }

    public static class ActivityStatusConstant
    {
        public const string RUNNING = "RUNNING";
        public const string FAILED = "FAILED";
        public const string CANCELLED = "CANCELLED";
        public const string SUCCESS = "SUCCESS";
        public const string CREATED = "CREATED";
        public const string COMPLETED = "COMPLETED";
    }

    public static class ActivityTaskCodeConstant
    {
        public const string PROCESS_IMPORT_ITB200 = "PROCESS_IMPORT_ITB200";
        public const string PROCESS_CREATE_NASIS_BULL_FROM_UI = "PROCESS_CREATE_NASIS_BULL_FROM_UI";
        public const string PROCESS_CREATE_BULL_FROM_UI = "PROCESS_CREATE_BULL_FROM_UI";
        public const string PROCESS_CREATE_COW_FROM_UI = "PROCESS_CREATE_COW_FROM_UI";
        public const string PROCESS_IMPORT_NASIS_BULL = "PROCESS_IMPORT_NASIS_BULL";
        public const string PROCESS_IMPORT_BULL = "PROCESS_IMPORT_BULL";
        public const string PROCESS_IMPORT_COW = "PROCESS_IMPORT_COW";
        public const string PROCESS_DELETE_BULL = "PROCESS_DELETE_BULL";
    }
}
