﻿using ActivityHelper.Common;
using ActivityHelper.Results;
using DataReaderUtilsLib;
using SQLUtilsLib;
using System;
using System.Collections.Generic;
using System.Data;

namespace ActivityHelper
{
    public class ActivityLogHelper
    {
        #region Properties
        private static ActivityLogHelper _instance;

        private static IDictionary<string, string> DataSetTypesDic;
        #endregion

        #region Constructor
        public ActivityLogHelper(string ConnStr_SSISDB)
        {
            var ConnStr_LND = WorkflowOperation.WorkflowOperation.GetConfigurationValue(ConnStr_SSISDB, "ConnStr_LND");
            var ConnStr_DV = WorkflowOperation.WorkflowOperation.GetConfigurationValue(ConnStr_SSISDB, "ConnStr_DV");
            DBReference.InitiateDBReference(ConnStr_LND, ConnStr_SSISDB, ConnStr_DV);

            if(DataSetTypesDic == null)
            {
                DataSetTypesDic = new Dictionary<string, string>();
                DataSetTypesDic.Add(ActivityConstant.CowDatasetTypeCD, "NATIONAL_COW_ID");
                DataSetTypesDic.Add(ActivityConstant.BullDatasetTypeCD, "NATIONAL_BULL_ID");
            }
        }
        #endregion

        #region Instance
        public static ActivityLogHelper Instance(string ConnStr_SSISDB)
        {
            // Just refresh singleton
            _instance = new ActivityLogHelper(ConnStr_SSISDB);

            return _instance;
        }
        #endregion

        #region Methods to use
        public static string GetWPIDFromActivityLogId(int activityLogId)
        {
            string WPID = (string)DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                                               string.Format(@" SELECT RELATED_WPID FROM report.ACTIVITY_LOGS WHERE PID = {0}", activityLogId));

            return WPID;
        }

        public static int CreateActivityLog(int sessionId, string taskCode)
        {
            string activityLogIdStr = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                string.Format(@"DECLARE @PID BIGINT
                                                        EXEC [dbo].[usp_common_log_activity] 
                                                        @SESSION_ID = {0},
                                                        @TASK_CD = '{1}',
                                                        @PID = @PID OUTPUT
                                                        SELECT @PID as PID
                                           ", sessionId, taskCode)).ToString();
            var activityLogId = 0;
            int.TryParse(activityLogIdStr, out activityLogId);

            return activityLogId;
        }

        public static void SetActivityLogStatus(int activityLogId, string status, string message, string eventData = "")
        {
            DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                string.Format("DECLARE @PID BIGINT EXEC dbo.wsp_update_activity_log_status @JOB_ID ={0}, @STATUS ='{1}', @MESSAGE ='{2}', @EVENT_DATA ='{3}', @PID = @PID OUTPUT SELECT @PID as PID", 
                    activityLogId, status, message.Replace("'", "''"), eventData.Replace("'", "''"))).ToString();
        }

        public static ActivityLog GetActivityLog(int activityLogId)
        {
            var activityLog = new ActivityLog();
            DataSet activityLogDs = DataReaderUtilities.GetData(DBReference.ConnStr_DV,
                string.Format("EXEC dbo.wsp_get_job_detail @JOB_ID ={0}", activityLogId));
            if (activityLogDs != null && activityLogDs.Tables.Count > 0)
            {
                activityLog.RUN_NAME = activityLogDs.Tables[0].Rows[0]["RUN_NAME"].ToString();
                activityLog.RUN_AT = DateTime.Parse(activityLogDs.Tables[0].Rows[0]["RUN_AT"].ToString());
                activityLog.STATUS = activityLogDs.Tables[0].Rows[0]["STATUS"].ToString();
                activityLog.RUN_BY = activityLogDs.Tables[0].Rows[0]["RUN_BY"].ToString();
                activityLog.ERROR_MESSAGE = activityLogDs.Tables[0].Rows[0]["ERROR_MESSAGE"].ToString();
                activityLog.FRESH = activityLogDs.Tables[0].Rows[0]["FRESH"].ToString();
                activityLog.CLONE = activityLogDs.Tables[0].Rows[0]["CLONE"].ToString();
                activityLog.EXTRACT_ONLY = activityLogDs.Tables[0].Rows[0]["EXTRACT_ONLY"].ToString();
                activityLog.CACL_DQI_FFP = activityLogDs.Tables[0].Rows[0]["CACL_DQI_FFP"].ToString();
                activityLog.START_TIME = DateTime.Parse(activityLogDs.Tables[0].Rows[0]["START_TIME"].ToString());
                activityLog.END_TIME = DateTime.Parse(activityLogDs.Tables[0].Rows[0]["END_TIME"].ToString());
                activityLog.RUN_TIME = activityLogDs.Tables[0].Rows[0]["RUN_TIME"].ToString();
                activityLog.RELATED_WPID = activityLogDs.Tables[0].Rows[0]["RELATED_WPID"].ToString();

                activityLog.FILES = new List<ActivityLogFile>();
                for (int i = 0; i < activityLogDs.Tables[0].Rows.Count; i++)
                {
                    var file = new ActivityLogFile
                    {
                        FILE_NAME = activityLogDs.Tables[0].Rows[i]["FILE_NAME"].ToString(),
                        DESCRIPTION = activityLogDs.Tables[0].Rows[i]["DESCRIPTION"].ToString(),
                        FILE_PATH = activityLogDs.Tables[0].Rows[i]["FILE_PATH"].ToString(),
                        FILE_ID = activityLogDs.Tables[0].Rows[i]["FILE_ID"].ToString()
                    };
                    activityLog.FILES.Add(file);
                }
            }

            return activityLog;
        }

        public static List<WorkFlowOutput> GetDIFWorkflowOutputs(string WPID, string datasetTypeCD)
        {
            var rs = new List<WorkFlowOutput>();
            string nationalIdCol = DataSetTypesDic[datasetTypeCD];
            DataSet ds = DataReaderUtilities.GetData(DBReference.ConnStr_LND,
                string.Format(@"EXEC usp_Get_DIFWorkflowOutput @WPID ={0}, @DATASET_TYPE_CD ='{1}'", WPID, datasetTypeCD));

            if (ds != null && ds.Tables.Count > 0)
            {
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    var output = new WorkFlowOutput
                    {
                        RUN_ID = int.Parse(ds.Tables[0].Rows[i]["RUN_ID"].ToString()),
                        VENDOR = ds.Tables[0].Rows[i]["VENDOR"].ToString(),
                        FILE_FULL_NAME = ds.Tables[0].Rows[i]["FILE_FULL_NAME"].ToString(),
                        ROW_REJECT_FLAG = ds.Tables[0].Rows[i]["ROW_REJECT_FLAG"].ToString(),
                        ROW_REJECT_CD = ds.Tables[0].Rows[i]["ROW_REJECT_CD"].ToString(),
                        ROW_REJECT_MESSAGE = ds.Tables[0].Rows[i]["ROW_REJECT_MESSAGE"].ToString(),
                        ROW_LINE_ID = ds.Tables[0].Rows[i]["ROW_LINE_ID"].ToString(),
                        ROW_PHYSICAL_ID = ds.Tables[0].Rows[i]["ROW_PHYSICAL_ID"].ToString(),
                        NATIONAL_ID = ds.Tables[0].Rows[i][nationalIdCol].ToString()
                    };
                    rs.Add(output);
                }
            }

            return rs;
        }

        public static string GetWorkflowStatus(string WPID)
        {
            return WorkflowOperation.WorkflowOperation.GetWorkflowOperationStatus(WPID);
        }

        public static WFActivityStatus GetWFActivityStatus(int activityLogId, string datasetTypeCD)
        {
            var WPID = GetWPIDFromActivityLogId(activityLogId);
            var rs = new WFActivityStatus
            {
                WorkflowStatus = GetWorkflowStatus(WPID),
                ActivityLog = GetActivityLog(activityLogId),
                WorkFlowOutputs = GetDIFWorkflowOutputs(WPID, datasetTypeCD)
            };

            return rs;
        }
        #endregion
    }
}
