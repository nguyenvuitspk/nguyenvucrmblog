FileHelpers Library Installed
-----------------------------

Check the version history at: http://www.filehelpers.net/changelog/

Visit the new home page http://www.filehelpers.net for more examples, tips and tutorials

Enjoy the library !!