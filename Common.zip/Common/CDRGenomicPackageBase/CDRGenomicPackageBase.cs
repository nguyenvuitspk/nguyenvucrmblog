﻿using CDRGenomicHelper;
using SQLUtilsLib;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDRGenomicPackageBase
{
    public abstract class CDRGenomicPackageBase : GenomicPackageBase.GenomicPackageBase
    {
        protected string connStrLND = string.Empty;

        protected WorkflowFile systemWorkflowLog;
        protected abstract override List<WorkflowOperation.Parameter> outputParameters { get; set; }

        public abstract override void Process();

        public override void GetInputParameters()
        {
            base.GetInputParameters();

            connStrLND = WorkflowOperation.WorkflowOperation.GetConfigurationValue(connStrSSISDB, "ConnStr_LND");
            DBReference.InitiateDBReference(connStrLND, connStrSSISDB, connStrDV);
            //[WPID] _[WFNAME].syslog
            string workflowName = GenomicDataHelper.BuildWorkFlowName(long.Parse(wPID));
            // using for writing system error
            systemWorkflowLog = new WorkflowFile(Int64.Parse(wPID), string.Format(WorkflowLogConstant.FILE_NAME_SYSTEM_LOG, wPID, workflowName), WorkflowLogConstant.SYSTEM_LOG_TYPE);
            systemWorkflowLog.WriteProcess(PID, WorkflowLogConstant.TRANSFORMATION_STATUS_START);
        }

        public override void WriteOutputs()
        {
            // Coding here to keep track DV_RUN_ID to finish the package

            // Set status OK for exported files belongs to workflow
            GenomicDataHelper.UpdateStatusWorkflow(Int64.Parse(wPID), WorkflowLogConstant.STATUS_OK);

            base.WriteOutputs();
        }

        public override void LogException(Exception ex, string packageParameters = "")
        {
            if (ex is UserException || (ex is SqlException && (ex as SqlException).Number == GSEnvironmentSetting.BUSINESS_ERROR_CODE))
            {
                base.LogException(ex, string.Empty);
            }
            else
            {
                string errorDate = String.Format("{0:G}", DateTime.Now);
                systemWorkflowLog.Write(string.Format(GenomicMessage.ERR_MSG_SYSTEM_ERROR, errorDate, $"{ex.Message}; {packageParameters}"));
                Exception newEx = new Exception(GenomicMessage.ERR_MSG_INTERNAL_EXCEPTION_ERROR);
                base.LogException(newEx, string.Empty);
            }

            systemWorkflowLog.WriteProcess(PID, WorkflowLogConstant.TRANSFORMATION_STATUS_END);
        }
    }
}
