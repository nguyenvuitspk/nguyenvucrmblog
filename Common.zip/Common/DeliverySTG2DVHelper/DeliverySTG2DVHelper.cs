﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataReaderUtilsLib;
using SQLUtilsLib;
using CommonETLLibs;
using System.Data;

namespace DeliverySTG2DVHelper
{
    public class DeliverySTG2DVHelper
    {
        public int CreateRun()
        {
            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                 string.Format(@"
                            DECLARE @MyNewIdentityValues table(ID BIGINT)
                            INSERT INTO [dbo].[DV_RUNS] OUTPUT Inserted.DV_RUN_ID INTO @MyNewIdentityValues 
                            DEFAULT VALUES 
                            select ID FROM @MyNewIdentityValues
                               "));
            return Convert.ToInt32(value);
        }


        public int CreateRunStatus(long RUN_ID, string STATUS_CD)
        {
            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                 string.Format(@"insert into [dbo].[DV_RUN_STATUS]
                                 ( [DV_RUN_ID] ,[STATUS_CD],[STATUS_CHANGE_TS])
                                 values ( {0},'{1}','{2}')

                               ", RUN_ID, STATUS_CD, DateTime.Now.ToString(Constant.SqlDateTimeFortmat)));
            return Convert.ToInt32(value);
        }
        public int GetCurrentRun()
        {
            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                 string.Format(@"select max(DV_RUN_ID) DV_RUN_ID from [dbo].[DV_RUNS]
                               "));
            return Convert.ToInt32(value);
        }

        public string GetListSTGRun()
        {
            string STGRunIds = string.Empty;
            string sql = string.Format(@"exec spGetListSTGRun");
            var ds = DataReaderUtilities.GetData(DBReference.ConnStr_STG, sql);

            if (!(ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0))
            {
                STGRunIds = string.Join(",", ds.Tables[0].AsEnumerable().Select(dataRow => dataRow.Field<int>("STG_RUN_ID")).Select(x => x.ToString()).ToArray());
            }
            return STGRunIds;
        }

        public void UpdateProcessingSTGRunList(string ProcessingSTGRunList)
        {
            string STGRunIds = string.Empty;
            string sql = string.Format(@"update [dbo].[SSISConfiguration] set [ConfiguredValue] ='{0}' where [ConfigurationName]='ProcessingSTGRunList' ", ProcessingSTGRunList);
            var ds = DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, sql);
        }

        public string GetProcessingSTGRunList()
        {
            string STGRunIds = string.Empty;
            string sql = string.Format(@"select [ConfiguredValue] from [dbo].[SSISConfiguration]where [ConfigurationName]='ProcessingSTGRunList'");
            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, sql);
            return value.ToString();
        }

        public void UpdateSTGRunIsProcessed(string ProcessingSTGRunList)
        {
            if (!string.IsNullOrEmpty(ProcessingSTGRunList))
            {
                string sql = string.Format(@"update [dbo].[STG_RUNS] set [IS_DV]=1 where [STG_RUN_ID] in({0})", ProcessingSTGRunList);
                DataReaderUtilities.GetData(DBReference.ConnStr_STG, sql);
            }
        }
    }
}
