﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ExportCSVHelper
{
    public class ExportCSV
    {
        public const string DELIMITER = ",";
        
        /// <summary>
        /// Export result of SQL Query to CSV file with header
        /// </summary>
        /// <param name="ConnStr_Source"> </param>
        /// <param name="sqlQueryData"></param>
        /// <param name="filePath"></param>
        /// <param name="delimiterChar"></param>
        /// <param name="header">E.g. "ANIMAL_NATIONTAL_ID,HEAR_ANIMAL_ID,HERD_TEST_VISIT_DATE"</param>
        public static void ExportSQLQueryToCSV(string ConnStr_Source, string sqlQueryData, string filePath, string delimiterChar, string header = null)
        {
            string headerFilePath = filePath.Replace(".CSV", ".csv").Replace(".csv", ".header");
            string dataFilePath = filePath.Replace(".CSV", ".csv").Replace(".csv", ".data");
            
            System.Data.Common.DbConnectionStringBuilder builder = new System.Data.Common.DbConnectionStringBuilder();
            builder.ConnectionString = ConnStr_Source;
            string serverName = builder["Data Source"] as string;
            string dbName = builder["Initial Catalog"] as string;

            // create header file
            if (!string.IsNullOrEmpty(header))
            {
                header = "SELECT " + header;
                ExportSQLQueryToFile(header, headerFilePath, serverName, dbName, delimiterChar);
            }
           
            // export data file
            ExportSQLQueryToFile(sqlQueryData, dataFilePath, serverName, dbName, delimiterChar);

            // Merge header and data file into destination csv file
            string[] fileList = null;
            if (string.IsNullOrEmpty(header))
            {
                fileList = new string[] { dataFilePath };
            }
            else
            {
                fileList = new string[] { headerFilePath, dataFilePath };
            }
            MergeFiles(fileList, filePath);

            // clean up temporary files
            if (File.Exists(headerFilePath))
            {
                File.Delete(headerFilePath);
            }
            if (File.Exists(dataFilePath))
            {
                File.Delete(dataFilePath);
            }
        }

        /// <summary>
        /// Utility function to export the result of sqlQuery to destFile using BCP
        /// This function is same as ImportHelperLib.ImportDIFHelper.ExportToFile but using -c option instead of -w and not count the exported rows
        /// </summary>
        /// <param name="sqlQuery"></param>
        /// <param name="destFile"></param>
        /// <param name="serverName"></param>
        /// <param name="dbName"></param>
        /// <param name="delimiter"></param>
        public static void ExportSQLQueryToFile(string sqlQuery, string destFile, string serverName, string dbName, string delimiter)
        {
            if (!String.IsNullOrEmpty(delimiter))
            {
                delimiter = " -t " + delimiter;
            }

            sqlQuery= @"""" + sqlQuery + @"""";
            string command = sqlQuery + @" queryout " + destFile + " -S " + serverName + " -d " + dbName + " -U -T -c -C ACP " + delimiter;

            var p = new Process();
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.RedirectStandardError = true;
            p.StartInfo.CreateNoWindow = true;
            p.StartInfo.FileName = "bcp";
            p.StartInfo.Arguments = command;
            try
            {
                p.Start();
                p.BeginOutputReadLine();

                StreamReader myStreamReader = p.StandardError;
                Console.WriteLine(myStreamReader.ReadLine());
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace.ToString());
                Console.WriteLine(e.Message);
                Console.ReadLine();
            }
            p.WaitForExit();
        }
        
        /// <summary>
        /// Merge list of source files to one destination file
        /// </summary>
        /// <param name="fileList">Array of source file paths</param>
        /// <param name="destFile">File path of destination file</param>
        public static void MergeFiles(string[] fileList, string destFile)
        {

            string command = "/C copy /b " + string.Join(" + ", fileList) + " " + destFile;
            var psi = new ProcessStartInfo("cmd.exe")
            {
                Arguments = command,
                UseShellExecute = false,
                CreateNoWindow = true
            };

            using (var process = Process.Start(psi))
            {
                process.WaitForExit();
            }

        }

        /// <summary>
        /// Convert .Net datetime to UnixTimeStamp
        /// </summary>
        /// <param name="dt"> default is Datetime.Now</param>
        /// <returns></returns>
        public static double ConvertDateTimeToUnixTimeStamp(DateTime? dt = null)
        {
            if (!dt.HasValue)
            {
                dt = DateTime.Now;
            }
            TimeSpan span = (dt.Value - new DateTime(1970, 1, 1, 0, 0, 0, 0).ToLocalTime());
            return span.TotalSeconds;
        }
    }
}
