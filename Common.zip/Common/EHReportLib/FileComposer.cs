﻿using OfficeOpenXml;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace EHReportLib
{
    public static class FileComposer
    {
        #region Text File

        public static void ExportTXTFile(DataTable data, string destFilePath)
        {
            if (!Directory.Exists(Path.GetDirectoryName(destFilePath)))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(destFilePath));
            }
            var file = File.Create(destFilePath);
            using (StreamWriter fStream = new StreamWriter(file))
            {
                // This loop is adding column name
                foreach (var column in data.Columns)
                {
                    fStream.Write(column.ToString() + "\t");
                }
                fStream.Write("\n");

                // This loop is adding data for each row
                foreach (DataRow row in data.Rows)
                {
                    foreach (var item in row.ItemArray)
                    {
                        fStream.Write((item != null ? item.ToString() : "\t") + "\t");
                    }
                    fStream.Write("\n");
                }
            }
        }

        #endregion


        #region PDF merging

        public static void PdfMerging(List<string> pdfFiles, string outPdfFile)
        {
            using (PdfDocument outPdf = new PdfDocument())
            {
                int count = 0;
                foreach (string pdf in pdfFiles)
                {
                    PdfDocument current = PdfReader.Open(pdf, PdfDocumentOpenMode.Import);

                    // Check Good Bulls Guide About 
                    if (count == 0 || count == pdfFiles.Count - 1)
                    {
                        outPdf.AddPage(current.Pages[0]);
                    }

                    // Check other Reports
                    for (int i = 0; i < current.PageCount; i++)
                    {
                        outPdf.AddPage(current.Pages[i]);
                    }
                    count++;
                }

                #region Decoration with graphical
                // Make a font and a brush to draw the page counter.                
                XFont font = new XFont("Segoe UI", 9);
                XBrush brush = new XSolidBrush(new XColor { R = 103, G = 112, B = 126 });
                // Add the page counter.
                string noPages = outPdf.Pages.Count.ToString();
                for (int index = 0; index < outPdf.Pages.Count; index++)
                {
                    if (index > 0 && index < outPdf.Pages.Count - 1)
                    {
                        PdfPage page = outPdf.Pages[index];
                        XRect layoutRectangle = new XRect(page.Width - 80/*X*/, page.Height - font.Height - 10/*Y*/, page.Width/*Width*/, font.Height/*Height*/);
                        using (XGraphics gfx = XGraphics.FromPdfPage(page))
                        {
                            gfx.DrawString(
                                "Page " + (index + 1).ToString() + " of " + noPages,
                                font,
                                brush,
                                layoutRectangle,
                                XStringFormats.TopLeft);
                        }
                    }
                }
                #endregion

                outPdf.Save(outPdfFile);
            }
        }

        #endregion

        #region ZipFile
        public static string AddZipFile(string filePath, string zipFileName)
        {
            string zipPath = string.Empty;
            string directory = Path.GetDirectoryName(filePath);
            DirectoryInfo di = new DirectoryInfo(directory);
            zipPath = string.Format(@"{0}\{1}", di.Parent.FullName, zipFileName);
            ZipFile.CreateFromDirectory(directory, zipPath);
            return zipPath;
        }
        #endregion
    }
}
