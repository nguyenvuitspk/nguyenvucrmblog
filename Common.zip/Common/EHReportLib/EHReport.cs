﻿using DataReaderUtilsLib;
using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using static EHReportLib.Constants;

namespace EHReportLib
{
    using NetworkShareHelper;
    public class EHReport : SSRSReport
    {
        #region Properties

        public string ReportName { get; set; }
        public int SystemReportId { get; set; }
        public string Requestor { get; set; }
        public string ReportDBConnString { get; set; }
        public string FileOutputExt { get; set; }
        public string ReportTime { get; set; }

        #endregion

        public EHReport(string reportName) : base()
        {
            ReportServer server = ManageReports.GetReportServerInformation();
            base.ReportServiceURL = server.ReportServiceURL;
            base.ReportServiceUsername = server.ReportServiceUsername;
            base.ReportServicePassword = server.ReportServicePassword;
            ReportDBConnString = server.ReportDBConnString;

            base.ProjectName = REPORT_PROJECT_NAME;
            base.ReportID = reportName;

            ReportName = reportName;
            SystemReportId = ManageReports.GetSystemReportId(ReportID);
            ReportTime = DateTime.Now.Ticks.ToString();
        }

        #region Methods
        public virtual int SubmitReport(string requestor, List<ReportParameter> parameters)
        {
            return ManageReports.SubmitReport(SystemReportId, requestor, parameters);
        }

        public virtual void SetReportTime(string timestamp)
        {
            ReportTime = timestamp;
        }

        public List<string> GenerateReports(int rptInstanceId, string[] fileTypes, int sessionID)
        {
            List<string> result = new List<string>();
            Requestor = ManageReports.GetRequestor(rptInstanceId);
            foreach (var fType in fileTypes)
            {
                try
                {
                    switch (fType.ToLower())
                    {
                        case "pdf":
                            result.Add(GetReport(rptInstanceId, ReportFileType.PDF, Requestor, sessionID));
                            break;
                        case "txt":
                            //GetReport(rptInstanceId, ReportFileType.TXT);
                            break;
                        default:
                            break;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            return result;
        }

        protected string GetReport(int rptInstanceId, ReportFileType fileType, string requestor, int SessionId)
        {
            string result = string.Empty;
            string reportFilePath = string.Empty;
            string reportFullPath = string.Empty;
            string reportFileName = string.Empty;
            string reportDirectory = string.Empty;
            string reportGenerateDirectory = string.Empty;
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);

            reportDirectory = string.Format(@"{0}\{1}\{2}\{3}\{4}", ManageReports.GetConfiguration(REPORT_WEB_DIRECTORY), EXPORT_HEIFER_DIRECTORY, requestor, SessionId, ReportTime);
            reportGenerateDirectory = string.Format(ReportTime);

            reportFileName = string.Format("{0}-{1}", ManageReports.GetReportOutputName(SystemReportId), ReportParameters.Where(r => r.ParamName == "NLIS_INTERNAL_ID").FirstOrDefault().ParamValue);

            string reportFileExt;
            FILE_TYPE_EXTENSIONS.TryGetValue(fileType, out reportFileExt);


            reportFilePath = string.Format(REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFileName, reportFileExt);
            reportFullPath = string.Format(REPORT_DIRECTORY_FORMAT, reportDirectory, reportFileName, reportFileExt);

            string reportFileDirectory = string.Format(@"{0}\{1}", "WEBReport", ReportTime);
            string reportFileFullPath = string.Format(WEB_REPORT_PATH_FORMAT, reportFileDirectory, reportFileName, reportFileExt);

            try
            {
                switch (fileType)
                {
                    case ReportFileType.PDF:
                        result = Export2Pdf(fileType, reportFullPath);
                        break;
                    case ReportFileType.TXT:
                        //Export2Txt(reportFullPath);
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        #endregion

        #region Handle Main logic
        protected string Export2Pdf(ReportFileType fileType, string finalOutputFile)
        {
            string result = string.Empty;
            ReportID = ReportName;
            bool isConnected = NetworkShareHelper.CheckConnection(ManageReports.GetConfiguration(REPORT_WEB_DIRECTORY), base.ReportServiceUsername, base.ReportServicePassword);
            result = isConnected ? base.GetReportWithoutCredential(finalOutputFile, fileType) : base.GetReport(finalOutputFile, fileType);

            return result;
        }

        private void Export2Txt(string finalOutputFile)
        {
            ReportParameter param = ReportParameters.Where(rp => rp.ParamName.Equals("param_Runs")).FirstOrDefault();
            if (param != null)
            {
                var rptData = DataReaderUtilities.GetData(ReportDBConnString, string.Format(@"EXEC dbo.usp_{0} @param_Runs = '{1}'", ReportID, param.ParamValue));
                if ((rptData != null) && (rptData.Tables.Count > 0))
                {
                    FileComposer.ExportTXTFile(rptData.Tables[0], finalOutputFile);
                }
            }
        }
        #endregion
    }
}
