﻿using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EHReportLib
{
    public class Constants
    {
        public const string REPORT_PROJECT_NAME = "ExportHeifer";
        public const string REPORT_DB_CONN = "REPORT_DB_CONN";
        public const string REPORT_SERVICE_URL = "REPORT_SERVICE_URL";
        public const string REPORT_SERVICE_USERNAME = "REPORT_SERVICE_USERNAME";
        public const string REPORT_SERVICE_PASSWORD = "REPORT_SERVICE_PASSWORD";
        public const string REPORT_TEMP_PATH_FORMAT = @"{0}\Temp\{1}_{2}_{3}.{4}.{5}";
        public const string DATETIME_FORMAT = @"yyyyMMdd_hhmmss";
        public const string REPORT_DIRECTORY_FORMAT = @"{0}\{1}.{2}";
        //// Website
        public const string WEB_REPORT_PATH_FORMAT = @"{0}/{1}.{2}";
        public const string WEB_REPORT_FILENAME_FORMAT = @"{0}.{1}";
        public const string REPORT_WEB_DIRECTORY = "REPORT_WEB_DIRECTORY";
        public const string EXPORT_HEIFER_DIRECTORY = "EXPORT_HEIFER";

        public static readonly Dictionary<ReportFileType, string> FILE_TYPE_EXTENSIONS = new Dictionary<ReportFileType, string>()
        {
            { ReportFileType.PDF, "pdf" },
            { ReportFileType.CSV, "csv" },
            { ReportFileType.HTML5, "html" },
            { ReportFileType.IMAGE, "png" },
            { ReportFileType.MHTML, "mthml" },
            { ReportFileType.EXCEL, "xls" },
            { ReportFileType.EXCELOPENXML, "xlsx" },
            { ReportFileType.WORD, "doc" },
            { ReportFileType.PPTX, "pptx" },
            { ReportFileType.ATOM, "atom" },
            { ReportFileType.RGDI, "rgdi" },
            { ReportFileType.DIF, "" },
            { ReportFileType.TXT, "txt" },
        };

        public class ReportServer
        {
            public string ReportDBConnString { get; set; }
            public string ReportServiceURL { get; set; }
            public string ReportServiceUsername { get; set; }
            public string ReportServicePassword { get; set; }
        }
    }

    public static class EHReportConfiguration
    {
        public const string EH_PRINT_CERTIFICATE_REPORT_CONFIG_NAME = "EH_RPT_Final_Certificate";
        public const string EH_PRE_EMBARKATION_CERTIFICATION_REPORT_CONFIG_NAME = "EH_RPT_PreEmbarkation_Certificate";
    }
}
