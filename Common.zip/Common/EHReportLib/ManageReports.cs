﻿using DataReaderUtilsLib;
using SQLUtilsLib;
using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using static EHReportLib.Constants;

namespace EHReportLib
{
    public class ManageReports
    {
        #region Get Configurations

        public static string GetConfiguration(string configurationName)
        {
            var serverConfig = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                                   string.Format(@"SELECT [VALUE]
                                                    FROM [report].[CONSTANTS]
                                                    WHERE [NAME] = '{0}'", configurationName));
            return serverConfig?.ToString();
        }

        public static ReportServer GetReportServerInformation()
        {
            ReportServer server = new ReportServer();
            server.ReportDBConnString = GetConfiguration(REPORT_DB_CONN);
            server.ReportServiceURL = GetConfiguration(REPORT_SERVICE_URL);
            server.ReportServiceUsername = GetConfiguration(REPORT_SERVICE_USERNAME);
            server.ReportServicePassword = GetConfiguration(REPORT_SERVICE_PASSWORD);

            return server;
        }
        #endregion

        #region Report Utils

        public static List<ReportParameter> GetReportParameters(int rptInstanceId)
        {
            var parameters = DataReaderUtilities.GetData(DBReference.ConnStr_DV,
                                    string.Format(@"SELECT [PARAM_NAME], [PARAM_VALUE]
                                                    FROM [report].[VIEW_RPT_REPORT_PARAMETERS]
                                                    WHERE [REPORT_INSTANCE_ID] = {0}", rptInstanceId));

            List<ReportParameter> rptParams = new List<ReportParameter>();
            if (parameters != null && parameters.Tables.Count > 0)
            {
                foreach (DataRow dr in parameters.Tables[0].Rows)
                {
                    rptParams.Add(new ReportParameter()
                    {
                        ParamName = dr["PARAM_NAME"].ToString(),
                        ParamValue = dr["PARAM_VALUE"].ToString()
                    });
                }
            }

            return rptParams;
        }

        public static List<string> GetSubReports(int sysReportId, ReportFileType fileType)
        {
            DataSet data = new DataSet();
            if (fileType.Equals(ReportFileType.PDF))
            {
                data = DataReaderUtilities.GetData(DBReference.ConnStr_DV,
                                    string.Format(@"SELECT [REPORT_NAME] 
                                                    FROM report.SUB_REPORTS 
                                                    WHERE REPORT_ID = {0} AND ACTIVE = 1 
                                                    ORDER BY REPORT_ORDER", sysReportId));
            }
            else if (fileType.Equals(ReportFileType.EXCELOPENXML))
            {
                data = DataReaderUtilities.GetData(DBReference.ConnStr_DV,
                                    string.Format(@"SELECT [REPORT_NAME] 
                                                    FROM report.SUB_REPORTS 
                                                    WHERE REPORT_ID = {0} AND SHEET_NAME IS NOT NULL AND ACTIVE = 1 
                                                    ORDER BY REPORT_ORDER", sysReportId));
            }

            List<string> reports = new List<string>();
            if (data != null && data.Tables.Count > 0)
            {
                if (fileType.Equals(ReportFileType.EXCELOPENXML))
                {
                    foreach (DataRow dr in data.Tables[0].Rows)
                    {
                        string rp = (!string.IsNullOrWhiteSpace(dr["REPORT_NAME"].ToString())) ? dr["REPORT_NAME"].ToString().Trim() : string.Empty;
                        reports.Add(rp);
                    }
                }
                else if (fileType.Equals(ReportFileType.PDF))
                {
                    int latest = data.Tables[0].Rows.Count;
                    int index = 0;
                    foreach (DataRow dr in data.Tables[0].Rows)
                    {
                        index++;
                        string rp = (!string.IsNullOrWhiteSpace(dr["REPORT_NAME"].ToString())) ? dr["REPORT_NAME"].ToString().Trim() : string.Empty;
                        reports.Add(index == latest || index == 1 ? rp : rp + "_PDF");
                    }
                }
            }
            return reports;
        }

        public static int GetSystemReportId(string rptName)
        {
            var systemReportId = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                                   string.Format(@"SELECT [REPORT_ID]
                                                    FROM [report].[REPORTS]
                                                    WHERE [NAME] = '{0}'", rptName));

            return Convert.ToInt32(systemReportId.ToString());
        }

        public static string GetFriendlyName(int sysReportId, string subReportID)
        {
            string frName = string.Empty;
            var data = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                                    string.Format(@"SELECT [SHEET_NAME] 
                                                    FROM report.SUB_REPORTS
                                                    WHERE REPORT_ID = {0} 
                                                        AND REPORT_NAME = '{1}'
                                                    ORDER BY REPORT_ORDER", sysReportId, subReportID));

            frName = data != null ? data.ToString() : string.Empty;
            return frName;
        }

        public static string GetReportOutputName(int sysReportId)
        {
            var outputReportName = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                                      string.Format(@"SELECT [OUTPUT_NAME]
                                                    FROM [report].[REPORTS]
                                                    WHERE [REPORT_ID] = {0}", sysReportId));
            return outputReportName?.ToString();

        }

        public static DataTable GetBreedCodeReport()
        {
            DataTable breedCode = DataReaderUtilities.GetData(DBReference.ConnStr_DV,
                                      string.Format(@"SELECT [BREED_CODE],[SHORT_NAME]
                                                    FROM BREEDS")).Tables[0];
            return breedCode;

        }

        public static DataTable GetReportWithoutTemplate(string connReport, List<ReportParameter> reportParameters, string reportId)
        {
            DataTable result = new DataTable();
            ReportParameter param = reportParameters.Where(x => x.ParamName.Equals("param_Runs")).FirstOrDefault();
            if (param != null)
            {
                var data = DataReaderUtilities.GetData(connReport, string.Format(@"EXEC dbo.usp_{0} @param_Runs = '{1}'", reportId, param.ParamValue));
                result = data.Tables[0];
            }

            return result;
        }

        public static string GetRequestor(int rptInstanceId)
        {
            var requestor = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                                   string.Format(@"SELECT rRuns.REPORTER
                                                FROM report.REPORT_RUNS rRuns
                                                JOIN report.REPORT_INSTANCES rInstance ON rInstance.REPORT_RUN_ID = rRuns.REPORT_RUN_ID
                                                WHERE rInstance.REPORT_INSTANCE_ID = {0}", rptInstanceId));
            return requestor?.ToString();
        }

        public static string GetReportName(int rptInstanceId)
        {
            var reportName = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                                   string.Format(@"SELECT reports.NAME
                                                FROM report.REPORTS reports
                                                JOIN report.REPORT_INSTANCES rInstance ON rInstance.REPORT_ID = reports.REPORT_ID
                                                WHERE rInstance.REPORT_INSTANCE_ID = {0}", rptInstanceId));
            return reportName?.ToString();
        }

        public static int SubmitReport(int sysReportId, string requestor, List<ReportParameter> parameters)
        {
            DataSet datasets = new DataSet();
            DataTable paramDt = ConvertParameterToDataTable(parameters);
            int rptInstanceId = int.MinValue;

            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(DBReference.ConnStr_DV);
            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                connection.Open();
                // Configure the SqlCommand and SqlParameter. 
                SqlCommand cmd = new SqlCommand("report.usp_rpt_submit_report", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter reportIdParam = cmd.Parameters.AddWithValue("@REPORT_ID", sysReportId);
                reportIdParam.SqlDbType = SqlDbType.Int;

                SqlParameter requestorParam = cmd.Parameters.AddWithValue("@REQUESTOR", requestor);
                requestorParam.SqlDbType = SqlDbType.VarChar;

                SqlParameter parameterParam = cmd.Parameters.AddWithValue("@Params", paramDt);
                parameterParam.SqlDbType = SqlDbType.Structured;

                SqlParameter rptInstanceIdParam = cmd.Parameters.Add("@REPORT_INSTANCE_ID", SqlDbType.Int);
                rptInstanceIdParam.Direction = ParameterDirection.Output;

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                adapter.SelectCommand.CommandTimeout = 0;
                adapter.Fill(datasets);

                rptInstanceId = Convert.ToInt32(rptInstanceIdParam.Value);
                connection.Close();
            }

            return rptInstanceId;
        }

        public static DataTable ConvertParameterToDataTable(List<ReportParameter> parameters)
        {
            // Here we create a DataTable with fine columns.
            DataTable table = new DataTable();
            table.Columns.Add("PARAM_NAME", typeof(string));
            table.Columns.Add("PARAM_VALUE", typeof(string));

            foreach (ReportParameter param in parameters)
            {
                table.Rows.Add(param.ParamName, param.ParamValue);
            }

            return table;
        }

        public static string GetActiveRunId(string sConnString)
        {
            string sqlCommand = @"SELECT TOP 1 runs.RUN_ID
                                FROM dbo.RELEASES (NOLOCK) releases
                                JOIN dbo.RUNS (NOLOCK) runs ON runs.RELEASE_ID = releases.RELEASE_ID
                                WHERE releases.[STATUS] = 'Active'
	                                AND runs.RUN_TYPE = 'FINAL_BV'
                                    AND runs.[STATUS] = 'COMPLETED'
                                ORDER BY runs.RUN_DATE DESC";

            return DataReaderUtilities.GetScalaValue(sConnString, sqlCommand).ToString();
        }
        #endregion

        #region Report Files

        public static void SaveGeneratedRptFile(int rptInstanceId, string fileName, string filePath, string owner, string party = "", DataTable fileTags = null, string status = "", string mess = "")
        {
            DataSet datasets = new DataSet();
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(DBReference.ConnStr_DV);
            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                connection.Open();
                // Configure the SqlCommand and SqlParameter. 
                SqlCommand cmd = new SqlCommand("report.usp_rpt_submit_abv_report_file", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter fileNameParam = cmd.Parameters.AddWithValue("@FILE_NAME", fileName);
                fileNameParam.SqlDbType = SqlDbType.VarChar;

                SqlParameter filePathParam = cmd.Parameters.AddWithValue("@FILE_PATH", filePath);
                filePathParam.SqlDbType = SqlDbType.VarChar;

                SqlParameter ownerParam = cmd.Parameters.AddWithValue("@OWNER", owner);
                ownerParam.SqlDbType = SqlDbType.VarChar;

                SqlParameter rptInstanceParam = cmd.Parameters.AddWithValue("@REPORT_INSTANCE_ID", rptInstanceId);
                rptInstanceParam.SqlDbType = SqlDbType.Int;

                SqlParameter partyParam = cmd.Parameters.AddWithValue("@PARTY", party);
                partyParam.SqlDbType = SqlDbType.VarChar;

                SqlParameter fileTagsParam = cmd.Parameters.AddWithValue("@FileTags", fileTags);
                fileTagsParam.SqlDbType = SqlDbType.Structured;

                if (!string.IsNullOrEmpty(status))
                {
                    SqlParameter statusParam = cmd.Parameters.AddWithValue("@STATUS", status);
                    statusParam.SqlDbType = SqlDbType.VarChar;

                    SqlParameter messParam = cmd.Parameters.AddWithValue("@MESS", mess);
                    messParam.SqlDbType = SqlDbType.VarChar;
                }

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                adapter.SelectCommand.CommandTimeout = 0;
                adapter.Fill(datasets);

                connection.Close();
            }
        }

        #endregion
    }
}
