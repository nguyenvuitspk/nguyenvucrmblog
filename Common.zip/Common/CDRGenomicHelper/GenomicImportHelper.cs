﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using DataReaderUtilsLib;
using SQLUtilsLib;
using System.Text.RegularExpressions;

namespace CDRGenomicHelper
{
    public class GenomicImportHelper
    {
        /// <summary>
        /// Create landing batches based on fileList and partyCode
        /// </summary>
        /// <param name="partyCode"></param>
        /// <param name="fileList"></param>
        /// <returns></returns>
        public static IDictionary<int, List<string>> CreateLandingBatches(string partyCode, List<string> fileList)
        {
            int batchId = CreateBatch(partyCode);
            var batch = new Dictionary<int, List<string>>();
            batch.Add(batchId, fileList);

            return batch;
        }

        /// <summary>
        /// Update batch status
        /// </summary>
        /// <param name="batchID"></param>
        /// <param name="status">BATCH_STATUS.NEW, BATCH_STATUS.PENDING, ...</param>
        public static void UpdateLandingBatchStatus(int batchID, string status)
        {
            // Update LND_BATCHES.STATUS
            string sqlCommand = string.Format(@"UPDATE [dbo].[LND_BATCHES]
                                                SET [STAGING_STATUS] = {0}
                                                WHERE [BATCH_ID] = {1}", status, batchID);

            DataReaderUtilities.GetScalaValue(DBReference.ConnStr_LND, sqlCommand);
        }
        
        /// <summary>
        /// Update landing batch to failed QA when got format error
        /// </summary>
        /// <param name="batchID"></param>
        public static void UpdateFailedQALandingBatch(int batchID)
        {
            // Update LND_BATCHES.STATUS
            string sqlCommand = string.Format(@"UPDATE [dbo].[LND_BATCHES]
                                                SET [IS_FAILED_QA] = 1
                                                WHERE [BATCH_ID] = {0}", batchID);

            DataReaderUtilities.GetScalaValue(DBReference.ConnStr_LND, sqlCommand);
        }

        /// <summary>
        /// Create landing run belong to a batch with a datasetkey (get from IdentifyDataset)
        /// </summary>
        /// <param name="batchID"></param>
        /// <param name="datasetKey"></param>
        /// <param name="filepath"></param>
        /// <returns></returns>
        public static int InitLandingRun(int? batchID, int datasetKey, string filepath, string partyCode)
        {
            string fileName = Path.GetFileName(filepath);

            if (string.IsNullOrEmpty(partyCode))
            {
                var dir = Path.GetDirectoryName(filepath);
                partyCode = GetPartyCodeByDirPath(dir);
            }

            // Insert into LND_RUNS
            string sqlCommand = string.Format(@"INSERT INTO dbo.LND_RUNS
                                                        ( [DATASET_KEY]
                                                          ,[RELATED_RUN_ID]
                                                          ,[RUN_SOURCE_PARTY_NAME]
                                                          ,[RUN_PATH]
                                                          ,[RUN_FILE]
                                                          ,[IS_STAGED]
                                                          ,[BATCH_ID]
                                                        )
                                                OUTPUT INSERTED.[RUN_ID]
                                                VALUES  ( {0}
                                                          ,NULL
                                                          ,'{1}'
                                                          ,'{2}'
                                                          ,'{3}'
                                                          ,{4}
                                                          ,{5}
                                                        )", datasetKey, partyCode, filepath, fileName, (int)LND_RUN_STATUS.LANDED_SUCCESS, batchID?.ToString() ?? "NULL");

            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_LND, sqlCommand);
            return value != null ? int.Parse(value.ToString()) : -1;
        }

        /// <summary>
        /// Extract file summary and import into LND_HEADERS
        /// </summary>
        /// <param name="lndRunID"></param>
        /// <param name="firstRow"></param>
        /// <param name="lastRow"></param>
        public static void ImportLandingHeader(int lndRunID, int firstRow, int lastRow, string delimiter = GSEnvironmentSetting.DEFAULT_EXPORT_FILE_DELIMITER)
        {
            var filepath = GetFilePathByRunID(lndRunID);
            var fileLines = File.ReadAllLines(filepath).Skip(firstRow - 1).Take(lastRow - firstRow + 1);
            DataTable LndHeaders = CreateLandingHeaders();
            int count = firstRow;

            foreach (var fileLine in fileLines)
            {
                var lineItems = Regex.Split(fileLine, delimiter);
                DataRow row = LndHeaders.NewRow();
                row["RUN_ID"] = lndRunID;
                row["ROW_PHYSICAL_ID"] = count;
                row["HEADER_KEY"] = lineItems[0];
                row["HEADER_VALUE"] = lineItems[1];
                LndHeaders.Rows.Add(row);
                count++;
            }

            // Calling stored procedure
            var connStrLND = DBReference.ConnStr_LND.Replace(";Provider=SQLNCLI11.1", "");
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(connStrLND);
            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                connection.Open();
                // Configure the SqlCommand and SqlParameter.
                SqlCommand insertCommand = new SqlCommand("usp_common_add_lnd_header", connection);
                insertCommand.CommandType = CommandType.StoredProcedure;
                SqlParameter validPedigreeValuesParam = insertCommand.Parameters.AddWithValue("@LndHeaders", LndHeaders);
                validPedigreeValuesParam.SqlDbType = SqlDbType.Structured;

                //Set timeout no limit
                insertCommand.CommandTimeout = 0;
                // Execute the command.
                insertCommand.ExecuteNonQuery();
                connection.Close();
            }
        }

        /// <summary>
        /// build data table for landing header
        /// </summary>
        /// <param name="firstRow"></param>
        /// <param name="lastRow"></param>
        /// <param name="lndRunID"></param>
        /// <param name="delimiter"></param>
        /// <returns></returns>
        public static DataTable GetLandingHeaderDataTable(string filepath, int firstRow, int lastRow, string delimiter = GSEnvironmentSetting.DEFAULT_EXPORT_FILE_DELIMITER, int lndRunID = -1)
        {
            var fileLines = File.ReadLines(filepath).Skip(firstRow - 1).Take(lastRow - firstRow + 1);
            DataTable LndHeaders = CreateLandingHeaders();
            int count = firstRow;

            foreach (var fileLine in fileLines)
            {
                var lineItems = Regex.Split(fileLine, delimiter);
                DataRow row = LndHeaders.NewRow();
                row["RUN_ID"] = lndRunID;
                row["ROW_PHYSICAL_ID"] = count;
                row["HEADER_KEY"] = lineItems[0];
                row["HEADER_VALUE"] = lineItems[1];
                LndHeaders.Rows.Add(row);
                count++;
            }

            return LndHeaders;
        }

        /// <summary>
        /// Update landing run status
        /// </summary>
        /// <param name="lndRunID"></param>
        /// <param name="status">LND_RUN_STATUS.LANDED_SUCCESS</param>
        public static void UpdateLandingStatus(int lndRunID, LND_RUN_STATUS status)
        {
            // Update LND_RUNS.IS_STAGED
            string sqlCommand = string.Format(@"UPDATE [dbo].[LND_RUNS]
                                                SET [IS_STAGED] = {0}
                                                WHERE [RUN_ID] = {1}", status, lndRunID);

            DataReaderUtilities.GetScalaValue(DBReference.ConnStr_LND, sqlCommand);
        }

        /// <summary>
        /// Simple detection DatasetKey of a file based on its extension
        /// </summary>
        /// <param name="filepath"></param>
        /// <param name="typeName"></param>
        /// <returns></returns>
        public static IDictionary<int, string> IdentifyDataset(string filepath, string typeName = null)
        { 
            // Failed to get Dataset, TF need to manually detect dataset
            var extension = Path.GetExtension(filepath);
            if (extension != null)
            {
                string ext = extension.Replace(".", string.Empty);
                string sqlCommand = string.Empty;

                if (typeName == null)
                {
                    sqlCommand = string.Format(@"SELECT lDatasets.[DATASET_KEY], lDFormats.[FORMAT_XML]   
                                                    FROM [dbo].[LND_DATASETS] lDatasets
                                                    INNER JOIN [dbo].[LND_DATASET_FORMATS] lDFormats ON lDFormats.[DATASET_KEY] = lDatasets.[DATASET_KEY]
                                                    WHERE lDatasets.[DATASET_TYPE_CD] = '{0}'", ext);
                }
                else
                {
                    sqlCommand = string.Format(@"SELECT lDatasets.[DATASET_KEY], lDFormats.[FORMAT_XML]   
                                                    FROM [dbo].[LND_DATASETS] lDatasets
                                                    INNER JOIN [dbo].[LND_DATASET_FORMATS] lDFormats ON lDFormats.[DATASET_KEY] = lDatasets.[DATASET_KEY]
                                                    WHERE lDatasets.[DATASET_TYPE_CD] = '{0}' AND lDatasets.[DATASET_TYPE_NAME] = '{1}'", ext, typeName);
                }

                var dataset = DataReaderUtilities.GetData(DBReference.ConnStr_LND, sqlCommand);
                var table = dataset == null ? new DataTable() : dataset.Tables[0];
                if (table.Rows.Count == 1)
                {
                    var datasetKey = int.Parse(table.Rows[0]["DATASET_KEY"].ToString());
                    var xmlFormat = table.Rows[0]["FORMAT_XML"].ToString();
                    return new Dictionary<int, string> {{datasetKey, xmlFormat}};
                }
            }

            return null;
        }

        /// <summary>
        /// Get party code in file path when request from FTP
        /// </summary>
        /// <param name="dir"></param>
        /// <returns></returns>
        public static string GetPartyCodeByDirPath(string dir)
        {
            List<string> listFolderName = dir.Split('\\').ToList();

            listFolderName.Reverse(0, listFolderName.Count);
            var partycode = listFolderName[1];

            return partycode;
        }

        /// <summary>
        /// Check content file is empty or not
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static bool IsEmptyContentFile(string fileName)
        {
            if (File.Exists(fileName))
            {
                if (new FileInfo(fileName).Length == 0)
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Log warning message into transformation operation in database
        /// </summary>
        /// <param name="PID"></param>
        /// <param name="message"></param>
        public static void LogWarningForTransformationOperation(long PID, string message)
        {
            DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, string.Format(@"exec [dbo].[spLogMessageForTransformationOperations]
                                                                                @PID ={0},
                                                                                @MessageSource = '{1}',
                                                                                @Message = '{2}'"
                                                                            , PID
                                                                            , GSEnvironmentSetting.GENOTYPE_SOURCE
                                                                            , message));
        }

        /// <summary>
        /// Insert new batch into db
        /// </summary>
        /// <param name="partyCode"></param>
        /// <returns></returns>
        private static int CreateBatch(string partyCode)
        {
            string sqlCommand = string.Format(@"INSERT [dbo].[LND_BATCHES]
                                                        ( [PARTY_CODE]
                                                          ,[LOADED_DATE]
                                                          ,[STAGING_STATUS]
                                                          ,[IS_FAILED_QA]
                                                        )
                                                OUTPUT INSERTED.[BATCH_ID]
                                                VALUES  ( '{0}'
                                                          ,GETDATE()
                                                          ,'{1}'
                                                          ,0
                                                        )", partyCode, CDRBatchConstant.BATCH_STATUS_NEW);

            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_LND, sqlCommand);
            return value != null ? int.Parse(value.ToString()) : -1;
        }

        /// <summary>
        /// Get file path in LND_RUNS
        /// </summary>
        /// <param name="lndRunID"></param>
        /// <returns></returns>
        private static string GetFilePathByRunID(int lndRunID)
        {
            string sqlCommand = string.Format(@"SELECT [RUN_PATH] 
                                                FROM dbo.[LND_RUNS]
                                                WHERE [RUN_ID] = {0}", lndRunID);

            var filepath = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_LND, sqlCommand).ToString();

            return filepath;
        }

        /// <summary>
        /// Table to store SAT_GDNA_IMPUTED values
        /// </summary>
        /// <returns></returns>
        private static DataTable CreateLandingHeaders()
        {
            DataTable LndHeaders = new DataTable("LndHeaders");

            LndHeaders.Columns.Add("RUN_ID", typeof(int));
            LndHeaders.Columns.Add("ROW_PHYSICAL_ID", typeof(int));
            LndHeaders.Columns.Add("HEADER_KEY", typeof(string));
            LndHeaders.Columns.Add("HEADER_VALUE", typeof(string));

            return LndHeaders;
        }
    }
}
