﻿using NetworkShareHelper;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Net;

namespace CDRGenomicHelper
{
    public class WorkflowLog
    {
        private WorkflowFile logFile;
        private WorkflowFile errorFile;
        private string workflowName;
        private string folderPath;
        private long WPID;
        private long PID;

        public string LogFilePath
        {
            get
            {
                return logFile.FilePath;
            }
        }

        public string ErrorFilePath
        {
            get
            {
                return errorFile.FilePath;
            }
        }

        /// <summary>
        /// Create log and eror for workflow
        /// </summary>
        /// <param name="_WPID"></param>
        /// <param name="_PID"></param>
        public WorkflowLog(long _WPID, long _PID)
        {
            WPID = _WPID;
            PID = _PID;
            workflowName = GenomicDataHelper.BuildWorkFlowName(_WPID);
            var networkAccess = new GNetworkAccess(WorkflowLogConstant.WEB_DIRECTORY_BIN);

            using (new NetworkConnection(networkAccess.RootFolder, new NetworkCredential(networkAccess.Username, networkAccess.Password)))
            {
                folderPath = GenomicDataHelper.BuildLocationForFile(networkAccess.RootFolder, WorkflowLogConstant.LOG_DIRECTORY);

                // build log file and error file
                string logFileName = $"{_WPID}_{workflowName}.{GenomicExtension.LOG_FILE_EXT}";
                string logFilePath = Path.Combine(folderPath, logFileName);

                // create log file if not exist
                if (!File.Exists(logFilePath))
                {
                    logFile = new WorkflowFile(_WPID, logFileName, WorkflowLogConstant.LOG_TYPE);
                    WriteFileHeader(WorkflowLogConstant.LOG_TYPE);
                }
                else // error file existed, create new instance, not write header
                {
                    logFile = new WorkflowFile(_WPID, logFileName, WorkflowLogConstant.LOG_TYPE);
                }

                WriteProcess(_PID, WorkflowLogConstant.LOG_TYPE);
            }
        }

        /// <summary>
        /// Append text to file
        /// </summary>
        public void WriteLog(string content)
        {
            logFile.Write(content);
        }

        /// <summary>
        /// Write log for datatable
        /// </summary>
        public void WriteLog(DataTable dt, string delimiter = GSEnvironmentSetting.DEFAULT_EXPORT_FILE_DELIMITER, bool isWriteTableHeader = true)
        {
            logFile.Write(dt, delimiter, isWriteTableHeader);
        }

        /// <summary>
        /// Append text to file with list content
        /// </summary>
        public void WriteLog(IEnumerable<string> contents)
        {
            logFile.Write(contents);
        }

        /// <summary>
        /// Append text to error file with list content
        /// </summary>
        public void WriteError(IEnumerable<string> contents)
        {
            // Exist error.
            CreateErrorFile();
            errorFile.Write(contents);
        }

        /// <summary>
        /// Append error message text to only error file 
        /// </summary>
        /// <param name="content"></param>
        public void WriteError(string content)
        {
            // Exist error.
            CreateErrorFile();
            errorFile.Write(content);
        }

        /// <summary>
        /// Write error for datatable
        /// </summary>
        public void WriteError(DataTable dt, string delimiter = GSEnvironmentSetting.DEFAULT_EXPORT_FILE_DELIMITER)
        {
            // Exist error.
            CreateErrorFile();
            errorFile.Write(dt, delimiter);
        }

        /// <summary>
        /// Append error message text to log/error file 
        /// </summary>
        /// <param name="content"></param>
        public void WriteLogAndError(string content)
        {
            logFile.Write(content);

            // Exist error.
            CreateErrorFile();
            errorFile.Write(content);
        }

        /// <summary>
        /// Append list of error message text to log/error file 
        /// </summary>
        /// <param name="content"></param>
        public void WriteLogAndError(IEnumerable<string> content)
        {
            logFile.Write(content);

            // Exist error.
            CreateErrorFile();
            errorFile.Write(content);
        }

        /// <summary>
        /// Write warning message
        /// </summary>
        /// <param name="content"></param>
        public void WriteWarning(string content)
        {
            logFile.Write($"Warning: {content}");
        }

        /// <summary>
        /// Write warning message with list content
        /// </summary>
        public void WriteWarning(IEnumerable<string> contents)
        {
            List<string> warningContents = new List<string>();
            foreach (string s in contents)
            {
                warningContents.Add($"Warning: {s}");
            }

            logFile.Write(warningContents);
        }

        /// <summary>
        /// Write header for log/error
        /// </summary>
        /// <param name="type">LOG, EROR, ...</param>
        private void WriteFileHeader(string type)
        {
            String timeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
            bool isError = type.ToUpper() == WorkflowLogConstant.ERROR_TYPE.ToUpper();
            string wfInfo = $"---------------------Type: [{type.ToUpper()}] - Workflow: [{WPID}] - Time: [{timeStamp}]----------------------\n";

            // header for error file
            if (isError)
            {
                errorFile.Write(wfInfo);
            }
            else
            {
                logFile.Write(wfInfo);
            }
        }

        /// <summary>
        /// Write 'Done' in the end of file
        /// </summary>
        public void WriteEndOfFile()
        {
            logFile.Write(WorkflowLogConstant.DONE_EVERYTHING);
            GenomicDataHelper.UpdateStatusWorkflow(WPID, WorkflowLogConstant.STATUS_COMPLETED);
        }

        /// <summary>
        /// Get Transformation Name from PID and write to error/log file
        /// </summary>
        /// <param name="PID"></param>
        /// <param name="type"></param>
        private void WriteProcess(long PID, string type)
        {
            string transName = GenomicDataHelper.GetTransformationName(PID);
            string transInfo = $"---------------------Transformation: {PID} ~ [{transName}]----------------------\n";
            bool isError = type.ToUpper() == WorkflowLogConstant.ERROR_TYPE.ToUpper();
            if (isError)
            {
                errorFile.Write(transInfo);
            }
            else
            {
                logFile.Write(transInfo);
            }
        }

        /// <summary>
        /// Log processing file
        /// </summary>
        public void WriteProcessFile(string fileName)
        {
            logFile.Write($"Processing {fileName}");
        }

        /// <summary>
        /// Create a error file
        /// </summary>
        private void CreateErrorFile()
        {
            // if error file is null, new transformation started and got error -> Write process
            // else error file is not null, current transformation had more than 1 error -> No need write process.
            if (errorFile == null)
            {
                string errorFileName = $"{WPID}_{workflowName}.{GenomicExtension.ERROR_FILE_EXT}";
                string errFilePath = Path.Combine(folderPath, errorFileName);

                // create error file and write header if not exist
                if (!File.Exists(errFilePath))
                {
                    errorFile = new WorkflowFile(WPID, errorFileName, WorkflowLogConstant.ERROR_TYPE);
                    WriteFileHeader(WorkflowLogConstant.ERROR_TYPE);
                }
                else // error file existed, create new instance, not write header
                {
                    errorFile = new WorkflowFile(WPID, errorFileName, WorkflowLogConstant.ERROR_TYPE);
                }

                WriteProcess(PID, WorkflowLogConstant.ERROR_TYPE);
            }
        }
    }
}
