﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataReaderUtilsLib;
using SQLUtilsLib;
using System.Data;
using System.Data.SqlClient;

namespace CDRGenomicHelper
{
    public class GsEventLogHelper
    {
        /// <summary>
        /// Add new event log to track in DB
        /// </summary>
        /// <param name="type">"EXCEPTION", "MANUAL_ACTION"</param>
        /// <param name="activity">"DELETE_SAMPLE", "SAMPLE_ACTIVE", "SERVICE_REQUEST_NF",...</param>
        /// <param name="keyword">e.g. SAMPLE_ID for "SAMPLE_ACTIVE" type</param>
        /// <param name="description"></param>
        public static void WriteGsEventLog(string PID, string type, string activity, string keyword, string description)
        {
            string sqlCommand = string.Format(@"INSERT INTO [dbo].[GSEventLog]
                                                        (    [PID]
                                                            ,[CREATED_TIME]
                                                            ,[TYPE]
                                                            ,[ACTIVITY]
                                                            ,[KEYWORD]
                                                            ,[DESCRIPTION])
                                                VALUES  (  GETDATE()
		                                                    ,'{0}'
		                                                    ,'{1}'
		                                                    ,'{2}'
		                                                    ,'{3}
                                                            ,'{4}')", PID, type, activity, keyword, description);

            DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, sqlCommand);
        }

        /// <summary>
        /// Add new event logs to track in DB
        /// </summary>
        /// <param name="type">"EXCEPTION", "MANUAL_ACTION"</param>
        /// <param name="activity">"DELETE_SAMPLE", "SAMPLE_ACTIVE", "SERVICE_REQUEST_NF",...</param>
        /// <param name="keywords">List keywords to log in DB that have same type, activity and description</param>
        /// <param name="description"></param>
        public static void WriteGsEventLogs(string PID, string type, string activity, IEnumerable<string> keywords, string description)
        {
            if (keywords.Count() == 0)
                return;

            string sqlCommand = string.Format(@"INSERT INTO [dbo].[GSEventLog]
                                                        (   [PID]
                                                            ,[CREATED_TIME]
                                                            ,[TYPE]
                                                            ,[ACTIVITY]
                                                            ,[KEYWORD]
                                                            ,[DESCRIPTION])
                                                SELECT '{0}'
                                                        ,GETDATE()
	                                                    ,'{1}'
	                                                    ,'{2}'
	                                                    ,keywords.[value]
	                                                    ,'{4}'
                                                FROM (SELECT [value] FROM dbo.fnSplitString('{3}', ',')) AS keywords", PID, type, activity, string.Join(",", keywords), description);

            DataReaderUtilities.GetData(DBReference.ConnStr_SSISDB, sqlCommand);
        }

        /// <summary>
        /// Add new event logs to track in DB
        /// </summary>
        /// <param name="gsEventLogTable">Contains information gs event log. Table must have columns: [TYPE], [ACTIVITY], [KEYWORD], [DESCRIPTION]</param>
        public static void WriteGsEventLogs(string PID, DataTable gsEventLogTable)
        {
            if (gsEventLogTable.Rows.Count == 0)
                return;

            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(DBReference.ConnStr_SSISDB);
            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                connection.Open();

                // Configure the SqlCommand and SqlParameter.
                SqlCommand insertCommand = new SqlCommand("spGsEventLogs", connection);
                insertCommand.CommandType = CommandType.StoredProcedure;

                SqlParameter sampleValuesParam = insertCommand.Parameters.AddWithValue("@GS_EVENT_LOG_VALUES", gsEventLogTable);
                sampleValuesParam.SqlDbType = SqlDbType.Structured;

                //Set timeout no limit
                insertCommand.CommandTimeout = 0;
                // Execute the command.
                insertCommand.ExecuteNonQuery();
                connection.Close();
            }
        }
    }
}
