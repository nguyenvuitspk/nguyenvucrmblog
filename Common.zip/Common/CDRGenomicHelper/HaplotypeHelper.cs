﻿using DataReaderUtilsLib;
using GenomicPackageBase;
using SQLUtilsLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CDRGenomicHelper
{
    public class HaplotypeHelper
    {
        #region function Haplotype

        /// <summary>
        /// Get haplotype configuration and validate it
        /// </summary>
        /// <returns></returns>
        public static Dictionary<string, HaplotypeInformation> GetConfigurationOfHaplotypeTypes()
        {
            string sqlCommand = string.Format(@"SELECT hHaplotypes.[BK_HAPLOTYPE_CODE]
	                                                   ,sHaplotypes.[BREED_CODE]
	                                                   ,hGmarkers.[BK_MARKER_ID]
	                                                   ,sHGmarkers.[STATUS]
                                                FROM [dbo].[HUB_HAPLOTYPES] hHaplotypes
                                                INNER JOIN [dbo].[SAT_HAPLOTYPES] sHaplotypes ON sHaplotypes.[PK_HAPLOTYPE_ID] = hHaplotypes.[PK_HAPLOTYPE_ID]
										                                                   AND sHaplotypes.[MD_LOADEND_TS] IS NULL
                                                INNER JOIN [dbo].[LNK_HAPLOTYPES_GMARKERS] lHGmarkers ON lHGmarkers.[PK_HAPLOTYPE_ID] = hHaplotypes.[PK_HAPLOTYPE_ID]
                                                INNER JOIN [dbo].[SAT_HAPLOTYPE_GMARKERS] sHGmarkers ON sHGmarkers.[PK_HAPLOTYPE_GMARKER_ID] = lHGmarkers.[PK_HAPLOTYPE_GMARKER_ID]
													                                                 AND sHGmarkers.[MD_LOADEND_TS] IS NULL
                                                INNER JOIN [dbo].[HUB_GMARKERS] hGmarkers ON hGmarkers.[PK_GMARKER_ID] = lHGmarkers.[PK_GMARKER_ID]");

            DataTable table = DataReaderUtilities.GetData(DBReference.ConnStr_DV, sqlCommand).Tables[0];
            Dictionary<string, HaplotypeInformation> inforHaplotypeTypes = new Dictionary<string, HaplotypeInformation>();

            if (table != null)
            {
                foreach (DataRow row in table.Rows)
                {
                    string haplotypeCode = row["BK_HAPLOTYPE_CODE"].ToString();

                    if (inforHaplotypeTypes.ContainsKey(haplotypeCode))
                    {
                        inforHaplotypeTypes[haplotypeCode].markerList.Add(int.Parse(row["BK_MARKER_ID"].ToString()));
                        inforHaplotypeTypes[haplotypeCode].statusList.Add(Convert.ToByte(row["STATUS"]));
                    }
                    else
                    {
                        inforHaplotypeTypes.Add(haplotypeCode, new HaplotypeInformation()
                        {
                            markerList = new List<int>() { int.Parse(row["BK_MARKER_ID"].ToString()) },
                            statusList = new List<byte>() { Convert.ToByte(row["STATUS"]) },
                            breedCode = row["BREED_CODE"].ToString()
                        });
                    }
                }
            }

            // Validate configuration of haplotype
            if (inforHaplotypeTypes.Count == 0)
                throw new Exception(CDRGenomicHelper.GenomicMessage.ERR_MSG_GS_DV_HAP_SSIS_CONFIGURATION_MISSING);

            foreach (HaplotypeInformation haplotypeInformation in inforHaplotypeTypes.Values)
            {
                if (string.IsNullOrEmpty(haplotypeInformation.breedCode) ||
                    haplotypeInformation.markerList.Count != haplotypeInformation.statusList.Count)
                    throw new Exception(CDRGenomicHelper.GenomicMessage.ERR_MSG_GS_DV_HAP_SSIS_CONFIGURATION_MISSING);
            }
            return inforHaplotypeTypes;
        }

        /// <summary>
        /// Get sample haplotype values and storage to sampleHaplotypeTable
        /// </summary>
        /// <param name="inforSampleInputs"></param>
        /// <param name="inforHaplotypeTypes"></param>
        /// <param name="sampleHaplotypeTable"></param>
        public static void GetSampleHaplotypeResults(Queue<SampleInformation> inforSampleInputs, Dictionary<string, HaplotypeInformation> inforHaplotypeTypes
                                                        , SampleHaplotypeTable sampleHaplotypeTable)
        {
            double maxMissingCallPercent;
            try
            {
                maxMissingCallPercent = double.Parse(CDRGenomicHelper.GenomicDataHelper.GetConstantValue(CDRConfigurationConstant.CONF_MAX_MISSING_CALL_PERCENT));
            }
            catch(Exception)
            {
                throw new Exception(GenomicMessage.ERR_MSG_GS_DV_HAP_SSIS_CONFIGURATION_MISSING);
            }

            int numThreadImplement = GSEnvironmentSetting.NUM_THREAD_SAMPLE_HAPLOTYPE;
            object objectThreadSync = new object();
            Thread[] threads = new Thread[numThreadImplement];
            ManualResetEvent[] DoneEvent = new ManualResetEvent[numThreadImplement];
            var haplotypeCodes = inforHaplotypeTypes.Keys;

            for (int i = 0; i < numThreadImplement; i++)
            {
                int indexThread = i;
                DoneEvent[indexThread] = new ManualResetEvent(false);

                // Init thread and implement to calculate sample haplotype values
                new Thread(() =>
                {
                    GenomicSQLFileStreamContext genSqlFS = new GenomicSQLFileStreamContext();
                    byte[] contextTransaction = genSqlFS.GetContext();
                    byte[] dnaBytes = null;
                    int acarrier = 0;
                    int missing = 0;
                    bool isInsertedData;
                    SampleInformation sampleInformation;

                    // Implement computed sample haloptype value for each sample in inforSampleInputs
                    do
                    {
                        lock (objectThreadSync)
                        {
                            // Condition to stop loop
                            if (inforSampleInputs.Count == 0)
                                break;

                            sampleInformation = inforSampleInputs.Dequeue();
                        }

                        isInsertedData = false;
                        dnaBytes = GenomicDNAHelper.GetDNA(contextTransaction, sampleInformation.dnaFilePath);

                        foreach (string haplotypeCode in haplotypeCodes)
                        {
                            HaplotypeInformation haplotypeType = inforHaplotypeTypes[haplotypeCode];

                            if (!haplotypeType.breedCode.Equals(sampleInformation.breedCode))
                                continue;

                            isInsertedData = true;
                            int lengthMarkers = haplotypeType.markerList.Count;
                            CalculateMissingAndAgreementOfHaplotype(dnaBytes, haplotypeType, ref acarrier, ref missing);

                            double missCallPercent = (double)missing / lengthMarkers;
                            double hapAgreementPercent = missing != lengthMarkers ? (double)acarrier / (lengthMarkers - missing) : -1;
                            string hapStatus = "-";

                            if (missCallPercent < maxMissingCallPercent)
                            {
                                hapStatus = acarrier > (lengthMarkers - missing - 1) ? "C" : "F";
                            }

                            // Add sample halotype value is computed to sampleHaplotypeTable
                            sampleHaplotypeTable.AddNewRecord(sampleInformation.sampleId, haplotypeCode, hapStatus, hapAgreementPercent, missCallPercent, isInsertedData);
                        }

                        if(!isInsertedData)
                        {
                            sampleHaplotypeTable.AddNewRecord(sampleInformation.sampleId, null, null, -1, -1, isInsertedData);
                        }
                    } while (true);

                    // Close connection sql filestream
                    genSqlFS.Dispose();

                    DoneEvent[indexThread].Set();
                }).Start();
            }

            // Wait all thread complete
            WaitHandle.WaitAll(DoneEvent);
        }

        /// <summary>
        /// Calculate missing value and agreement value of haplotype
        /// </summary>
        /// <param name="dnaBytes"></param>
        /// <param name="haplotypeType"></param>
        /// <param name="acarrier"></param>
        /// <param name="missing"></param>
        public static void CalculateMissingAndAgreementOfHaplotype(byte[] dnaBytes, HaplotypeInformation haplotypeType, ref int acarrier, ref int missing)
        {
            byte[] dnaChecks = GenomicDNAHelper.ComputeDnaCheckString(dnaBytes, haplotypeType.markerList);
            int lengthMarkers = haplotypeType.markerList.Count;
            acarrier = 0;
            missing = 0;

            if (lengthMarkers == 1)
            {
                if (dnaChecks[0] == 5)
                    missing++;

                if (haplotypeType.statusList[0] == dnaChecks[0])
                    acarrier++;
            }
            else
            {
                int index = 0;

                foreach (char status in haplotypeType.statusList)
                {
                    if (dnaChecks[index] == 5)
                        missing++;

                    if (status == 0 && (dnaChecks[index] == 0 || dnaChecks[index] == 1))
                        acarrier++;
                    else if (status == 2 && (dnaChecks[index] == 2 || dnaChecks[index] == 1))
                        acarrier++;

                    index++;
                }
            }

            // Clear memory
            dnaChecks = null;
        }

        /// <summary>
        /// Update haplotype check required status to 0 in sat_gsample_dqis
        /// </summary>
        /// <param name="sampleList"></param>
        /// <param name="PID"></param>
        public static void UpdateDQIHapCheckRequiredStatus(Queue<string> sampleList, string PID)
        {
            if (sampleList.Count == 0)
                return;

            DataTable sampleTable = new DataTable();
            sampleTable.Columns.Add("PK_SAMPLE_ID", typeof(string));

            double maxSampleCount = 0;
            while (sampleList.Count > 0)
            {
                maxSampleCount = sampleList.Count < GSEnvironmentSetting.MAX_BUFFER_DATA_TABLE ? sampleList.Count : GSEnvironmentSetting.MAX_BUFFER_DATA_TABLE;

                // Add sample id to sampleTable from sampleList
                while (maxSampleCount > 0)
                {
                    DataRow row = sampleTable.NewRow();
                    row["PK_SAMPLE_ID"] = sampleList.Dequeue();
                    sampleTable.Rows.Add(row);

                    maxSampleCount--;
                }

                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(DBReference.ConnStr_DV);
                using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                {
                    connection.Open();

                    // Configure the SqlCommand and SqlParameter.
                    SqlCommand insertCommand = new SqlCommand("usp_gs_ga_update_haplotype_check_required_status", connection);
                    insertCommand.CommandType = CommandType.StoredProcedure;

                    SqlParameter PIDParam = insertCommand.Parameters.AddWithValue("@PID", PID);
                    PIDParam.SqlDbType = SqlDbType.VarChar;

                    SqlParameter sampleValuesParam = insertCommand.Parameters.AddWithValue("@SAMPLE_LIST", sampleTable);
                    sampleValuesParam.SqlDbType = SqlDbType.Structured;

                    //Set timeout no limit
                    insertCommand.CommandTimeout = 0;
                    // Execute the command.
                    insertCommand.ExecuteNonQuery();
                    connection.Close();
                }

                // reset variable
                sampleTable.Clear();
            }
        }

        #endregion

        #region declare struct

        public struct HaplotypeInformation
        {
            public List<int> markerList;
            public List<byte> statusList;
            public string breedCode; // 1 charater
        }

        public struct SampleInformation
        {
            public string sampleId;
            public string breedCode; // contain 1 charater
            public string dnaFilePath;
        }

        #endregion

        #region class table storage haplotype value
        public class SampleHaplotypeTable
        {
            private DataTable sampleHaplotyeTable;
            private string PID;
            private double MAX_BUFFER_TABLE = GSEnvironmentSetting.MAX_BUFFER_DATA_TABLE;
            private int rowCount = 0; // row count of dnaPairAnalysisTable
            private object syncInsertData = new object();

            public SampleHaplotypeTable(string PID)
            {
                this.PID = PID;
                InitSampleHaplotyeTable();
            }

            public void InitSampleHaplotyeTable()
            {
                ClearTable();

                sampleHaplotyeTable = new DataTable();
                sampleHaplotyeTable.Columns.Add("PK_SAMPLE_ID", typeof(string));
                sampleHaplotyeTable.Columns.Add("HAPLOTYPE_CODE", typeof(string));
                sampleHaplotyeTable.Columns.Add("HAPLOTYPE_STATUS", typeof(string));
                sampleHaplotyeTable.Columns.Add("HAPLOTYPE_AGREEMENT_PERCENT", typeof(decimal));
                sampleHaplotyeTable.Columns.Add("MISSING_CALL_PERCENT", typeof(decimal));
                sampleHaplotyeTable.Columns.Add("IS_INSERT_DATA", typeof(bool));

                rowCount = 0;
            }

            public void AddNewRecord(string sampleId, string haplotypeCode, string halotypeStatus, double haplotypeAgreementPercent, double missCallPercent, bool isInsertData)
            {
                lock (syncInsertData)
                {
                    if (rowCount == MAX_BUFFER_TABLE)
                    {
                        StorageSampleHaplotypeValuesToDB();
                        InitSampleHaplotyeTable(); // Reset datatable
                    }

                    DataRow row = sampleHaplotyeTable.NewRow();
                    row["PK_SAMPLE_ID"] = sampleId;
                    row["HAPLOTYPE_CODE"] = haplotypeCode;
                    row["HAPLOTYPE_STATUS"] = halotypeStatus;
                    row["HAPLOTYPE_AGREEMENT_PERCENT"] = haplotypeAgreementPercent;
                    row["MISSING_CALL_PERCENT"] = missCallPercent;
                    row["IS_INSERT_DATA"] = isInsertData;
                    sampleHaplotyeTable.Rows.Add(row);

                    // increase row count
                    rowCount++;
                }
            }

            public void StorageSampleHaplotypeValuesToDB()
            {
                if (rowCount == 0)
                    return;

                // Insert pds value to database
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(DBReference.ConnStr_DV);
                using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                {
                    connection.Open();
                    SqlCommand insertCommand = new SqlCommand("usp_gs_ga_storage_sample_haplotpe_values", connection);
                    insertCommand.CommandType = CommandType.StoredProcedure;

                    SqlParameter pidParam = insertCommand.Parameters.AddWithValue("@PID", PID);
                    pidParam.SqlDbType = SqlDbType.VarChar;

                    SqlParameter dnaPairValueParam = insertCommand.Parameters.AddWithValue("@SAMPLE_HAPLOTYPE_VALUES", sampleHaplotyeTable);
                    dnaPairValueParam.SqlDbType = SqlDbType.Structured;

                    //Set timeout no limit
                    insertCommand.CommandTimeout = 0;
                    // Execute the command.
                    insertCommand.ExecuteNonQuery();

                    connection.Close();
                }
            }

            public void ClearTable()
            {
                if (sampleHaplotyeTable != null)
                    sampleHaplotyeTable.Dispose();

                sampleHaplotyeTable = null;
            }
        }

        #endregion
    }
}
