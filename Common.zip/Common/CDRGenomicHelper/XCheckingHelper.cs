﻿using DataReaderUtilsLib;
using GenomicPackageBase;
using SQLUtilsLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CDRGenomicHelper
{
    public class XCheckingHelper
    {
        public static void GetConstantValuesForXChecking(ref double maxXYLimit, ref double xCheckingThreshold)
        {
            try
            {
                maxXYLimit = double.Parse(GenomicDataHelper.GetConstantValue("GS_MAX_XY_LIMIT").ToString());
                xCheckingThreshold = double.Parse(GenomicDataHelper.GetConstantValue("GS_X_CHECKING_THRESHOLD").ToString());
            }
            catch
            {
                throw new Exception(GenomicMessage.ERR_MSG_GS_DV_XCHECKING_SSIS_CONFIGURATION_MISSING);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="unIdentifiedSamples"></param>
        /// <param name="markersOfChips"></param>
        /// <param name="chromoPosnsOfChips"></param>
        /// <param name="xCheckTable"></param>
        /// <param name="maxXYLimit"></param>
        /// <param name="xCheckingThreshold"></param>
        /// <param name="sampleList">Storage list sample id to update xchecking and pds dqi</param>
        public static void GetXCheckingResultsOfUnIdentifiedSample(Queue<SampleInformation> unIdentifiedSamples, Dictionary<string, List<int>> markersOfChips, Dictionary<string, List<int>> chromoPosnsOfChips
                                                                    , XCheckTable xCheckTable, double maxXYLimit, double xCheckingThreshold)
        {
            int numThreadImplement = GSEnvironmentSetting.NUM_THREAD_XCHECKING;
            object objectThreadSync = new object(); // using synchronize threads implement xchecking
            Thread[] threads = new Thread[numThreadImplement];
            ManualResetEvent[] DoneEvent = new ManualResetEvent[numThreadImplement];

            for (int i = 0; i < numThreadImplement; i++)
            {
                int indexThread = i;
                DoneEvent[indexThread] = new ManualResetEvent(false);

                // Init thread and implement to calculate xchecking status values
                new Thread(() =>
                {
                    GenomicSQLFileStreamContext genSqlFS = new GenomicSQLFileStreamContext();
                    byte[] contextTransaction = genSqlFS.GetContext();

                    SampleInformation sampleInformation;

                    do
                    {
                        lock (objectThreadSync)
                        {
                            // Condition to stop loop
                            if (unIdentifiedSamples.Count == 0)
                                break;

                            sampleInformation = unIdentifiedSamples.Dequeue();
                        }

                        if(!sampleInformation.status.Equals(GSampleConstant.SAMPLE_STATUS_HIGH_AB) && !sampleInformation.status.Equals(GSampleConstant.SAMPLE_STATUS_LOW_CR))
                        {
                            double xPercent = GetXCheckingPercent(sampleInformation, markersOfChips, chromoPosnsOfChips, maxXYLimit, contextTransaction);

                            if (sampleInformation.sex.Equals("M") && xPercent > xCheckingThreshold)
                            {
                                xCheckTable.AddNewRecord(sampleInformation.sampleId, GSampleConstant.SAMPLE_STATUS_DISAGREES_WITH_ANIMAL_SEX);
                            }
                            else
                            {
                                xCheckTable.AddNewRecord(sampleInformation.sampleId, GSampleConstant.SAMPLE_STATUS_OK);

                            }
                        }           
                    } while (true);

                    genSqlFS.Dispose();
                    DoneEvent[indexThread].Set();

                }).Start();
            }

            // Wait all thread complete
            WaitHandle.WaitAll(DoneEvent);
        }

        private static double GetXCheckingPercent(SampleInformation sampleInformation, Dictionary<string, List<int>> markersOfChips
                                                        , Dictionary<string, List<int>> chromoPosnsOfChips, double maxXYLimit, byte[] contextTransaction)
        {
            if (!markersOfChips.ContainsKey(sampleInformation.chipId)) // Best chip have not contain marker have chromo_no = 30 or 31
                return 0;

            int densityXHetero = 0;
            int numXHetero = 0;
            int index = -1;

            string chipId = sampleInformation.chipId;
            byte[] dnaBytes = GenomicDNAHelper.GetDNA(contextTransaction, sampleInformation.dnaFilePath);
            byte[] dnaCheckstring = GenomicDNAHelper.ComputeDnaCheckString(dnaBytes, markersOfChips[chipId]);

            foreach (int chromoPosn in chromoPosnsOfChips[chipId])
            {
                index++;

                if (dnaCheckstring[index] == 5)
                    continue;

                densityXHetero++;

                if (dnaCheckstring[index] == 1 && chromoPosn <= maxXYLimit)
                    numXHetero++;
            }

            // Clear memory
            dnaBytes = null;
            dnaCheckstring = null;

            if (densityXHetero == 0)
                return 0;

            return (double)numXHetero / densityXHetero;
        }

        #region Declare struct   

        public struct SampleInformation
        {
            public string sampleId;
            public string chipId;
            public string sex;
            public string dnaFilePath;
            public string status;
        }

        #endregion

        /// <summary>
        /// Class xchecking table storage status of samples that has been xchecking
        /// </summary>
        public class XCheckTable
        {
            private DataTable xCheckingTable;
            private string PID;
            private double MAX_BUFFER_TABLE = GSEnvironmentSetting.MAX_BUFFER_DATA_TABLE;
            private int rowCount = 0; // row count of xCheckingTable
            private object syncInsertData = new object();

            public XCheckTable(string PID)
            {
                this.PID = PID;
                InitXCheckingTable();
            }

            public void InitXCheckingTable()
            {
                ClearTable();

                xCheckingTable = new DataTable();
                xCheckingTable.Columns.Add("PK_SAMPLE_ID", typeof(string));
                xCheckingTable.Columns.Add("STATUS", typeof(string));

                rowCount = 0;
            }

            public void AddNewRecord(string sampleId, string status)
            {
                lock (syncInsertData)
                {
                    if (rowCount == MAX_BUFFER_TABLE)
                    {
                        StorageXCheckingValuesToDB();
                        InitXCheckingTable(); // Reset datatable
                    }

                    DataRow row = xCheckingTable.NewRow();
                    row["PK_SAMPLE_ID"] = sampleId;
                    row["STATUS"] = status;
                    xCheckingTable.Rows.Add(row);

                    // increase row count
                    rowCount++;
                }
            }

            public void StorageXCheckingValuesToDB()
            {
                if (rowCount == 0)
                    return;

                // Insert pds value to database
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(DBReference.ConnStr_DV);
                using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                {
                    connection.Open();

                    // Configure the SqlCommand and SqlParameter.
                    SqlCommand insertCommand = new SqlCommand("usp_gs_ga_storage_status_sample_of_x_checking", connection);
                    insertCommand.CommandType = CommandType.StoredProcedure;

                    SqlParameter PIDParam = insertCommand.Parameters.AddWithValue("@PID", PID);
                    PIDParam.SqlDbType = SqlDbType.VarChar;

                    SqlParameter sampleValuesParam = insertCommand.Parameters.AddWithValue("@SAMPLE_STATUS_VALUES", xCheckingTable);
                    sampleValuesParam.SqlDbType = SqlDbType.Structured;

                    //Set timeout no limit
                    insertCommand.CommandTimeout = 0;
                    // Execute the command.
                    insertCommand.ExecuteNonQuery();
                    connection.Close();
                }
            }

            public void ClearTable()
            {
                if (xCheckingTable != null)
                    xCheckingTable.Dispose();

                xCheckingTable = null;
            }
        }
    }
}
