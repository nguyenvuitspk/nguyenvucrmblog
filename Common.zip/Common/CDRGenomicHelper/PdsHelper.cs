﻿using DataReaderUtilsLib;
using GenomicPackageBase;
using SQLUtilsLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CDRGenomicHelper
{
    public class PdsHelper
    {
        private static object objectThreadSync = new object();

        /// <summary>
        /// Get configuration values for pds discovery
        /// </summary>
        public static void GetConfigurationValuesForPds()
        {
            bool isError = false;

            try
            {
                PdsConfigurationValue.pdsPanel = GetConfigDefaultCoreOrPdsPanel(TypePanelConstant.TYPE_PDS_PANEL);
                PdsConfigurationValue.core6kPanel = GetConfigDefaultCoreOrPdsPanel(TypePanelConstant.TYPE_CORE_PANEL);
                PdsConfigurationValue.pdsDiscoveryThreshold = (int)double.Parse(GenomicDataHelper.GetConstantValue(CDRConfigurationConstant.CONF_PDS_DISCOVERY_THRESHOLD));
                PdsConfigurationValue.pdsMinCmpMarkers = (int)double.Parse(GenomicDataHelper.GetConstantValue(CDRConfigurationConstant.CONF_PDS_MINIMUM_CMP_MARKERS));
                PdsConfigurationValue.fullDiscoveryThreshold = (int)double.Parse(GenomicDataHelper.GetConstantValue(CDRConfigurationConstant.CONF_FULL_DISCOVERY_THRESHOLD));
                PdsConfigurationValue.fullMinCmpMarkers = (int)double.Parse(GenomicDataHelper.GetConstantValue(CDRConfigurationConstant.CONF_FULL_MINIMUM_CMP_MARKERS));
                PdsConfigurationValue.genoInconsistencyThreshold = (int)double.Parse(GenomicDataHelper.GetConstantValue(CDRConfigurationConstant.CONF_GENO_INCONSISTENCY_THRESHOLD));
                PdsConfigurationValue.parentOffSpringAgeDiffMin = (int)double.Parse(GenomicDataHelper.GetConstantValue(CDRConfigurationConstant.CONF_PARENT_OFFSPRING_AGE_DIFF_MIN));
                PdsConfigurationValue.minDuplicateCmp = (int)double.Parse(GenomicDataHelper.GetConstantValue(CDRConfigurationConstant.CONF_MIN_DUPLICATE_CMP));
                PdsConfigurationValue.duplicateThreshold = (int)double.Parse(GenomicDataHelper.GetConstantValue(CDRConfigurationConstant.CONF_DUPLICATE_THRESHOLD));

                if (string.IsNullOrEmpty(PdsConfigurationValue.pdsPanel)
                    || string.IsNullOrEmpty(PdsConfigurationValue.core6kPanel))
                    isError = true;
            }
            catch (Exception)
            {
                isError = true;
            }

            if (isError)
                throw new Exception(GenomicMessage.ERR_MSG_GS_DV_PDS_SSIS_CONFIGURATION_MISSING);
        }

        /// <summary>
        /// Get default panel for pds/core
        /// </summary>
        /// <param name="typePanel"></param>
        /// <returns></returns>
        public static string GetConfigDefaultCoreOrPdsPanel(string typePanel)
        {
            int isPdsPanelType = typePanel.Equals(TypePanelConstant.TYPE_PDS_PANEL) ? 1 : 0;
            int isCorePanelType = typePanel.Equals(TypePanelConstant.TYPE_CORE_PANEL) ? 1 : 0; ;

            string sqlCommand = string.Format(@"SELECT hMasks.BK_MASK_ID
                                                FROM dbo.HUB_MASKS (NOLOCK) hMasks
                                                JOIN dbo.SAT_MASKS (NOLOCK) sMasks ON sMasks.PK_MASK_ID = hMasks.PK_MASK_ID
									                                                   AND sMasks.MD_LOADEND_TS IS NULL
                                                WHERE sMasks.PANEL_TYPE = '{0}' AND sMasks.PDS_PREFERRED_PANEL = {1} AND sMasks.CORE_PREFERRED_PANEL = {2}", typePanel, isPdsPanelType, isCorePanelType);

            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV, sqlCommand);
            return value != null? value.ToString() : null;
        }


        /// <summary>
        /// Get union marker list of panels (core + pds) that markers belong chromo_no smaller 30
        /// </summary>
        /// <returns></returns>
        public static List<int> GetMarkerListForPanels()
        {
            // 1. Add markers of pds panel (markers belong chromo_no smaller 30) to marker list
            List<int> markerList = GenomicDataHelper.GetMarkerListForPds(PdsConfigurationValue.pdsPanel);
            PdsConfigurationValue.numberPoisOfPds = markerList.Count;

            // 2. Add markers core panel (markers belong chromo_no smaller 30) to marker list
            markerList.AddRange(GenomicDataHelper.GetMarkerListForPds(PdsConfigurationValue.core6kPanel));
            PdsConfigurationValue.numberPoisPanels = markerList.Count;

            return markerList;
        }

        /// <summary>
        /// Get all dna checkstring of sample inputs belong to subPdsDnaIdList
        /// </summary>
        /// <param name="subPdsDnaIdList">Contain dna ids belong to samples input</param>
        /// <param name="markerList"></param>
        /// <param name="allSampleOkInSystem">Contain information of samples. Ex: animalId, sireId, damId, chipId,...</param>
        /// <returns></returns>
        public static Dictionary<string, byte[]> GetDnaCheckstringOfSampleInputs(HashSet<string> subPdsDnaIdList, List<int> markerList, Dictionary<string, AnimalInformation> allSampleOkInSystem)
        {
            Dictionary<string, byte[]> dnaCheckOfSamplesInput = new Dictionary<string, byte[]>();

            int dnaIndex = 0;
            int dnaCount = subPdsDnaIdList.Count() - 1;

            int numThreadImplement = GSEnvironmentSetting.NUM_THREAD_PDS_DISCOVERY;
            Thread[] threads = new Thread[numThreadImplement];
            ManualResetEvent[] DoneEvent = new ManualResetEvent[numThreadImplement];         

            for (int i = 0; i < numThreadImplement; i++)
            {
                int indexThread = i;
                DoneEvent[indexThread] = new ManualResetEvent(false);  

                new Thread(() =>
                {
                    string dnaId = null;
                    int subDnaIndex = 0;

                    GenomicSQLFileStreamContext genFS = new GenomicSQLFileStreamContext();
                    byte[] contextTransaction = genFS.GetContext();

                    do
                    {
                        lock (objectThreadSync)
                        {
                            if (dnaIndex > dnaCount)
                                break;

                            subDnaIndex = dnaIndex++;
                        }

                        dnaId = subPdsDnaIdList.ElementAt(subDnaIndex);
                        byte[] dnaCheck = GenomicDNAHelper.ComputeDnaCheckString(GenomicDNAHelper.GetDNA(contextTransaction, allSampleOkInSystem[dnaId].dnaFilePath), markerList);

                        lock (objectThreadSync)
                        {
                            dnaCheckOfSamplesInput.Add(dnaId, dnaCheck);
                        }
                    } while (true);

                    // Close transaction sql filestream
                    genFS.Dispose();

                    DoneEvent[indexThread].Set();
                }).Start();            
            }

            // Wait all thread complete
            WaitHandle.WaitAll(DoneEvent);

            return dnaCheckOfSamplesInput;
        }

        /// <summary>
        /// Get information for all sample that have status = 'OK' in system
        /// </summary>
        /// <returns></returns>
        public static Dictionary<string, AnimalInformation> GetInforSamplesHaveStatusOKInSystem()
        {
            string sqlCommand = string.Format(@"SELECT hAnimals.[PK_ANIMAL_ID]
				                                        ,sAnimals.[SEX]
				                                        ,sAnimals.[BIRTH_DATE]
				                                        ,lASires.[PK_SIRE_ID]
				                                        ,lAGDams.[PK_GENETIC_DAM_ID]
                                                        ,sGsamples.[PK_SAMPLE_ID]
				                                        ,lGGSamples.[PK_GCHIP_ID]
				                                        ,lGGdnas.[PK_DNA_ID]
				                                        ,sGdnas.[DNA].PathName() AS [DNA_UNIMPUTED_FILEPATH]
		                                        FROM [dbo].[HUB_ANIMALS] (NOLOCK) hAnimals
		                                        INNER JOIN [dbo].[LNK_NOMINATION_ANIMAL_SAMPLES] (NOLOCK) lNASamples ON lNASamples.[PK_ANIMAL_ID] = hAnimals.[PK_ANIMAL_ID]
		                                        INNER JOIN [dbo].[SAT_GSAMPLES] (NOLOCK) sGsamples ON sGsamples.[PK_SAMPLE_ID] = lNASamples.[PK_SAMPLE_ID]
													                                                AND sGsamples.[STATUS] = 'OK'
													                                                AND sGsamples.[MD_LOADEND_TS] IS NULL
		                                        INNER JOIN [dbo].[LNK_GCHIP_GSAMPLES] (NOLOCK) lGGSamples ON lGGSamples.[PK_SAMPLE_ID] = lNASamples.[PK_SAMPLE_ID]
		                                        INNER JOIN [dbo].[LNK_GSAMPLE_GDNAS] (NOLOCK) lGGdnas ON lGGdnas.[PK_SAMPLE_ID] = lNASamples.[PK_SAMPLE_ID]
		                                        INNER JOIN [dbo].[SAT_GDNAS] (NOLOCK) sGdnas ON sGdnas.[PK_DNA_ID] = lGGdnas.[PK_DNA_ID]
											                                                 AND sGdnas.[MD_LOADEND_TS] IS NULL
		                                        INNER JOIN [dbo].[SAT_ANIMALS] (NOLOCK) sAnimals ON sAnimals.[PK_ANIMAL_ID] = hAnimals.[PK_ANIMAL_ID]
												                                        AND sAnimals.[MD_LOADEND_TS] IS NULL
		                                        LEFT JOIN [dbo].[LNK_ANIMAL_SIRES] (NOLOCK) lASires ON lAsires.[PK_ANIMAL_ID] = hAnimals.[PK_ANIMAL_ID]
		                                        LEFT JOIN [dbo].[LNK_ANIMAL_GENETIC_DAMS] (NOLOCK) lAGDams ON lAGDams.[PK_ANIMAL_ID] = hAnimals.[PK_ANIMAL_ID]
                                                ORDER BY sGdnas.[DNA].PhysicalPathName()
												OPTION (QUERYTRACEON 5556)");

            DataTable table = DataReaderUtilities.GetData(DBReference.ConnStr_DV, sqlCommand).Tables[0];
            Dictionary<string, AnimalInformation> allAnimalData = new Dictionary<string, AnimalInformation>();

            if (table != null)
            {
                foreach (DataRow row in table.Rows)
                {
                    if (!allAnimalData.ContainsKey(row["PK_DNA_ID"].ToString()))
                        allAnimalData.Add(row["PK_DNA_ID"].ToString(), new AnimalInformation()
                        {
                            animalId = row["PK_ANIMAL_ID"].ToString(),
                            sireId = DBNull.Value.Equals(row["PK_SIRE_ID"])? null : row["PK_SIRE_ID"].ToString(),
                            damId = DBNull.Value.Equals(row["PK_GENETIC_DAM_ID"])? null : row["PK_GENETIC_DAM_ID"].ToString(),
                            isMale = row["SEX"].ToString().Equals("M") ? true : false,
                            birthDay = DBNull.Value.Equals(row["BIRTH_DATE"])? (DateTime?) null : Convert.ToDateTime(row["BIRTH_DATE"].ToString()),
                            dnaId = row["PK_DNA_ID"].ToString(),
                            sampleId = row["PK_SAMPLE_ID"].ToString(),
                            chipId = row["PK_GCHIP_ID"].ToString(),
                            dnaFilePath = row["DNA_UNIMPUTED_FILEPATH"].ToString(),
                        });
                }
            }

            return allAnimalData;
        }

        /// <summary>
        /// Discovery pds result of pds samples input vs all sample ok in system and storage to dnaPairAnalysisTable if it have value
        /// </summary>
        /// <param name="pdsDnaIds">Contain dna ids belong to samples input (that need recompute dna pair values)</param>
        /// <param name="refDnaIdsSystem">Contain dna ids belong to samples that have status ok in system</param>
        /// <param name="markerList"></param>
        /// <param name="refSampleList">Contain information of samples. Ex: animalId, sireId, damId, chipId,...</param>
        /// <param name="noMarkerOfChips"></param>
        /// <param name="dnaCheckOfSampleInputs"></param>
        /// <param name="dnaPairAnalysisTable">using storage dna pair values</param>
        /// <returns></returns>
        public static void GetPdsDiscoveryResultOfSamples(HashSet<string> pdsDnaIds, Queue<string> refDnaIdsSystem, List<int> markerList, Dictionary<string, AnimalInformation> refSampleList
                                                            , Dictionary<string, int> noMarkerOfChips, Dictionary<string, byte[]> dnaCheckOfSampleInputs, DnaPairAnalysisTable dnaPairAnalysisTable)
        {
            int numThreadImplement = GSEnvironmentSetting.NUM_THREAD_PDS_DISCOVERY;
            Thread[] threads = new Thread[numThreadImplement];
            ManualResetEvent[] DoneEvent = new ManualResetEvent[numThreadImplement];

            for (int i = 0; i < numThreadImplement; i++)
            {
                int indexThread = i;
                DoneEvent[indexThread] = new ManualResetEvent(false);

                new Thread(() =>
                {
                    byte[] dnaCheckCmpAnimal = null;
                    string cmpDnaId = null;

                    GenomicSQLFileStreamContext genFS = new GenomicSQLFileStreamContext();
                    byte[] contextTransaction = genFS.GetContext();

                    do
                    {
                        lock (objectThreadSync)
                        {
                            // Condition to stop loop
                            if (refDnaIdsSystem.Count == 0)
                                break;

                            cmpDnaId = refDnaIdsSystem.Dequeue();
                        }

                        AnimalInformation cmpAnimalRecord = refSampleList[cmpDnaId];
                        bool isNeedPdsDiscoveryOpposite = !pdsDnaIds.Contains(cmpDnaId);

                        if (dnaCheckOfSampleInputs.ContainsKey(cmpDnaId))
                            dnaCheckCmpAnimal = dnaCheckOfSampleInputs[cmpDnaId];
                        else
                            dnaCheckCmpAnimal = GenomicDNAHelper.ComputeDnaCheckString(GenomicDNAHelper.GetDNA(contextTransaction, cmpAnimalRecord.dnaFilePath), markerList);

                        foreach (string pdsDnaId in pdsDnaIds)
                        {
                            if (pdsDnaId.Equals(cmpDnaId))
                                continue;

                            AnimalInformation pdsAnimalRecord = refSampleList[pdsDnaId];
                            int noCmpMarkers = Math.Min(noMarkerOfChips[pdsAnimalRecord.chipId], noMarkerOfChips[cmpAnimalRecord.chipId]);

                            GetPdsDiscoveryResultOfSample(pdsAnimalRecord, cmpAnimalRecord, dnaPairAnalysisTable, noCmpMarkers, noMarkerOfChips, dnaCheckOfSampleInputs[pdsDnaId], dnaCheckCmpAnimal, isNeedPdsDiscoveryOpposite);

                        }
                    } while (true);

                    // Close transaction sql filestream
                    genFS.Dispose();

                    DoneEvent[indexThread].Set();
                }).Start();
            }

            // Wait all thread complete
            WaitHandle.WaitAll(DoneEvent);
        }


        /// <summary>
        /// Discovery pds result of a sample and storage to dnaPairAnalysisTable if it have value
        /// There may be at most two dna pair value:
        ///     + dna pair value between pdsAnimalRecord vs cmpAnimalRecord (compulsory)
        ///     + dna pair value between cmpAnimalRecord vs pdsAnimalRecord (if isNeedPdsDiscoveryOpposite = true)
        /// </summary>
        /// <param name="pdsAnimalRecord">animal record belong to pds animal (sample input)</param>
        /// <param name="cmpAnimalRecord">animal record belong to animals system</param>
        /// <param name="minPois">minimum pois between pdsAnimal's pois and cmpAnimal's pois</param>
        /// <param name="noMarkerOfChips"></param>
        /// <param name="dnaCheckPdsAnimal"></param>
        /// <param name="dnaCheckCmpAnimal"></param>
        /// <param name="isNeedPdsDiscoveryOpposite">If value is true, then continue get dna pair value between cmpAnimalRecord and pdsAnimalRecord</param>
        /// <returns></returns>
        public static void GetPdsDiscoveryResultOfSample(AnimalInformation pdsAnimalRecord, AnimalInformation cmpAnimalRecord, DnaPairAnalysisTable dnaPairAnalysisTable, int minPois
                                                          , Dictionary<string, int> noMarkerOfChips, byte[] dnaCheckPdsAnimal, byte[] dnaCheckCmpAnimal, bool isNeedPdsDiscoveryOpposite)
        {
            bool isKnowPedigree = false;

            if (pdsAnimalRecord.animalId.Equals(cmpAnimalRecord.sireId) || pdsAnimalRecord.animalId.Equals(cmpAnimalRecord.damId)
                || cmpAnimalRecord.animalId.Equals(pdsAnimalRecord.sireId) || cmpAnimalRecord.animalId.Equals(pdsAnimalRecord.damId))
            {
                isKnowPedigree = true;
            }

            AnimalRelation animalRelation = CompareDnaOfSamples(pdsAnimalRecord, cmpAnimalRecord, minPois, isKnowPedigree, dnaCheckPdsAnimal, dnaCheckCmpAnimal);

            // Get result betwen pdsAnimalRecord vs cmpAnimalRecord
            DnaPairAnalysis? dnaPair1 = CreatePdsDiscoveryResult(pdsAnimalRecord, cmpAnimalRecord, isKnowPedigree, minPois, animalRelation);

            // Add to dna pair value to dnaPairAnalysisTable
            if (dnaPair1.HasValue)
            {
                lock (objectThreadSync)
                {
                    dnaPairAnalysisTable.AddNewRecord(dnaPair1.Value);
                }
            }

            // Discovery pds opposite cmpAnimalRecord vs pdsAnimalRecord
            if (isNeedPdsDiscoveryOpposite)
            {
                DnaPairAnalysis? dnaPair2 = CreatePdsDiscoveryResult(cmpAnimalRecord, pdsAnimalRecord, isKnowPedigree, minPois, animalRelation);

                if (dnaPair2.HasValue)
                {
                    lock (objectThreadSync)
                    {
                        dnaPairAnalysisTable.AddNewRecord(dnaPair2.Value);
                    }
                }
            }
        }

        /// <summary>
        /// Create pds dicovery result between two animals base on animalRelative
        /// </summary>
        /// <param name="animalRecord1"></param>
        /// <param name="animalRecord2"></param>
        /// <param name="isKnowPedigree"></param>
        /// <param name="minPois">minimum pois between animalRecord1's pois and animalRecord2's pois</param>
        /// <param name="animalRelative"></param>
        /// <returns></returns>
        private static DnaPairAnalysis? CreatePdsDiscoveryResult(AnimalInformation animalRecord1, AnimalInformation animalRecord2, bool isKnowPedigree, int minPois, AnimalRelation animalRelative)
        {
            bool isSire = false;
            bool isDam = false;
            bool isSibling = false;
            bool isDuplicate = false;
            bool isContradic = false;
            bool isInconsistent = false;
            bool isHaveResult = false;

            switch (animalRelative)
            {
                case AnimalRelation.Duplicate:
                    isDuplicate = true;
                    isHaveResult = true;

                    // we have only a duplicate but really should also have a relative, meaning that the difference in genotypes are flipped
                    // homozygotes and occur probably in the PDS panel... i'll also issue a warning here.
                    if (isKnowPedigree && minPois > PdsConfigurationValue.fullMinCmpMarkers)
                    {
                        CheckRelativeAnimal(animalRecord1, animalRecord2, ref isSire, ref isDam, ref isSibling);

                        if (isSire || isDam || isSibling)
                        {
                            isInconsistent = true;
                            isSire = false;
                            isDam = false;
                            isSibling = false;
                        }           
                    }

                    break;
                case AnimalRelation.Relative:
                    if (!animalRecord1.animalId.Equals(animalRecord2.animalId))
                    {
                        CheckRelativeAnimal(animalRecord1, animalRecord2, ref isSire, ref isDam, ref isSibling);

                        if (isSire || isDam || isSibling)
                        {
                            isHaveResult = true;
                        }
                    }
                    else
                    {
                        // if we found a relative, but both samples come from the same animal, then we have no flipped homozyotes but some differing heteroygote calls,
                        // which means we will report contradicing genotypes.
                        isContradic = true;
                        isHaveResult = true;
                    }

                    break;
                case AnimalRelation.BothDuplicateAndRelative:
                    isDuplicate = true;
                    isHaveResult = true;

                    if (!animalRecord1.animalId.Equals(animalRecord2.animalId))
                        CheckRelativeAnimal(animalRecord1, animalRecord2, ref isSire, ref isDam, ref isSibling);

                    break;
                case AnimalRelation.NotDuplicateAndRelative:
                    if (isKnowPedigree && minPois > PdsConfigurationValue.fullMinCmpMarkers)
                    {
                        CheckRelativeAnimal(animalRecord1, animalRecord2, ref isSire, ref isDam, ref isSibling);

                        if (isSire || isDam || isSibling)
                        {
                            isInconsistent = true;
                            isSire = false;
                            isDam = false;
                            isSibling = false;
                            isHaveResult = true;
                        }
                    }
                    break;
            }

            if (isHaveResult)
                return new DnaPairAnalysis()
                {
                    dnaId = animalRecord1.dnaId,
                    pairDnaId = animalRecord2.dnaId,
                    isSire = isSire,
                    isDam = isDam,
                    isSibling = isSibling,
                    isDuplicate = isDuplicate,
                    isContradic = isContradic,
                    isInconsistent = isInconsistent
                };

            return null;
        }

        /// <summary>
        /// Compare dna between pdsAnimalRecord's dna and cmpAnimalRecord's dna
        /// </summary>
        /// <param name="pdsAnimalRecord"></param>
        /// <param name="cmpAnimalRecord"></param>
        /// <param name="minPois">minimum pois between pdsAnimalRecord's pois and cmpAnimalRecord's pois</param>
        /// <param name="isKnowPedigree"></param>
        /// <param name="dnaCheckPdsAnimal"></param>
        /// <param name="dnaCheckCmpAnimal"></param>
        /// <returns></returns>
        public static AnimalRelation CompareDnaOfSamples(AnimalInformation pdsAnimalRecord, AnimalInformation cmpAnimalRecord, int minPois, bool isKnowPedigree
                                                  , byte[] dnaCheckPdsAnimal, byte[] dnaCheckCmpAnimal)
        {
            int noDiff = 0
               , noFlip = 0
               , noMarkerComp = 0;

            bool isDuplicate = true
                , isRelative = true
                , isPdsComp = false;

            int noMarkerToEvaluate = PdsConfigurationValue.numberPoisPanels;

            // If the minimum chip for either animal is < MINIMUM_FULL_PANEL_MARKER_COMPARISONS, then we only compare the pds panel
            if (minPois < PdsConfigurationValue.fullMinCmpMarkers)
            {
                noMarkerToEvaluate = PdsConfigurationValue.numberPoisOfPds;
                isPdsComp = true;
            }

            // We start the comparisons with the PDS panel threshold, as they are the first SNPs in the list of all SNPS.
            double discoveryThreshold = PdsConfigurationValue.pdsDiscoveryThreshold;

            // If the minimum number of snps > pds_panel and we are doing geno-inconsistency checking then update the threshold.
            // we only allow for geno-inconsistency to be performed on higher density panels.
            // if we use the known pedigree consistency threshold, it applies of all markers, PDS panel included.
            if (isKnowPedigree && minPois > PdsConfigurationValue.fullMinCmpMarkers)
                discoveryThreshold = PdsConfigurationValue.genoInconsistencyThreshold;

            for (int i = 0; i < noMarkerToEvaluate; i++)
            {
                if (dnaCheckPdsAnimal[i] == 5 || dnaCheckCmpAnimal[i] == 5)
                    continue;

                noMarkerComp++;

                if (i > PdsConfigurationValue.numberPoisOfPds && !isKnowPedigree)
                    discoveryThreshold = PdsConfigurationValue.fullDiscoveryThreshold;

                // if we are still comparing duplicates
                if (isDuplicate)
                {
                    if (dnaCheckPdsAnimal[i] != dnaCheckCmpAnimal[i])
                        noDiff++;
                }

                // if we are still comparing relatives
                if (isRelative)
                {
                    if ((dnaCheckPdsAnimal[i] == 2 && dnaCheckCmpAnimal[i] == 0)
                        || (dnaCheckPdsAnimal[i] == 0 && dnaCheckCmpAnimal[i] == 2))
                        noFlip++;
                }

                // specifiy the cut offs
                if (noFlip > discoveryThreshold) isRelative = false;
                if (noDiff > PdsConfigurationValue.duplicateThreshold) isDuplicate = false;

                // is an exit early if possible
                if (!isDuplicate && !isRelative)
                {
                    return AnimalRelation.NotDuplicateAndRelative;
                }
            }

            // I require a certain number of comparisons to make any decisions at all.
            if (isPdsComp && noMarkerComp < PdsConfigurationValue.pdsMinCmpMarkers)
                return AnimalRelation.Undetermined;

            if (!isPdsComp && noMarkerComp < PdsConfigurationValue.fullMinCmpMarkers)
                return AnimalRelation.Undetermined;

            if (noMarkerComp < PdsConfigurationValue.minDuplicateCmp)
                isDuplicate = false;

            if (isRelative && isDuplicate)
                return AnimalRelation.BothDuplicateAndRelative;

            if (isRelative && !isDuplicate)
                return AnimalRelation.Relative;

            if (!isRelative && isDuplicate)
                return AnimalRelation.Duplicate;

            return AnimalRelation.NotDuplicateAndRelative;
        }

        /// <summary>
        /// Defined relation between two animals (sire or dam or sibling)
        /// </summary>
        /// <param name="pdsAnimalRecord"></param>
        /// <param name="cmpAnimalRecord"></param>
        /// <param name="isSire"></param>
        /// <param name="isDam"></param>
        /// <param name="isSibling"></param>
        public static void CheckRelativeAnimal(AnimalInformation pdsAnimalRecord, AnimalInformation cmpAnimalRecord, ref bool isSire, ref bool isDam, ref bool isSibling)
        {
            if (!cmpAnimalRecord.birthDay.HasValue || !pdsAnimalRecord.birthDay.HasValue)
                return;

            double parentOffSpringAgeDiff = (pdsAnimalRecord.birthDay.Value - cmpAnimalRecord.birthDay.Value).TotalDays;

            if (parentOffSpringAgeDiff > PdsConfigurationValue.parentOffSpringAgeDiffMin)
            {
                if (cmpAnimalRecord.isMale)
                    isSire = true;
                else
                    isDam = true;
            }
            else if (Math.Abs(parentOffSpringAgeDiff) < PdsConfigurationValue.parentOffSpringAgeDiffMin)
                isSibling = true;
        }

        /// <summary>
        /// Remove samples in allSampleOkInSystem base on input dna ids of dnaIdList
        /// </summary>
        /// <param name="allSampleOkInSystem"></param>
        /// <param name="dnaIdList">list dna id need remove in allSampleOkInSystem</param>
        public static void RemoveSamplesOfSampleSystem(Dictionary<string, AnimalInformation> allSampleOkInSystem, HashSet<string> dnaIdList)
        {
            foreach (string dnaId in dnaIdList)
            {
                if (allSampleOkInSystem.ContainsKey(dnaId))
                    allSampleOkInSystem.Remove(dnaId);
            }
        }

        /// <summary>
        /// Update PdsCheckRequired = 0 in [SAT_GSAMPLE_DQIS] base on dnaIdList input
        /// </summary>
        /// <param name="dnaIdList"></param>
        /// <param name="PID"></param>
        public static void UpdatePdsCheckRequiredStatus(HashSet<string> dnaIdList, Dictionary<string, AnimalInformation> allSampleOkInSystem, string PID)
        {
            if (dnaIdList.Count == 0)
                return;

            DataTable sampleTable = new DataTable();
            sampleTable.Columns.Add("PK_SAMPLE_ID", typeof(string));

            foreach (string dnaId in dnaIdList)
            {
                DataRow row = sampleTable.NewRow();
                row["PK_SAMPLE_ID"] = allSampleOkInSystem[dnaId].sampleId;
                sampleTable.Rows.Add(row);
            }

            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(DBReference.ConnStr_DV);
            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                connection.Open();

                // Configure the SqlCommand and SqlParameter.
                SqlCommand insertCommand = new SqlCommand("usp_gs_ga_update_pds_check_status", connection);
                insertCommand.CommandType = CommandType.StoredProcedure;

                SqlParameter PIDParam = insertCommand.Parameters.AddWithValue("@PID", PID);
                PIDParam.SqlDbType = SqlDbType.VarChar;

                SqlParameter sampleValuesParam = insertCommand.Parameters.AddWithValue("@SAMPLE_LIST", sampleTable);
                sampleValuesParam.SqlDbType = SqlDbType.Structured;

                //Set timeout no limit
                insertCommand.CommandTimeout = 0;
                // Execute the command.
                insertCommand.ExecuteNonQuery();
                connection.Close();
            }
        }

        /// <summary>
        /// Update obsoleted all records of input pdsDnaIds in SAT_DNA_PAIR_ANALYSIS
        /// </summary>
        /// <param name="pdsDnaIds">Input samples use for calculated pds</param>
        /// <param name="PID"></param>
        public static void UpdateObsoleteDnaPairAnalysisOfPdsSamples(HashSet<string> dnaIdList, string PID)
        {
            if (dnaIdList.Count == 0)
                return;

            string sqlCommand = string.Format(@"EXEC usp_gs_ga_update_obsoleted_data_pds '{0}', '{1}'", string.Join(",", dnaIdList), PID);
            DataReaderUtilities.GetData(DBReference.ConnStr_DV, sqlCommand);
        }

        #region declare struct and enum

        public enum AnimalRelation
        {
            Duplicate = 1,
            Relative = 2,
            BothDuplicateAndRelative = 3,
            NotDuplicateAndRelative = 4,
            Undetermined = 5
        }

        public struct AnimalInformation
        {
            public string animalId;
            public string sireId;
            public string damId;
            public string dnaId;
            public bool isMale;
            public DateTime? birthDay;
            public string sampleId;
            public string chipId;
            public string dnaFilePath;
        }

        public struct DnaPairAnalysis
        {
            public string dnaId;
            public string pairDnaId;
            public bool isSire;
            public bool isDam;
            public bool isSibling;
            public bool isDuplicate;
            public bool isInconsistent;
            public bool isContradic;
        }

        public static class PdsConfigurationValue
        {
            public static string pdsPanel = string.Empty;
            public static string core6kPanel = string.Empty;
            public static int pdsDiscoveryThreshold = 0;
            public static int fullDiscoveryThreshold = 0;
            public static int genoInconsistencyThreshold = 0;
            public static int duplicateThreshold = 0;
            public static int minDuplicateCmp = 0;
            public static int pdsMinCmpMarkers = 0;
            public static int fullMinCmpMarkers = 0;
            public static int parentOffSpringAgeDiffMin = 0;
            public static int numberPoisOfPds = 0;
            public static int numberPoisPanels = 0;     // Sum number pois of panels (pois_pdsPanel + pois_core6kPanel)
        }

        #endregion

        #region Class table pds storage

        public class DnaPairAnalysisTable
        {
            private DataTable dnaPairAnalysisTable;
            private string PID;
            private double MAX_BUFFER_TABLE = GSEnvironmentSetting.MAX_BUFFER_DATA_TABLE; // because datatable have limit row is 2^24
            private int rowCount = 0; // row count of dnaPairAnalysisTable

            public DnaPairAnalysisTable(string PID)
            {
                this.PID = PID;
                InitDnaPairAnalysisTable();
            }

            public void InitDnaPairAnalysisTable()
            {
                ClearTable();

                dnaPairAnalysisTable = new DataTable();
                dnaPairAnalysisTable.Columns.Add("PK_DNA_ID", typeof(string));
                dnaPairAnalysisTable.Columns.Add("PK_PAIR_DNA_ID", typeof(string));
                dnaPairAnalysisTable.Columns.Add("IS_SIRE", typeof(bool));
                dnaPairAnalysisTable.Columns.Add("IS_DAM", typeof(bool));
                dnaPairAnalysisTable.Columns.Add("IS_SIBLING", typeof(bool));
                dnaPairAnalysisTable.Columns.Add("IS_DUPLICATE", typeof(bool));
                dnaPairAnalysisTable.Columns.Add("IS_INCONSISTENT", typeof(bool));
                dnaPairAnalysisTable.Columns.Add("IS_CONTRADICT", typeof(bool));

                rowCount = 0;
            }

            public void AddNewRecord(PdsHelper.DnaPairAnalysis dnaPairAnalaysis)
            {
                if (rowCount == MAX_BUFFER_TABLE)
                {
                    StoreDnaPairValuesToDB();
                    InitDnaPairAnalysisTable(); // Reset datatable
                }

                DataRow row = dnaPairAnalysisTable.NewRow();
                row["PK_DNA_ID"] = dnaPairAnalaysis.dnaId;
                row["PK_PAIR_DNA_ID"] = dnaPairAnalaysis.pairDnaId;
                row["IS_SIRE"] = dnaPairAnalaysis.isSire;
                row["IS_DAM"] = dnaPairAnalaysis.isDam;
                row["IS_SIBLING"] = dnaPairAnalaysis.isSibling;
                row["IS_DUPLICATE"] = dnaPairAnalaysis.isDuplicate;
                row["IS_INCONSISTENT"] = dnaPairAnalaysis.isInconsistent;
                row["IS_CONTRADICT"] = dnaPairAnalaysis.isContradic;
                dnaPairAnalysisTable.Rows.Add(row);

                // increase row count
                rowCount++;
            }

            public void StoreDnaPairValuesToDB()
            {
                if (rowCount == 0)
                    return;

                // Insert pds value to database
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(DBReference.ConnStr_DV);
                using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                {
                    connection.Open();
                    SqlCommand insertCommand = new SqlCommand("usp_gs_ga_storage_pds_values", connection);
                    insertCommand.CommandType = CommandType.StoredProcedure;

                    SqlParameter pidParam = insertCommand.Parameters.AddWithValue("@PID", PID);
                    pidParam.SqlDbType = SqlDbType.VarChar;

                    SqlParameter dnaPairValueParam = insertCommand.Parameters.AddWithValue("@DNA_PAIR_ANALYSIS_VALUES", dnaPairAnalysisTable);
                    dnaPairValueParam.SqlDbType = SqlDbType.Structured;

                    //Set timeout no limit
                    insertCommand.CommandTimeout = 0;
                    // Execute the command.
                    insertCommand.ExecuteNonQuery();

                    connection.Close();
                }
            }

            public void ClearTable()
            {
                if (dnaPairAnalysisTable != null)
                    dnaPairAnalysisTable.Dispose();

                dnaPairAnalysisTable = null;
            }
        }

        #endregion
    }
}
