﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.RegularExpressions;

namespace CDRGenomicHelper
{
    public class GenomicFileHelper
    {
        /// <summary>
        /// Scan folder recursive and find the files which have extension is in the acceptanceFileExtensions and ignore folder in the exceptedFolder
        /// </summary>
        /// <param name="scannedFolder">Root folder need to scan</param>
        /// <param name="acceptanceFileExtensions">List of extension file, i.e. 481, 561, ggg</param>
        /// <param name="exceptedFolder">ETL_DIRECTORY_BIN/Complete, WEB_DIRECTORY_BIN/UserId/Complele</param>
        /// <param name="unzipRequired">Flag 'true' if need unzip files before scanning</param>
        /// <returns></returns>
        public static IEnumerable<string> ScanFiles(string scannedFolder, List<string> acceptanceFileExtensions, string exceptedFolder, bool unzipRequired = true)
        {
            if (Directory.Exists(scannedFolder))
            {
                if (unzipRequired)
                    Unzip(scannedFolder, exceptedFolder);

                foreach (var file in Directory.GetFiles(scannedFolder, "*.*", SearchOption.AllDirectories).Where(d => string.IsNullOrEmpty(exceptedFolder) || !d.StartsWith(exceptedFolder)))
                {
                    var extension = Path.GetExtension(file);
                    if (extension != null)
                    {
                        string ext = extension.Replace(".", string.Empty);
                        if (acceptanceFileExtensions.Contains(ext))
                        {
                            yield return file;
                        }
                    }
                }
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="folder"></param>
        /// <param name="acceptanceFileExtensions"></param>
        /// <param name="exceptedFolder"></param>
        /// <returns>
        /// Guid : unique ID for a batch
        /// List<string> : List of files in a batch
        /// </returns>
        public static IDictionary<Guid, List<string>> ScanFileZip(string zipFile, IEnumerable<string> acceptanceFileExtensions)
        {
            Dictionary<Guid, List<string>> batchResults = new Dictionary<Guid, List<string>>();

            if (File.Exists(zipFile) && zipFile.EndsWith(GenomicExtension.ZIP_FILE_EXT))
            {
                Guid zipGuild = Guid.NewGuid();
                string directory = Path.Combine(Path.GetDirectoryName(zipFile), zipGuild.ToString());
                UnzipToDestination(zipFile, directory);
                var filesInZip = ScanFiles(directory, acceptanceFileExtensions.ToList(), string.Empty, false);
                if (filesInZip.Count() != 0)
                {
                    batchResults.Add(zipGuild, new List<string>(filesInZip));
                }
                else
                {
                    DeleteDirectory(directory);
                }
            }

            return batchResults;
        }


        /// <summary>
        /// Scan folder recursive and extract zip files at the same folder, then move these zips into completed folder
        /// </summary>
        /// <param name="scannedFolder"></param>
        /// <param name="exceptedFolder"></param>
        private static void Unzip(string scannedFolder, string exceptedFolder)
        {
            // scan all file in folder
            foreach (var file in Directory.GetFiles(scannedFolder, "*.*", SearchOption.AllDirectories).Where(f => (string.IsNullOrEmpty(exceptedFolder) || !f.StartsWith(exceptedFolder)) && f.EndsWith(GenomicExtension.ZIP_FILE_EXT)))
            {
                using (ZipArchive archive = ZipFile.OpenRead(file))
                {
                    foreach (ZipArchiveEntry entry in archive.Entries)
                    {
                        string completeFileName = Path.Combine(scannedFolder, entry.FullName);
                        if (entry.Name == "")
                        {
                            // Assuming Empty for Directory
                            var directory = Path.GetDirectoryName(completeFileName);
                            if (directory != null)
                                Directory.CreateDirectory(directory);
                            continue;
                        }

                        entry.ExtractToFile(completeFileName, true);
                    }
                }
            }
        }

        /// <summary>
        /// Zip all files in list file to .zip
        /// </summary>
        /// <param name="files">Files that need to zip</param>
        /// <param name="zipPath">Path of zip file. Extension is ".zip"</param>
        public static void ZipFiles(List<string> files, string zipPath)
        {
            if (File.Exists(zipPath))
                File.Delete(zipPath);

            // Zip files
            using (ZipArchive zip = ZipFile.Open(zipPath, ZipArchiveMode.Create))
            {
                foreach (var file in files)
                    zip.CreateEntryFromFile(file, Path.GetFileName(file));
            }
        }

        /// <summary>
        /// Unzip to specify destination
        /// </summary>
        /// <param name="zipFile"></param>
        /// <param name="destinationFolder"></param>
        public static void UnzipToDestination(string zipFile, string destinationFolder)
        {
            if (!Directory.Exists(destinationFolder))
            {
                Directory.CreateDirectory(destinationFolder);
            }

            using (ZipArchive archive = ZipFile.OpenRead(zipFile))
            {
                foreach (ZipArchiveEntry entry in archive.Entries)
                {
                    string completeFileName = Path.Combine(destinationFolder, entry.FullName);
                    if (entry.Name == "")
                    {
                        // Assuming Empty for Directory
                        var directory = Path.GetDirectoryName(completeFileName);
                        if (directory != null)
                            Directory.CreateDirectory(directory);
                        continue;
                    }

                    entry.ExtractToFile(completeFileName, true);
                }
            }
        }

        /// <summary>
        /// Delete directory
        /// </summary>
        /// <param name="directory"></param>
        public static void DeleteDirectory(string directory)
        {
            if (Directory.Exists(directory))
            {
                Directory.Delete(directory, true);
            }
        }

        /// <summary>
        /// Using for FTP request
        /// After scan files in a batch, move file to complete folder
        /// </summary>
        /// <param name="batchFolder"></param>
        public static void MoveCompletedFTPFile(string batchFolder)
        {
            if (Directory.Exists(batchFolder))
            {
                var froot = new GNetworkAccess(WorkflowLogConstant.ETL_DIRECTORY_BIN).RootFolder;

                var completeFolder = GenomicDataHelper.BuildLocationForFile(froot, WorkflowLogConstant.COMPLETE_FOLDER);

                foreach (var file in Directory.GetFiles(batchFolder, "*.*", SearchOption.AllDirectories))
                {
                    var directory = Path.GetDirectoryName(file);
                    if (directory != null)
                    {
                        var destination = directory.Replace(froot, completeFolder);

                        if (!Directory.Exists(destination))
                        {
                            Directory.CreateDirectory(destination);
                        }

                        var destinationFile = Path.Combine(destination, Path.GetFileName(file));

                        if (File.Exists(destinationFile))
                        {
                            File.Delete(destinationFile);
                        }

                        File.Move(file, destinationFile);
                    }
                }

                if (!Directory.EnumerateFiles(batchFolder).Any())
                    Directory.Delete(batchFolder, true);
            }
        }

        /// <summary>
        /// read csv file and parse to datatable
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="delimiter"></param>
        /// <param name="headerRow">position of header row, start by 0</param>
        /// <returns></returns>
        public static DataTable ReadCSVDataFile(string filePath, string delimiter = GSEnvironmentSetting.DEFAULT_EXPORT_FILE_DELIMITER, int headerRow = -1)
        {
            DataTable dtCsv = new DataTable();
            var lines = File.ReadLines(filePath).ToArray();
            string[] headerValues = Regex.Split(lines[headerRow != -1 ? headerRow : headerRow + 1], delimiter);

            // create header
            if (headerRow != -1)
            {
                dtCsv.Columns.AddRange(headerValues.Select(columnName => new DataColumn(columnName)).ToArray());
            }
            else
            {
                for (int i = 0; i < headerValues.Length; i++)
                {
                    dtCsv.Columns.Add("Column" + i);
                }
            }

            // add data
            for (int i = headerRow + 1; i < lines.Length; i++)
            {
                string[] rowValues = Regex.Split(lines[i], delimiter);
                if (rowValues.Length > 0)
                {
                    DataRow dr = dtCsv.NewRow();
                    for (int j = 0; j < rowValues.Length; j++)
                    {
                        dr[j] = rowValues[j].ToString();
                    }

                    dtCsv.Rows.Add(dr);
                }
            }

            return dtCsv;
        }

        #region Nominations

        /// <summary>
        /// Using for logging nomination validation after commit
        /// </summary>
        /// <param name="wPID"></param>
        /// <param name="invalidNominations"></param>
        public static void LogInvalidNominations(string wPID, DataSet invalidNominations)
        {
            List<string> logContent = new List<string>();
            WriteLogFile(wPID, GetMessageAnimalNotExisted(invalidNominations.Tables[0]));
            WriteLogFile(wPID, GetMessageMissingAnimalId(invalidNominations.Tables[1]));
            WriteLogFile(wPID, GetMessageMissingProvider(invalidNominations.Tables[2]));
            WriteLogFile(wPID, GetMessageMissingRequester(invalidNominations.Tables[3]));
            WriteLogFile(wPID, GetMessageMissingSampleForCow(invalidNominations.Tables[4]));
            WriteLogFile(wPID, GetMessageDuplicationNomination(invalidNominations.Tables[5]));
            WriteLogFile(wPID, GetMessageMultipleAnimal(invalidNominations.Tables[6]));
        }

        private static void WriteLogFile(string wPID, Dictionary<string, List<string>> files)
        {
            WorkflowFile nominationLogger = null;                  
            foreach (var file in files)
            {
                nominationLogger = new WorkflowFile(Int64.Parse(wPID), wPID + "_" + file.Key + ".txt", WorkflowLogConstant.REPORT_TYPE);
                nominationLogger.Write(file.Value);
            }
        }

        private static Dictionary<string, List<string>> GetMessageAnimalNotExisted(DataTable invalidNominations)
        {
            Dictionary<string, List<string>> files = new Dictionary<string, List<string>>();
            foreach (DataRow nomination in invalidNominations.Rows)
            {
                string filename = nomination["IMPORT_FILE"].ToString();
                if (!files.ContainsKey(filename))
                    files.Add(filename, new List<string>());
                files[filename].Add(string.Format(GenomicMessage.ERR_MSG_GS_STG_NOMINATION_ANIMAL_NOT_EXISTED, nomination["ROW_LINE_ID"].ToString(), nomination["BK_ANIMAL_NATIONAL_ID"].ToString()));
            }
            return files;
        }

        private static Dictionary<string, List<string>> GetMessageMissingAnimalId(DataTable invalidNominations)
        {
            Dictionary<string, List<string>> files = new Dictionary<string, List<string>>();
            foreach (DataRow nomination in invalidNominations.Rows)
            {
                string filename = nomination["IMPORT_FILE"].ToString();
                if (!files.ContainsKey(filename))
                    files.Add(filename, new List<string>());
                files[filename].Add(string.Format(GenomicMessage.ERR_MSG_GS_STG_NOMINATION_MISSING_ANIMAL_ID, nomination["ROW_LINE_ID"].ToString()));
            }
            return files;
        }

        private static Dictionary<string, List<string>> GetMessageMissingProvider(DataTable invalidNominations)
        {
            Dictionary<string, List<string>> files = new Dictionary<string, List<string>>();
            foreach (DataRow nomination in invalidNominations.Rows)
            {
                string filename = nomination["IMPORT_FILE"].ToString();
                if (!files.ContainsKey(filename))
                    files.Add(filename, new List<string>());
                files[filename].Add(string.Format(GenomicMessage.ERR_MSG_GS_STG_NOMINATION_MISSING_PROVIDER, nomination["ROW_LINE_ID"].ToString()));
            }
            return files;
        }

        private static Dictionary<string, List<string>> GetMessageMissingRequester(DataTable invalidNominations)
        {
            Dictionary<string, List<string>> files = new Dictionary<string, List<string>>();
            foreach (DataRow nomination in invalidNominations.Rows)
            {
                string filename = nomination["IMPORT_FILE"].ToString();
                if (!files.ContainsKey(filename))
                    files.Add(filename, new List<string>());
                files[filename].Add(string.Format(GenomicMessage.ERR_MSG_GS_STG_NOMINATION_MISSING_REQUESTER, nomination["ROW_LINE_ID"].ToString()));
            }
            return files;
        }

        private static Dictionary<string, List<string>> GetMessageMissingSampleForCow(DataTable invalidNominations)
        {
            Dictionary<string, List<string>> files = new Dictionary<string, List<string>>();
            foreach (DataRow nomination in invalidNominations.Rows)
            {
                string filename = nomination["IMPORT_FILE"].ToString();
                if (!files.ContainsKey(filename))
                    files.Add(filename, new List<string>());
                files[filename].Add(string.Format(GenomicMessage.ERR_MSG_GS_STG_NOMINATION_MISSING_SAMPLE_FOR_COW, nomination["ROW_LINE_ID"].ToString(), nomination["BK_ANIMAL_NATIONAL_ID"].ToString()));
            }
            return files;
        }

        private static Dictionary<string, List<string>> GetMessageDuplicationNomination(DataTable invalidNominations)
        {
            Dictionary<string, List<string>> files = new Dictionary<string, List<string>>();
            foreach (DataRow nomination in invalidNominations.Rows)
            {
                string filename = nomination["IMPORT_FILE"].ToString();
                if (!files.ContainsKey(filename))
                    files.Add(filename, new List<string>());
                files[filename].Add(string.Format(GenomicMessage.ERR_MSG_GS_STG_NOMINATION_DUPLICATION_NOMINATION, nomination["ROW_LINE_ID"].ToString(), nomination["BK_ANIMAL_NATIONAL_ID"].ToString(), nomination["SUPPLIED_SAMPLE_ID"].ToString()));
            }
            return files;
        }

        private static Dictionary<string, List<string>> GetMessageMultipleAnimal(DataTable invalidNominations)
        {
            Dictionary<string, List<string>> files = new Dictionary<string, List<string>>();
            foreach (DataRow nomination in invalidNominations.Rows)
            {
                string filename = nomination["IMPORT_FILE"].ToString();
                if (!files.ContainsKey(filename))
                    files.Add(filename, new List<string>());
                files[filename].Add(string.Format(GenomicMessage.ERR_MSG_GS_STG_NOMINATION_NOMINATE_FOR_MULTIPLE_ANIMALS, nomination["ROW_LINE_ID"].ToString(), nomination["SUPPLIED_SAMPLE_ID"].ToString()));
            }
            return files;
        }

        #endregion
    }
}
