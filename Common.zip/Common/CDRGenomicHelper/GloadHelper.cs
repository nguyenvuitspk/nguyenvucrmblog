﻿using CDRGenomicHelper;
using DataReaderUtilsLib;
using GenomicPackageBase;
using SQLUtilsLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CDRGenomicHelper
{
    public static class WorkflowLogInstance
    {
        public static WorkflowLog instance;
    }

    public class Batch
    {
        public Guid batchID;
        public int insertedId;
        public List<string> listOfFiles;
        public bool isFailedQA;
        public string partyCode;
    }

    public class Marker
    {
        public string SNPIndex { get; set; }
        public string MarkerCode { get; set; }
        public int NoMarkers { get; set; }
        public int OriginalNoMarkers { get; set; }
    }

    public static class GloadHelper
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="folder"></param>
        /// <param name="exceptionFolder"></param>
        /// <returns></returns>
        public static IEnumerable<Batch> ScanBatches(string folder, string exceptionFolder)
        {
            List<Batch> batches = new List<Batch>();
            var files = Directory.GetFiles(folder).Where(d => string.IsNullOrEmpty(exceptionFolder) || !d.StartsWith(exceptionFolder)).ToList();
            var subfolders = Directory.GetDirectories(folder);
            foreach (var file in files)
            {
                // don't handle files existed in batch
                if (batches.SelectMany(_ => _.listOfFiles).Contains(file))
                    continue;
                var dir = Path.GetDirectoryName(file);
                var ext = Path.GetExtension(file).Replace(".", string.Empty);
                switch (ext)
                {
                    case GenomicExtension.TXT_FILE_EXT:
                        var batch = new Batch { batchID = Guid.NewGuid(), partyCode = GenomicImportHelper.GetPartyCodeByDirPath(dir), listOfFiles = new List<string> { file } };
                        batches.Add(batch);
                        break;
                    case GenomicExtension.ZIP_FILE_EXT:
                        var zipBatch = ScanBatchesFromZip(file);
                        if (zipBatch.listOfFiles != null && zipBatch.listOfFiles.Count != 0)
                        {
                            batches.Add(zipBatch);
                        }
                        break;
                    case GenomicExtension.GGG_FILE_EXT:
                    case GenomicExtension.GMS_FILE_EXT:
                    case GenomicExtension.GSS_FILE_EXT:
                        // Different extension but same name, add to a batch
                        string fileName = Path.GetFileNameWithoutExtension(file);
                        string directory = Path.GetDirectoryName(file);
                        // check existed couple of files (ggg, gms, gss)
                        string gggFile = Path.Combine(directory, $"{fileName}.{GenomicExtension.GGG_FILE_EXT}");
                        string gmsFile = Path.Combine(directory, $"{fileName}.{GenomicExtension.GMS_FILE_EXT}");
                        string gssFile = Path.Combine(directory, $"{fileName}.{GenomicExtension.GSS_FILE_EXT}");

                        if (File.Exists(gggFile) && File.Exists(gmsFile) && File.Exists(gssFile))
                        {
                            var newBatch = new Batch { batchID = Guid.NewGuid(), partyCode = GenomicImportHelper.GetPartyCodeByDirPath(dir), listOfFiles = new List<string> { gggFile, gmsFile, gssFile } };
                            batches.Add(newBatch);
                        }
                        else
                        {
                            WorkflowLogInstance.instance.WriteLog(string.Format(GenomicMessage.LOG_MSG_GS_LND_IGNORE_MISSING_COUPLE_GGG_GMS_GSS, file));
                        }

                        break;
                }
            }

            foreach (string sub in subfolders)
            {
                var subBatches = ScanBatches(sub, exceptionFolder);

                if (subBatches.Count() != 0)
                    batches.AddRange(subBatches);
            }

            return batches;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="zipPath"></param>
        /// <returns></returns>
        public static Batch ScanBatchesFromZip(string zipPath)
        {
            Batch batch = new Batch();

            if (File.Exists(zipPath) && zipPath.EndsWith(GenomicExtension.ZIP_FILE_EXT))
            {
                Guid zipGuild = Guid.NewGuid();
                string directory = Path.Combine(Path.GetDirectoryName(zipPath), zipGuild.ToString());
                GenomicFileHelper.UnzipToDestination(zipPath, directory);
                List<Batch> tempBatches = ScanBatches(directory, string.Empty).ToList();
                if (tempBatches.Count() != 0)
                {
                    var dir = Path.GetDirectoryName(zipPath);
                    batch.batchID = zipGuild;
                    batch.listOfFiles = new List<string>(tempBatches.SelectMany(_ => _.listOfFiles));
                    batch.partyCode = GenomicImportHelper.GetPartyCodeByDirPath(dir);
                }
                else
                {
                    GenomicFileHelper.DeleteDirectory(directory);
                }
            }

            return batch;
        }

        /// <summary>
        /// Used for validate format for US files
        /// </summary>
        /// <param name="filePath">Source of US input files.</param>
        /// <param name="delimiter">Delimmiter for split line</param>
        /// <returns></returns>
        public static bool CheckUSFormat(string filePath, string delimiter)
        {
            var lines = File.ReadLines(filePath);
            if (string.IsNullOrEmpty(delimiter))
            {
                delimiter = GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER;
            }

            char[] rightFormatAllele = CDRImportFileHeaderConstant.US_RIGHT_FORMAT;
            int countValidRow = 0;
            int countRow = 0;
            List<string> errorList = new List<string>();

            // Process US file
            IDictionary<string, IDictionary<string, string>> fdict = new Dictionary<string, IDictionary<string, string>>();
            foreach (var line in lines)
            {
                countRow++;

                bool isErrorLine = false;

                var valueOfLine = Regex.Split(line, delimiter).Where(_ => !string.IsNullOrEmpty(_)).ToArray();

                if (valueOfLine.Length == 0)
                {
                    countValidRow++;
                    continue;
                }

                if (valueOfLine.Length != 5)
                {
                    isErrorLine = true;
                    errorList.Add(string.Format(GenomicMessage.ERR_MSG_GS_LND_NUMBER_OF_COLUMN, countRow, valueOfLine.Length));
                    continue;
                }

                // Data Name column
                if (valueOfLine[0].Length != 9)
                {
                    isErrorLine = true;
                    errorList.Add(string.Format(GenomicMessage.ERR_MSG_GS_LND_NUMBER_OF_CHARACTER_OF_COLUMN,
                                                                          countRow,
                                                                          CDRImportFileHeaderConstant.US_DATANAME_COLUMN_NAME,
                                                                          CDRImportFileHeaderConstant.US_NO_OF_CHAR_DATANAME_COLUMN_REQUIRED));
                }

                // Sample column
                if (valueOfLine[1].Length != 19)
                {
                    isErrorLine = true;
                    errorList.Add(string.Format(GenomicMessage.ERR_MSG_GS_LND_NUMBER_OF_CHARACTER_OF_COLUMN,
                                                                        countRow,
                                                                        CDRImportFileHeaderConstant.US_SAMPLE_COLUMN_NAME,
                                                                        CDRImportFileHeaderConstant.US_NO_OF_CHAR_SAMPLE_COLUMN_REQUIRED));
                }

                // SNP Index column
                int tempOutput = 0;
                if (int.TryParse(valueOfLine[2], out tempOutput) == false)
                {
                    isErrorLine = true;
                    errorList.Add(string.Format(GenomicMessage.ERR_MSG_GS_LND_INVALID_NUMERIC_SNP, countRow));
                }

                // Allele 1 column 
                if (valueOfLine[3].Length != 1 || rightFormatAllele.Contains(Convert.ToChar(valueOfLine[3])) == false)
                {
                    isErrorLine = true;
                    errorList.Add(string.Format(GenomicMessage.ERR_MSG_GS_LND_INVALID_FORMAT_ALLELE1, countRow));
                }

                // Allele 2 column
                if (valueOfLine[4].Length != 1 || rightFormatAllele.Contains(Convert.ToChar(valueOfLine[4])) == false)
                {
                    isErrorLine = true;
                    errorList.Add(string.Format(GenomicMessage.ERR_MSG_GS_LND_INVALID_FORMAT_ALLELE2, countRow));
                }

                if (isErrorLine == false)
                {
                    countValidRow++;
                }
            }

            if (errorList.Count != 0)
            {
                WorkflowLogInstance.instance.WriteError(errorList);
            }

            return countValidRow == lines.Count();
        }

        /// <summary>
        /// Process convert US file to output files: ggg, gss, gms after call CheckUSFormat files
        /// </summary>
        /// <param name="filePath">Source of US input files.</param>
        /// <param name="delimiter">Delimmiter for split line</param>
        /// <param name="markerCrossRef">Call GetAllMarkerCodeWithTopAllele method</param>
        /// <param name="snpOrders">Call GetAllSnipOrders method</param>
        /// <param name="listOfFiles"></param>
        /// <returns></returns>
        public static bool TryConvertUSToGGG(string filePath, string delimiter, IDictionary<string, string> markerCrossRef, IDictionary<string, HashSet<Marker>> snpOrders, out List<string> listOfFiles)
        {
            IDictionary<string, IDictionary<string, string>> fdict = new Dictionary<string, IDictionary<string, string>>();

            listOfFiles = new List<string>();

            var lines = File.ReadLines(filePath);
            lines = lines.Where(x => !string.IsNullOrEmpty(x) || !string.IsNullOrWhiteSpace(x));

            if (string.IsNullOrEmpty(delimiter))
            {
                delimiter = GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER;
            }

            foreach (string line in lines)
            {
                // process line 
                var data = Regex.Split(line, delimiter).Where(_ => !string.IsNullOrEmpty(_)).ToArray();
                var sampleId = data[1].ToUpper();
                var marker = data[2].ToUpper();
                var allele = (data[3] + data[4]).ToUpper();

                IDictionary<string, string> sampleData;
                if (!fdict.ContainsKey(sampleId))
                {
                    sampleData = new Dictionary<string, string>();
                    fdict.Add(sampleId, sampleData);
                }
                sampleData = fdict[sampleId];

                if(sampleData.ContainsKey(marker))
                    return false;

                sampleData.Add(marker, allele);
            }

            List<string> errorList = new List<string>();

            // Process sample data
            IDictionary<string, IDictionary<string, IDictionary<string, string>>> allSamplesByChip = new Dictionary<string, IDictionary<string, IDictionary<string, string>>>();
            foreach (string sample in fdict.Keys)
            {
                bool assignedchip = false;
                int noMarkerOfSample = fdict[sample].Keys.Count();

                foreach (string chip in snpOrders.Keys)
                {
                    if (snpOrders[chip].ElementAt(0).OriginalNoMarkers == noMarkerOfSample)
                    {
                        if (!allSamplesByChip.ContainsKey(chip))
                        {
                            allSamplesByChip.Add(chip, new Dictionary<string, IDictionary<string, string>>());
                        }

                        allSamplesByChip[chip].Add(sample, fdict[sample]);

                        assignedchip = true;
                        break;
                    }
                }

                if (!assignedchip)
                {
                    errorList.Add(string.Format(GenomicMessage.ERR_MSG_GS_LND_MARKER_CANT_ASSIGN_ANY_CHIP,
                                                                          sample,
                                                                          fdict[sample].Count()));
                }
            }

            if (errorList.Count != 0)
                WorkflowLogInstance.instance.WriteError(errorList);

            int idx = 0;
            string dir = Path.GetDirectoryName(filePath);


            // Write out three files
            foreach (string chip in allSamplesByChip.Keys)
            {
                idx++;
                var fileName = Path.GetFileNameWithoutExtension(filePath) + "_" + idx.ToString();
                var gssFileName = dir + Path.DirectorySeparatorChar + fileName + "." + GenomicExtension.GSS_FILE_EXT;
                var gmsFileName = dir + Path.DirectorySeparatorChar + fileName + "." + GenomicExtension.GMS_FILE_EXT;
                var gggFileName = dir + Path.DirectorySeparatorChar + fileName + "." + GenomicExtension.GGG_FILE_EXT;

                var samples = allSamplesByChip[chip].Keys;
                var markers = snpOrders[chip];

                var fileDate = DateTime.Today.ToString("d");
                var importName = DateTime.Today.ToString("d");

                // Write GSS file
                using (StreamWriter sw = new StreamWriter(gssFileName, false))
                {
                    sw.WriteLine(CDRImportFileHeaderConstant.GSS_HEADER_FOOTER);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GSS_IMPORT_NAME, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, importName);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GSS_NO_SAMPLES, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, samples.Count);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GSS_FILE_DATE, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, fileDate);
                    sw.WriteLine("{0}{1}{2}{3}{4}", CDRImportFileHeaderConstant.GSS_DATA_HEADER[0],
                                                    GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER,
                                                    CDRImportFileHeaderConstant.GSS_DATA_HEADER[1],
                                                    GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER,
                                                    CDRImportFileHeaderConstant.GSS_DATA_HEADER[2]);
                    foreach (string sample in samples)
                    {
                        sw.WriteLine("{0}{1}{2}{3}", sample, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, 1, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER);
                    }

                    sw.WriteLine(CDRImportFileHeaderConstant.GSS_HEADER_FOOTER);
                }

                listOfFiles.Add(gssFileName);


                // Write GMS file
                using (StreamWriter sw = new StreamWriter(gmsFileName, false))
                {
                    sw.WriteLine(CDRImportFileHeaderConstant.GMS_HEADER_FOOTER);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GMS_IMPORT_NAME, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, importName);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GMS_NO_MARKERS, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, markers.Count);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GMS_FILE_DATE, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, fileDate);
                    sw.WriteLine("{0}{1}{2}{3}{4}", CDRImportFileHeaderConstant.GMS_DATA_HEADER[0][0],
                                                     GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER,
                                                     CDRImportFileHeaderConstant.GMS_DATA_HEADER[1][0],
                                                     GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER,
                                                     CDRImportFileHeaderConstant.GMS_DATA_HEADER[2][0]);

                    foreach (Marker marker in markers)
                    {
                        sw.WriteLine("{0}{1}{2}{3}", marker.MarkerCode.ToUpper(), GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, 1, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER);
                    }

                    sw.WriteLine(CDRImportFileHeaderConstant.GMS_HEADER_FOOTER);
                }

                listOfFiles.Add(gmsFileName);

                // Write GGG file
                using (StreamWriter sw = new StreamWriter(gggFileName, false))
                {
                    sw.WriteLine(CDRImportFileHeaderConstant.GGG_HEADER_FOOTER);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GGG_IMPORT_NAME, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, importName);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GGG_NO_MARKERS, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, markers.Count);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GGG_NO_SAMPLES, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, samples.Count);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GGG_FILE_DATE, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, fileDate);
                    sw.WriteLine("{0}{1}{2}{3}{4}{5}{6}{7}{8}", CDRImportFileHeaderConstant.GGG_DATA_HEADER[0],
                                                      GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER,
                                                      CDRImportFileHeaderConstant.GGG_DATA_HEADER[1],
                                                      GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER,
                                                      CDRImportFileHeaderConstant.GGG_DATA_HEADER[2],
                                                      GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER,
                                                      CDRImportFileHeaderConstant.GGG_DATA_HEADER[3],
                                                      GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER,
                                                       CDRImportFileHeaderConstant.GGG_DATA_HEADER[4]
                                                      );

                    foreach (string sample in samples)
                    {
                        foreach (Marker marker in markers)
                        {
                            var mcode = marker.MarkerCode.ToUpper();
                            var midx = marker.SNPIndex;


                            if (!allSamplesByChip[chip][sample].ContainsKey(midx))
                            {
                                sw.WriteLine("{0}{1}{2}{3}{4}{5}{6}{7}{8}", mcode, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                        , sample, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                        , CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6], GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                        , CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6], GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                        , "1");
                            }
                            else
                            {
                                if (allSamplesByChip[chip][sample][midx].Count() != 2)
                                {
                                    sw.WriteLine("{0}{1}{2}{3}{4}{5}{6}{7}{8}", mcode, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                            , sample, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                            , CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6], GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                            , CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6], GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                            , "1");
                                }
                                else
                                {
                                    if (markerCrossRef.ContainsKey(mcode))
                                    {

                                        string ab = CDRImportFileHeaderConstant.US_AB_FORMAT;

                                        var topalleles = markerCrossRef[mcode];
                                        var allele = allSamplesByChip[chip][sample][midx];
                                        var allele1 = allele[0].ToString();
                                        var allele2 = allele[1].ToString();

                                        int a1Idx = ab.IndexOf(allele1);
                                        allele1 = (a1Idx >= 0) ? topalleles.Substring(a1Idx, 1) : CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6];

                                        int a2Idx = ab.IndexOf(allele2);
                                        allele2 = (a2Idx >= 0) ? topalleles.Substring(a2Idx, 1) : CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6];

                                        string gtac = CDRImportFileHeaderConstant.US_GTAC_FORMAT;

                                        if (!gtac.Contains(allele1))
                                        {
                                            allele1 = CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6];
                                        }

                                        if (!gtac.Contains(allele2))
                                        {
                                            allele2 = CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6];
                                        }

                                        sw.WriteLine("{0}{1}{2}{3}{4}{5}{6}{7}{8}", mcode, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                                , sample, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                                , allele1, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                                , allele2, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                                , "1");
                                    }
                                    else
                                    {
                                        sw.WriteLine("{0}{1}{2}{3}{4}{5}{6}{7}{8}", mcode, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                                , sample, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                                , CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6], GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                                , CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6], GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                                , "1");
                                    }
                                }
                            }
                        }
                    }

                    sw.WriteLine(CDRImportFileHeaderConstant.GGG_HEADER_FOOTER);
                }

                listOfFiles.Add(gggFileName);
            }

            if (listOfFiles.Count != 3)
            {
                WorkflowLogInstance.instance.WriteError(GenomicMessage.ERR_MSG_GS_LND_FAILED_NUM_OF_US_EXPORT_FILE);
                return false;
            }

            return listOfFiles.Count == 3;
        }

        public static bool CheckRawFormat(String filePath, string delimiter, out IDictionary<String, String> rawFormatType)
        {
            // TODO: move below block to local constant.
            List<string[]> formats = new List<string[]>();
            formats.Add(new String[] { "toptop", "SNP NAME", "SAMPLE ID", "ALLELE1 - TOP", "ALLELE2 - TOP" });
            formats.Add(new String[] { "toptop", "SNP NAME", "ID ID", "ALLELE1 - TOP", "ALLELE2 - TOP" });
            formats.Add(new String[] { "AB", "SNP NAME", "SAMPLE ID", "ALLELE1 - AB", "ALLELE2 - AB" });
            formats.Add(new String[] { "AB", "SNP NAME", "SAMPLE NAME", "ALLELE1 - TOP", "ALLELE2 - TOP" });
            formats.Add(new String[] { "AB", "SNP_NAME", "ITT", "ALLELE1_AB", "ALLELE2_AB" });
            formats.Add(new String[] { "ALLELE", "SNP_NAME", "SAMPLE_ID", "ALLELE_1", "ALLELE_2" });

            rawFormatType = new Dictionary<String, String>();
            List<string> errorList = new List<string>();

            if (string.IsNullOrEmpty(delimiter))
            {
                delimiter = GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER;
            }

            var lines = File.ReadLines(filePath).Take(10).ToArray();

            // TODO: check if the raw file has [header] or [data] line.
            if (!string.Equals(lines[0].Trim(), CDRImportFileHeaderConstant.RAW_FILE_HEADER, StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(lines[8].Trim(), CDRImportFileHeaderConstant.RAW_FILE_DATA_HEADER, StringComparison.OrdinalIgnoreCase))
            {
                WorkflowLogInstance.instance.WriteError(string.Format(GenomicMessage.ERR_MSG_GS_INVALID_COLUMN_HEADER,
                                                                         1,
                                                                         CDRImportFileHeaderConstant.RAW_FILE_HEADER + "," + CDRImportFileHeaderConstant.US_NO_OF_CHAR_DATANAME_COLUMN_REQUIRED
                                                                         ));
                return false;
            }

            var version = lines[1].Trim().Split(new string[] { delimiter }, StringSplitOptions.RemoveEmptyEntries).Select(_ => _.Trim()).ToArray();
            if (!string.Equals(version[0], CDRImportFileHeaderConstant.RAW_FILE_GSGT_VERSION, StringComparison.OrdinalIgnoreCase))
            {
                WorkflowLogInstance.instance.WriteError(string.Format(GenomicMessage.ERR_MSG_GS_INVALID_COLUMN_HEADER,
                                                                      2,
                                                                      CDRImportFileHeaderConstant.RAW_FILE_GSGT_VERSION
                                                                      ));
                return false;
            }

            var processingDate = lines[2].Trim().Split(new string[] { delimiter }, StringSplitOptions.RemoveEmptyEntries).Select(_ => _.Trim()).ToArray();
            if (!string.Equals(processingDate[0], CDRImportFileHeaderConstant.RAW_FILE_PROCESSING_DATE, StringComparison.OrdinalIgnoreCase))
            {
                WorkflowLogInstance.instance.WriteError(string.Format(GenomicMessage.ERR_MSG_GS_INVALID_COLUMN_HEADER,
                                                                    3,
                                                                    CDRImportFileHeaderConstant.RAW_FILE_PROCESSING_DATE
                                                                    ));
                return false;
            }

            var content = lines[3].Trim().Split(new string[] { delimiter }, StringSplitOptions.RemoveEmptyEntries).Select(_ => _.Trim()).ToArray();
            if (!string.Equals(content[0], CDRImportFileHeaderConstant.RAW_FILE_CONTENT, StringComparison.OrdinalIgnoreCase))
            {
                WorkflowLogInstance.instance.WriteError(string.Format(GenomicMessage.ERR_MSG_GS_INVALID_COLUMN_HEADER,
                                                                 4,
                                                                 CDRImportFileHeaderConstant.RAW_FILE_CONTENT
                                                                 ));
                return false;
            }

            bool valid;
            var numSNPs = lines[4].Trim().Split(new string[] { delimiter }, StringSplitOptions.RemoveEmptyEntries).Select(_ => _.Trim()).ToArray();
            int numOfSNPs;
            valid = int.TryParse(numSNPs[1], out numOfSNPs);
            if (!string.Equals(numSNPs[0], CDRImportFileHeaderConstant.RAW_FILE_NUM_SNP, StringComparison.OrdinalIgnoreCase) || !valid || numOfSNPs < 0)
            {
                WorkflowLogInstance.instance.WriteError(string.Format(GenomicMessage.ERR_MSG_GS_INVALID_COLUMN_HEADER_AND_VALUE,
                                                                5,
                                                                CDRImportFileHeaderConstant.RAW_FILE_NUM_SNP
                                                                ));
                return false;
            }

            var totalSNPs = lines[5].Trim().Split(new string[] { delimiter }, StringSplitOptions.RemoveEmptyEntries).Select(_ => _.Trim()).ToArray();
            int totalOfSNPs;
            valid = int.TryParse(totalSNPs[1], out totalOfSNPs);
            if (!string.Equals(totalSNPs[0], CDRImportFileHeaderConstant.RAW_FILE_TOTAL_SNP, StringComparison.OrdinalIgnoreCase) || !valid || totalOfSNPs < 0)
            {
                WorkflowLogInstance.instance.WriteError(string.Format(GenomicMessage.ERR_MSG_GS_INVALID_COLUMN_HEADER_AND_VALUE,
                                                               6,
                                                               CDRImportFileHeaderConstant.RAW_FILE_TOTAL_SNP
                                                               ));
                return false;
            }

            var numSamples = lines[6].Trim().Split(new string[] { delimiter }, StringSplitOptions.RemoveEmptyEntries).Select(_ => _.Trim()).ToArray();
            int numOfSamples;
            valid = int.TryParse(numSamples[1], out numOfSamples);
            if (!string.Equals(numSamples[0], CDRImportFileHeaderConstant.RAW_FILE_NUM_SAMPLE, StringComparison.OrdinalIgnoreCase) || !valid || numOfSamples < 0)
            {
                WorkflowLogInstance.instance.WriteError(string.Format(GenomicMessage.ERR_MSG_GS_INVALID_COLUMN_HEADER_AND_VALUE,
                                                               7,
                                                               CDRImportFileHeaderConstant.RAW_FILE_NUM_SAMPLE
                                                               ));
                return false;
            }

            var totalSamples = lines[7].Trim().Split(new string[] { delimiter }, StringSplitOptions.RemoveEmptyEntries).Select(_ => _.Trim()).ToArray();
            int totalOfSamples;
            valid = int.TryParse(totalSamples[1], out totalOfSamples);
            if (!string.Equals(totalSamples[0], CDRImportFileHeaderConstant.RAW_FILE_TOTAL_SAMPLE, StringComparison.OrdinalIgnoreCase) || !valid || totalOfSamples < 0)
            {
                WorkflowLogInstance.instance.WriteError(string.Format(GenomicMessage.ERR_MSG_GS_INVALID_COLUMN_HEADER_AND_VALUE,
                                                           8,
                                                           CDRImportFileHeaderConstant.RAW_FILE_TOTAL_SAMPLE
                                                           ));
                return false;
            }

            var headers = lines[9].Trim().Split(new string[] { delimiter }, StringSplitOptions.RemoveEmptyEntries).Select(_ => _.Trim()).ToList();
            foreach (String[] format in formats)
            {
                String type = format[0];
                int snpNameIdx = headers.FindIndex(_ => _.IndexOf(format[1], StringComparison.OrdinalIgnoreCase) == 0);
                int sampleIdIdx = headers.FindIndex(_ => _.IndexOf(format[2], StringComparison.OrdinalIgnoreCase) == 0);
                int allele1Idx = headers.FindIndex(_ => _.IndexOf(format[3], StringComparison.OrdinalIgnoreCase) == 0);
                int allele2Idx = headers.FindIndex(_ => _.IndexOf(format[4], StringComparison.OrdinalIgnoreCase) == 0);

                if (snpNameIdx >= 0 && sampleIdIdx >= 0 && allele1Idx >= 0 && allele2Idx >= 0)
                {
                    rawFormatType.Add(CDRImportFileHeaderConstant.RAW_ALLELE_TYPE, type);
                    rawFormatType.Add(CDRImportFileHeaderConstant.RAW_SNP_NAME_IDX, snpNameIdx.ToString());
                    rawFormatType.Add(CDRImportFileHeaderConstant.RAW_SAMPLE_ID_IDX, sampleIdIdx.ToString());
                    rawFormatType.Add(CDRImportFileHeaderConstant.RAW_ALLELE_1, allele1Idx.ToString());
                    rawFormatType.Add(CDRImportFileHeaderConstant.RAW_ALLELE_2, allele2Idx.ToString());
                    break;
                }
            }

            return (rawFormatType.Count == 5);
        }

        public static bool TryConvertRawToGGG(string filePath, IDictionary<String, String> rawFormatType, string delimiter, IDictionary<String, String> allsnps, IDictionary<String, HashSet<String>> allchips, out bool isABFormat, out List<string> listOfFiles)
        {
            listOfFiles = new List<string>();

            if (string.IsNullOrEmpty(delimiter))
            {
                delimiter = GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER;
            }

            // Process sample data
            string type = rawFormatType[CDRImportFileHeaderConstant.RAW_ALLELE_TYPE];
            int snpNameIdx = int.Parse(rawFormatType[CDRImportFileHeaderConstant.RAW_SNP_NAME_IDX]);
            int sampleIdIdx = int.Parse(rawFormatType[CDRImportFileHeaderConstant.RAW_SAMPLE_ID_IDX]);
            int allele1Idx = int.Parse(rawFormatType[CDRImportFileHeaderConstant.RAW_ALLELE_1]);
            int allele2Idx = int.Parse(rawFormatType[CDRImportFileHeaderConstant.RAW_ALLELE_2]);

            isABFormat = string.Equals(CDRImportFileHeaderConstant.RAW_AB_FORMAT, type, StringComparison.OrdinalIgnoreCase);

            var lines = File.ReadLines(filePath).Skip(10);
            lines = lines.Where(x => !string.IsNullOrEmpty(x) || !string.IsNullOrWhiteSpace(x));

            IDictionary<String, IDictionary<String, String>> sampleData = new Dictionary<String, IDictionary<String, String>>();
            foreach (String line in lines)
            {
                var data = Regex.Split(line, delimiter).Select(s => s.ToUpper()).ToArray();
                var snpName = data[snpNameIdx].ToUpper();
                var sampleId = data[sampleIdIdx].ToUpper();

                if (!allsnps.ContainsKey(snpName))
                {
                    continue;
                }

                var allele1 = data[allele1Idx];
                var allele2 = data[allele2Idx];

                // If is AB format, convert to ATGC format from DB.
                if (isABFormat)
                {
                    string allele = allsnps[snpName];

                    int a1Idx = CDRImportFileHeaderConstant.RAW_AB_FORMAT.IndexOf(allele1);
                    allele1 = (a1Idx >= 0) ? allele.Substring(a1Idx, 1) : CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6];

                    int a2Idx = CDRImportFileHeaderConstant.RAW_AB_FORMAT.IndexOf(allele2);
                    allele2 = (a2Idx >= 0) ? allele.Substring(a2Idx, 1) : CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6];
                }

                IDictionary<String, String> snpData;
                if (!sampleData.ContainsKey(sampleId))
                {
                    sampleData.Add(sampleId, new Dictionary<String, String>());
                }
                snpData = sampleData[sampleId];

                if (snpData.ContainsKey(snpName))
                    return false;

                snpData.Add(snpName, allele1 + allele2);
            }

            // Find the best chip for the data
            IDictionary<String, IDictionary<String, IDictionary<String, String>>> allSamplesByChip = new Dictionary<String, IDictionary<String, IDictionary<String, String>>>();
            foreach (String sampleId in sampleData.Keys)
            {
                int numberofchanges = -1;
                String bestChip = "";
                foreach (String chip in allchips.Keys)
                {
                    var overlap = allchips[chip].Intersect(sampleData[sampleId].Keys).Count();
                    var numbertoremove = sampleData[sampleId].Keys.Count - overlap;
                    var numbertopatch = allchips[chip].Count - overlap;
                    var chipchanges = numbertoremove + numbertopatch;

                    if (chipchanges < numberofchanges || numberofchanges < 0)
                    {
                        numberofchanges = chipchanges;
                        bestChip = chip;
                    }
                }

                if (!allSamplesByChip.ContainsKey(bestChip))
                {
                    allSamplesByChip.Add(bestChip, new Dictionary<String, IDictionary<String, String>>());
                }

                IDictionary<String, IDictionary<String, String>> sample = allSamplesByChip[bestChip];
                sample.Add(sampleId, sampleData[sampleId]);
            }

            // Write out three files
            int idx = 0;
            string dir = Path.GetDirectoryName(filePath);
            foreach (String bestChip in allSamplesByChip.Keys)
            {
                idx++;
                var fileName = Path.GetFileNameWithoutExtension(filePath) + "_" + idx.ToString();

                var gssFileName = dir + Path.DirectorySeparatorChar + fileName + "." + GenomicExtension.GSS_FILE_EXT;
                var gmsFileName = dir + Path.DirectorySeparatorChar + fileName + "." + GenomicExtension.GMS_FILE_EXT;
                var gggFileName = dir + Path.DirectorySeparatorChar + fileName + "." + GenomicExtension.GGG_FILE_EXT;

                var samples = allSamplesByChip[bestChip].Keys;
                var markers = allchips[bestChip];

                var fileDate = DateTime.Today.ToString("d");
                var importName = DateTime.Today.ToString("d");

                // Write GSS file
                using (StreamWriter sw = new StreamWriter(gssFileName, false))
                {
                    sw.WriteLine(CDRImportFileHeaderConstant.GSS_HEADER_FOOTER);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GSS_IMPORT_NAME, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, importName);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GSS_NO_SAMPLES, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, samples.Count);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GSS_FILE_DATE, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, fileDate);
                    sw.WriteLine("{0}{1}{2}{3}{4}", CDRImportFileHeaderConstant.GSS_DATA_HEADER[0],
                                                    GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER,
                                                    CDRImportFileHeaderConstant.GSS_DATA_HEADER[1],
                                                    GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER,
                                                    CDRImportFileHeaderConstant.GSS_DATA_HEADER[2]);
                    foreach (string sample in samples)
                    {
                        sw.WriteLine("{0}{1}{2}{3}", sample, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, 1, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER);
                    }

                    sw.WriteLine(CDRImportFileHeaderConstant.GSS_HEADER_FOOTER);
                }
                listOfFiles.Add(gssFileName);


                // Write GMS file
                using (StreamWriter sw = new StreamWriter(gmsFileName, false))
                {
                    sw.WriteLine(CDRImportFileHeaderConstant.GMS_HEADER_FOOTER);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GMS_IMPORT_NAME, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, importName);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GMS_NO_MARKERS, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, markers.Count);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GMS_FILE_DATE, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, fileDate);
                    sw.WriteLine("{0}{1}{2}{3}{4}", CDRImportFileHeaderConstant.GMS_DATA_HEADER[0][0],
                                                     GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER,
                                                     CDRImportFileHeaderConstant.GMS_DATA_HEADER[1][0],
                                                     GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER,
                                                     CDRImportFileHeaderConstant.GMS_DATA_HEADER[2][0]);

                    foreach (String marker in markers)
                    {
                        sw.WriteLine("{0}{1}{2}{3}", marker.ToUpper(), GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, 1, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER);
                    }

                    sw.WriteLine(CDRImportFileHeaderConstant.GMS_HEADER_FOOTER);
                }
                listOfFiles.Add(gmsFileName);

                // Write GGG file
                using (StreamWriter sw = new StreamWriter(gggFileName, false))
                {
                    sw.WriteLine(CDRImportFileHeaderConstant.GGG_HEADER_FOOTER);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GGG_IMPORT_NAME, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, importName);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GGG_NO_MARKERS, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, markers.Count);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GGG_NO_SAMPLES, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, samples.Count);
                    sw.WriteLine("{0}{1}{2}", CDRImportFileHeaderConstant.GGG_FILE_DATE, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER, fileDate);
                    sw.WriteLine("{0}{1}{2}{3}{4}{5}{6}{7}{8}", CDRImportFileHeaderConstant.GGG_DATA_HEADER[0],
                                                      GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER,
                                                      CDRImportFileHeaderConstant.GGG_DATA_HEADER[1],
                                                      GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER,
                                                      CDRImportFileHeaderConstant.GGG_DATA_HEADER[2],
                                                      GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER,
                                                      CDRImportFileHeaderConstant.GGG_DATA_HEADER[3],
                                                      GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER,
                                                       CDRImportFileHeaderConstant.GGG_DATA_HEADER[4]
                                                      );

                    foreach (String sample in samples)
                    {
                        foreach (String marker in markers)
                        {
                            string a1 = CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6];
                            string a2 = CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6];
                            if (!allSamplesByChip[bestChip][sample].ContainsKey(marker))
                            {
                                sw.WriteLine("{0}{1}{2}{3}{4}{5}{6}{7}{8}", marker, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                        , sample, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                        , CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6], GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                        , CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6], GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                        , "1");
                            }
                            else
                            {
                                if (allSamplesByChip[bestChip][sample][marker].Count() != 2)
                                {
                                    sw.WriteLine("{0}{1}{2}{3}{4}{5}{6}{7}{8}", marker, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                            , sample, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                            , CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6], GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                            , CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6], GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                            , "1");
                                }
                                else
                                {
                                    Char[] allele = allSamplesByChip[bestChip][sample][marker].ToCharArray();
                                    a1 = allele[0].ToString().ToUpper();
                                    a2 = allele[1].ToString().ToUpper();

                                    string gtac = CDRImportFileHeaderConstant.RAW_GTAC_FORMAT;

                                    if (!gtac.Contains(a1))
                                    {
                                        a1 = CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6];
                                    }

                                    if (!gtac.Contains(a2))
                                    {
                                        a2 = CDRImportFileHeaderConstant.GGG_ALLELE_VALUE_SET[6];
                                    }

                                    sw.WriteLine("{0}{1}{2}{3}{4}{5}{6}{7}{8}", marker, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                            , sample, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                            , a1, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                            , a2, GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER
                                                                            , "1");
                                }

                            }
                        }
                    }

                    sw.WriteLine(CDRImportFileHeaderConstant.GGG_HEADER_FOOTER);
                }
                listOfFiles.Add(gggFileName);
            }

            return (listOfFiles.Count > 0);
        }

        public static IDictionary<String, String> GetAllMarkerCodeWithTopAllele()
        {
            // Get all marker code and top allele from DB.
            var sqlCommand = "SELECT UPPER(ma.[MARKER_CODE]) AS MARKER_CODE, UPPER(gm.TOP_TOP_ALLELE) AS ALLELE FROM [dbo].[MARKER_ALIASES] ma JOIN [dbo].[GMARKERS] gm ON gm.[MARKER_ID] = ma.[MARKER_ID]";
            IDictionary<String, String> allsnps = DataReaderUtilities.GetData(DBReference.ConnStr_STG, sqlCommand).Tables[0].AsEnumerable()
                .ToDictionary(row => row.Field<string>("MARKER_CODE").ToUpper(), row => row.Field<string>("ALLELE"));
            return allsnps;
        }

        public static IDictionary<String, HashSet<String>> GetAllChipsWithMarkers()
        {
            // Get all chips and a list of marker codes for each chip.
            var sqlCommand = "SELECT UPPER(gc.[GCHIP_CODE]) AS GCHIP_CODE, UPPER(cm.[MARKER_CODE]) AS MARKER_CODE FROM [dbo].[GCHIPS] gc JOIN [dbo].[GCHIP_GMARKERS] cm ON cm.[GCHIP_CODE] = gc.[GCHIP_CODE]";
            var dataRows = DataReaderUtilities.GetData(DBReference.ConnStr_STG, sqlCommand).Tables[0].Rows.Cast<DataRow>().ToList();
            var chipCodes = dataRows.GroupBy(r => r["GCHIP_CODE"].ToString(), r => r["MARKER_CODE"].ToString());

            IDictionary<String, HashSet<String>> allchips = new Dictionary<String, HashSet<String>>();
            foreach (IGrouping<String, String> chipCode in chipCodes)
            {
                allchips.Add(chipCode.Key, new HashSet<string>(chipCode.ToList()));
            }

            return allchips;
        }

        public static IDictionary<string, HashSet<Marker>> GetAllSnipOrders()
        {
            // Get all SNP, marker code
            var sqlCommand = @"SELECT s.US_SNPORDER_ID, d.[US_SNP_INDEX], UPPER(d.MARKER_CODE) AS MARKER_CODE, s.NO_MARKERS, s.ORIGINAL_NO_MARKERS
                                FROM[dbo].[US_SNPORDER_DETAILS] d
                                INNER JOIN[dbo].[US_SNPORDERS] s ON d.US_SNPORDER_ID = s.US_SNPORDER_ID";

            var dataRows = DataReaderUtilities.GetData(DBReference.ConnStr_STG, sqlCommand).Tables[0].Rows.Cast<DataRow>().ToList();
            var snpOrderDB = dataRows.GroupBy(r => r["US_SNPORDER_ID"].ToString(), r => new Marker { SNPIndex = r["US_SNP_INDEX"].ToString()
                                                                                                        , MarkerCode = r["MARKER_CODE"].ToString()
                                                                                                        , NoMarkers = int.Parse(r["NO_MARKERS"].ToString())
                                                                                                        , OriginalNoMarkers = int.Parse(r["ORIGINAL_NO_MARKERS"].ToString())});

            IDictionary<string, HashSet<Marker>> snpOrders = new Dictionary<string, HashSet<Marker>>(); // snp id : marker code
            foreach (IGrouping<string, Marker> snpOrder in snpOrderDB)
            {
                snpOrders.Add(snpOrder.Key, new HashSet<Marker>(snpOrder.ToList()));
            }

            return snpOrders;
        }
    }
}
