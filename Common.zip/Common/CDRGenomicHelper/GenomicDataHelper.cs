﻿using System.IO;
using DataReaderUtilsLib;
using SQLUtilsLib;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Data.SqlClient;

namespace CDRGenomicHelper
{
    public static class GenomicDataHelper
    {
        /// <summary>
        /// Build workflow name, get by workflow detail in DV
        /// </summary>
        /// <param name="wPID"></param>
        /// <returns></returns>
        public static string BuildWorkFlowName(long wPID)
        {
            string sqlCommand = string.Format(@"SELECT wOperations.[WORKFLOW_ID] 
                                                FROM [dbo].[WorkflowOperations] wOperations
                                                WHERE wOperations.[WPID] = {0}", wPID);
            string workflowID = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, sqlCommand)?.ToString() ?? string.Empty;

            string sqlCommandDV = string.Format(@"SELECT [BK_WORKFLOW_NAME] 
                                                    FROM [dbo].[WORKFLOW_DETAIL]
                                                    WHERE [PK_WORKFLOW_ID] = '{0}'", workflowID);
            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV, sqlCommandDV);

            var workflowName = value?.ToString() ?? string.Empty;

            // remove white space for workflow name
            foreach (char c in Path.GetInvalidFileNameChars())
            {
                workflowName = workflowName.Replace(c, '_');
            }

            workflowName = workflowName.Replace(' ', '_');
            return workflowName;
        }

        public static string ConvertDateTimeToString(DateTime dateTime)
        {
            return dateTime.ToString("yyyyMMddHHmmssfff");
        }

        /// <summary>
        /// Insert files with default status Incompleted 
        /// </summary>
        /// <param name="wPID"></param>
        /// <param name="filePath"></param>
        /// <param name="fileName"></param>
        /// <param name="type"></param>
        public static long InsertWorkflowFile(long wPID, string filePath, string fileName, string type)
        {
 
            string sqlCommand = string.Format(@" INSERT INTO [dbo].[WorkflowFiles]
                                                        ( [F_FILEPATH]
                                                          ,[F_NAME]
                                                          ,[F_TYPE]
                                                          ,[F_STATUS]
                                                          ,[F_CREATED_TIME]
                                                          ,[WPID]
                                                        )
                                                 VALUES ( '{0}'
                                                          ,'{1}'
                                                          ,'{2}'
                                                          ,'{3}'
                                                          ,GETDATE()
                                                          ,{4}
                                                        )
                                               SELECT @@IDENTITY", filePath, fileName, type, WorkflowLogConstant.STATUS_COMPLETED, wPID);

            var wfFileID = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, sqlCommand);
            return Convert.ToInt64(wfFileID);
        }

        /// <summary>
        /// Update status for Workflow files
        /// </summary>
        /// <param name="wPID"></param>
        /// <param name="status">WorkflowLogConstant.STATUS_OK, WorkflowLogConstant.STATUS_INCOMPLELED</param>
        public static void UpdateStatusWorkflow(long wPID, string status)
        {
            string sqlCommand = string.Format(@"UPDATE [dbo].[WorkflowFiles]
                                                SET [F_STATUS] = '{0}'
                                                WHERE [WPID] = {1}", status, wPID);

            DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, sqlCommand);
        }

        /// <summary>
        /// Get transformation name
        /// </summary>
        /// <param name="PID"></param>
        /// <returns></returns>
        public static string GetTransformationName(long PID)
        {
            string sqlCommand = string.Format(@"SELECT [Transform_Name] FROM [dbo].[vOperations] WHERE [PID] = {0}", PID);
            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_SSISDB, sqlCommand);
            return value?.ToString() ?? string.Empty;
        }

        /// <summary>
        /// Build location to store log files/ error files...
        /// </summary>
        /// <param name="baseFolder"></param>
        /// <param name="folder"></param>
        /// <returns></returns>
        public static string BuildLocationForFile(string baseFolder, string folder)
        {
            string path = string.Format(@"{0}\{1}", baseFolder, folder);
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            return path;
        }

        /// <summary>
        /// Get constant value in table [SSISDB].[Constants] base on constantName
        /// </summary>
        /// <param name="constantName"></param>
        /// <returns></returns>
        public static string GetConstantValue(string constantName)
        {
            string sqlCommand = string.Format(@"SELECT [Value], [StringValue], [DateValue], [Type]
                                                FROM Constants
                                                WHERE Name = '{0}'", constantName);

            DataRow row = DataReaderUtilities.GetRowValue(DBReference.ConnStr_SSISDB, sqlCommand);
            string constantValue = null;

            if(row != null)
            {
                switch (row["Type"].ToString())
                {
                    case "String":
                        constantValue = row["StringValue"] != null? row["StringValue"].ToString() : null;
                        break;
                    case "Datetime":
                        constantValue = row["DateValue"] != null ? row["DateValue"].ToString() : null;
                        break;
                    default: // default is numeric
                        constantValue = row["Value"] != null ? row["Value"].ToString() : null;
                        break;

                }
            }

            return constantValue;
        }

        /// <summary>
        /// Get markers for pds service of mask panel code with markers belong chromo_no smaller 30
        /// </summary>
        /// <param name="maskPanel"></param>
        /// <returns></returns>
        public static List<int> GetMarkerListForPds(string maskPanel)
        {
            string sqlCommand = string.Format(@"SELECT DISTINCT hGmarkers.[BK_MARKER_ID]
                                                FROM [dbo].[HUB_MASKS] hMasks
                                                JOIN [dbo].[LNK_MARKER_MASKS] lMMasks ON lMMasks.[PK_MASK_ID] = hMasks.[PK_MASK_ID]
                                                JOIN [dbo].[SAT_MASKS] sMasks ON sMasks.PK_MASK_ID = hMasks.PK_MASK_ID AND sMasks.MD_LOADEND_TS IS NULL
                                                JOIN [dbo].[HUB_GMARKERS] hGmarkers ON hGmarkers.[PK_GMARKER_ID] = lMMasks.[PK_GMARKER_ID]
                                                JOIN [dbo].[LNK_GCHIP_GMARKERS] lCMarkers ON lCMarkers.[PK_GMARKER_ID] = hGMarkers.[PK_GMARKER_ID]
                                                JOIN [dbo].[SAT_GCHIP_GMARKERS] sCMarkers ON sCMarkers.[PK_GCHIP_GMARKER_ID] = lCMarkers.[PK_GCHIP_GMARKER_ID] 
										                                                  AND sCMarkers.[CHROMO_NO] < 30
										                                                  AND sCMarkers.[MD_LOADEND_TS] IS NULL
                                                JOIN [dbo].[SAT_GCHIPS] sChips ON sChips.[BUILD_NO] = sMasks.[BUILD_NO] AND sChips.[PK_GCHIP_ID] = lCMarkers.[PK_GCHIP_ID] AND sChips.[MD_LOADEND_TS] IS NULL
                                                WHERE hMasks.[BK_MASK_ID] = '{0}'", maskPanel);

            return DataReaderUtilities.GetData(DBReference.ConnStr_DV, sqlCommand).Tables[0].AsEnumerable().Select(x => int.Parse(x["BK_MARKER_ID"].ToString())).ToList();
        }

        /// <summary>
        /// Get number of pois for each chips in Database
        /// </summary>
        /// <returns></returns>
        public static Dictionary<string, int> GetNumberOfPoisForChips()
        {
            string sqlCommand = string.Format(@"SELECT  hGchips.[PK_GCHIP_ID], COUNT(1) AS NUMBER_OF_POIS
                                                FROM [dbo].[HUB_GCHIPS] hGchips
                                                INNER JOIN [dbo].[LNK_GCHIP_GMARKERS] lGGmarkers ON lGGmarkers.[PK_GCHIP_ID] = hGchips.[PK_GCHIP_ID]
                                                GROUP BY hGchips.[PK_GCHIP_ID]");

            DataTable table = DataReaderUtilities.GetData(DBReference.ConnStr_DV, sqlCommand).Tables[0];
            Dictionary<string, int> numPoisOfChips = new Dictionary<string, int>();

            if (table != null)
            {
                foreach (DataRow row in table.Rows)
                {
                    numPoisOfChips.Add(row["PK_GCHIP_ID"].ToString(), int.Parse(row["NUMBER_OF_POIS"].ToString()));
                }
            }

            return numPoisOfChips;
        }

        public static IEnumerable<string> ExtractLogByLogCode(DataTable logDataTable, string logCode)
        {
            var dataMessages = logDataTable.Rows.Cast<DataRow>().Where(row => row["LOG_CODE"].ToString().Equals(logCode)).Select(_ => _["DATA"].ToString());

            return dataMessages;
        }

        public static IDictionary<string, List<string>> ExtractLogByLogCodeAndGroupBy(DataTable logDataTable, string logCode, string groupByCol)
        {
            var data = logDataTable.Rows.Cast<DataRow>().Where(row => row["LOG_CODE"].ToString().Equals(logCode))
                                                            .GroupBy(r => r[groupByCol].ToString(), r => r["DATA"].ToString(), (key, group) => new { KEY = key, DATA_LIST = group.ToList() })
                                                            .ToDictionary(_ => _.KEY, _ => _.DATA_LIST);

            return data;
        }

        /// <summary>
        /// Update DQI required status to 0 in sat_gsample_dqis for samples input base on store procedure name input
        /// </summary>
        /// <param name="sampleList"></param>
        /// <param name="PID"></param>
        public static void UpdateDQIStatusForSamples(Queue<string> sampleList, string PID, string storeProcedureName)
        {
            if (sampleList.Count == 0)
                return;

            DataTable sampleTable = new DataTable();
            sampleTable.Columns.Add("PK_SAMPLE_ID", typeof(string));

            double maxSampleCount = 0;
            while (sampleList.Count > 0)
            {
                maxSampleCount = sampleList.Count < GSEnvironmentSetting.MAX_BUFFER_DATA_TABLE ? sampleList.Count : GSEnvironmentSetting.MAX_BUFFER_DATA_TABLE;

                // Add sample id to sampleTable from sampleList
                while (maxSampleCount > 0)
                {
                    DataRow row = sampleTable.NewRow();
                    row["PK_SAMPLE_ID"] = sampleList.Dequeue();
                    sampleTable.Rows.Add(row);

                    maxSampleCount--;
                }

                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(DBReference.ConnStr_DV);
                using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                {
                    connection.Open();

                    // Configure the SqlCommand and SqlParameter.
                    SqlCommand insertCommand = new SqlCommand(storeProcedureName, connection);
                    insertCommand.CommandType = CommandType.StoredProcedure;

                    SqlParameter PIDParam = insertCommand.Parameters.AddWithValue("@PID", PID);
                    PIDParam.SqlDbType = SqlDbType.VarChar;

                    SqlParameter sampleValuesParam = insertCommand.Parameters.AddWithValue("@SAMPLE_LIST", sampleTable);
                    sampleValuesParam.SqlDbType = SqlDbType.Structured;

                    //Set timeout no limit
                    insertCommand.CommandTimeout = 0;
                    // Execute the command.
                    insertCommand.ExecuteNonQuery();
                    connection.Close();
                }

                // reset variable
                sampleTable.Clear();
            }
        }
    }
}
