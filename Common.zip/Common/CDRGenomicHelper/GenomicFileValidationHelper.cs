﻿using GenomicPackageBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CDRGenomicHelper
{
    public class GenomicFileValidationHelper
    {
        public static bool ValidateFileHeaderAndFooter(string text, string compareText, bool isApplyCleanFile = true)
        {
            if (isApplyCleanFile)
                return text.ToUpper().Equals(compareText.ToUpper());
            else
                return text.Trim().ToUpper().Equals(compareText.ToUpper());
        }

        public static bool ValidateSummaryRow(string text, string textAtFirstColumn, out string value, string delimiter = GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER)
        {
            var values = Regex.Split(text, delimiter);
            if (values.Count() != 2)
            {
                value = string.Empty;
                return false;
            }
            value = values[1];
            return values[0].ToUpper().Equals(textAtFirstColumn.ToUpper());
        }

        public static bool ValidateSummaryRow(string text, string textAtFirstColumn, int lineNumberOfText, out string value, out string logError, string delimiter = GSEnvironmentSetting.DEFAULT_IMPORT_FILE_DELIMITER)
        {
            var values = Regex.Split(text, delimiter);
            if (values.Count() != 2 || !values[0].ToUpper().Equals(textAtFirstColumn.ToUpper()))
            {
                logError = string.Format(GenomicMessage.ERR_MSG_GS_LND_GSP_CHIP_INVALID_HEADERS, lineNumberOfText, textAtFirstColumn, values[0]);
                value = string.Empty;
                return false;
            }

            value = values[1];
            logError = string.Empty;

            return true;
        }
    }
}
