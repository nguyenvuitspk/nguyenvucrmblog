﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace CDRGenomicHelper
{
    public class WorkflowLogConstant
    {
        public const string DONE_EVERYTHING = "Done everything";
        public const string STATUS_OK = "OK";
        public const string STATUS_INCOMPLELED = "INCOMPLETED";
        public const string STATUS_COMPLETED = "COMPLETED";
        public const string COMPLETE_FOLDER = "complete";
        public const string LOG_TYPE = "LOG";
        public const string ERROR_TYPE = "ERROR";
        public const string REPORT_TYPE = "REPORT";
        public const string OUTPUT_TYPE = "OUTPUT";
        public const string EXPORT_TYPE = "EXPORT";
        public const string SERVICE_REQUEST_TYPE_PDS = "PDS";
        public const string SERVICE_REQUEST_TYPE_HAP = "HAP";
        public const string SERVICE_REQUEST_TYPE_BP = "BP";
        public const string WEB_DIRECTORY_BIN = "WEB_DIRECTORY_BIN";
        public const string ETL_DIRECTORY_BIN = "ETL_DIRECTORY_BIN";
        public const string LOG_DIRECTORY = @"system\log";
        public const string REPORT_DIRECTORY = @"system\report";
        public const string FILE_LOG_FRIENDLY_NAME = "Log";
        public const string FILE_ERROR_FRIENDLY_NAME = "Error";
        public const string FILE_EXPORT_SERVICE_REQUEST_FORMAT = "report_{0}.{1}.{2}.csv";
        public const string FILE_EXPORT_ABVG_SERVICE_REQUEST_NEW_FORMAT_LOG = "abvg_service_request_new_format_log.{0}.txt";
        public const string FILE_EXPORT_SAMPLE_COMPARE_FORMAT = "report_sample_comparision.{0}.csv";
        public const string FILE_EXPORT_GENOTYPE_LOAD_FORMAT = "genotype_loading_summary_{0}.txt";
        public const string FILE_EXPORT_GENOTYPE_LOAD_DATE_FORMAT = "yyyyMMdd";
        public const string FILE_EXPORT_GENOTYPE_LOAD_SUMMARY_FORMAT = "genotype_loading_summary_{0}_{1}.csv";
        public const string DATE_FORMAT_GENOTYPE_LOAD_SUMMARY = "yyyy-MM-dd";
        public const string FILE_EXPORT_GGG_FORMAT = "export_multiple_{0}.{1}.ggg";
        public const string PREFIX_FILE_EXPORT_DNA_OR_MAP_FORMAT = "export_multiple_sample_{0}.{1}";
        public const string IMAGE_FILE_REPORT_FORMAT = "report_{0}.{1}.{2}.{3}"; // report_{service_type}.{category_chart_type}.{WPID}.{image_format}
        public const string FILE_NAME_SAMPLE_CANNOT_BE_LINKED = "nomination_sample_cannot_be_linked.{0}.txt";
        public const string FILE_NAME_NOMINATION_SUCCESSFUL = "nomination_successful.{0}.txt";
        public const string FILE_NAME_NOMINATION_FAILED = "nomination_failed.{0}.txt";
        public const string FILE_NAME_NOMINATION_VALIDATION = "nomination_validation.{0}.txt";
        public const string FILE_NAME_SYSTEM_LOG = "{0}_{1}.syslog";
        public const string SYSTEM_LOG_TYPE = "SYSTEM_LOG";
        public const string SERVICE_REQUEST_MANUAL_PDS_TYPE = "MANUAL PDS";
        public const string SERVICE_ROUNTINE_GENOTYPE_QA_TYPE = "rountine_genotype_qa";
        public const string CHIP_TYPE = "CHIP";
        public const string PANEL_TYPE = "PANEL";
        public const string MAF_CHART_TYPE = "maf";
        public const string HW_CHART_TYPE = "hw";
        public const string TRANSFORMATION_STATUS_START = "Start";
        public const string TRANSFORMATION_STATUS_END = "End";
        public const string FILE_REPORT_ANIMAL_HISTORY = "report_animal_{0}.{1}.txt";
        public const string FILE_REPORT_SAMPLE_HISTORY = "report_sample_{0}.{1}.csv";
        public const string FILE_REPORT_PARENTAGE_DISCOVERY_DIF_565_FORMAT = "report_pds_discovery_{0}_{1}.565";
        public const string FILE_REPORT_PARENTAGE_DISCOVERY_CSV_565_FORMAT = "report_pds_discovery_{0}_{1}.csv";
    }

    public class GSEnvironmentSetting
    {
        public const int NUM_THREAD_PDS_DISCOVERY = 8;
        public const int NUM_THREAD_SAMPLE_HAPLOTYPE = 4;
        public const int NUM_THREAD_XCHECKING = 4;
        public const int NUM_THREAD_ROUTINE_GENOTYPE_QA = 4;
        public const int NUM_THREAD_STAT_GDNA_PANEL = 4;
        public const int NUM_THREAD_CHIP_GSP_COMMIT = 6;
        public const int RUN_ID_INITIAL_VALUE = -1;
        public const double MAX_BUFFER_DATA_TABLE = 16777215; // 2^24 -1
        public const string DEFAULT_EXPORT_FILE_DELIMITER = "\t";
        public const string DEFAULT_REPORT_FILE_DELIMITER = "\t";
        public const string DEFAULT_IMPORT_FILE_DELIMITER = "\t";
        public const string FILE_COMMA_DELIMITER = ",";
        public const string COMMA_DELIMITER = ",";
        public const string SPACE_DELIMITER = " ";
        public const string CDR_ON_DEMAND_MD_SRCSYS_CD = "EW";
        public const int BUSINESS_ERROR_CODE = 70000;
        public const string GENOTYPE_SOURCE = "Genotype";
        public const string TIMESTAMP_FORMAT = "yyyyMMddHHmmssffff";
        public const int STRING_BUILDER_LIMIT_CHARACTER = 50000000; //~100MB Memory
    }

    public class GSampleConstant
    {        
        public const string SAMPLE_STATUS_HIGH_AB = "HIGH_AB";
        public const string SAMPLE_STATUS_LOW_CR = "LOW_CR";
        public const string SAMPLE_STATUS_OK = "OK";
        public const string SAMPLE_STATUS_DISAGREES_WITH_ANIMAL_SEX = "GENOTYPE DISAGREES WITH ANIMAL SEX";
        // Add more constant belong to a sample
    }

    public class GsChartConstant
    {
        #region Routine Genotype QA
        // Title x-axis and y-axis chart
        public const string ROUTINE_GEN_QA_TITLE_X_AXIS_CHART = "Target Cohort";
        public const string ROUTINE_GEN_QA_TITLE_Y_AXIS_CHART = "Reference Cohort";

        // Size chart
        public const int ROUTINE_GEN_QA_HEIGHT_CHART = 768;
        public const int ROUTINE_GEN_QA_WIDTH_CHART = 1024;

        // Font chart
        public const string ROUTINE_GEN_QA_FONT_FAMILY_NAME = "Arial";
        public const float ROUTINE_GEN_QA_SIZE_FONT = 12;


        // Title chart
        public const string ROUTINE_GEN_QA_MAF_TITLE_CHART = "MAF COMPARISION";
        public const string ROUTINE_GEN_QA_HW_TITLE_CHART = "HW COMPARISION";
        #endregion
    }

    public class TypePanelConstant
    {
        public const string TYPE_PDS_PANEL = "PDS PANEL";
        public const string TYPE_CORE_PANEL = "CORE PANEL";
    }

    public class DataTypeExportFile
    {
        public const string EXPORT_RAW_DNA_DATA_TYPE = "Raw data";
        public const string EXPORT_IMPUTED_DATA_TYPE = "Imputed data";
        public const string EXPORT_IMPUTED_AND_RAW_DNA_DATA_TYPE = "Imputed and Raw data";
        public const string EXPORT_RAW_AB_GLOAD_DATA_TYPE = "GEN_RAW_AB";
        public const string EXPORT_RAW_NON_AB_GLOAD_DATA_TYPE = "GEN_RAW_NON_AB";
        public const string EXPORT_US_GLOAD_DATA_TYPE = "GEN_US";
        public const string EXPORT_GGG_GLOAD_DATA_TYPE = "GEN_GGG";
        public const string EXPORT_GMS_GLOAD_DATA_TYPE = "GEN_GMS";
        public const string EXPORT_GSS_GLOAD_DATA_TYPE = "GEN_GSS";
    }

    public class CDRBatchConstant
    {
        // add const string for importing process
        public const string BATCH_STATUS_NEW = "NEW";
        public const string BATCH_STATUS_INVALID = "INVALID";
        public const string BATCH_STATUS_PENDING = "PROCESSING";
        public const string BATCH_STATUS_COMMITED = "COMMITED";
    }

    public class GenomicExtension
    {
        public const string _561_FILE_EXT = "561";
        public const string _481_FILE_EXT = "481";
        public const string LOG_FILE_EXT = "log";
        public const string ZIP_FILE_EXT = "zip";
        public const string ERROR_FILE_EXT = "err";
        public const string GSP_FILE_EXT = "gsp";
        public const string TXT_FILE_EXT = "txt";
        public const string GMS_FILE_EXT = "gms";
        public const string GSS_FILE_EXT = "gss";
        public const string GGG_FILE_EXT = "ggg";
        public const string DNA_FILE_EXT = "dna";
        public const string MAP_DNA_FILE_EXT = "map";
        public const string CROSS_REFERENCE_FILE_EXT = "crossref.txt";
        public const IMG_FORMAT IMG_REPORT_FILE_EXT = IMG_FORMAT.Png;
    }

    public class GenomicMessage
    {
        #region Common
        public const string ERR_MSG_INTERNAL_EXCEPTION_ERROR = "Internal Exception Error";
        public const string ERR_MSG_SYSTEM_ERROR = "[{0}] - System Error: {1}";
        public const string ERR_MSG_STG_GOT_NO_BATCH = "Staging got no BATCH_ID";

        #endregion

        /******************************** Log message ************************** */
        #region Landing

        public const string LOG_MSG_GS_LND_LAND_SUCCESSFULLY = "File {0} landed successfully";
        public const string LOG_MSG_GS_LND_MOVE_FILE_TO_COMPLETE_FOLDER = "File {0} moved to {1}";
        public const string LOG_MSG_GS_LND_SCAN_NO_FILE_SCHEDULE = "No input file matched with this workflow found";
        public const string LOG_MSG_GS_LND_BULK_SUCCESS = "Bulk insert process is successfully!";
        public const string LOG_MSG_GS_LND_CREATE_XML_SUCCESS = "Create successfully the XML format file: {0}";
        public const string LOG_MSG_GS_LND_WARNING_NOT_FULLY_LANDED = "Warning: Not fully landed ({0} of {1} files)";
        public const string LOG_MSG_GS_LND_IGNORE_MISSING_COUPLE_GGG_GMS_GSS = "Ignore file {0} due to missing a couple of files (ggg, gms, gss)";
        public const string LOG_MSG_GS_LND_PROCESS_QA_FOR_FILE = "Process QA for file {0} \r\n===============================";
        public const string LOG_MSG_GS_LND_END_PROCESS_QA_FOR_FILE = "End process QA for file {0}";
        public const string LOG_MSG_GS_LND_IS_US_FORMAT = "File is US format";
        public const string LOG_MSG_GS_LND_IS_RAW_FORMAT = "File is Raw format";
        public const string LOG_MSG_GS_LND_PROCESSING_DATA = "Processing data …";
        public const string LOG_MSG_GS_LND_US_SNPORDER_INVALID_NO_OF_COLUMNS = "Row {0} have invalid number of columns ({1} of 5)";

        #endregion

        #region Staging

        public const string LOG_MSG_GS_STG_GTYPE_QA1_START_PROCESS = "Processing GTYPE-LOAD-QA-1 \r\n===============================";
        public const string LOG_MSG_GS_STG_GTYPE_QA1_END_PROCESS = "End Processing GTYPE-LOAD-QA-1 \r\n===============================";
        public const string LOG_MSG_GS_STG_GTYPE_QA1_START_PROCESS_FOR_FILE = "Processing GTYPE-LOAD-QA-1 for {0} \r\n===============================";
        public const string LOG_MSG_GS_STG_GTYPE_QA1_START_PROCESS_FOR_SAMPLE = "Processing QA1 for sample {0} \r\n===============================";
        public const string LOG_MSG_GS_STG_GTYPE_QA1_END_PROCESS_FOR_SAMPLE = @"End QA1 processing for sample {0}";
        public const string LOG_MSG_GS_STG_GTYPE_PROBLEM_MARKERS_NOT_EXIST_DB = "Problem markers (which is not exist in database):";
        public const string LOG_MSG_GS_STG_GTYPE_PROBLEM_MARKERS_DUPLICATED = "Problem markers (which is duplicated):";
        public const string LOG_MSG_GS_STG_GTYPE_PROBLEM_SAMPLES_GGG_FILE = "Problem samples (which is not exist in GGG file):";
        public const string LOG_MSG_GS_STG_GTYPE_PROBLEM_SAMPLES_NOT_PROVIDED_CALL_RATE_ABFREQ = "Problem samples (which wasn't provided call rate and AB frequency value):";
        public const string LOG_MSG_GS_STG_GTYPE_PROBLEM_SAMPLES_DUPLICATED  = "Problem samples (which is duplicated):";
        public const string LOG_MSG_GS_STG_GTYPE_GGG_ROWS_DIF_MULTIPLE_GMS_GSS_ROWS = @"Number of data rows in ggg ({0}) are different with the multiplication of number of markers in gms({1}) and number of samples in gss ({2}).";
        public const string LOG_MSG_GS_STG_GTYPE_PROBLEM_SAMPLES_NOT_EXIST_IN_GSS = "Problem samples (which is not exist in GSS file):";
        public const string LOG_MSG_GS_STG_GTYPE_COMPARE_CORE_GENOTYPING_PANELS = "Comparing with core genotyping panels:";
        public const string LOG_MSG_GS_STG_GTYPE_PROBLEM_MARKERS_NOT_IN_PANEL = "Problem markers(which is not in '{0}' panel)";
        public const string LOG_MSG_GS_STG_GTYPE_COMPARE_PDS_GENOTYPING_PANELS = "Comparing with PDS genotyping panels:";
        public const string LOG_MSG_GS_STG_GTYPE_FAILED_QA1 = "These files failed to pass genotype loading QA1: ";
        public const string LOG_MSG_GS_STG_GTYPE_FILE_STORED = "- {0} was stored in {1}";
        public const string LOG_MSG_GS_STG_GTYPE_START_PROCESS_INCONSISTENCY = "Processing genotype data inconsistency for {0} \r\n===============================";
        public const string LOG_MSG_GS_STG_GTYPE_START_PROCESS_INCONSISTENCY_SAMPLE = "Processing genotype data inconsistency for sample {0} \r\n===============================";
        public const string LOG_MSG_GS_STG_GTYPE_END_PROCESS_INCONSISTENCY_SAMPLE = "End Processing for sample {0}";
        public const string LOG_MSG_GS_STG_GTYPE_END_PROCESS_INCONSISTENCY = "End processing genotype data inconsistency";
        public const string LOG_MSG_GS_STG_GTYPE_FINDING_BEST_CHIP = "Finding best chip...";
        public const string LOG_MSG_GS_STG_GTYPE_CALLED_MARKERS_ON_CORE_PANEL = "Called markers on core genotyping panels:";
        public const string LOG_MSG_GS_STG_GTYPE_CALLED_MARKERS_ON_PDS_PANEL = "Called markers on PDS panels:";
        public const string LOG_MSG_GS_STG_GTYPE_SAMPLES_LOADED_AS_NEW_VERSION = "Samples would be loaded as a new version:";
        public const string LOG_MSG_GS_STG_GTYPE_SAMPLES_LOADED_NEW_VERSION_WITH_NEW_VALUE = "Samples would be loaded as a new version with new value of specification, call rate or AB frequency:";
        public const string LOG_MSG_GS_STG_GTYPE_PROBLEM_SAMPLES_DIF_CALL_RATE = "Problem samples (which have different value of call rate after re-computing):";
        public const string LOG_MSG_GS_STG_GTYPE_PROBLEM_SAMPLES_CALL_RATE_ZERO = "Problem samples (which have computed call rate equal to 0):";
        public const string LOG_MSG_GS_STG_GTYPE_PROBLEM_MARKER_DIF_ALLELE_BEST_CHIP = "Problem markers (which have non-missing calls and different with alleles of best chip):";

        // GSP 
        public const string LOG_MSG_GS_STG_CHIP_COULD_NOT_BE_LOADED = "File {0} could not be loaded";
        #endregion

        #region CDR S2D

        //CDR Mask Import files
        public const string LOG_MSG_GS_CDR_MASK_FILE_START_PROCESS = "Processing QA for <{0}> (marker mask)";
        public const string LOG_MSG_GS_CDR_MASK_FILE_START_PROCESS_PREFIX = "=============================== ";
        public const string LOG_MSG_GS_CDR_MASK_FILE_END_PROCESS = "End processing";

        //CDR Export files
        public const string LOG_MSG_GS_DV_NOM_SAMPLE_CANNOT_BE_LINKED = "Cannot link sample {0}";
        public const string LOG_MSG_GS_DV_NOM_NOMINATE_SUCCESSFULLY = "Nomination success for animal {0} - sample {1}";
        public const string LOG_MSG_GS_DV_NOM_NOMINATE_FAILED = "Nomination failed for animal {0} - sample {1}";
        public const string LOG_MSG_GS_DV_NOM_NO_SERVICE_REQUEST_FOR_NOMINATED_ANIMAL = "No service request for animal {0}";
        public const string LOG_MSG_GS_DV_NOM_NO_NOMINATION_FOR_ANIMAL = "No nomination for animal {0}";
        public const string LOG_MSG_GS_DV_NOM_MULTIPLE_HERDBOOK_MATCHED = "Multiple herdbook is matched for sample {0} - herdbook {1}";
        public const string LOG_MSG_GS_DV_PDS_REPORT_HEADER = "===============  REQUEST SERVICE: PDS ===============";
        public const string LOG_MSG_GS_DV_HAP_REPORT_HEADER = "===============  REQUEST SERVICE: HAPLOTYPE ===============";
        public const string LOG_MSG_GS_DV_BP_REPORT_HEADER = "=============== SERVICE RESULT: BREED PERCENT ===============";
        public const string LOG_MSG_GS_DV_ABVG_SERVICE_REQUEST_NF_LOG_HEADER = "=============== LOG TYPE ABVG OF SERVICE REQUEST NEW FORMAT ===============";
        public const string LOG_MSG_GS_DV_SAMPLE_COMPARISION_HEADER = "SAMPLE COMPARISION";
        public const string LOG_MSG_GS_DV_PDS_EXPORT_FILE_NAME = "PDS report.csv";
        public const string LOG_MSG_GS_DV_HAP_EXPORT_FILE_NAME = "Haplotype report.csv";
        public const string LOG_MSG_GS_DV_HAP_EXPORT_COLUMN_NAME_SUPPLIER = "Supplier";
        public const string LOG_MSG_GS_DV_HAP_EXPORT_COLUMN_NAME_NATIONALID = "National ID";
        public const string LOG_MSG_GS_DV_HAP_EXPORT_COLUMN_NAME_NAME = "Name";
        public const string LOG_MSG_GS_DV_HAP_EXPORT_COLUMN_NAME_BREED = "Breed";
        public const string LOG_MSG_GS_DV_BP_EXPORT_FILE_NAME = "Breed Percent report.csv";
        public const string LOG_MSG_GS_DV_BP_EXPORT_COLUMN_NAME_NATIONALID = "National ID";
        public const string LOG_MSG_GS_DV_BP_EXPORT_COLUMN_NAME_NAME = "Name";
        public const string LOG_MSG_GS_DV_RPT_GENOTYPE_LOAD_DELIMITER = ",";
        public const string EXPORT_MSG_GS_DV_RPT_GENOTYPE_LOAD_HEADER = "Genotype Loading Summary";
        public const string EXPORT_MSG_GS_DV_RPT_GENOTYPE_LOAD_SUMMARY_HEADER = "Genotype Loading Summary from {0} to {1}";
        public const string EXPORT_MSG_GS_DV_RPT_GENOTYPE_LOAD_DATE = "Date,{0}";
        public const string EXPORT_MSG_GS_DV_RPT_GENOTYPE_LOAD_SAMPLE_LOADED = "Sample loaded,{0}";
        public const string EXPORT_MSG_GS_DV_RPT_GENOTYPE_LOAD_SAMPLE_LAB_HEADER = "Statistics by Lab";
        public const string EXPORT_MSG_GS_DV_RPT_GENOTYPE_LOAD_SAMPLE_CHIP_HEADER = "Statistics by Chip";
        public const string EXPORT_MSG_GS_DV_RPT_GENOTYPE_LOAD_SAMPLE_STATUS_LOW_CR = "Low CR";
        public const string EXPORT_MSG_GS_DV_RPT_GENOTYPE_LOAD_SAMPLE_STATUS_HIGH_AB = "High AB";
        public const string EXPORT_MSG_GS_DV_RPT_GENOTYPE_LOAD_SAMPLE_STATUS_SEX_DISAGREE = "Sex Disagree";
        public const string EXPORT_MSG_GS_DV_RPT_GENOTYPE_LOAD_SAMPLE_FAILED_SAMPLE= "Failed sample,{0}";
        public const string LOG_MSG_GS_DV_RPT_ANIMAL_HISTORY_HEADER = "ANIMAL HISTORY";
        public const string LOG_MSG_GS_DV_RPT_SAMPLE_HISTORY_HEADER = "SAMPLE HISTORY";
        public const string EXPORT_MGS_GS_DV_PDS_MANUAL_HEADER = "REQUEST SERVICE: MANUAL PDS";

        #endregion

        /********************************* Error message ************************** */
        #region Landing

        public const string ERR_MSG_GS_LND_FILE_NOT_EXIST = "The landing file does not exist.";
        public const string ERR_MSG_GS_LND_NOT_ACCEPT_SPACE_DELIM_FOR_LOADING_STANDARD_GENOTYPE = "Loading standard genotype files (ggg, gms, gss) in batch {0} are not allow space delimiter.";
        public const string ERR_MSG_GS_LND_NOT_ACCEPT_SPACE_DELIM_FOR_LOADING_RAW_GENOTYPE = "Loading raw genotype files in batch {0} are not allow space delimiter.";
        public const string ERR_MSG_GS_LND_NO_FILE_LANDED = "Workflow didn't landing succesfully any file!";
        public const string ERR_MSG_GS_LND_EMPTY_FILE = "Landing file content is empty.";
        public const string ERR_MSG_GS_LND_BULK_FAILED = "Landing process failed: {0}";
        public const string ERR_MSG_GS_LND_BULK_FAILED_NO_PARAMETER = "Landing process failed";
        public const string ERR_MSG_GS_LND_SCAN_NO_FILE_ON_DEMAND = "No input file matched with this workflow found";
        public const string ERR_MSG_GS_LND_BULK_PROCESS_FAILED = "Bulk Insert Process failed: {0}";
        public const string ERR_MSG_GS_LND_UNKNOWN_FORMAT = "File: {0} has a unknown format";
        public const string ERR_MSG_GS_LND_NOT_FOUND_FOOTER = "Not found the line of footer";
        public const string ERR_MSG_GS_LND_NOT_GENOTYPE_FORMAT = "File is not genotype format";
        public const string ERR_MSG_GS_LND_OUTPUT_IS_EMPTY = "Workflow didn't validate succesfully any file!";
        public const string ERR_MSG_GS_LND_INPUT_FOLDER_IS_EMPTY = "Input parameter FOLDER is empty!";
        public const string ERR_MSG_GS_LND_US_SNPORDER_LINE_HAVE_NOT_TAB_DELIMITED = "Row {0} is not in tab delimited format";

        // Landing - US, Raw File
        public const string ERR_MSG_GS_LND_NUMBER_OF_COLUMN = "(US) Row {0} have invalid number of columns ({1} of 5)";
        public const string ERR_MSG_GS_LND_NUMBER_OF_CHARACTER_OF_COLUMN = "(US) Row {0} Column {1} should have {2} characters";
        public const string ERR_MSG_GS_LND_INVALID_NUMERIC_SNP = "(US) Row {0} Could not read SNP Index value due to not be a numeric value";
        public const string ERR_MSG_GS_LND_INVALID_FORMAT_ALLELE1 = "(US) Row {0} Allele 1 should be one character A, B, Z";
        public const string ERR_MSG_GS_LND_INVALID_FORMAT_ALLELE2 = "(US) Row {0} Allele 2 should be one character A, B, Z";
        public const string ERR_MSG_GS_LND_MARKER_CANT_ASSIGN_ANY_CHIP = "(US) Sample {0} with {1} markers could not be assigned to any chip";
        public const string ERR_MSG_GS_LND_FAILED_CONVERSION_US_TO_GGG = "(US) Failed conversion from US to GGG";
        public const string ERR_MSG_GS_LND_FAILED_CONVERSION_RAW_TO_GGG = "(RAW) Failed conversion from Raw to GGG";
        public const string ERR_MSG_GS_LND_FAILED_NUM_OF_US_EXPORT_FILE = "(RAW) The number of export file should be 3";
        public const string ERR_MSG_GS_INVALID_COLUMN_HEADER = "The column header at line {0} should be '{1}'";
        public const string ERR_MSG_GS_INVALID_COLUMN_HEADER_AND_VALUE = "The column header at line {0} should be '{1}' and the value should be right format";

        //GMS
        public const string ERR_MSG_GS_LND_GMS_UNKNOWN_FORMAT = "(GMS) File: {0} has a unknown format";
        public const string ERR_MSG_GS_LND_GMS_NUMBER_OF_COLUMN = "(GMS) Row {0} wrong number of columns, got {1} expected 3, got {2}. May be due to tabs";
        public const string ERR_MSG_GS_LND_GMS_NOT_FOUND_FOOTER = "(GMS) Not found the line of footer";
        public const string ERR_MSG_GS_LND_GMS_NEW_ROW_AFTER_FOOTER = "(GMS) Found {0} new row(s) after the footer";
        public const string ERR_MSG_GS_LND_GMS_INVALID_NUMERIC_NO_OF_MARKERS = "(GMS) Could not read number of Markers due to not be a numeric value";

        //GSS
        public const string ERR_MSG_GS_LND_GSS_UNKNOWN_FORMAT = "(GSS) File: {0} has a unknown format";
        public const string ERR_MSG_GS_LND_GSS_NUMBER_OF_COLUMN = "(GSS) Row {0} wrong number of columns, got {1} expected 3, got {2}. May be due to tabs";
        public const string ERR_MSG_GS_LND_GSS_NOT_FOUND_FOOTER = "(GSS) Not found the line of footer";
        public const string ERR_MSG_GS_LND_GSS_NEW_ROW_AFTER_FOOTER = "(GSS) Found {0} new row(s) after the footer";
        public const string ERR_MSG_GS_LND_GSS_INVALID_NUMERIC_NO_OF_SAMPLES = "(GSS) Could not read number of Samples due to not be a numeric value";

        //GGG
        public const string ERR_MSG_GS_LND_GGG_UNKNOWN_FORMAT = "(GGG) File: {0} has a unknown format";
        public const string ERR_MSG_GS_LND_GGG_NUMBER_OF_COLUMN = "(GGG) Row {0} wrong number of columns, got {1} expected 5, got {2}. May be due to tabs";
        public const string ERR_MSG_GS_LND_GGG_NOT_FOUND_FOOTER = "(GGG) Not found the line of footer";
        public const string ERR_MSG_GS_LND_GGG_NEW_ROW_AFTER_FOOTER = "(GGG) Found {0} new row(s) after the footer";
        public const string ERR_MSG_GS_LND_GGG_INVALID_ALLELES = "Row {0} have invalid value of alleles";
        public const string ERR_MSG_GS_LND_GGG_INVALID_NUMERIC_NO_OF_MARKERS = "(GGG) Could not read number of Markers due to not be a numeric value";
        public const string ERR_MSG_GS_LND_GGG_INVALID_NUMERIC_NO_OF_SAMPLES = "(GGG) Could not read number of Samples due to not be a numeric value";

        public const string ERR_MSG_GS_LND_GENOTYPE_HEADERS_UNKNOW_FORMAT = "({0}) Record line {1}, got {2}. May be due to tabs"; // {0} typeFle: ggg,gms,...;  {1}: line Number;  {2} text of that line
        public const string ERR_MSG_GS_LND_GENOTYPE_INVALID_HEADERS = "({0}) Row {1}: Error - row should contain \"{2}\" but instead contains \"{3}\"";

        //GSP
        public const string ERR_MSG_GS_LND_GSP_NUMBER_OF_COLUMN = "(GSP) Row {0} have invalid number of columns ({1} of 4)";
        public const string ERR_MSG_GS_LND_GSP_NEW_ROW_AFTER_FOOTER = "(GSP) Row {0}: Found new row after the footer";
        public const string ERR_MSG_GS_LND_NOT_FOUND_TAB_DELIMITER = "Row {0} is not in tab delimited format";
        public const string ERR_MSG_GS_LND_INVALID_CHROMOSOME = "Row {0}: Chromosome value has invalid format";
        public const string ERR_MSG_GS_LND_INVALID_NUMERIC_POSN = "Row {0}: Position value is invalid, numeric value required";
        public const string ERR_MSG_GS_LND_INVALID_CHARS_FLANKING_SEQUENCE = "Row {0}: Flanking sequence has invalid characters";
        public const string ERR_MSG_GS_LND_INVALID_FORMAT_FLANKING_SEQUENCE = "Row {0}: Flanking sequence has invalid format";
        public const string ERR_MSG_GS_LND_GSP_CHIP_EXISTED_IN_DB = "Error - {0} already exists in the database. File {1} cannot be loaded.";
        public const string ERR_MSG_GS_LND_GSP_INICATION_NOT_FOUND = "Indication F or Forward is not found in GSP file";
        public const string ERR_MSG_GS_LND_GSP_CHIP_CODE_NULL= "Chip code has value of NULL";
        public const string ERR_MSG_GS_LND_GSP_CHIP_INVALID_GENOME_BUILD = "The new chip provided an invalid genome build {0}. Pattern genome build is valid look like {1}";
        public const string ERR_MSG_GS_LND_GSP_CHIP_INVALID_HEADERS = "(GSP) Row {0}: Error - row should contain \"{1}\" but instead contains \"{2}\"";

        #endregion

        #region Staging

        public const string ERR_MSG_GS_STG_L2S_SR_NO_LND_RUN = "Staging got no LND_RUN_ID.";
        public const string ERR_MSG_GS_STG_NOMINATION_ANIMAL_NOT_EXISTED = "Line {0} - Not existed animal : {1}";
        public const string ERR_MSG_GS_STG_NOMINATION_MISSING_ANIMAL_ID = "Line {0} - National ID is missing.";
        public const string ERR_MSG_GS_STG_NOMINATION_MISSING_PROVIDER = "Line {0} - Provider code is missing.";
        public const string ERR_MSG_GS_STG_NOMINATION_MISSING_REQUESTER = "Line {0} - Requester code is missing.";
        public const string ERR_MSG_GS_STG_NOMINATION_MISSING_SAMPLE_FOR_COW = "Line {0} - Sample ID is missing for cow : {1}";
        public const string ERR_MSG_GS_STG_NOMINATION_DUPLICATION_NOMINATION = "Line {0} - Duplicate link : {1} - {2}";
        public const string ERR_MSG_GS_STG_NOMINATION_NOMINATE_FOR_MULTIPLE_ANIMALS = "Line {0} - Multiple animals are linked to sample : {1}";
        public const string ERR_MSG_GS_STG_GLOAD_EMPTY_MARKERS = "There're no markers in system.";

        // GSP
        public const string ERR_MSG_GS_STG_NO_CHIP_SUCCESS = "Workflow didn't staging succesfully any chips!";

        #endregion

        #region CDR S2D

        public const string ERR_MSG_GS_DV_INPUT_STG_RUN_ID_LIST_EMPTY = "Input parameter STG_RUN_ID_LIST is empty!";
        public const string ERR_MSG_GS_DV_INPUT_PK_SAMPLE_ID_EMPTY = "Input parameter PK_SAMPLE_ID is empty!";
        public const string ERR_MSG_GS_DV_INPUT_PK_ANIMAL_ID_EMPTY = "Input parameter PK_ANIMAL_ID is empty!";
        public const string ERR_MSG_GS_DV_HAP_SSIS_CONFIGURATION_MISSING = "Missing configuration for Haplotype analysis";
        public const string ERR_MSG_GS_DV_PDS_SSIS_CONFIGURATION_MISSING = "Missing configuration for PDS analysis";
        public const string ERR_MSG_GS_DV_XCHECKING_SSIS_CONFIGURATION_MISSING = "Missing configuration for X-Checking analysis";
        public const string ERR_MSG_GS_DV_PDS_SSIS_CONFIGURATION_MISSING_MIN_PDS_PANEL_OBSERVED_MARKERS = "Missing configuration GS_MIN_PDS_PANEL_OBSERVED_MARKERS for PDS analysis";
        public const string ERR_MSG_GS_DV_PDS_SSIS_CONFIGURATION_MISSING_MIN_CORE_PANEL_OBSERVED_MARKERS = "Missing configuration GS_MIN_CORE_PANEL_OBSERVED_MARKERS for PDS analysis";
        public const string ERR_MSG_GS_DV_SR_NOMINATE_NO_SERVICE_REQUEST = "No service request for nomination.";
        public const string ERR_MSG_GS_DV_PDS_MANUAL_IMPUT_EXIST_PDS_SSIS_CONFIGURATION_MISSING = "Missing configuration CORE_PANEL/PDS_PANEL for PDS analysis.";
        public const string ERR_MSG_GS_DV_PDS_MANUAL_INPUT_FILE_NOT_FOUND = "Missing input file for manual PDS analysis.";
        public const string ERR_MSG_GS_DV_PDS_MANUAL_SERVICE_REQUEST_CAN_NOT_CREATED = "Can not create service request for manual PDS";
        public const string LOG_MSG_GS_STG_BETTER_SAMPLE_FOR_MANUAL_ACTIVE_ANIMAL = "New sample (ID = {0}, Version = {1}) received for manually linked sample, no change in active status.";
        public const string LOG_MSG_GS_STG_NO_ACTIVE_SAMPLE_FOR_ANIMAL = "No samples is satisfied to be active. The active sample for that animal (ID = {0}) must be set manually";
        public const string ERR_MSG_GS_DV_SR_SERVICE_REQUEST_LIST_IS_EMPTY = "Input parameter SERVICE_REQUEST_LIST is empty!";
        public const string ERR_MSG_GS_DV_EXPORT_GENOTYPE_DNA_REDUNDANCY = "Exist sample input have more than one {0} dna";  // {0} is raw or imputed
        public const string ERR_MSG_GS_DV_EXPORT_GENOTYPE_DNA_MISSING = "Exist sample input have not {0} dna";  // {0} is raw or imputed
        public const string ERR_MSG_GS_DV_EXPORT_GENOTYPE_FILE_INPUT_NOT_CORRECT_FORMAT = "File sample input have line bigger than one when using export for format file *.dna";
        public const string ERR_MSG_GS_DV_EXPORT_GENOTYPE_FILE_INPUT_NOT_FOUND = "File sample input of workflow have not found";
        public const string ERR_MSG_GS_DV_PDS_REQUEST_STATUS_IN_COMPLETED = "PDS request status is not COMPLETED";
        public const string ERR_MSG_GS_DV_PDS_REPORT_UPDATE_FAILED_SOME_SERVICE_REQUEST = "WARNING: Some PDS service request not report yet";
        public const string ERR_MSG_GS_DV_PDS_REPORT_UPDATE_FAILED_ALL_SERVICE_REQUEST = "ERROR: All PDS service request failed report";
        public const string ERR_MSG_GS_DV_HAP_REQUEST_STATUS_IN_COMPLETED = "HAP request status is not COMPLETED";
        public const string ERR_MSG_GS_DV_HAP_REPORT_UPDATE_FAILED_SOME_SERVICE_REQUEST = "WARNING: Some HAP service request not report yet";
        public const string ERR_MSG_GS_DV_HAP_REPORT_UPDATE_FAILED_ALL_SERVICE_REQUEST = "ERROR: All HAP service request failed report";
        public const string ERR_MSG_GS_DV_BP_REQUEST_STATUS_IN_COMPLETED = "BP request status is not COMPLETED";
        public const string ERR_MSG_GS_DV_BP_REPORT_UPDATE_FAILED_SOME_SERVICE_REQUEST = "WARNING: Some BP service request not report yet";
        public const string ERR_MSG_GS_DV_BP_REPORT_UPDATE_FAILED_ALL_SERVICE_REQUEST = "ERROR: All BP service request failed report";
        public const string ERR_MSG_GS_DV_FLAT_UI_REASON_EMPTY = "REASON can not be empty";
        public const string ERR_MSG_GS_DV_FLAT_UI_STATUS_IS_INVALID = "Status is invalid";
        public const string ERR_MSG_GS_DV_SR_ALL_SR_NOT_COMPLETE_NOMINATION = "All service requests have not done nomination yet";
        public const string ERR_MSG_GS_DV_RPT_ROUNTINE_GENOTYPE_QA_FILE_NOT_FOUND = "Missing input file {0} for rountine genotype QA report!";
        public const string ERR_MSG_GS_DV_RPT_ROUNTINE_GENOTYPE_QA_INPUT_SCATTER_CHART_WRONG = "Length of target (HW/MAF) values array not match with length of reference (HW/MAF) values array";
        public const string ERR_MSG_GS_DV_RPT_ANIMAL_HISTORY = "ERROR: Report Animal History failed";
        public const string ERR_MSG_GS_DV_RPT_SAMPLE_HISTORY = "ERROR: Report Sample History failed";
        public const string ERR_MSG_GS_DV_RPT_ANIMAL_HISTORY_ANIMAL_NOT_EXISTS = "ERROR: Animal not exists in system";
        public const string ERR_MSG_GS_DV_RPT_SAMPLE_HISTORY_SAMPLE_NOT_EXISTS = "ERROR: Sample not exists in system";
        public const string ERR_MSG_GS_DV_RPT_GENOTYPE_LOAD_SUMMARY_INVALID_DATE = "DATE_FROM can not greater than DATE_TO";
        public const string ERR_MSG_GS_DV_RPT_GENOTYPE_LOAD_SUMMARY_INVALID_DATE_FORMAT = "Date time input have invalid format";
        public const string ERR_MSG_GS_CDR_INPUT_FILE_NOT_FOUND = "Not found inputted file";
        public const string ERR_MSG_GS_CDR_INPUT_FILE_EMPTY = "Inputted file is empty";
        public const string ERR_MSG_GS_CDR_INVALID_INPUT_PARAMS = "Invalid input parameters";
        public const string ERR_MSG_GS_CDR_SAMPLE_COMPARE_INVALID_SAMPLE_ID = "The sample id is invalid";
        public const string ERR_MSG_GS_CDR_SAMPLE_COMPARE_TWO_SAMPLE_ID_IS_THE_SAME = "Two sample id to compare can not be the same";
        public const string ERR_MSG_GS_CDR_SAMPLE_COMPARE_SAMPLE_NOT_EXISTS_IN_DB = "Sample does not exist in system";

        //CDR Mask Import files
        public const string ERR_MSG_GS_CDR_MASK_FOLDER_NOT_EXISTS = "Can't find inputted folder";
        public const string ERR_MSG_GS_CDR_MASK_FILE_INCORRECT_STRUCTURE = "Row {0}: {1} was not found";
        public const string ERR_MSG_GS_CDR_MASK_FILE_NOT_FOUND_FOOTER = "Row {0}: Footer line was not found";
        public const string ERR_MSG_GS_CDR_MASK_FILE_NEW_ROW_AFTER_FOOTER = "(Mask) Found {0} new row(s) after the footer";
        public const string ERR_MSG_GS_CDR_MASK_LANDING_FAILED_ALL_FILE = "Transformation did not landing successfully any file!";
        public const string ERR_MSG_GS_CDR_MASK_LANDING_EMPTY_FILE = "Transformation have not file input (*.txt, *.gsp) for landing!";
        public const string ERR_MSG_GS_CDR_MASK_LANDING_FAILED_SOME_FILE = "WARNING: Some files not landing successfully!";
        public const string ERR_MSG_GS_CDR_MASK_MASK_CODE_EXIST_IN_DATABASE = "<{0}> was found in database";
        public const string ERR_MSG_GS_CDR_MASK_MASK_BUILD_NOT_FOUND = "Genome build <{0}> could not be found";
        public const string ERR_MGS_GS_CDR_MASK_MARKER_IS_DUPLICATED_BY_ALIAS = "Row {0}: <{1}> is alias with <{2}> at row {3}";
        public const string ERR_MSG_GS_CDR_MASK_MARKER_NOT_FOUND_IN_SYSTEM = "Warning: Row {0}: <{1}> is not found in database";
        public const string ERR_MSG_GS_CDR_MASK_MARKER_IS_DUPLICATED = "Row {0}: <{1}> is duplicated with row {2}";
        public const string ERR_MSG_GS_DV_MANUAL_SWAP_INCORRECT_FILE_STRUCTURE = "File: {0} has incorrect order follow structure of manual swap file";
        public const string ERR_MSG_GS_DV_MANUAL_SWAP_EMPTY_TABLE = "Input manual swap file is empty";
        public const string ERR_MSG_GS_DV_MANUAL_ACTIVE_SAMPLES_EMPTY_TABLE = "Input manual active samples file is empty";
        public const string ERR_MSG_GS_DV_MANUAL_LINK_INCORRECT_FILE_STRUCTURE = "File: {0} has incorrect order follow structure of manual link file";
        public const string ERR_MSG_GS_DV_MANUAL_LINK_EMPTY_TABLE = "Input manual link file is empty";

        #endregion
    }

    public class GenomicCode
    {
        public const string CODE_US_SNPORDER_UNKNOWN_MARKER = "US_SNPORDER_UNKNOWN_MARKER";
        public const string CODE_US_SNPORDER_NOT_MATCHED_CHROMOSOME = "US_SNPORDER_NOT_MATCHED_CHROMOSOME";
        public const string CODE_US_SNPORDER_DUPLICATED_MARKER = "US_SNPORDER_DUPLICATED_MARKER";
        public const string CODE_US_SNPORDER_DUPLICATED_INDEX = "US_SNPORDER_DUPLICATED_INDEX";

        //Staging GLOAD - Log code
        public const string GMS_MISSING_MARKER = "GMS_MISSING_MARKER";
        public const string GMS_DUPLICATED_MARKER = "GMS_DUPLICATED_MARKER";
        public const string GSS_MISSING_GGG_SAMPLE = "GSS_MISSING_GGG_SAMPLE";
        public const string GSS_SAMPLE_BLANK_DATA = "GSS_SAMPLE_BLANK_DATA";
        public const string GSS_DUPLICATED_SAMPLE = "GSS_DUPLICATED_SAMPLE";
        public const string GGG_MISSING_GSS_SAMPLE = "GGG_MISSING_GSS_SAMPLE";
        public const string GGG_MISSING_MARKER_CORE_PANEL = "GGG_MISSING_MARKER_CORE_PANEL";
        public const string GGG_MISSING_MARKER_PDS_PANEL = "GGG_MISSING_MARKER_PDS_PANEL";
        public const string GLOAD_GS_STG_GTYPE_GGG_ROWS_DIF_MULTIPLE_GMS_GSS_ROWS = "GLOAD_GS_STG_GTYPE_GGG_ROWS_DIF_MULTIPLE_GMS_GSS_ROWS";
        public const string GGG_DUPLICATED_MARKER_FOR_SAMPLE = "GGG_DUPLICATED_MARKER_FOR_SAMPLE";
        public const string GGG_NOT_ENOUGH_PERCENT_MARKER_ON_CORE_PANEL = "GGG_NOT_ENOUGH_PERCENT_MARKER_ON_CORE_PANEL";
        public const string GGG_NOT_ENOUGH_OBSERVED_MARKER_ON_PDS_PANEL = "GGG_NOT_ENOUGH_OBSERVED_MARKER_ON_PDS_PANEL";
        public const string GGG_NOT_ENOUGH_OBSERVED_MARKER_ON_CORE_PANEL = "GGG_NOT_ENOUGH_OBSERVED_MARKER_ON_CORE_PANEL";
        public const string GGG_OVERLAP_MARKER_AND_CHIP = "GGG_OVERLAP_MARKER_AND_CHIP";
        public const string GGG_FIND_BEST_CHIP_AUTOMATICALLY = "GGG_FIND_BEST_CHIP_AUTOMATICALLY";
        public const string GGG_ACTIVE_BEST_CHIP = "GGG_ACTIVE_BEST_CHIP";
        public const string GGG_TOO_MUCH_REMOVED_MARKER = "GGG_TOO_MUCH_REMOVED_MARKER";
        public const string GGG_NOT_FOUND_PERFECT_CHIP = "GGG_NOT_FOUND_PERFECT_CHIP";
        public const string GGG_CALLED_MARKER_ON_CORE_PANEL_STATISTIC = "GGG_CALLED_MARKER_ON_CORE_PANEL_STATISTIC";
        public const string GGG_CALLED_MARKER_ON_PDS_PANEL_STATISTIC = "GGG_CALLED_MARKER_ON_PDS_PANEL_STATISTIC";
        public const string GGG_ERROR_CALLED_RATE_MARKER = "GGG_ERROR_CALLED_RATE_MARKER";
        public const string GGG_NEW_SAMPLE_VERSION = "GGG_NEW_SAMPLE_VERSION";
        public const string GGG_NEW_SAMPLE_VERSION_WITH_UPDATED = "GGG_NEW_SAMPLE_VERSION_WITH_UPDATED";
        public const string GGG_SAMPLE_WITH_DIFFERENT_CALL_RATE = "GGG_SAMPLE_WITH_DIFFERENT_CALL_RATE";
        public const string GGG_SAMPLE_WITH_MISSING_CALL_RATE = "GGG_SAMPLE_WITH_MISSING_CALL_RATE";
        public const string GGG_PROBLEM_MARKER_IN_SAMPLE = "GGG_PROBLEM_MARKER_IN_SAMPLE";
        public const string GGG_SAMPLE_LOADING_SUMMARY = "GGG_SAMPLE_LOADING_SUMMARY";
        public const string GGG_LOADING_SUMMARY = "GGG_LOADING_SUMMARY";
    }

    public class GenomicColumnGroup
    {
        public const string COLUMN_NAME_PANEL_ID = "PANEL_ID";
        public const string COLUMN_NAME_SAMPLE_ID = "SAMPLE_ID";
        public const string COLUMN_NAME_ITEM_PROCESSED = "ITEM_PROCESSED";
    }

    public enum LND_RUN_STATUS
    {
        LANDED_SUCCESS = 0,
        STAGED_SUCCESS = 1,
        STAGED_WARNING = 2,
        LANDED_FAILED = -1
    }

    public enum RETURN_CODE
    {
        SUCCESS = 1,
        ERROR = -1
    }

    public enum IMG_FORMAT
    {
        Jpeg = 0,
        Png = 1,
        Bmp = 2,

    }

    public class CDRImportFileHeaderConstant
    {
        // GMS
        public const string GMS_HEADER_FOOTER = "GEN MARKER SUMMARY FILE";
        public const string GMS_IMPORT_NAME = "Import Name";
        public const string GMS_NO_MARKERS = "No Markers";
        public const string GMS_FILE_DATE = "File Date";
        public static readonly List<List<string>> GMS_DATA_HEADER = new List<List<string>> {
            new List<string> { "Marker_Name", "Marker Name" },
            new List<string> { "Call_Freq", "Call-Freq" },
            new List<string> { "Gentrain_Score", "GC_Score" }
        };

        public static readonly List<int> GMS_NO_OF_DATA_COLUMN_REQUIRED = new List<int> { 1, 2, 3 };
        public const int GMS_HEADER_SUMMARY_FIRST_ROW = 2;
        public const int GMS_HEADER_SUMMARY_LAST_ROW = 4;

        // GSS
        public const string GSS_HEADER_FOOTER = "GEN SAMPLE SUMMARY FILE";
        public const string GSS_IMPORT_NAME = "Import Name";
        public const string GSS_NO_SAMPLES = "No Samples";
        public const string GSS_FILE_DATE = "File Date";
        public static readonly List<string> GSS_DATA_HEADER = new List<string> { "Sample_name", "Call_Rate", @"A/B_Freq" };
        public static readonly List<int> GSS_NO_OF_DATA_COLUMN_REQUIRED = new List<int> { 1, 2, 3 };
        public const int GSS_HEADER_SUMMARY_FIRST_ROW = 2;
        public const int GSS_HEADER_SUMMARY_LAST_ROW = 4;

        // GGG
        public const string GGG_HEADER_FOOTER = "GEN DNA RESULTS FILE";
        public const string GGG_IMPORT_NAME = "Import Name";
        public const string GGG_NO_MARKERS = "No Markers";
        public const string GGG_NO_SAMPLES = "No Samples";
        public const string GGG_FILE_DATE = "File Date";
        public static readonly List<string> GGG_DATA_HEADER = new List<string> { "SNP_Name", "Sample_ID", "Allele_1", "Allele_2", "GC_Score" };
        public static readonly List<string> GGG_IMPUTED_DATA_HEADER = new List<string> { "SNP_Name", "Sample_ID", "Allele_1", "Allele_2", "Imputed" };
        public static readonly List<int> GGG_NO_OF_DATA_COLUMN_REQUIRED = new List<int> { 2, 3, 4, 5 };
        public const int GGG_HEADER_SUMMARY_FIRST_ROW = 2;
        public const int GGG_HEADER_SUMMARY_LAST_ROW = 5;
        public static readonly List<string> GGG_ALLELE_VALUE_SET = new List<string> { "C", "G", "A", "T", "B", "Z", "-", "NULL" };
        public const string GGG_DEFAULT_GC_CORE = "1";
        public const string GGG_DEFAULT_ALLELE = "-";

        // GSP
        public const string GSP_READ_SEQ = "Read sequence";
        public static readonly List<string> GSP_READ_SEQ_VALUES = new List<string> { "F", "Forward" };
        public const int GSP_HEADER_SUMMARY_FIRST_ROW = 2;
        public const int GSP_HEADER_SUMMARY_LAST_ROW = 5;
        public const string GSP_HEADER_FOOTER = "GEN MARKER SPECIFICATION FILE";
        public const string GSP_CHIP_CODE = "Chip Code";
        public const string GSP_CHIP_DESCRIPTION = "Chip Description";
        public const string GSP_GENOME_BUILD = "Genome Build";
        public const string GSP_PATTERN_GENOME_BUILD = "^bos taurus 3.*";
        public static readonly List<string> GSP_DATA_HEADER = new List<string> { "Marker ID", "Chr", "Posn", "Sequence" };
        public const int GSP_NO_OF_DATA_COLUMN_REQUIRED = 4;
        public static readonly List<string> CHROMOSOME_VALUE_SET = new List<string> { "X", "Y", "MT", "" };
        public const int CHROMOSOME_VALUE_SET_INT_MIN = 1;
        public const int CHROMOSOME_VALUE_SET_INT_MAX = 29;
        public static readonly char[] SEQUENCE_VALUE_SET = { 'A', 'C', 'G', 'T', '[', ']', '/', 'M', 'R', 'W', 'S', 'Y', 'K', 'N' };
        public const int SEQUENCE_LENGTH = 125;
        public const int OPEN_SQUARE_BRACKET = 60;
        public const int SLASH = 62;
        public const int CLOSE_SQUARE_BRACKET = 64;

        // Raw
        public const string RAW_ALLELE_TYPE = "type";
        public const string RAW_SNP_NAME_IDX = "snpNameIdx";
        public const string RAW_SAMPLE_ID_IDX = "sampleIdIdx";
        public const string RAW_ALLELE_1 = "allele1Idx";
        public const string RAW_ALLELE_2 = "allele2Idx";
        public const string RAW_AB_FORMAT = "AB";
        public const string RAW_GTAC_FORMAT = "GTAC";
        public const string RAW_FILE_HEADER = "[Header]";
        public const string RAW_FILE_DATA_HEADER = "[Data]";
        public const string RAW_FILE_GSGT_VERSION = "GSGT Version";
        public const string RAW_FILE_PROCESSING_DATE = "Processing Date";
        public const string RAW_FILE_CONTENT = "Content";
        public const string RAW_FILE_NUM_SNP = "Num SNPs";
        public const string RAW_FILE_TOTAL_SNP = "Total SNPs";
        public const string RAW_FILE_NUM_SAMPLE = "Num Samples";
        public const string RAW_FILE_TOTAL_SAMPLE = "Total Samples";        

        // US
        public const int US_NO_OF_DATA_COLUMN_REQUIRED = 5;
        public const int US_NO_OF_CHAR_DATANAME_COLUMN_REQUIRED = 9;
        public const string US_DATANAME_COLUMN_NAME = "Data Name";
        public const int US_NO_OF_CHAR_SAMPLE_COLUMN_REQUIRED = 19;
        public const string US_SAMPLE_COLUMN_NAME = "Sample";
        public static readonly char[] US_RIGHT_FORMAT = { 'A', 'B', 'Z' };
        public const string US_AB_FORMAT = "AB";
        public const string US_GTAC_FORMAT = "GTAC";

        // Marker mask
        public const string MARKER_MASK_HEADER_FOOTER = "Gen Marker Mask Specification File";
        public const string MASK_MARKER_ID = "Marker ID";
    }

    public class GsEventLogConstant
    {
        // Type
        public const string LOG_EXCEPTION_TYPE = "EXCEPTION";
        public const string LOG_MANUAL_ACTION_TYPE = "MANUAL_ACTION";

        // Activity
        public const string LOG_ACTIVITY_DELETE_SAMPLE = "DELETE_SAMPLE";
        public const string LOG_ACTIVITY_SAMPLE_ACTIVE = "SAMPLE_ACTIVE";
        public const string LOG_ACTIVITY_SERVICE_REQUEST_NF = "SERVICE_REQUEST_NF";
    }

    public class CDRConfigurationConstant
    {
        public const string CONF_PREFERED_PDS_PANEL = "GS_PDSPANEL";
        public const string CONF_PREFERED_CORE_PANEL = "GS_CORE6KPANEL";
        public const string CONF_PDS_DISCOVERY_THRESHOLD = "GS_PDS_PANEL_DISCOVERY_THRESHOLD";
        public const string CONF_PDS_MINIMUM_CMP_MARKERS = "GS_MIN_PDS_PANEL_OBSERVED_MARKERS";
        public const string CONF_FULL_DISCOVERY_THRESHOLD = "GS_FULL_PANEL_DISCOVERY_THRESHOLD";
        public const string CONF_FULL_MINIMUM_CMP_MARKERS = "GS_MIN_CORE_PANEL_OBSERVED_MARKERS";
        public const string CONF_GENO_INCONSISTENCY_THRESHOLD = "GS_GENO_INCONSISTENCY_THRESHOLD";
        public const string CONF_PARENT_OFFSPRING_AGE_DIFF_MIN = "GS_PARENT_OFFSPRING_AGE_DIFF_MIN";
        public const string CONF_MIN_DUPLICATE_CMP = "GS_MIN_DUPLICATE_CMP";
        public const string CONF_DUPLICATE_THRESHOLD = "GS_DUPLICATE_THRESHOLD";
        public const string CONF_MAX_MISSING_CALL_PERCENT = "GS_FLOAT_MAX_MISSING_CALL_PERCENT";
        public const string CONF_GS_MIN_OVERLAP_NUCLEOTIDES_FOR_ALIAS_MARKERS = "GS_MIN_OVERLAP_NUCLEOTIDES_FOR_ALIAS_MARKERS";
    }
}
