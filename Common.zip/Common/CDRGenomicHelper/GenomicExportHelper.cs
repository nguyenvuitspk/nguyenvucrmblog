using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;

namespace CDRGenomicHelper
{
    public class GenomicExportHelper
    {        
        public static void ReportServiceRequest(WorkflowFile file, string fileHeader, DataTable data)
        {
            file.Write(fileHeader);
            file.WriteRecordDate();
            file.Write(data, GSEnvironmentSetting.COMMA_DELIMITER);  // CSV file
        }
              
        public static void ReportAnimalHistory(WorkflowFile file, string header, string animalNationalID, string activeSampleName, string linkedSamples, DataTable animalHistory)
        {
            file.Write(header);
            file.Write(string.Empty);
            file.Write(string.Format("Animal ID: {0}", animalNationalID));
            file.Write(string.Empty);
            file.Write("Final Status:");
            file.Write(string.Format(" - Active sample: {0}", activeSampleName));
            file.Write(string.Format(" - Linked samples: {0}", linkedSamples));
            file.Write(string.Empty);
            file.Write(animalHistory, GSEnvironmentSetting.DEFAULT_REPORT_FILE_DELIMITER);
        }

        public static void ReportSampleHistory(WorkflowFile file, string header, string sampleName, bool isActiveSample, string animalNationalID, string sampleStatus, DataTable sampleHistory)
        {
            file.Write(header);
            file.Write(string.Empty);
            file.Write(string.Format("Sample ID: {0}", sampleName));
            file.Write(string.Empty);
            file.Write("Final Status:");
            file.Write(string.Format(" - Active: {0}", isActiveSample ? "Active" : "Non-active"));
            file.Write(string.Format(" - Link: {0}", animalNationalID));
            file.Write(string.Format(" - Status: {0}", sampleStatus));
            file.Write(string.Empty);
            file.Write(sampleHistory, GSEnvironmentSetting.COMMA_DELIMITER);
        }
    }
}
