﻿using NetworkShareHelper;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace CDRGenomicHelper
{
    public class WorkflowFile
    {
        private string F_FilePath;
        public string FilePath {
            get
            {
                return F_FilePath;
            }
        }
        private string F_Type;
        private long wPID;
        private long id;
        public long ID
        {
            get
            {
                return id;
            }
        }

        /// <summary>
        /// Create a file belongs to Workflow
        /// </summary>
        /// <param name="_WPID"></param>
        /// <param name="fileName"></param>
        /// <param name="type">LOG, REPORT, EXPORT</param>
        public WorkflowFile(long _WPID, string fileName, string type)
        {
            wPID = _WPID;            
            F_Type = type;

            var networkAccess = new GNetworkAccess(WorkflowLogConstant.WEB_DIRECTORY_BIN);

            using (new NetworkConnection(networkAccess.RootFolder, new NetworkCredential(networkAccess.Username, networkAccess.Password)))
            {
                string folderPath = GenomicDataHelper.BuildLocationForFile(networkAccess.RootFolder, WorkflowLogConstant.LOG_DIRECTORY);
                F_FilePath = Path.Combine(folderPath, fileName);

                // create log file and error file if not exist
                if (!File.Exists(F_FilePath))
                {
                    File.Create(F_FilePath).Close();
                    // Insert log file into db
                    id = GenomicDataHelper.InsertWorkflowFile(wPID, F_FilePath, F_Type, F_Type);
                }
            }
        }

        /// <summary>
        /// Create a file belongs to Workflow and override it if already exists
        /// </summary>
        /// <param name="_WPID"></param>
        /// <param name="fileName"></param>
        /// <param name="type">LOG, REPORT, EXPORT</param>
        /// <param name="fileLocation">Location where store file. Format: WEB_DIRECTORY_BIN:\\fileLocation</param>
        /// <param name="overrideIfFileExists">If "true" then delete file if it already exists</param>
        public WorkflowFile(long _WPID, string fileName, string type, string fileLocation, bool overrideIfFileExists)
        {
            wPID = _WPID;
            F_Type = type;

            var networkAccess = new GNetworkAccess(WorkflowLogConstant.WEB_DIRECTORY_BIN);

            using (new NetworkConnection(networkAccess.RootFolder, new NetworkCredential(networkAccess.Username, networkAccess.Password)))
            {
                string folderPath = GenomicDataHelper.BuildLocationForFile(networkAccess.RootFolder, fileLocation);
                F_FilePath = Path.Combine(folderPath, fileName);

                // Delete file if it exists
                if (File.Exists(F_FilePath) && overrideIfFileExists == true)
                {
                    File.Delete(F_FilePath);
                }

                // create log file and error file if not exist
                if (!File.Exists(F_FilePath))
                {
                    File.Create(F_FilePath).Close();
                    // Insert log file into db
                    id = GenomicDataHelper.InsertWorkflowFile(wPID, F_FilePath, F_Type, F_Type);
                }
            }
        }

        /// <summary>
        /// Write content
        /// </summary>
        /// <param name="content"></param>
        public void Write(string content)
        {
            using (StreamWriter sw = File.AppendText(F_FilePath))
            {
                sw.WriteLine(content);
            }
        }

        /// <summary>
        /// Write content with defined format (CSV, TABLE, ...)
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="delimiter">Default: "\t", CSV: ","</param>
        /// <param name="isWriteTableHeader">Default: true</param>
        public void Write(DataTable dt, string delimiter = GSEnvironmentSetting.DEFAULT_EXPORT_FILE_DELIMITER, bool isWriteTableHeader = true)
        {
            StringBuilder sb = new StringBuilder();

            if(isWriteTableHeader)
            {
                var columnHeaders = dt.Columns.Cast<DataColumn>().Select(x => x.ColumnName);

                // write header columns
                sb.Append(string.Join(delimiter, columnHeaders));
                sb.AppendLine();
            }

            // write data rows
            foreach (DataRow dr in dt.Rows)
            {
                sb.Append(string.Join(delimiter, dr.ItemArray));
                if (sb.Length >= GSEnvironmentSetting.STRING_BUILDER_LIMIT_CHARACTER)
                {
                    Write(sb.ToString());
                    sb.Clear();
                }
                else
                {
                    sb.AppendLine();
                }
            }

            if (sb.Length > 0)
                Write(sb.ToString());
        }

        /// <summary>
        /// Write content array
        /// </summary>
        /// <param name="contents"></param>
        public void Write(IEnumerable<string> contents)
        {           
            StringBuilder sb = new StringBuilder();
            foreach (string s in contents)
            {
                sb.Append(s);

                if (sb.Length >= GSEnvironmentSetting.STRING_BUILDER_LIMIT_CHARACTER)
                {
                    Write(sb.ToString());
                    sb.Clear();
                }
                else
                {
                    sb.AppendLine();
                }
            }

            if (sb.Length > 0)
                Write(sb.ToString());
        }

        /// <summary>
        /// Write Record Date
        /// </summary>
        public void WriteRecordDate()
        {
            var date = DateTime.Now;
            Write(String.Format("Record date: {0:MM/dd/yyyy}", date));
        }

        /// <summary>
        /// Get Transformation Name from PID and write to error/log file
        /// </summary>
        /// <param name="PID"></param>
        /// <param name="status">TRANSFORMATION_STATUS_START, TRANSFORMATION_STATUS_END</param>
        public void WriteProcess(long PID, string status)
        {
            string transName = GenomicDataHelper.GetTransformationName(PID);
            string transInfo = $"--------------------- {status} - Transformation: {PID} ~ [{transName}]----------------------\n";
            Write(transInfo);
        }
    }
}
