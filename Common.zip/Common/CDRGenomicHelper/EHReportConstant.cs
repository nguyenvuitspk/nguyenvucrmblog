﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace CDRGenomicHelper
{
    public class EHReportConstant
    {
        public const string EH_REPORT_DIRECTORY = @"system\report\EH";
        public const string EH_REPORT_FILENAME_HERD_EXPORT_READINESS = @"herd_export_readiness_{0}.pdf"; // e.g. herd_export_readiness_20170814170100.pdf

        // ABV Constant
        public const string UpdatedTestPeriod = "UpdatedTestPeriod";
        public const string UpdatedDQI = "UpdatedDQI";
        public const string UpdatedFFP = "UpdatedFFP";
        public const string UpdatedHeterosis = "UpdatedHeterosis";
        public const string UpdatedMatingPattern = "UpdatedMatingPattern";
        public const string ProcessEH = "ProcessExportHeifer";
    }    
}
