﻿using System;
using DataReaderUtilsLib;
using SQLUtilsLib;
using CommonETLLibs;
using System.Data;

namespace DeliveryDV2EXPHelper
{
    public class DeliveryDV2EXPHelper
    {
        public int CreateRun()
        {
            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_EXP,
                 string.Format(@"INSERT INTO [dbo].[EXP_RUNS] DEFAULT VALUES
                                  SELECT @@IDENTITY as [RUN_ID]"));
            return Convert.ToInt32(value);
        }
        
        public int CreateRunStatus(long RUN_ID, string STATUS_CD)
        {
            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_EXP,
                 string.Format(@"INSERT INTO [dbo].[EXP_RUN_STATUS]
                                 ([EXP_RUN_ID], [STATUS_CD], [STATUS_CHANGE_TS])
                                 VALUES ({0}, '{1}', '{2}')", 
                                 RUN_ID, STATUS_CD, DateTime.Now.ToString(Constant.SqlDateTimeFortmat)));
            return Convert.ToInt32(value);
        }
        public int GetCurrentRun()
        {
            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_EXP,
                 string.Format(@"SELECT MAX(EXP_RUN_ID) EXP_RUN_ID from [dbo].[EXP_RUNS]"));
            return Convert.ToInt32(value);
        }

        public DataSet GetListSPDeliveryToRun(int transformation_level)
        {
            var value = DataReaderUtilities.GetData(DBReference.ConnStr_EXP,
                 string.Format(@"SELECT NAME AS DeliveryStoreProc 
                                FROM [dbo].sysobjects 
                                WHERE TYPE = 'P' AND NAME LIKE 'usp_Delivery_CDR_D2E_TR' + CAST({0} AS VARCHAR) + '%'
                                ORDER BY NAME", transformation_level.ToString()));
            return value;
        }        
    }
}
