﻿using SSRSReportLib;
using System.Collections.Generic;

namespace FFRReportLib
{
    public class FFRReportConstants
    {
        public const string MULTI_ANIMAL_NATIONAL_ID = "(ANIMAL_NATIONAL_ID) IN";
        public const string ANIMAL_NATIONAL_ID = "(ANIMAL_NATIONAL_ID)";
        public const string REPORT_DB_CONN = "REPORT_DB_CONN";
        public const string REPORT_SERVICE_URL = "REPORT_SERVICE_URL";
        public const string REPORT_SERVICE_USERNAME = "REPORT_SERVICE_USERNAME";
        public const string REPORT_SERVICE_PASSWORD = "REPORT_SERVICE_PASSWORD";
        public const string REPORT_DIF_TEMPLATE_PATH = "REPORT_DIF_TEMPLATE_PATH";
        public const string REPORT_PATH_FORMAT = @"{0}\{1}";
        public const string REPORT_FILE_NAME_FORMAT = @"{0}_{1}_{2}.{3}";
        public const string REPORT_TEMP_PATH_FORMAT = @"{0}\Temp\{1}_{2}_{3}.{4}.{5}";
        public const string DATETIME_FORMAT = @"yyyyMMdd_hhmmss";
        public const string REPORT_DIRECTORY_FORMAT = @"{0}\{1}.{2}";
        public const string DIF_REPORT_DIRECTORY_FORMAT = @"{0}\{1}";
        public const string REPORT_TEMP_DIRECTORY_FORMAT = @"{0}\Temp\{1}.{2}.";
        // Website
        public const string WEB_DIF_REPORT_PATH_FORMAT = @"{0}/{1}";
        public const string WEB_REPORT_PATH_FORMAT = @"{0}/{1}.{2}";
        public const string WEB_REPORT_FILENAME_FORMAT = @"{0}.{1}";
        public const string GPR_REPORT = "GPR_REPORT";
        public const string SMTP_SERVER = "SMTP_SERVER";
        public const string SMTP_PORT = "SMTP_PORT";
        public const string PUBLIC_REPORT = "PUBLIC_REPORT";
        public const string REPORT_WEB_DIRECTORY = "REPORT_WEB_DIRECTORY";
        public const string FFR_REPORT_SERVICE_URL = "FFR_REPORT_SERVICE_URL";
        public const string FFR_REPORT_SERVICE_USERNAME = "FFR_REPORT_SERVICE_USERNAME";
        public const string FFR_REPORT_SERVICE_PASSWORD = "FFR_REPORT_SERVICE_PASSWORD";
        // Report Status
        public const string REPORT_STATUS_CREATED = "CREATED";
        public const string REPORT_STATUS_PROCESSING = "PROCESSING";
        public const string REPORT_STATUS_COMPLETED = "COMPLETED";

        public static readonly Dictionary<ReportFileType, string> FILE_TYPE_EXTENSIONS = new Dictionary<ReportFileType, string>()
        {
            { ReportFileType.PDF, "pdf" },
            { ReportFileType.CSV, "csv" },
            { ReportFileType.HTML5, "html" },
            { ReportFileType.IMAGE, "png" },
            { ReportFileType.MHTML, "mthml" },
            { ReportFileType.EXCEL, "xls" },
            { ReportFileType.EXCELOPENXML, "xlsx" },
            { ReportFileType.WORD, "doc" },
            { ReportFileType.PPTX, "pptx" },
            { ReportFileType.ATOM, "atom" },
            { ReportFileType.RGDI, "rgdi" },
            { ReportFileType.DIF, "" },
            { ReportFileType.TXT, "txt" },
        };
    }
    
    public class ReportServer
    {
        public string ReportDBConnString { get; set; }
        public string FFRReportServiceURL { get; set; }
        public string FFRReportServiceUsername { get; set; }
        public string FFRReportServicePassword { get; set; }
    }
}
