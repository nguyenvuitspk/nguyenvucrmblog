﻿using DataReaderUtilsLib;
using SQLUtilsLib;
using SSRSReportLib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ABVReportLib;

namespace ABVReportLib
{
    public class NRRReport : SSRSReport
    {
        #region Properties

        public string ReportName { get; set; }
        public int SystemReportId { get; set; }
        public string Requestor { get; set; }
        public string ReportDBConnString { get; set; }
        public string FileOutputExt { get; set; }

        #endregion

        #region Constructors

        public NRRReport(string reportName) : base()
        {
            ReportServer server = ManageReports.GetReportServerInformation();
            base.ReportServiceURL = server.ReportServiceURL;
            base.ReportServiceUsername = server.ReportServiceUsername;
            base.ReportServicePassword = server.ReportServicePassword;
            ReportDBConnString = server.ReportDBConnString;

            base.ProjectName = "NRR";
            base.ReportID = reportName;

            ReportName = reportName;
            SystemReportId = ManageReports.GetSystemReportId(ReportID);
        }

        #endregion

        #region Methods

        public virtual int SubmitReport(string requestor, List<ReportParameter> parameters)
        {
            return ManageReports.SubmitReport(SystemReportId, requestor, parameters);

        }

        public virtual void GenerateReport(int rptInstanceId)
        {

        }

        public virtual string GenerateReportWithMessage(int rptInstanceId)
        {
            return "";
        }

        public void GenerateReports(int rptInstanceId, string[] fileTypes, string runNameSrc = "", string runNameComp = "")
        {
            Requestor = ManageReports.GetRequestor(rptInstanceId);
            foreach (var fType in fileTypes)
            {
                switch (fType.ToLower())
                {
                    case "pdf":
                        GetReport(rptInstanceId, ReportFileType.PDF);
                        break;
                    case "xlsx":
                        GetReport(rptInstanceId, ReportFileType.EXCELOPENXML, runNameSrc, runNameComp);
                        break;
                    case "dif":
                        GetReport(rptInstanceId, ReportFileType.DIF);
                        break;
                    case "txt":
                        GetReport(rptInstanceId, ReportFileType.TXT);
                        break;
                    default:
                        break;
                }
            }
        }

        protected string Naming(string SystemReportId)
        {
            return SystemReportId;
        }
        
        protected void GetReport(int rptInstanceId, ReportFileType fileType, string runNameSrc = "", string runNameComp = "")
        {
            string reportFullFileName = "";
            ReportParameters = ManageReports.GetReportParameters(rptInstanceId);
            DateTime reportTime = DateTime.Now;
            string reportDirectory = string.Format(@"{0}/{1}", ManageReports.GetConfiguration(ABVReportConstant.REPORT_WEB_DIRECTORY), reportTime.Ticks.ToString());
            string reportFileName = ManageReports.GetReportOutputName(SystemReportId);
            switch (SystemReportId) {
                case 68:
                    reportFullFileName = reportFileName + runNameSrc + " and " + runNameComp;
                    break;
                case 69:
                    reportFullFileName = reportFileName + runNameSrc + "_" + runNameComp;
                    break;
                case 70:
                    reportFullFileName = reportFileName + runNameSrc + "_Rel";
                    break;
                case 71:
                    reportFullFileName = reportFileName + runNameSrc + " and " + runNameComp;
                    break;
                case 72:
                    reportFullFileName = reportFileName + runNameSrc + " not in " + runNameComp;
                    break;
                case 73:
                    reportFullFileName = reportFileName + runNameSrc;
                    break;
            }


            
            string reportFileExt;
            ABVReportConstant.FILE_TYPE_EXTENSIONS.TryGetValue(fileType, out reportFileExt);

            string reportGenerateDirectory = string.Format(reportTime.Ticks.ToString());
            string reportFilePath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportGenerateDirectory, reportFullFileName, reportFileExt);
            string reportFullPath = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, reportDirectory, reportFullFileName, reportFileExt);

            List<string> subReports;
            switch (fileType)
            {
                case ReportFileType.PDF:
                    subReports = ManageReports.GetSubReports(SystemReportId, fileType);
                    Export2Pdf(ABVReportConstant.REPORT_TEMP_PATH_FORMAT, reportDirectory, rptInstanceId, reportTime, reportFileExt, fileType, subReports, reportFullPath);
                    ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFullFileName, reportFilePath, Requestor);
                    break;
                case ReportFileType.EXCELOPENXML:
                    subReports = ManageReports.GetSubReports(SystemReportId, fileType);
                    List<string> listFileWithoutMergeSheet = Export2Excel(ABVReportConstant.REPORT_TEMP_PATH_FORMAT, reportDirectory, rptInstanceId, reportTime, reportFileExt, fileType, subReports, reportFullPath, reportFileName);

                    if (listFileWithoutMergeSheet.Count > 0)
                    {
                        foreach (var fileNotMerge in listFileWithoutMergeSheet)
                        {
                            var fileName = Path.GetFileName(fileNotMerge);
                            ManageReports.SaveGeneratedRptFile(rptInstanceId, fileName, fileNotMerge, Requestor);
                        }
                    }
                    else
                        ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFullFileName, reportFilePath, Requestor);
                    break;
                case ReportFileType.DIF:
                    reportFilePath = string.Format(@"{0}/{1}", reportGenerateDirectory, reportFileName);
                    //Export2Dif(reportFullPath, fileXML, forType);
                    ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                    break;
                case ReportFileType.TXT:
                    Export2Txt(reportFullPath);
                    ManageReports.SaveGeneratedRptFile(rptInstanceId, reportFileName, reportFilePath, Requestor);
                    break;
                default:
                    break;
            }
        }

        #endregion

        #region Handle Main logic

        protected void Export2Pdf(string maskPath, string outpDirectory, int rptHistoryId, DateTime execTime, string fileExt, ReportFileType fileType, List<string> subReports, string finalOutputFile)
        {
            if (subReports.Count > 0)
            {
                int count = 0;
                List<string> allSubFiles = new List<string>();

                foreach (var subReportID in subReports)
                {
                    count++;
                    string subFile = string.Format(maskPath, outpDirectory, rptHistoryId, SystemReportId, execTime.ToString(ABVReportConstant.DATETIME_FORMAT), fileExt, count.ToString());
                    ReportID = subReportID;
                    base.GetReport(subFile, fileType);
                    allSubFiles.Add(subFile);
                }

                FileComposer.PdfMerging(allSubFiles, finalOutputFile);
                foreach (string file in allSubFiles)
                {
                    File.Delete(file);
                }
            }
            else
            {
                ReportID = ReportName + "_PDF";
                base.GetReport(finalOutputFile, fileType);
            }
        }

        protected List<string> Export2Excel(string maskPath, string outpDirectory, int rptHistoryId, DateTime execTime, string fileExt, ReportFileType fileType, List<string> subReports, string finalOutputFile, string outputName, string fileXML = "", string forType = "")
        {
            List<string> listFileWithoutMerge = new List<string>();
            if (subReports.Count > 0)
            {
                if (Array.Exists(ABVReportConstant.REPORT_WITHOUT_MERGE, elem => elem.Equals(this.ReportName)))
                {
                    foreach (var subReportID in subReports)
                    {
                        string subFile = string.Format(ABVReportConstant.REPORT_DIRECTORY_FORMAT, outpDirectory, subReportID, fileExt);
                        ReportID = subReportID;
                        base.GetReport(subFile, fileType);
                        string frName = ManageReports.GetFriendlyName(SystemReportId, subReportID);
                        string fileWithoutMerge = FileComposer.FriendlyName4SheetExcel(subFile, frName);
                        listFileWithoutMerge.Add(fileWithoutMerge);
                    }
                }
                else
                {
                    int count = 0;
                    List<string> allSubFiles = new List<string>();

                    /** Dictionary <Key, Value> subReportsWithFriendlyName    
                    ** Key: Path to Report 
                    ** Value: Report Friendly name 
                    **/
                    Dictionary<string, string> subReportsWithFriendlyName = new Dictionary<string, string>();

                    foreach (var subReportID in subReports)
                    {
                        count++;
                        string subFile = string.Format(maskPath, outpDirectory, rptHistoryId, SystemReportId, execTime.ToString(ABVReportConstant.DATETIME_FORMAT), fileExt, count.ToString());
                        ReportID = subReportID;
                        base.GetReport(subFile, fileType);
                        allSubFiles.Add(subFile);
                        subReportsWithFriendlyName.Add(subFile, ManageReports.GetFriendlyName(SystemReportId, subReportID));
                    }
                    FileComposer.ExcelSheetMerging(allSubFiles, finalOutputFile);
                    foreach (string file in allSubFiles)
                    {
                        File.Delete(file);
                    }
                }
            }
            else
            {
                if (Array.Exists(ABVReportConstant.REPORT_WITHOUT_TEMPLATE, elem => elem.Equals(this.ReportName)))
                {
                    // Export excel file with out template
                    string xmlTemplatePath = ManageReports.GetPathToTemplateFile();
                    string destFilePath = string.Format(@"{0}/{1}.xml", xmlTemplatePath, this.ReportName);
                    System.Data.DataTable rptData;

                    if (fileXML.Length > 0)
                        rptData = DataReaderUtilities.GetData(ReportDBConnString, string.Format(@"EXEC dbo.wsp_EXPORT_FILE @searchFields = '{0}', @forType = '{1}'", fileXML, forType)).Tables[0];
                    else
                        rptData = ManageReports.GetReportWithoutTemplate(ReportDBConnString, ReportParameters, ReportID);

                    if (File.Exists(destFilePath))
                    {
                        FileComposer.ExportExcelFileWithOutTemplate(rptData, finalOutputFile, outputName, new FileStream(destFilePath, FileMode.Open, FileAccess.Read));
                    }
                    else
                    {
                        FileComposer.ExportExcelFileWithOutTemplate(rptData, finalOutputFile, outputName);
                    }
                }
                else if (Array.Exists(ABVReportConstant.REPORT_CONFIG_TEMPLATE, elem => elem.Equals(this.ReportName)))
                {
                    FileComposer.ExcelConfigTemplate(finalOutputFile);
                }
                else
                {
                    base.GetReport(finalOutputFile, fileType);
                    FileComposer.SSRSExcelFormat(finalOutputFile, outputName);
                    if (ReportID == "COW_IN_HERD")
                    {
                        FileComposer.RenameSheets(finalOutputFile);
                        FileComposer.DeleteLastColumn(finalOutputFile);
                    }

                }
            }

            return listFileWithoutMerge;
        }

        private void Export2Dif(string finalOutputFile, string fileXML = "", string forType = "")
        {
            System.Data.DataSet rptData = null;

            if (fileXML.Length > 0)
                rptData = DataReaderUtilities.GetData(ReportDBConnString, string.Format(@"EXEC dbo.wsp_EXPORT_FILE @searchFields = '{0}', @forType = '{1}'", fileXML, forType));
            else
            {
                ReportParameter param = ReportParameters.Where(rp => rp.ParamName.Equals("param_Runs")).FirstOrDefault();
                if (param != null)
                {
                    rptData = DataReaderUtilities.GetData(ReportDBConnString, string.Format(@"EXEC dbo.usp_{0} @param_Runs = '{1}'", ReportID, param.ParamValue));
                }
            }

            if ((rptData != null) && (rptData.Tables.Count > 0))
            {
                string xmlTemplatePath = ManageReports.GetPathToTemplateFile();
                string maskPath = string.Format(@"{0}\{1}.xml", xmlTemplatePath, ReportID);
                FileComposer.ExportDIFFile(maskPath, rptData.Tables[0], finalOutputFile);
            }
            else
            {
                FileComposer.ExportDIFFileForNoData(finalOutputFile);
            }
        }

        private void Export2File(string finalOutputFile, string fileXML = "", string forType = "")
        {
            var rptData = DataReaderUtilities.GetData(ReportDBConnString, string.Format(@"EXEC dbo.wsp_EXPORT_FILE @searchFields = '{0}', @forType = '{1}'", fileXML, forType));
            if ((rptData != null) && (rptData.Tables.Count > 0))
            {
                string xmlTemplatePath = ManageReports.GetPathToTemplateFile();
                string maskPath = string.Format(@"{0}\{1}.xml", xmlTemplatePath, ReportID);
                FileComposer.ExportDIFFile(maskPath, rptData.Tables[0], finalOutputFile);
            }
        }

        private void Export2Txt(string finalOutputFile)
        {
            ReportParameter param = ReportParameters.Where(rp => rp.ParamName.Equals("param_Runs")).FirstOrDefault();
            if (param != null)
            {
                var rptData = DataReaderUtilities.GetData(ReportDBConnString, string.Format(@"EXEC dbo.usp_{0} @param_Runs = '{1}'", ReportID, param.ParamValue));
                if ((rptData != null) && (rptData.Tables.Count > 0))
                {
                    FileComposer.ExportTXTFile(rptData.Tables[0], finalOutputFile);
                }
            }
        }

        #endregion
    }
}
