﻿using SQLUtilsLib;
using SSRSReportLib;
using ABVReportLib;
using System.Collections.Generic;

namespace NRRReportLib
{
    public class NRRReportHelper
    {
        public static void SubmitReports(string reportName, List<ReportParameter> parameters)
        {

        }

        public static void GenerateReports(int rptInstanceId, string[] fileTypes, string runNameSrc = "", string runNameComp = "")
        {
            string reportName = ManageReports.GetReportName(rptInstanceId);
            var reporting = new NRRReport(reportName);
            reporting.GenerateReports(rptInstanceId, fileTypes, runNameSrc, runNameComp);
        }
    }
}
