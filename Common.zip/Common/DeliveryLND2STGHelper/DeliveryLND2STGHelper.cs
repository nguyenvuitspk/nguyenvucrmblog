﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonETLLibs;
using DataReaderUtilsLib;
using SQLUtilsLib;
using System.Data;

namespace DeliveryLND2STGHelper
{
    public class DeliveryLND2STGHelper
    {
        public int CreateRun()
        {
            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_STG,
                 string.Format(
                                @"DECLARE @MyNewIdentityValues table(ID BIGINT)
                                insert into [dbo].[STG_RUNS]([IS_DV]) OUTPUT Inserted.STG_RUN_ID INTO @MyNewIdentityValues
                                values(0) 
                                select ID FROM @MyNewIdentityValues
                               "));
            return Convert.ToInt32(value);
        }


        public int CreateRunStatus(int RUN_ID, string STATUS_CD)
        {
            var value = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_STG,
                 string.Format(@"
                        DECLARE @MyNewIdentityValues table(ID BIGINT)
                        insert into [dbo].[STG_RUN_STATUS]
                        ([STG_RUN_ID]
                        ,[STATUS_CD]
                        ,[STATUS_CHANGE_TS])
                        OUTPUT Inserted.STATUS_ID INTO @MyNewIdentityValues
                        values
                        (
                        {0},'{1}','{2}'
                        )

                        select ID FROM @MyNewIdentityValues
                               ", RUN_ID, STATUS_CD, DateTime.Now.ToString(Constant.SqlDateTimeFortmat)));
            return Convert.ToInt32(value);
        }

        public List<int> GetListRunByDatasetType(string DS_Type_CD)
        {
            List<int> RunList = new List<int>();
            string sql = string.Format(@"exec spGetListRunByDatasetType @DS_Type_CD='{0}'", DS_Type_CD);
            var ds = DataReaderUtilities.GetData(DBReference.ConnStr_LND, sql);

            if (!(ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0))
            {
                RunList = ds.Tables[0].AsEnumerable().Select(dataRow => dataRow.Field<int>("RUN_ID")).ToList();
            }
            return RunList;
        }


        public string GetSourceFileNameByRun(int LND_Run_Id)
        {
            string sql = string.Format(@"select RUN_PATH+'\'+ RUN_FILE as [SourceFileName] from [dbo].[LND_RUNS] where run_id = {0}", LND_Run_Id);
            string sourceFileName = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_LND, sql).ToString();

            return sourceFileName;
        }
    }
}
