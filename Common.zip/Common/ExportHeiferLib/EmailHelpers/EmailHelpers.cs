﻿using DataReaderUtilsLib;
using ExportHeiferLib.Configuration.EmailHelpers;
using ExportHeiferLib.EmailHelpers.Common;
using ExportHeiferLib.EmailHelpers.Models;
using SQLUtilsLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Mail;

namespace ExportHeiferLib.EmailHelpers
{
    public class EmailHelpers
    {
        private static EmailHelpers _instance;

        public static EmailHelpers Instance(string cdrConnectionStr)
        {
            _instance = new EmailHelpers(cdrConnectionStr);

            return _instance;
        }

        public EmailHelpers(string cdrConnectionStr)
        {
            DBReference.InitiateDBReference(null, null, cdrConnectionStr);
        }
        public static string TextToHtml(string text)
        {
            text = text.Replace("\r\n", "");
            text = text.Replace("\n", "");
            text = text.Replace("\r", "");
            text = text.Replace("  ", "");
            text = text.Replace("\"", "\"");
            text = text.Replace("\\\"", "\"");
            return text;
        }

        public static string SendingEmail(EmailType type, EmailModel emailCriteria, Dictionary<string, object> bodyCriteria)
        {
            string host = EmailConfiguration.GetConfiguration(EmailConstants.SMTP_SERVER);
            int port = Convert.ToInt32(EmailConfiguration.GetConfiguration(EmailConstants.SMTP_PORT));

            string htmlBody = GetHtmlTemplate(type);

            using (var client = new SmtpClient(host, port))
            {
                try
                {
                    MailMessage message = new MailMessage();
                    message.IsBodyHtml = true;

                    // The body of the email
                    var BODY = PopulateBody(bodyCriteria, htmlBody);
                    if (type == EmailType.VALIDATION_ERROR)
                    {
                        if (bodyCriteria.ContainsKey("NUMBER_01") && Convert.ToInt32(bodyCriteria["NUMBER_01"]) > 0)
                        {
                            BODY = BODY.Replace("display:none", "display:block");
                        }
                    }
                    BODY = TextToHtml(BODY);

                    // The email criteria
                    if (emailCriteria.EMAIL_TO == null || emailCriteria.EMAIL_TO.Count() == 0)
                    {
                        return EmailConstants.EMAIL_TO_EMPTY_MESSAGE;
                    }
                    message.From = new MailAddress(emailCriteria.FROM_EMAIL, emailCriteria.FROM_NAME);

                    foreach (var item in emailCriteria.EMAIL_TO)
                    {
                        message.To.Add(new MailAddress(item));
                    }

                    foreach (var item in emailCriteria.EMAIL_CC)
                    {
                        message.CC.Add(item);
                    }

                    foreach (var item in emailCriteria.EMAIL_BCC)
                    {
                        message.Bcc.Add(item);
                    }

                    // Attachment files
                    foreach (string filePath in emailCriteria.EMAIL_ATTACHMENTS)
                    {
                        Attachment data = new Attachment(filePath);
                        message.Attachments.Add(data);
                    }

                    message.Subject = emailCriteria.SUBJECT_EMAIL;

                    message.Body = BODY;

                    // Comment or delete the next line if you are not using a configuration set
                    message.Headers.Add(EmailConstants.HEADER_CONSTANT, EmailConstants.CONFIGSET);

                    client.Send(message);
                    return EmailConstants.SENDING_SUCCESS;
                }
                catch (Exception ex)
                {
                    return ex.Message + " | " + ex.InnerException;
                }
            }
        }

        private static string GetHtmlTemplate(EmailType type)
        {
            string htmlBody = string.Empty;
            switch (type)
            {
                case EmailType.HEIFER_TASK_REPORT:
                    htmlBody = @"
                        <div style='font-family:Arial;color:black;font-size:10pt' class='row'>
                            <div>
                                Status report for shipment [SHIPMENT_ID] prepared by Datagene on [CURRENT_DATE]
                                <br /><br />
                            </div>
                            <div>
                                <p>Summary:</p>
                                <p>Heifers currently listed in the shipment = [NO_ALL_HEIFER]</p>
                                <p>Problems in connecting to the DG database = [NO_HEIFER_CANT_CONNECT_DG]</p>
                                <p>Heifers whose details cannot be disclosed = [NO_HEIFER_CANT_BE_DISCLOSED]</p>
                                <p>One exporter heifer record connects to two or more DG records = [NO_1HEIFER_TO_MOREDG]</p>
                                <p>Two or more exporter heifer records connect to one DG record = [NO_2HEIFER_TO_1_DG]</p>
                                <p>Heifers whose breed is different to that sought = [NO_HEIFER_BREED_DIFF_TO_SOUGHT]</p>
                                <p>Heifers that are too old = [NO_HEIFER_TOO_OLD]</p>
                                <p>Heifers with insufficient pedigree = [NO_HEIFER_INSUFFICIENT_PED]</p>
                                <p>Heifers eligible for D certificate = [NO_HEIFER_D]</p>
                                <p>Heifers eligible for E certificate = [NO_HEIFER_E]</p>
                                <p>Heifers eligible for F certificate = [NO_HEIFER_F]</p>
                                <p>Please find more details in the attachment.</p>
                            </div>
                        </div>
                    ";
                    break;
                case EmailType.VALIDATION_ERROR:
                    htmlBody = @"
                        <div style='font-family:Arial;color:black;font-size:10pt' class='row'>
                            <div>
                                <p>Import Shipment [SHIPMENT_FILE] for shipment [SHIPMENT_ID] prepared by Datagene on [IMPORT_DATE]</p>
                                <p>Number of failure heifers: [NUMBER_01]</p>
                                <p>Number of warning heifers: [NUMBER_02]
                                <p style='display:none'>Please find more details in the attachment.</p>
                             </div>
                        </div>
                    ";
                    break;
                case EmailType.PRINT_FINAL_CERTIFICATE:
                case EmailType.PRINT_PRE_EMBARKATION_CERTIFICATION:
                    htmlBody = @"
                        <div style='font-family:Arial;color:black;font-size:10pt' class='row'>
                            <div>
                                Status report for shipment [SHIPMENT_ID] prepared by Datagene on [CURRENT_DATE]
                                <br /><br />
                            </div>
                            <div>
                                <p>Summary:</p>
                                <p>Heifers in the shipment = [HEIFER_IN_SHIPMENT]</p>                                
                                <p>Heifers ineligible = [HEIFER_INELIGIBLE]</p>
                                <p>Heifers invalid to print final cerfiticate = [HEIFER_INVALID_PRINT_FINAL]</p>                                
                                <p>Heifers invalid to print pre embarkation cerfiticate = [HEIFER_INVALID_PRINT_PRE_EMBARKATION]</p>
                                <p>Please find more details in the attachment.</p>
                            </div>
                        </div>
                    ";
                    break;
                default:
                    break;
            }
            return htmlBody;
        }

        public static Dictionary<string, object> GetEmailBodyCriterialForPrintCertificate(string shipmentID, string exporterID)
        {
            // Need to replace criterial by get value from DB
            var dt = DataReaderUtilities.GetData(DBReference.ConnStr_DV,
                                        string.Format(@"DECLARE @PK_EH_REQUEST_SE_ID UNIQUEIDENTIFIER
		                                                        ,@PK_SHIPMENT_EXPORTER_ID UNIQUEIDENTIFIER
		                                                        ,@NO_ALL_HEIFER INT
                                                                ,@NO_INELIGIBLE INT
		                                                        ,@NO_VALID_FINAL INT
		                                                        ,@NO_VALID_PRE INT

                                                        SELECT	@PK_EH_REQUEST_SE_ID = lERSes.PK_EH_REQUEST_SE_ID
		                                                        ,@PK_SHIPMENT_EXPORTER_ID = lSExporters.PK_SHIPMENT_EXPORTER_ID
                                                        FROM dbo.LNK_SHIPMENT_EXPORTERS (NOLOCK) lSExporters
                                                        JOIN dbo.HUB_SHIPMENTS (NOLOCK) hShipments ON hShipments.PK_SHIPMENT_ID = lSExporters.PK_SHIPMENT_ID
                                                        JOIN dbo.HUB_EXPORTERS (NOLOCK) hExporters ON hExporters.PK_EXPORTER_ID = lSExporters.PK_EXPORTER_ID
                                                        JOIN dbo.LNK_EH_REQUEST_SES (NOLOCK) lERSes ON lERSes.PK_SHIPMENT_EXPORTER_ID = lSExporters.PK_SHIPMENT_EXPORTER_ID
                                                        JOIN dbo.SAT_EH_REQUEST_SES (NOLOCK) sERSes ON sERSes.PK_EH_REQUEST_SE_ID = lERSes.PK_EH_REQUEST_SE_ID AND sERSes.MD_LOADEND_TS IS NULL
                                                        WHERE hShipments.BK_SHIPMENT_CODE = '{0}'
	                                                        AND hExporters.BK_EXPORTER_CODE = '{1}'
	                                                        AND sERSes.IS_ACTIVE = 1

                                                        IF OBJECT_ID('tempdb..#certificates') IS NOT NULL
	                                                        DROP TABLE #certificates

                                                        SELECT sCertificates.[CERTIFICATE]
                                                        INTO #certificates
                                                        FROM dbo.LNK_EH_REQUEST_SE_SE_SHIPMENT_ANIMALS (NOLOCK) lERSSSAnimals
                                                        JOIN dbo.LNK_SE_SHIPMENT_ANIMALS (NOLOCK) lSSAnimals ON lSSAnimals.PK_SE_SHIPMENT_ANIMAL_ID = lERSSSAnimals.PK_SE_SHIPMENT_ANIMAL_ID
                                                        JOIN dbo.SAT_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_CERTIFICATES (NOLOCK) sCertificates ON sCertificates.PK_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_ID = lERSSSAnimals.PK_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_ID
																				                                                        AND sCertificates.MD_LOADEND_TS IS NULL
                                                        WHERE lERSSSAnimals.PK_EH_REQUEST_SE_ID = @PK_EH_REQUEST_SE_ID
	                                                        AND lSSAnimals.PK_SHIPMENT_EXPORTER_ID = @PK_SHIPMENT_EXPORTER_ID

                                                        SELECT @NO_ALL_HEIFER = COUNT(1) FROM LNK_SE_SHIPMENT_ANIMALS WHERE PK_SHIPMENT_EXPORTER_ID = @PK_SHIPMENT_EXPORTER_ID
                                                        SELECT @NO_INELIGIBLE = COUNT(1) 
                                                        FROM dbo.LNK_SE_SHIPMENT_ANIMALS lSSAnimals
                                                        JOIN dbo.SAT_SE_SHIPMENT_ANIMAL_STATUSES sSSAStatuses ON sSSAStatuses.PK_SE_SHIPMENT_ANIMAL_ID = lSSAnimals.PK_SE_SHIPMENT_ANIMAL_ID AND sSSAStatuses.MD_LOADEND_TS IS NULL
                                                         WHERE lSSAnimals.PK_SHIPMENT_EXPORTER_ID = @PK_SHIPMENT_EXPORTER_ID
	                                                        AND sSSAStatuses.[STATUS] = 'Ineligible'
                                                        SELECT @NO_VALID_FINAL = COUNT(1) FROM #certificates WHERE CERTIFICATE = 'Final'
                                                        SELECT @NO_VALID_PRE = COUNT(1) FROM #certificates WHERE CERTIFICATE = 'Pre-embarkation'

                                                        SELECT 'NO_ALL_HEIFER' AS [NAME]
		                                                        ,@NO_ALL_HEIFER
                                                        UNION
                                                        SELECT 'NO_INELIGIBLE'
		                                                        ,@NO_INELIGIBLE
                                                        UNION
                                                        SELECT 'NO_INVALID_FINAL'
		                                                        ,@NO_ALL_HEIFER - @NO_VALID_FINAL
                                                        UNION
                                                        SELECT 'NO_INVALID_PRE'
		                                                        ,@NO_ALL_HEIFER - @NO_VALID_PRE", shipmentID, exporterID)).Tables[0];

            return new Dictionary<string, object>() {
                { "SHIPMENT_ID", shipmentID },
                { "CURRENT_DATE", DateTime.Now.ToShortDateString() },
                { "HEIFER_IN_SHIPMENT", dt.Rows[0][1].ToString()},
                { "HEIFER_INELIGIBLE", dt.Rows[1][1].ToString()},
                { "HEIFER_INVALID_PRINT_FINAL", dt.Rows[2][1].ToString()},
                { "HEIFER_INVALID_PRINT_PRE_EMBARKATION", dt.Rows[3][1].ToString()}
            };
        }

        public static EmailModel GetEmailModelForPrintCertificate(EmailType emailType, string shipmentID, string exporterID, int sessionID = 0)
        {
            var emailCriterial = new EmailModel();
            emailCriterial.FROM_EMAIL = EmailConfiguration.GetConfiguration("EH_HOST_EMAIL_SUPP_CONTS");
            emailCriterial.EMAIL_TO = EmailAddressesWhenPrintCertificates(shipmentID, exporterID);
            switch (emailType)
            {
                case EmailType.HEIFER_TASK_REPORT:
                    break;
                case EmailType.VALIDATION_ERROR:
                    break;
                case EmailType.PRINT_FINAL_CERTIFICATE:
                    emailCriterial.FROM_NAME = EmailPrintFinalCertificateConstants.FROM_NAME;
                    emailCriterial.SUBJECT_EMAIL = EmailPrintFinalCertificateConstants.SUBJECT;
                    break;
                case EmailType.PRINT_PRE_EMBARKATION_CERTIFICATION:
                    emailCriterial.FROM_NAME = EmailPrintPreEmbarkationCertificateConstants.FROM_NAME;
                    emailCriterial.SUBJECT_EMAIL = EmailPrintPreEmbarkationCertificateConstants.SUBJECT;
                    break;
                default:
                    break;
            }

            // Add EMAIL_ATTACHMENTS
            var fileHelper = new FileHelper.FileHelper("heifers.csv");
            fileHelper.Write(GetHeifersHaveDataFaultCodes(shipmentID, exporterID), ",");
            emailCriterial.EMAIL_ATTACHMENTS = new string[] { fileHelper.FilePath };

            return emailCriterial;
        }

        public static string PopulateBody(Dictionary<string, object> criteria, string htmlBody)
        {

            foreach (var item in criteria)
            {
                htmlBody = htmlBody.Replace(string.Format("[{0}]", item.Key), item.Value.ToString());
            }

            return htmlBody;
        }

        public static string[] EmailAddressesWhenPrintCertificates(string shipmentId, string exporterId)
        {
            string result = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                                   string.Format(@"SELECT LTRIM(RTRIM(COALESCE(sPartiesBS.EMAIL, '')))
                                                    FROM dbo.LNK_SHIPMENT_EXPORTERS (NOLOCK) lSExporters
                                                    JOIN dbo.HUB_EXPORTERS (NOLOCK) hExporters ON hExporters.PK_EXPORTER_ID = lSExporters.PK_EXPORTER_ID
                                                    JOIN dbo.HUB_SHIPMENTS (NOLOCK) hShipments ON hShipments.PK_SHIPMENT_ID = lSExporters.PK_SHIPMENT_ID
                                                    JOIN dbo.LNK_SHIPMENT_EXPORTER_BREED_SOCIETIES (NOLOCK) lSEBSocieties ON lSEBSocieties.PK_SHIPMENT_EXPORTER_ID = lSExporters.PK_SHIPMENT_EXPORTER_ID
                                                    JOIN dbo.LNK_PARTY_BREED_SOCIETIES (NOLOCK) lPBSocieties ON lPBSocieties.PK_BREED_SOCIETY_ID = lSEBSocieties.PK_BREED_SOCIETY_ID
                                                    LEFT JOIN dbo.SAT_PARTIES (NOLOCK) sPartiesBS ON sPartiesBS.PK_PARTY_ID = lPBSocieties.PK_PARTY_ID AND sPartiesBS.MD_LOADEND_TS IS NULL
                                                    WHERE hExporters.BK_EXPORTER_CODE = '{0}'
	                                                    AND hShipments.BK_SHIPMENT_CODE = '{1}'", exporterId, shipmentId)).ToString();

            return result.Split(';');
        }

        public static string[] EmailAddressesWhenLoadingShipmentFiles(string shipmentId, string exporterId)
        {
            string result = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                                    string.Format(@"SELECT LTRIM(RTRIM(COALESCE(sPartiesBS.EMAIL, '')))
                                                    FROM dbo.LNK_SHIPMENT_EXPORTERS (NOLOCK) lSExporters
                                                    JOIN dbo.HUB_EXPORTERS (NOLOCK) hExporters ON hExporters.PK_EXPORTER_ID = lSExporters.PK_EXPORTER_ID
                                                    JOIN dbo.HUB_SHIPMENTS (NOLOCK) hShipments ON hShipments.PK_SHIPMENT_ID = lSExporters.PK_SHIPMENT_ID
                                                    JOIN dbo.LNK_SHIPMENT_EXPORTER_BREED_SOCIETIES (NOLOCK) lSEBSocieties ON lSEBSocieties.PK_SHIPMENT_EXPORTER_ID = lSExporters.PK_SHIPMENT_EXPORTER_ID
                                                    JOIN dbo.LNK_PARTY_BREED_SOCIETIES (NOLOCK) lPBSocieties ON lPBSocieties.PK_BREED_SOCIETY_ID = lSEBSocieties.PK_BREED_SOCIETY_ID
                                                    LEFT JOIN dbo.SAT_PARTIES (NOLOCK) sPartiesBS ON sPartiesBS.PK_PARTY_ID = lPBSocieties.PK_PARTY_ID AND sPartiesBS.MD_LOADEND_TS IS NULL
                                                    WHERE hExporters.BK_EXPORTER_CODE = '{0}'
	                                                    AND hShipments.BK_SHIPMENT_CODE = '{1}'", exporterId, shipmentId)).ToString();

            return result.Split(';');
        }

        public static string[] EmailAddressesWhenHeiferTaskCompleted(string shipmentId, string exporterId, string sessionId)
        {
            string result = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                                   string.Format(@"SELECT CONCAT(
			                                                    IIF(COALESCE(sPartiesBS.EMAIL, '') <> '', LTRIM(RTRIM(sPartiesBS.EMAIL)) + ';', '')
			                                                    ,IIF(COALESCE(sPartiesExporter.EMAIL, '') <> '', LTRIM(RTRIM(sPartiesExporter.EMAIL)) + ';', '')
			                                                    ,IIF(COALESCE(sSExporters.CONTACT_EMAIL, '') <> '', LTRIM(RTRIM(sSExporters.CONTACT_EMAIL)), '')
			                                                    )
                                                    FROM dbo.LNK_SHIPMENT_EXPORTERS (NOLOCK) lSExporters
                                                    JOIN dbo.SAT_SHIPMENT_EXPORTERS (NOLOCK) sSExporters ON sSExporters.PK_SHIPMENT_EXPORTER_ID = lSExporters.PK_SHIPMENT_EXPORTER_ID AND sSExporters.MD_LOADEND_TS IS NULL
                                                    JOIN dbo.HUB_EXPORTERS (NOLOCK) hExporters ON hExporters.PK_EXPORTER_ID = lSExporters.PK_EXPORTER_ID
                                                    JOIN dbo.HUB_SHIPMENTS (NOLOCK) hShipments ON hShipments.PK_SHIPMENT_ID = lSExporters.PK_SHIPMENT_ID
                                                    JOIN dbo.LNK_SHIPMENT_EXPORTER_BREED_SOCIETIES (NOLOCK) lSEBSocieties ON lSEBSocieties.PK_SHIPMENT_EXPORTER_ID = lSExporters.PK_SHIPMENT_EXPORTER_ID
                                                    JOIN dbo.LNK_PARTY_EXPORTERS (NOLOCK) lPExporters ON lPExporters.PK_EXPORTER_ID = hExporters.PK_EXPORTER_ID
                                                    LEFT JOIN dbo.SAT_PARTIES (NOLOCK) sPartiesExporter ON sPartiesExporter.PK_PARTY_ID = lPExporters.PK_PARTY_ID AND sPartiesExporter.MD_LOADEND_TS IS NULL
                                                    JOIN dbo.LNK_PARTY_BREED_SOCIETIES (NOLOCK) lPBSocieties ON lPBSocieties.PK_BREED_SOCIETY_ID = lSEBSocieties.PK_BREED_SOCIETY_ID
                                                    LEFT JOIN dbo.SAT_PARTIES (NOLOCK) sPartiesBS ON sPartiesBS.PK_PARTY_ID = lPBSocieties.PK_PARTY_ID AND sPartiesBS.MD_LOADEND_TS IS NULL
                                                    WHERE hExporters.BK_EXPORTER_CODE = '{0}'
	                                                    AND hShipments.BK_SHIPMENT_CODE = '{1}'", exporterId, shipmentId)).ToString();

            return result.Split(';');
        }

        public static int CountHeifersInShipment(string shipmentId, string exporterId)
        {
            return Int32.Parse(DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV
                                    , string.Format(@"SELECT	COUNT(1)
                                                    FROM dbo.LNK_SHIPMENT_EXPORTERS (NOLOCK) lSExporters
                                                    JOIN dbo.HUB_EXPORTERS (NOLOCK) hExporters ON hExporters.PK_EXPORTER_ID = lSExporters.PK_EXPORTER_ID
                                                    JOIN dbo.HUB_SHIPMENTS (NOLOCK) hShipments ON hShipments.PK_SHIPMENT_ID = lSExporters.PK_SHIPMENT_ID
                                                    JOIN dbo.LNK_SE_SHIPMENT_ANIMALS (NOLOCK) lSSAnimals ON lSSAnimals.PK_SHIPMENT_EXPORTER_ID = lSExporters.PK_SHIPMENT_EXPORTER_ID
                                                    WHERE hExporters.BK_EXPORTER_CODE = '{0}'
	                                                    AND hShipments.BK_SHIPMENT_CODE = '{1}'"
                                                                                        , exporterId, shipmentId)).ToString());
        }

        public static DataTable CountHeiferForEachFaultCode(string shipmentId, string exporterId)
        {
            return DataReaderUtilities.GetData(DBReference.ConnStr_DV,
                                            string.Format(@"DECLARE @PK_SHIPMENT_EXPORTER_ID UNIQUEIDENTIFIER

	                                                        SELECT	@PK_SHIPMENT_EXPORTER_ID = lSExporters.PK_SHIPMENT_EXPORTER_ID
	                                                        FROM dbo.LNK_SHIPMENT_EXPORTERS (NOLOCK) lSExporters
	                                                        JOIN dbo.HUB_EXPORTERS (NOLOCK) hExporters ON hExporters.PK_EXPORTER_ID = lSExporters.PK_EXPORTER_ID
	                                                        JOIN dbo.HUB_SHIPMENTS (NOLOCK) hShipments ON hShipments.PK_SHIPMENT_ID = lSExporters.PK_SHIPMENT_ID
	                                                        WHERE hExporters.BK_EXPORTER_CODE = '{0}'
		                                                        AND hShipments.BK_SHIPMENT_CODE = '{1}'

                                                           IF OBJECT_ID('tempdb..#data') IS NOT NULL
	                                                            DROP TABLE #data

                                                            SELECT	sFCodes.REF_DATA_FAULT_CODE
                                                                    ,COUNT(1) AS ROW_COUNT
                                                            INTO #data
                                                            FROM dbo.LNK_EH_REQUEST_SES lERSes
                                                            JOIN dbo.SAT_EH_REQUEST_SES sERSes ON sERSes.PK_EH_REQUEST_SE_ID = lERSes.PK_EH_REQUEST_SE_ID AND sERSes.MD_LOADEND_TS IS NULL
                                                            JOIN dbo.LNK_EH_REQUEST_SE_SE_SHIPMENT_ANIMALS lERSSSAnimals ON lERSSSAnimals.PK_EH_REQUEST_SE_ID = lERSes.PK_EH_REQUEST_SE_ID
                                                            JOIN dbo.SAT_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_DATA_FAULT_CODES sFCodes ON sFCodes.PK_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_ID = lERSSSAnimals.PK_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_ID
                                                            WHERE sERSes.IS_ACTIVE = 1
	                                                            AND lERSes.PK_SHIPMENT_EXPORTER_ID = @PK_SHIPMENT_EXPORTER_ID
                                                            GROUP BY sFCodes.REF_DATA_FAULT_CODE

                                                            SELECT	rDFCodes.REF_DATA_FAULT_CODE AS DATA_FAULT_CODE
		                                                            ,COALESCE(#data.ROW_COUNT, 0) AS ROW_COUNT
                                                            FROM dbo.REF_DATA_FAULT_CODES rDFCodes
                                                            LEFT JOIN #data ON rDFCodes.REF_DATA_FAULT_CODE = #data.REF_DATA_FAULT_CODE
                                                            ", exporterId, shipmentId)).Tables[0];
        }

        public static DataTable GetHeifersHaveDataFaultCodes(string shipmentId, string exporterId)
        {
            return DataReaderUtilities.GetData(DBReference.ConnStr_DV,
                                            string.Format(@"DECLARE @PK_SHIPMENT_EXPORTER_ID UNIQUEIDENTIFIER
		                                                            ,@PK_EH_REQUEST_SE_ID UNIQUEIDENTIFIER

                                                            SELECT	@PK_SHIPMENT_EXPORTER_ID = lSExporters.PK_SHIPMENT_EXPORTER_ID
		                                                            ,@PK_EH_REQUEST_SE_ID = lERSes.PK_EH_REQUEST_SE_ID
                                                            FROM dbo.LNK_SHIPMENT_EXPORTERS (NOLOCK) lSExporters
                                                            JOIN dbo.HUB_EXPORTERS (NOLOCK) hExporters ON hExporters.PK_EXPORTER_ID = lSExporters.PK_EXPORTER_ID
                                                            JOIN dbo.HUB_SHIPMENTS (NOLOCK) hShipments ON hShipments.PK_SHIPMENT_ID = lSExporters.PK_SHIPMENT_ID
                                                            JOIN dbo.LNK_EH_REQUEST_SES (NOLOCK) lERSes ON lERSes.PK_SHIPMENT_EXPORTER_ID = lSExporters.PK_SHIPMENT_EXPORTER_ID
                                                            JOIN dbo.SAT_EH_REQUEST_SES (NOLOCK) sERSes ON sERSes.PK_EH_REQUEST_SE_ID = lERSes.PK_EH_REQUEST_SE_ID AND sERSes.MD_LOADEND_TS IS NULL
                                                            WHERE hExporters.BK_EXPORTER_CODE = '{0}'
	                                                            AND hShipments.BK_SHIPMENT_CODE = '{1}'
	                                                            AND sERSes.IS_ACTIVE = 1

                                                            IF OBJECT_ID('tempdb..#shipmentAnimals') IS NOT NULL
	                                                            DROP TABLE #shipmentAnimals

                                                            SELECT	lSSAnimals.PK_SE_SHIPMENT_ANIMAL_ID
		                                                            ,sSSAnimals.VISUAL_TAG
		                                                            ,sSSAnimals.NLIS_INTERNAL_ID
		                                                            ,sSSAnimals.NLIS_EXTERNAL_ID
		                                                            ,sSSAnimals.ANIMAL_NATIONAL_ID
		                                                            ,sSSAnimals.BREED_CD
		                                                            ,sSSAnimals.DPC_CD
                                                            INTO #shipmentAnimals
                                                            FROM dbo.LNK_SHIPMENT_EXPORTERS lSExporters
                                                            JOIN dbo.LNK_SE_SHIPMENT_ANIMALS lSSAnimals ON lSSAnimals.PK_SHIPMENT_EXPORTER_ID = lSExporters.PK_SHIPMENT_EXPORTER_ID
                                                            JOIN dbo.SAT_SE_SHIPMENT_ANIMALS sSSAnimals ON sSSAnimals.PK_SE_SHIPMENT_ANIMAL_ID = lSSAnimals.PK_SE_SHIPMENT_ANIMAL_ID AND sSSAnimals.MD_LOADEND_TS IS NULL
                                                            WHERE lSExporters.PK_SHIPMENT_EXPORTER_ID = @PK_SHIPMENT_EXPORTER_ID

                                                            ;WITH cteFCodes AS (
	                                                            SELECT	#shipmentAnimals.PK_SE_SHIPMENT_ANIMAL_ID
			                                                            ,dbo.GROUP_CONCAT_D(REF_DATA_FAULT_CODE, ';') AS REF_DATA_FAULT_CODES
	                                                            FROM #shipmentAnimals
	                                                            JOIN dbo.LNK_EH_REQUEST_SE_SE_SHIPMENT_ANIMALS lERSSSAnimals ON lERSSSAnimals.PK_SE_SHIPMENT_ANIMAL_ID = #shipmentAnimals.PK_SE_SHIPMENT_ANIMAL_ID
	                                                            JOIN dbo.SAT_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_DATA_FAULT_CODES sFCodes ON sFCodes.PK_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_ID = lERSSSAnimals.PK_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_ID AND sFCodes.MD_LOADEND_TS IS NULL
	                                                            WHERE lERSSSAnimals.PK_EH_REQUEST_SE_ID = @PK_EH_REQUEST_SE_ID
	                                                            GROUP BY #shipmentAnimals.PK_SE_SHIPMENT_ANIMAL_ID
                                                            )
                                                            SELECT NLIS_INTERNAL_ID AS [NLIS Internal]
                                                                  ,VISUAL_TAG AS [Visual Tag]
                                                                  ,NLIS_EXTERNAL_ID AS [NLIS External]
                                                                  ,ANIMAL_NATIONAL_ID AS [National ID]
                                                                  ,BREED_CD AS [Breed]
                                                                  ,DPC_CD AS [DPC Code]
                                                                  ,cteFCodes.REF_DATA_FAULT_CODES AS [Data Fault Codes]
                                                            FROM #shipmentAnimals
                                                            JOIN cteFCodes ON cteFCodes.PK_SE_SHIPMENT_ANIMAL_ID = #shipmentAnimals.PK_SE_SHIPMENT_ANIMAL_ID
                                                            ORDER BY NLIS_INTERNAL_ID
                                                            ", exporterId, shipmentId)).Tables[0];
        }


        public static DataTable GetHeiferTaskStatistic(string shipmentId, string exporterId)
        {
            return DataReaderUtilities.GetData(DBReference.ConnStr_DV,
                                            string.Format(@"DECLARE @PK_EH_REQUEST_SE_ID UNIQUEIDENTIFIER
		                                                            ,@PK_SHIPMENT_EXPORTER_ID UNIQUEIDENTIFIER
		                                                            ,@NO_ALL_HEIFER INT = 0
		                                                            ,@NO_HEIFER_CANT_CONNECT_DG INT = 0
		                                                            ,@NO_HEIFER_CANT_BE_DISCLOSED INT = 0
		                                                            ,@NO_1HEIFER_TO_MOREDG INT = 0
		                                                            ,@NO_2HEIFER_TO_1_DG INT = 0
		                                                            ,@NO_HEIFER_BREED_DIFF_TO_SOUGHT INT = 0
		                                                            ,@NO_HEIFER_TOO_OLD INT = 0
		                                                            ,@NO_HEIFER_INSUFFICIENT_PED INT = 0
		                                                            ,@NO_HEIFER_D INT = 0
		                                                            ,@NO_HEIFER_E INT = 0
		                                                            ,@NO_HEIFER_F INT = 0

                                                            SELECT	@PK_EH_REQUEST_SE_ID = lERSes.PK_EH_REQUEST_SE_ID
		                                                            ,@PK_SHIPMENT_EXPORTER_ID = lSExporters.PK_SHIPMENT_EXPORTER_ID
                                                            FROM dbo.LNK_SHIPMENT_EXPORTERS (NOLOCK) lSExporters
                                                            JOIN dbo.HUB_SHIPMENTS (NOLOCK) hShipments ON hShipments.PK_SHIPMENT_ID = lSExporters.PK_SHIPMENT_ID
                                                            JOIN dbo.HUB_EXPORTERS (NOLOCK) hExporters ON hExporters.PK_EXPORTER_ID = lSExporters.PK_EXPORTER_ID
                                                            JOIN dbo.LNK_EH_REQUEST_SES (NOLOCK) lERSes ON lERSes.PK_SHIPMENT_EXPORTER_ID = lSExporters.PK_SHIPMENT_EXPORTER_ID
                                                            JOIN dbo.SAT_EH_REQUEST_SES (NOLOCK) sERSes ON sERSes.PK_EH_REQUEST_SE_ID = lERSes.PK_EH_REQUEST_SE_ID AND sERSes.MD_LOADEND_TS IS NULL
                                                            WHERE hShipments.BK_SHIPMENT_CODE = '{0}'
	                                                            AND hExporters.BK_EXPORTER_CODE = '{1}'
	                                                            AND sERSes.IS_ACTIVE = 1

                                                            IF OBJECT_ID('tempdb..#lSASource') IS NOT NULL
	                                                            DROP TABLE #lSASource
                                                            IF OBJECT_ID('tempdb..#fCodes') IS NOT NULL
	                                                            DROP TABLE #fCodes
                                                            IF OBJECT_ID('tempdb..#pedCers') IS NOT NULL
	                                                            DROP TABLE #pedCers

                                                            SELECT lERSSSAnimals.PK_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_ID
                                                            INTO #lSASource
                                                            FROM dbo.LNK_EH_REQUEST_SE_SE_SHIPMENT_ANIMALS (NOLOCK) lERSSSAnimals
                                                            JOIN dbo.LNK_SE_SHIPMENT_ANIMALS (NOLOCK) lSSAnimals ON lSSAnimals.PK_SE_SHIPMENT_ANIMAL_ID = lERSSSAnimals.PK_SE_SHIPMENT_ANIMAL_ID
                                                            WHERE lERSSSAnimals.PK_EH_REQUEST_SE_ID = @PK_EH_REQUEST_SE_ID
	                                                            AND lSSAnimals.PK_SHIPMENT_EXPORTER_ID = @PK_SHIPMENT_EXPORTER_ID

                                                            CREATE CLUSTERED INDEX #lSASource_IDX ON #lSASource(PK_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_ID)

                                                            SELECT	sFCodes.PK_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_ID
		                                                            ,sFCodes.REF_DATA_FAULT_CODE
                                                            INTO #fCodes
                                                            FROM #lSASource
                                                            JOIN dbo.SAT_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_DATA_FAULT_CODES (NOLOCK) sFCodes ON sFCodes.PK_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_ID = #lSASource.PK_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_ID
																				                                                            AND sFCodes.MD_LOADEND_TS IS NULL
                                                            WHERE sFCodes.REF_DATA_FAULT_CODE IN ('DFC_15'
									                                                             ,'DFC_22'
									                                                             ,'DFC_12'
									                                                             ,'DFC_2', 'DFC_7', 'DFC_8'
									                                                             ,'DFC_1'
									                                                             ,'DFC_16', 'DFC_17', 'DFC_18', 'DFC_19')

                                                            SELECT	sPCertificates.PK_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_ID
		                                                            ,sPCertificates.PEDIGREE_CERTIFICATE
                                                            INTO #pedCers
                                                            FROM #lSASource
                                                            JOIN dbo.SAT_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_PEDIGREE_CERTIFICATES (NOLOCK) sPCertificates ON sPCertificates.PK_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_ID = #lSASource.PK_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_ID
																				                                                            AND sPCertificates.MD_LOADEND_TS IS NULL

                                                            SELECT @NO_ALL_HEIFER = COUNT(1) FROM #lSASource
                                                            SELECT @NO_HEIFER_CANT_CONNECT_DG = COUNT(1) FROM #fCodes WHERE REF_DATA_FAULT_CODE = 'DFC_15'
                                                            SELECT @NO_HEIFER_CANT_BE_DISCLOSED = COUNT(1) FROM #fCodes WHERE REF_DATA_FAULT_CODE = 'DFC_22'
                                                            SELECT @NO_1HEIFER_TO_MOREDG = COUNT(1) FROM #fCodes WHERE REF_DATA_FAULT_CODE = 'DFC_12'
                                                            SET @NO_2HEIFER_TO_1_DG = 0
                                                            SELECT @NO_HEIFER_BREED_DIFF_TO_SOUGHT = COUNT(DISTINCT PK_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_ID) FROM #fCodes WHERE REF_DATA_FAULT_CODE IN ('DFC_2', 'DFC_7', 'DFC_8')
                                                            SELECT @NO_HEIFER_TOO_OLD = COUNT(1) FROM #fCodes WHERE REF_DATA_FAULT_CODE = 'DFC_1'
                                                            SELECT @NO_HEIFER_INSUFFICIENT_PED = COUNT(DISTINCT PK_EH_REQUEST_SE_SE_SHIPMENT_ANIMAL_ID) FROM #fCodes WHERE REF_DATA_FAULT_CODE IN ('DFC_16', 'DFC_17', 'DFC_18', 'DFC_19')
                                                            --
                                                            SELECT @NO_HEIFER_D = COUNT(1) FROM #pedCers WHERE PEDIGREE_CERTIFICATE IN ('D1', 'D2')
                                                            SELECT @NO_HEIFER_E = COUNT(1) FROM #pedCers WHERE PEDIGREE_CERTIFICATE = 'E'
                                                            SELECT @NO_HEIFER_F = COUNT(1) FROM #pedCers WHERE PEDIGREE_CERTIFICATE = 'F'

                                                            ;WITH cteResult AS (
	                                                            SELECT 'NO_ALL_HEIFER' AS [NAME] ,@NO_ALL_HEIFER AS ROW_COUNT, 1 AS ORD
	                                                            UNION
	                                                            SELECT 'NO_HEIFER_CANT_CONNECT_DG', @NO_HEIFER_CANT_CONNECT_DG, 2
	                                                            UNION
	                                                            SELECT 'NO_HEIFER_CANT_BE_DISCLOSED', @NO_HEIFER_CANT_BE_DISCLOSED, 3
	                                                            UNION
	                                                            SELECT 'NO_1HEIFER_TO_MOREDG', @NO_1HEIFER_TO_MOREDG, 4
	                                                            UNION
	                                                            SELECT 'NO_2HEIFER_TO_1_DG', @NO_2HEIFER_TO_1_DG, 5
	                                                            UNION
	                                                            SELECT 'NO_HEIFER_BREED_DIFF_TO_SOUGHT', @NO_HEIFER_BREED_DIFF_TO_SOUGHT, 6
	                                                            UNION
	                                                            SELECT 'NO_HEIFER_TOO_OLD', @NO_HEIFER_TOO_OLD, 7
	                                                            UNION
	                                                            SELECT 'NO_HEIFER_INSUFFICIENT_PED', @NO_HEIFER_INSUFFICIENT_PED, 8
	                                                            UNION
	                                                            SELECT 'NO_HEIFER_D', @NO_HEIFER_D, 9
	                                                            UNION
	                                                            SELECT 'NO_HEIFER_E', @NO_HEIFER_E, 10
	                                                            UNION
	                                                            SELECT 'NO_HEIFER_F', @NO_HEIFER_F, 11
                                                            )
                                                            SELECT  cteResult.[NAME]
                                                                    ,cteResult.ROW_COUNT
                                                            FROM cteResult
                                                            ORDER BY cteResult.ORD
                                                          ", shipmentId, exporterId)).Tables[0];
        }

    }
}
