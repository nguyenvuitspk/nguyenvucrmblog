﻿namespace ExportHeiferLib.EmailHelpers.Common
{
    public enum EmailType
    {
        HEIFER_TASK_REPORT,
        VALIDATION_ERROR,
        PRINT_FINAL_CERTIFICATE,
        PRINT_PRE_EMBARKATION_CERTIFICATION
    }
}
