﻿namespace ExportHeiferLib.EmailHelpers.Common
{
    public partial class EmailConstants
    {
        public const string CONFIGSET = "ConfigSet";

        public const string HEADER_CONSTANT = "X-SES-CONFIGURATION-SET";

        public const string EMAIL_TO_EMPTY_MESSAGE = "Support email can't be null";

        public const string SENDING_SUCCESS = "Sending mail is successful";

        public const string SMTP_PORT = "SMTP_PORT";

        public const string SMTP_SERVER = "SMTP_SERVER";

        public const string HOST_EMAIL = "EH_HOST_EMAIL_SUPP_CONTS";
    }

    public static class EmailRejectedRecordConstants
    {
        public static string FILE_NAME = @"EH_ImportError_{0}.csv";
        public static string WARNING_FILE_NAME = @"warning_heifers.csv";
        public static string FROM_NAME = "Export Heifer";
        public static string SUBJECT = "Export Heifer Report of importing Shipment file";
    }
    
    public static class EmailReportHeiferTaskConstants
    {
        public static string FILE_NAME = @"EH_Errors.csv";
        public static string FROM_NAME = "Export Heifer";
        public static string SUBJECT = "Export Heifer Report of Heifer Task";
    }

    public static class EmailPrintFinalCertificateConstants
    {
        public static string FILE_NAME = @"Ineligible_Heifers.csv";
        public static string FROM_NAME = "Export Heifer";
        public static string SUBJECT = "Export Heifer Report for Printing Final Certificate";
    }

    public static class EmailPrintPreEmbarkationCertificateConstants
    {
        public static string FILE_NAME = @"Ineligible_Heifers.csv";
        public static string FROM_NAME = "Export Heifer";
        public static string SUBJECT = "Export Heifer Report for Printing Pre Embarkation Certificate";
    }
}
