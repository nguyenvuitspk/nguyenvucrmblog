﻿namespace ExportHeiferLib.EmailHelpers.Models
{
    public class EmailModel
    {
        public EmailModel()
        {
            EMAIL_TO = new string[] { };
            EMAIL_CC = new string[] { };
            EMAIL_BCC = new string[] { };
            EMAIL_ATTACHMENTS = new string[] { };
        }
        public string FROM_NAME { get; set; }
        public string FROM_EMAIL { get; set; }
        public string SUBJECT_EMAIL { get; set; }
        public string[] EMAIL_TO { get; set; }
        public string[] EMAIL_CC { get; set; }
        public string[] EMAIL_BCC { get; set; }
        public string[] EMAIL_ATTACHMENTS { get; set; }
    }
}
