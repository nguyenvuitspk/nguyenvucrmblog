﻿using DataReaderUtilsLib;
using SQLUtilsLib;

namespace ExportHeiferLib.Configuration.EmailHelpers
{
    public class EmailConfiguration
    {
        public static string GetConfiguration(string configurationName)
        {
            var serverConfig = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                                   string.Format(@"SELECT [VALUE]
                                                    FROM [report].[CONSTANTS]
                                                    WHERE [NAME] = '{0}'", configurationName));
            return serverConfig?.ToString();
        }
    }
}
