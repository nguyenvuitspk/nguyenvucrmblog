﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExportHeiferLib.FileHelper.Common
{
    public class FileConstants
    {
        public const string EH_REPORT_FILE_PATH = @"EXPORT_HEIFER\REPORT_FILE";
        public const string DEFAULT_EXPORT_FILE_DELIMITER = "\t";
        public const int STRING_BUILDER_LIMIT_CHARACTER = 50000000; //~100MB Memory
        public const string ETL_WEB_DIRECTORY_BIN = "ETL_WEB_DIRECTORY_BIN";
    }
}
