﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CDRGenomicHelper;
using NetworkShareHelper;
using System.Net;
using System.IO;
using ExportHeiferLib.FileHelper.Common;
using System.Data;

namespace ExportHeiferLib.FileHelper
{
    public class FileHelper
    {
        private string F_FilePath;
        public string FilePath
        {
            get
            {
                return F_FilePath;
            }
        }

        public FileHelper(string fileName)
        {
            var networkAccess = new GNetworkAccess(FileConstants.ETL_WEB_DIRECTORY_BIN);

            bool isConnected = NetworkShareHelper.NetworkShareHelper.CheckConnection(networkAccess.RootFolder, networkAccess.Username, networkAccess.Password);
            if (isConnected)
            {
                string folderPath = BuildLocationForFile(networkAccess.RootFolder, Path.Combine(FileConstants.EH_REPORT_FILE_PATH, DateTime.Now.Ticks.ToString()));
                F_FilePath = Path.Combine(folderPath, fileName);

                if (!File.Exists(F_FilePath))
                {
                    File.Create(F_FilePath).Close();
                }
            }
            else
            {
                throw new Exception("Can't connect to server.");
            }
        }

        public string BuildLocationForFile(string baseFolder, string folder)
        {
            string path = string.Format(@"{0}\{1}", baseFolder, folder);
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            return path;
        }

        public void Write(string content)
        {
            using (StreamWriter sw = File.AppendText(F_FilePath))
            {
                sw.WriteLine(content);
            }
        }

        public void Write(DataTable dt, string delimiter = FileConstants.DEFAULT_EXPORT_FILE_DELIMITER, bool isWriteTableHeader = true)
        {
            StringBuilder sb = new StringBuilder();

            if (isWriteTableHeader)
            {
                var columnHeaders = dt.Columns.Cast<DataColumn>().Select(x => x.ColumnName);

                // write header columns
                sb.Append(string.Join(delimiter, columnHeaders));
                sb.AppendLine();
            }

            // write data rows
            foreach (DataRow dr in dt.Rows)
            {
                sb.Append(string.Join(delimiter, dr.ItemArray));
                if (sb.Length >= FileConstants.STRING_BUILDER_LIMIT_CHARACTER)
                {
                    Write(sb.ToString());
                    sb.Clear();
                }
                else
                {
                    sb.AppendLine();
                }
            }

            if (sb.Length > 0)
                Write(sb.ToString());
        }
    }
}
