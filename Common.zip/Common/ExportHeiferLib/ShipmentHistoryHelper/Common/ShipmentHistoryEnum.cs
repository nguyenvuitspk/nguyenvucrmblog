﻿namespace ExportHeiferLib.ShipmentHistoryHelper.Common
{
    public enum ShipmentFileType
    {
        SHIPMENT_100,
        SHIPMENT_200,
        SHIPMENT_201,
        SHIPMENT_202,
        SHIPMENT_203,
    }

    public enum ImportShipmentOperationCode
    {
        EH_IMPORT_SHIPMENT_100,
        EH_IMPORT_SHIPMENT_200,
        EH_IMPORT_SHIPMENT_201,
        EH_IMPORT_SHIPMENT_202,
        EH_IMPORT_SHIPMENT_203
    }

    public enum ShipmentHistoryResultCode
    {
        SUCCESS,
        FAILED
    }
}
