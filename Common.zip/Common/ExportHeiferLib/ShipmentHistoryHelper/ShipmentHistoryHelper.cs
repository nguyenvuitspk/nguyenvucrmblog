﻿namespace ExportHeiferLib.ShipmentHistoryHelper
{
    using DataReaderUtilsLib;
    using System;
    using SQLUtilsLib;
    using Common;

    public class ShipmentHistoryHelper
    {
        public static void LogHistory(string shipmentCode, string exporterCode, ImportShipmentOperationCode operationCode, ShipmentHistoryResultCode resultCode, string message, int lndRunId)
        {
            DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                                string.Format(@"EXEC dbo.usp_eh_log_history @BK_SHIPMENT_CODE = '{0}'
                                                                            ,@BK_EXPORTER_CODE = '{1}'
                                                                            ,@OPERATION_CODE = '{2}'
                                                                            ,@RESULT_CODE = '{3}'
                                                                            ,@MESSAGE = '{4}'
                                                                            ,@LND_RUN_ID = {5}
                                                                            ,@NO_REJECTED_RECORDS = {6}"
                                                                            , shipmentCode, exporterCode, operationCode, resultCode, message, lndRunId.ToString(), GetNumberOfRejectedRecords(operationCode, lndRunId)));
        }

        public static int GetNumberOfRejectedRecords(ImportShipmentOperationCode operationCode, int lndRunId)
        {
            string sqlCmd = "";

            switch (operationCode)
            {
                case ImportShipmentOperationCode.EH_IMPORT_SHIPMENT_100:
                    sqlCmd = @"SELECT COUNT(*)
                                FROM dbo.LND_TABLE_SHIPMENT_100 lt
                                JOIN dbo.LND_SHIPMENT_100 ls ON lt.ROW_ID = ls.ROW_ID
                                WHERE lt.RUN_ID = {0}
	                                AND lt.ROW_REJECT_FLAG = 1";
                    break;
                case ImportShipmentOperationCode.EH_IMPORT_SHIPMENT_200:
                    sqlCmd = @"SELECT COUNT(*)
                                FROM dbo.LND_TABLE_SHIPMENT_200 lt
                                JOIN dbo.LND_SHIPMENT_200 ls ON lt.ROW_ID = ls.ROW_ID
                                WHERE lt.RUN_ID = {0}
	                                AND lt.ROW_REJECT_FLAG = 1";
                    break;
                case ImportShipmentOperationCode.EH_IMPORT_SHIPMENT_201:
                    sqlCmd = @"SELECT COUNT(*)
                                FROM dbo.LND_TABLE_SHIPMENT_201 lt
                                JOIN dbo.LND_SHIPMENT_201 ls ON lt.ROW_ID = ls.ROW_ID
                                WHERE lt.RUN_ID = {0}
	                                AND lt.ROW_REJECT_FLAG = 1";
                    break;
                case ImportShipmentOperationCode.EH_IMPORT_SHIPMENT_202:
                    sqlCmd = @"SELECT COUNT(*)
                                FROM dbo.LND_TABLE_SHIPMENT_202 lt
                                JOIN dbo.LND_SHIPMENT_202 ls ON lt.ROW_ID = ls.ROW_ID
                                WHERE lt.RUN_ID = {0}
	                                AND lt.ROW_REJECT_FLAG = 1";
                    break;
                case ImportShipmentOperationCode.EH_IMPORT_SHIPMENT_203:
                    sqlCmd = @"SELECT COUNT(*)
                                FROM dbo.LND_TABLE_SHIPMENT_203 lt
                                JOIN dbo.LND_SHIPMENT_203 ls ON lt.ROW_ID = ls.ROW_ID
                                WHERE lt.RUN_ID = {0}
	                                AND lt.ROW_REJECT_FLAG = 1";
                    break;
                default:
                    break;
            }

            return Int32.Parse(DataReaderUtilities.GetScalaValue(DBReference.ConnStr_LND,
                                                    string.Format(sqlCmd, lndRunId)).ToString());
        }

        public static int GetNumberOfWarningRecords(ImportShipmentOperationCode operationCode, int lndRunId)
        {
            string sqlCmd = "";

            switch (operationCode)
            {
                case ImportShipmentOperationCode.EH_IMPORT_SHIPMENT_200:
                    sqlCmd = @"SELECT COUNT(*)
                                FROM dbo.LND_TABLE_SHIPMENT_200 lt
                                JOIN dbo.LND_SHIPMENT_200 ls ON lt.ROW_ID = ls.ROW_ID
                                WHERE lt.RUN_ID = {0}
	                                AND lt.ROW_REJECT_FLAG = 0
                                    AND lt.ROW_REJECT_CD = 'WARNING'";
                    break;
                case ImportShipmentOperationCode.EH_IMPORT_SHIPMENT_201:
                    sqlCmd = @"SELECT COUNT(*)
                                FROM dbo.LND_TABLE_SHIPMENT_201 lt
                                JOIN dbo.LND_SHIPMENT_201 ls ON lt.ROW_ID = ls.ROW_ID
                                WHERE lt.RUN_ID = {0}
	                                AND lt.ROW_REJECT_FLAG = 0
                                    AND lt.ROW_REJECT_CD = 'WARNING'";
                    break;
                case ImportShipmentOperationCode.EH_IMPORT_SHIPMENT_202:
                    sqlCmd = @"SELECT COUNT(*)
                                FROM dbo.LND_TABLE_SHIPMENT_202 lt
                                JOIN dbo.LND_SHIPMENT_202 ls ON lt.ROW_ID = ls.ROW_ID
                                WHERE lt.RUN_ID = {0}
	                                AND lt.ROW_REJECT_FLAG = 0
                                    AND lt.ROW_REJECT_CD = 'WARNING'";
                    break;
                case ImportShipmentOperationCode.EH_IMPORT_SHIPMENT_203:
                    sqlCmd = @"SELECT COUNT(*)
                                FROM dbo.LND_TABLE_SHIPMENT_203 lt
                                JOIN dbo.LND_SHIPMENT_203 ls ON lt.ROW_ID = ls.ROW_ID
                                WHERE lt.RUN_ID = {0}
	                                AND lt.ROW_REJECT_FLAG = 0
                                    AND lt.ROW_REJECT_CD = 'WARNING'";
                    break;
                default:
                    break;
            }

            return Int32.Parse(DataReaderUtilities.GetScalaValue(DBReference.ConnStr_LND,
                                                    string.Format(sqlCmd, lndRunId)).ToString());
        }
    }
}
