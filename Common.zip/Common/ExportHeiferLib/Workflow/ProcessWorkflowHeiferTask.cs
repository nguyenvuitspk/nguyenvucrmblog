﻿using ActivityHelper;
using DataReaderUtilsLib;
using ExportHeiferLib.WorkflowImport.Common;
using SQLUtilsLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using ValidationWFHelper;
using ValidationWFHelper.Common;
using WorkflowOperation;

namespace ExportHeiferLib
{
    public class ProcessWorkflowHeiferTask
    {
        private static ProcessWorkflowHeiferTask _instance;
        public static ProcessWorkflowHeiferTask Instance(string ConnStr_SSISDB)
        {
            _instance = new ProcessWorkflowHeiferTask(ConnStr_SSISDB);

            return _instance;
        }
        public ProcessWorkflowHeiferTask(string ConnStr_SSISDB)
        {
            var ConnStr_LND = WorkflowOperation.WorkflowOperation.GetConfigurationValue(ConnStr_SSISDB, "ConnStr_LND");
            var ConnStr_DV = WorkflowOperation.WorkflowOperation.GetConfigurationValue(ConnStr_SSISDB, "ConnStr_DV");
            DBReference.InitiateDBReference(ConnStr_LND, ConnStr_SSISDB, ConnStr_DV);
        }

        public static int ProcessEHWorkflowRunningHeiferTask(int sessionId, Dictionary<string, string> param = null)
        {
            var activityLogId = ActivityLogHelper.CreateActivityLog(sessionId, ActivityTaskCodeConstants.EH_PROCESS_RUNNING_HEIFER_TASK);
            SetActivityLogDescription(param, activityLogId);

            string workflowName = ActivityTaskCodeConstants.EH_RUNNING_HEIFER_TASK_WORKFLOW_NAME;

            try
            {
                // Execute workflow
                var workflow = GetEHRunningHeiferTaskWorkflowDetail(workflowName, param);

                ProcessWFHelper.ExecuteCreateWorkflow(workflow, activityLogId);
            }
            catch (Exception)
            {
                activityLogId = 0;
            }
            
            return activityLogId;
        }

        private static void SetActivityLogDescription(Dictionary<string, string> param, int activityLogId)
        {
            string strXml = null;
            using (StringWriter sWriter = new StringWriter())
            {
                XmlDocument xmlDoc = new XmlDocument();
                XmlNode rootNode = xmlDoc.CreateElement("ACTIVITY_LOG_INFO");
                xmlDoc.AppendChild(rootNode);

                XmlNode node;
                foreach (var item in param)
                {
                    node = xmlDoc.CreateElement(item.Key);
                    node.InnerText = item.Value;
                    rootNode.AppendChild(node);
                }

                XmlWriterSettings xmlSettings = new XmlWriterSettings()
                {
                    OmitXmlDeclaration = true
                };
                XmlWriter xmlWriter = XmlWriter.Create(sWriter, xmlSettings);

                XmlSerializerNamespaces xmlNamespaces = new XmlSerializerNamespaces();
                xmlNamespaces.Add(string.Empty, string.Empty);

                XmlSerializer serializer = new XmlSerializer(typeof(XmlDocument));
                serializer.Serialize(xmlWriter, xmlDoc, xmlNamespaces);

                strXml = sWriter.ToString();
            }

            DataReaderUtilities.GetScalaValue(
                DBReference.ConnStr_DV,
                string.Format(@"UPDATE [report].[ACTIVITY_LOGS] SET DESCRIPTION = N'{0}' WHERE PID = {1}", strXml, activityLogId));
        }

        private static Workflow GetEHRunningHeiferTaskWorkflowDetail(string workflowName, Dictionary<string, string> param)
        {
            var arrayWfName = workflowName.Split(@"-".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            try
            {
                if (arrayWfName.Length == 4)
                {
                    var workflow = WorkflowOperation.WorkflowOperation.GetSystemWorkflowByName(workflowName);

                    if (param != null && param.Count == 3)
                    {
                        foreach (var item in param)
                        {
                            if (item.Key.Equals("BK_SHIPMENT_CODE") || item.Key.Equals("BK_EXPORTER_CODE") || item.Key.Equals("SESSION_ID"))
                            {
                                workflow.Transformations[0].Parameters.FirstOrDefault(c => c.Name == item.Key).Value = item.Value;
                            }
                        }
                    }

                    var shipmentExporterID = GetShipmentExporterID(param["BK_SHIPMENT_CODE"], param["BK_EXPORTER_CODE"]);
                    if (shipmentExporterID != Guid.Empty)
                    {
                        var additionalParam = CreateNewRunningHeiferTask(shipmentExporterID);
                        if (additionalParam != null && additionalParam.Count == 2)
                        {
                            foreach (var item in additionalParam)
                            {
                                if (item.Key.Equals("PK_EH_REQUEST_SE_ID") || item.Key.Equals("PK_SERVICE_REQUEST_ID"))
                                {
                                    workflow.Transformations[0].Parameters.FirstOrDefault(c => c.Name == item.Key).Value = item.Value.ToString();
                                }
                            }
                            workflow.ConsumerID = WFConstant.ConsumerID;

                            return workflow;

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return null;
        }

        private static Guid GetShipmentExporterID(string shipmentCode, string exporterCode)
        {
            var shipmentExporterID = DataReaderUtilities.GetScalaValue(DBReference.ConnStr_DV,
                                   string.Format(@"select link.PK_SHIPMENT_EXPORTER_ID from [dbo].[LNK_SHIPMENT_EXPORTERS] as link
	                                                    join [dbo].[HUB_SHIPMENTS] as hubShip ON link.PK_SHIPMENT_ID = hubShip.PK_SHIPMENT_ID
	                                                    join [dbo].[HUB_EXPORTERS] as hubExp ON link.PK_EXPORTER_ID = hubExp.PK_EXPORTER_ID
	                                                    WHERE hubShip.BK_SHIPMENT_CODE = '{0}' AND hubExp.BK_EXPORTER_CODE = '{1}'", shipmentCode, exporterCode));
            return Guid.Parse(shipmentExporterID?.ToString());
        }

        private static Dictionary<string, Guid> CreateNewRunningHeiferTask(Guid shipmentExporterID)
        {
            DataSet datasets = new DataSet();
            Dictionary<string, Guid> result = new Dictionary<string, Guid>();

            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(DBReference.ConnStr_DV);
                using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                {
                    connection.Open();
                    // Configure the SqlCommand and SqlParameter. 
                    SqlCommand cmd = new SqlCommand("dbo.usp_eh_heifer_task_new_run", connection);
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlParameter bkShipmentExporterID = cmd.Parameters.AddWithValue("@PK_SHIPMENT_EXPORTER_ID", shipmentExporterID);
                    bkShipmentExporterID.SqlDbType = SqlDbType.UniqueIdentifier;

                    SqlParameter pkEHRequestSEID = cmd.Parameters.Add("@PK_EH_REQUEST_SE_ID", SqlDbType.UniqueIdentifier);
                    pkEHRequestSEID.Direction = ParameterDirection.Output;

                    SqlParameter pkServiceRequestID = cmd.Parameters.Add("@PK_SERVICE_REQUEST_ID", SqlDbType.UniqueIdentifier);
                    pkServiceRequestID.Direction = ParameterDirection.Output;

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                    adapter.SelectCommand.CommandTimeout = 0;
                    adapter.Fill(datasets);

                    result.Add("PK_EH_REQUEST_SE_ID", Guid.Parse(pkEHRequestSEID.Value?.ToString()));
                    result.Add("PK_SERVICE_REQUEST_ID", Guid.Parse(pkServiceRequestID.Value?.ToString()));

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }
    }
}
