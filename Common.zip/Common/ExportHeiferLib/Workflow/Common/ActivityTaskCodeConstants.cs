﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExportHeiferLib.WorkflowImport.Common
{
    public class ActivityTaskCodeConstants
    {
        public const string EH_PROCESS_IMPORT_SHIPMENT_100 = "EH_IMPORT_SHIPMENT_100";
        public const string EH_PROCESS_IMPORT_SHIPMENT_200 = "EH_IMPORT_SHIPMENT_200";
        public const string EH_PROCESS_IMPORT_SHIPMENT_201 = "EH_IMPORT_SHIPMENT_201";
        public const string EH_PROCESS_IMPORT_SHIPMENT_202 = "EH_IMPORT_SHIPMENT_202";
        public const string EH_PROCESS_IMPORT_SHIPMENT_203 = "EH_IMPORT_SHIPMENT_203";

        public const string EH_PROCESS_RUNNING_HEIFER_TASK = "EH_RUN_HEIFER_TASK";

        public const string EHImport100WorkflowName = "WF-EH-F2D-SHIPMENT-100";
        public const string EHImport200WorkflowName = "WF-EH-F2D-SHIPMENT-200";
        public const string EHImport201WorkflowName = "WF-EH-F2D-SHIPMENT-201";
        public const string EHImport202WorkflowName = "WF-EH-F2D-SHIPMENT-202";
        public const string EHImport203WorkflowName = "WF-EH-F2D-SHIPMENT-203";

        public const string EH_RUNNING_HEIFER_TASK_WORKFLOW_NAME = "WF-EH-HEIFER-TASK";
    }
}
