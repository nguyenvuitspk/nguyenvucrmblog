﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExportHeiferLib.WorkflowImport.Common
{
    public enum ShipmentImportType
    {
        File_100 = 100,
        File_200 = 200,
        File_201 = 201,
        File_202 = 202,
        File_203 = 203
    }
}
