﻿using ActivityHelper;
using DataReaderUtilsLib;
using ExportHeiferLib.WorkflowImport.Common;
using SQLUtilsLib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;
using ValidationWFHelper;
using ValidationWFHelper.Common;
using WorkflowOperation;

namespace ExportHeiferLib.WorkflowImport
{
    public class ProcessWorkflowImport
    {
        private static ProcessWorkflowImport _instance;
        public static ProcessWorkflowImport Instance(string ConnStr_SSISDB)
        {
            _instance = new ProcessWorkflowImport(ConnStr_SSISDB);

            return _instance;
        }
        public ProcessWorkflowImport(string ConnStr_SSISDB)
        {
            var ConnStr_LND = WorkflowOperation.WorkflowOperation.GetConfigurationValue(ConnStr_SSISDB, "ConnStr_LND");
            var ConnStr_DV = WorkflowOperation.WorkflowOperation.GetConfigurationValue(ConnStr_SSISDB, "ConnStr_DV");
            DBReference.InitiateDBReference(ConnStr_LND, ConnStr_SSISDB, ConnStr_DV);
        }
        public static int ProcessEHWorkflowImportShipmentFile(ShipmentImportType type, string filePath, int sessionId, Dictionary<string, string> param = null)
        {
            string taskCode = GetEHTaskCodeImportShipmentFileName(type);
            var activityLogId = ActivityLogHelper.CreateActivityLog(sessionId, taskCode);
            if (type == ShipmentImportType.File_200)
            {
                SetActivityLogDescription(param, activityLogId);
            }

            string workflowName = GetEHWorkflowImportShipmentFileName(type);
            // Execute workflow
            param = type == ShipmentImportType.File_100 ? null : param;
            var workflow = GetEHImportFileWorkflowDetail(workflowName, filePath, param);

            ProcessWFHelper.ExecuteCreateWorkflow(workflow, activityLogId);

            return activityLogId;
        }

        private static void SetActivityLogDescription(Dictionary<string, string> param, int activityLogId)
        {
            string strXml = null;
            using (StringWriter sWriter = new StringWriter())
            {
                XmlDocument xmlDoc = new XmlDocument();
                XmlNode rootNode = xmlDoc.CreateElement("ACTIVITY_LOG_INFO");
                xmlDoc.AppendChild(rootNode);

                XmlNode node;
                foreach (var item in param)
                {
                    node = xmlDoc.CreateElement(item.Key);
                    node.InnerText = item.Value;
                    rootNode.AppendChild(node);
                }

                XmlWriterSettings xmlSettings = new XmlWriterSettings()
                {
                    OmitXmlDeclaration = true
                };
                XmlWriter xmlWriter = XmlWriter.Create(sWriter, xmlSettings);

                XmlSerializerNamespaces xmlNamespaces = new XmlSerializerNamespaces();
                xmlNamespaces.Add(string.Empty, string.Empty);

                XmlSerializer serializer = new XmlSerializer(typeof(XmlDocument));
                serializer.Serialize(xmlWriter, xmlDoc, xmlNamespaces);

                strXml = sWriter.ToString();
            }

            DataReaderUtilities.GetScalaValue(
                DBReference.ConnStr_DV,
                string.Format(@"UPDATE [report].[ACTIVITY_LOGS] SET DESCRIPTION = N'{0}' WHERE PID = {1}", strXml, activityLogId));
        }

        private static string GetEHTaskCodeImportShipmentFileName(ShipmentImportType type)
        {
            string result = string.Empty;
            switch (type)
            {
                case ShipmentImportType.File_100:
                    result = ActivityTaskCodeConstants.EH_PROCESS_IMPORT_SHIPMENT_100;
                    break;
                case ShipmentImportType.File_200:
                    result = ActivityTaskCodeConstants.EH_PROCESS_IMPORT_SHIPMENT_200;
                    break;
                case ShipmentImportType.File_201:
                    result = ActivityTaskCodeConstants.EH_PROCESS_IMPORT_SHIPMENT_201;
                    break;
                case ShipmentImportType.File_202:
                    result = ActivityTaskCodeConstants.EH_PROCESS_IMPORT_SHIPMENT_202;
                    break;
                case ShipmentImportType.File_203:
                    result = ActivityTaskCodeConstants.EH_PROCESS_IMPORT_SHIPMENT_203;
                    break;
                default:
                    break;
            }
            return result;
        }

        private static string GetEHWorkflowImportShipmentFileName(ShipmentImportType type)
        {
            string result = string.Empty;
            switch (type)
            {
                case ShipmentImportType.File_100:
                    result = ActivityTaskCodeConstants.EHImport100WorkflowName;
                    break;
                case ShipmentImportType.File_200:
                    result = ActivityTaskCodeConstants.EHImport200WorkflowName;
                    break;
                case ShipmentImportType.File_201:
                    result = ActivityTaskCodeConstants.EHImport201WorkflowName;
                    break;
                case ShipmentImportType.File_202:
                    result = ActivityTaskCodeConstants.EHImport202WorkflowName;
                    break;
                case ShipmentImportType.File_203:
                    result = ActivityTaskCodeConstants.EHImport203WorkflowName;
                    break;
                default:
                    break;
            }
            return result;
        }

        public static Workflow GetEHImportFileWorkflowDetail(string workflowName, string fullPathFile, Dictionary<string, string> param)
        {
            var pathLevels = fullPathFile.Split(@"\".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            if (pathLevels.Length == 7)
            {
                var arrayWfName = workflowName.Split(@"-".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                if (arrayWfName.Length == 5)
                {
                    var workflow = WorkflowOperation.WorkflowOperation.GetSystemWorkflowByName(workflowName);

                    workflow.Transformations[0].Parameters.FirstOrDefault(c => c.Name == "FilePath").Value =
                        string.Format(@"{0}\{1}\{2}\{3}",
                            pathLevels[3],
                            pathLevels[4],
                            pathLevels[5],
                            pathLevels[6]);

                    if (param != null && param.Count > 0)
                    {
                        foreach (var item in param)
                        {
                            if (item.Key.Equals("BK_SHIPMENT_CODE") || item.Key.Equals("BK_EXPORTER_CODE") || item.Key.Equals("SESSION_ID") || item.Key.Equals("SOURCE"))
                            {
                                workflow.Transformations[0].Parameters.FirstOrDefault(c => c.Name == item.Key).Value = item.Value;
                            }
                        }
                    }
                    

                    workflow.Transformations[0].Parameters.FirstOrDefault(c => c.Name == "SourceDirectory").Value =
                        string.Format(@"\\{0}\{1}\{2}",
                            pathLevels[0],
                            pathLevels[1],
                            pathLevels[2]);

                    workflow.Transformations[0].Parameters.FirstOrDefault(c => c.Name == "CompleteDirectory").Value =
                        string.Format(@"\\{0}\{1}\{2}\COMPLETE",
                            pathLevels[0],
                            pathLevels[1],
                            pathLevels[2]);

                    workflow.Transformations[0].Parameters.FirstOrDefault(c => c.Name == "FailedDirectory").Value =
                        string.Format(@"\\{0}\{1}\{2}\FAILED",
                            pathLevels[0],
                            pathLevels[1],
                            pathLevels[2]);

                    workflow.Transformations[0].Parameters.FirstOrDefault(c => c.Name == "RejectDirectory").Value =
                        string.Format(@"\\{0}\{1}\{2}\REJECT",
                            pathLevels[0],
                            pathLevels[1],
                            pathLevels[2]);

                    workflow.ConsumerID = WFConstant.ConsumerID;

                    return workflow;
                }
            }

            return null;
        }
    }
}
